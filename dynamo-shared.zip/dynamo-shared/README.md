# dynamo-shared — the single source of truth for Dynamo work

Every Dynamo repo reads from here. **Nothing in this folder is ever copied into a repo.** That is
the whole point: copies fork, and forks lose things. On 2026-07-28 a consolidation found 17 copies
of `TASK_RETROSPECTIVE.md` in two lineages, and an **accepted task's entire record** surviving in
exactly one of them.

This folder is a local git repo. It is never pushed anywhere.

## What is here

| File | What it is |
|---|---|
| `TASK_RETROSPECTIVE.md` | **The** retrospective. One file. Append-only. |
| `Dynamo_Reference_Rulebook.md` | Build rules and gate mechanics. |
| `Dynamo_Workflow_Claude.md` | Working method. |
| `NEXT_TASK_PROMPTS.md` | Claim prompts and concept starters. |
| `DYNAMO_HANDOFF.md` | Cross-session handoff: theory, evidence, process facts. |
| `notes/` | Raw source material — Slack exports, examples. Never edited, only added to. |
| `inbox/` | Per-task findings awaiting merge. **The only place a session writes during a task.** |
| `archive/` | Superseded copies, kept so any merge can be checked. |

## The write protocol

**Read anything here, any time, from any repo.**

**During a task, write only `inbox/<repo-hash>-<slug>.md`.** One file per task, one writer per
file, so concurrent sessions never touch the same file. Append findings as they are *measured* —
numbers, not plans.

**Merge into `TASK_RETROSPECTIVE.md` only at a task boundary** — accepted, released, or abandoned.
Never mid-task.

### Merging, precisely

1. **Check `.merge-lock`.** If it exists and is less than an hour old, do not merge — leave the
   work in `inbox/` and say so. Merges are never urgent.
2. **Take the lock**: write `.merge-lock` with the date and which repo you are merging for.
3. **`Edit`-append. Never `Write` the retrospective.** `Write` is a whole-file overwrite and will
   silently erase anything another session merged since you last read. `Edit` is exact-string
   replacement against current on-disk content, so disjoint edits both land — and a colliding
   append **fails loudly** because the anchor text has moved, which is the behaviour you want.
4. **Assign the section number at merge time**, never in the inbox. Read the current maximum, take
   the next one. Two sessions cannot both claim §26 if neither claims a number until it merges.
5. **Commit** — one commit per merge, message naming the task.
6. **Delete the lock** and the merged inbox file.

### Two rules that are not negotiable

- **Never renumber sections.** They are cross-referenced by number throughout; renumbering breaks
  every reference silently. §25 predates §23 and that is fine — trust the dates in the headings.
- **Never rewrite a finished task's section.** If it turns out to be wrong, add a superseding note
  at the top of it and leave the original text. §23c is the worked example: its evidence stayed,
  its conclusion got a warning pointing at §25d.

## Why git

Not ceremony. It means a bad merge is `git checkout` rather than archaeology, that two sessions
colliding produces a visible conflict instead of a silent overwrite, and that the near-loss that
prompted this folder cannot happen again — every prior state is in history.

Commit after each inbox write and after each merge. Local only; no remote, ever.

## What stays in the repo instead

Repo-specific things do **not** live here: the repo's `CLAUDE.md` (task state, next action, its
own constraints), concept and diagnosis docs, PR feedback captures, proposals for that task. The
split is: **strategy and history here, this-task state there.**
