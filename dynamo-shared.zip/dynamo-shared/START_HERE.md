# START HERE — how to run a Dynamo task with Claude

Open this file any time you forget. It is the whole workflow, fork to finish.

**The one thing to remember:** you never copy files between folders any more. Claude finds
everything itself, because `~/.claude/CLAUDE.md` points it here automatically at session start.

---

## Step 1 — Fork and clone

Fork the task repo on the Dynamo platform, then in a terminal:

```
cd C:\Users\ADMIN\Desktop
gh repo clone BeverlyAnnBushie/dynamo-<hash>-<category>
```

Nothing else. No docs to copy in.

## Step 2 — Open Claude **inside that folder** and say:

> New Dynamo repo — set it up.

This matters: the working directory must be the new repo, or its `CLAUDE.md` will not load later.

Claude will fix `.gitignore` and line endings, read the pre-seeded category and subcategory, write
the repo's own `CLAUDE.md`, and open an inbox file in `dynamo-shared/inbox/`. Takes a few minutes.

**Why this step is not optional.** A freshly forked repo ignores only Python and Node junk. It does
**not** ignore `jobs/` — the Harbor run directory, which holds the solved answer and `reward.txt` —
nor root `*.md` / `*.txt`, which is how working notes end up in a submission and fail the
`no_extraneous_files` check. The exact block is in `~/.claude/CLAUDE.md`.

If you want to confirm it worked, ask: *"show me git status and confirm nothing but task files is
tracked."*

## Step 3 — Design, before any code

> Design the task. Bench the crux on paper before writing any code.

Claude reads the retrospective and proposes concepts with the crux measured, not assumed. **Do not
skip the bench.** It is what catches "the model's standard move already solves this" *before* you
spend a day building — which is exactly what nearly sank the image task.

Expect to be asked which concept to take. That is the one decision that is genuinely yours.

## Step 3b — Write the proposal

> Write the proposal from the template. Use the humanizer skill.

**Every task needs one. It is not optional.** Writing it *after* the PR goes green is fine and
often preferable — by then you know the proposal describes something that works — but a task
without one is unfinished. If Claude ever suggests skipping it on an accepted task, it is wrong;
say so and it will write it from `task.toml` and the design notes.

**Say "use the humanizer skill".** The template also carries the house style, and it is strict:
plain professional prose, **no em dashes, no bullets or numbered lists, no underlined or decorated
headings, no filler**. If what comes back has bullets in it, say "prose only, no lists" and it
will redraft.

The proposal is not technically part of the repo, which is why root `*.md`/`*.txt` are gitignored
everywhere. It still lives in the task repo, for convenience.

Every repo keeps it at `PROPOSAL.txt`, same name everywhere. The template is
`dynamo-shared/PROPOSAL_TEMPLATE.txt` and it covers what a reviewer asks: why the task is hard, who
does this work in reality, whether the data is synthetic, the pitfalls that produce a wrong answer,
the intended solution and expert effort, how grading distinguishes right from wrong, and the
category justification.

One thing gets checked here rather than later: the answer has to be **uniquely determined** by what
the agent can see, or the task gets blocked as underdetermined.

The proposal's only taxonomy content is the **category / sub-category justification**.

## Step 3c — Answer the task_objective and artifact_type questions

> Pick task_objective and artifact_type and say why each fits.

These are **separate questions, asked once per task** — not part of the proposal. They come from the
closed sets in `TAXONOMY_CHEATSHEET.md`, chosen by the four questions in that file rather than
copied from the last task, and they go in `task.toml`.

Worth doing properly: the review rubric grades them (`accurate_taxonomy_labels`), and defaulting to
the last task's pair is how the corpus ends up concentrated on two labels.

## Step 4 — Build

> Build it. Oracle 1.0, nop 0.0, and a mutant matrix before we push.

The mutant matrix is not optional: it proves the tests actually fail when the answer is wrong. A
task that has not been mutant-checked is not ready.

## Step 5 — Push **once**

> Pre-flight, then push once.

**Every push is destructive.** It cancels any run in flight and its verdict replaces the previous
one — and because the difficulty gates are stochastic, a green PR can go red on identical code.
So: batch every fix into a single push, and **never push to a PR that is passing or mid-run.**

## Step 6 — Read the result

> Read the run and tell me what happened.

Claude pulls the real numbers from the CI logs and artifacts rather than the PR comments, which go
stale. It writes what it found to the inbox file.

Then loop: fix → **one** push → read. Usually two or three rounds.

## Step 7 — When the task ends

Whether it was accepted, released, or abandoned:

> The task is <accepted / released / abandoned> — merge the findings into the retrospective.

This is the only time the retrospective gets edited. It is how the next task learns from this one,
and skipping it is how knowledge got lost before.

---

## If something looks wrong

| Symptom | Say this |
|---|---|
| Claude seems not to know about the shared folder | "What does my global CLAUDE.md say about pushing, and where does the retrospective live?" — if it has to go searching, tell me and we will re-wire it |
| A gate fails and the PR comment makes no sense | "Pull the real verdict from the run logs and artifacts, not the PR comments" |
| A gate fails and it looks like Dynamo's side, not the task | "Wait a few hours, then one push." Nothing else. Don't let Claude propose raising it with the team |
| Claude wants to push a second fix straight after the first | "No — one push. Batch them." |
| Claude proposes rebuilding a task that is close | "Don't rebuild. What do the last trial numbers actually say?" |
| Two Claude sessions running at once | Fine by design — each writes its own inbox file. Neither touches the retrospective until step 7 |

## Where things live

- **`dynamo-shared/`** — strategy and history. Shared by every task. Read freely; only step 7 writes
  to the retrospective.
- **`dynamo-shared/inbox/`** — one file per task in progress. This is where findings go meanwhile.
- **The task repo** — that task's own `CLAUDE.md`, concept notes, diagnosis, PR feedback. Nothing
  shared lives here.

## The four rules that actually matter

1. **One push at a time**, and never onto a passing or running PR.
2. **Bench the crux on paper** before building.
3. **Never edit the pre-seeded `task.toml` fields** (`category`, `subcategory`, `model_tested`,
   `agent_tested`).
4. **Merge to the retrospective only when the task ends** — never mid-task.
