# Dynamo — Cross-Task Retrospective, Pitfalls & Strategy

_Local working doc. Not part of any submission (see `.gitignore`). Covers **4 tasks / ~18 pipeline runs**, ending 2026-07-16._

> **⚠️ Scope and status.** This is a **historical log**, not a status board. Everything below happened on **earlier repos** — the long-running case study is `repair-order-etl` in the `data-processing-and-etl` repo. It is kept because the *mechanisms* transfer to any category, not because any of it describes current work.
>
> **Where that case study actually ended:** ACCEPTED on `4815529` (run 29374946300 — pass@5 = 2 solved / 3 good-valid anchors, avg@5 0.400, all 8 gates green), then **reopened by a second human reviewer** who judged the 3 fails too convergent on one code path and required rerun-robust hardening. §11 covers that round; its first read (run 29527291349) passed pass2 on a JSON-wedge fail and carried **zero crux signal**. So: accepted once, reopened, unresolved. §10e is superseded by §11.
>
> **How to read this file.** §1-§3 and §6-§7 are the transferable strategy: the disclosure paradox, the infra tax, and the gate mechanics. §10c and §11 are the most valuable pages — they describe the only trap family that has ever reliably worked. §0, §4, §5, §8, §9 are task-specific evidence for a ledger-ETL task; mine them for mechanism, ignore the specifics. **Anything here that contradicts the current repo's `README.md`, its `task.toml`, or a live PR bot comment is stale — the live pipeline wins.**
>
> **The one-paragraph version.** Across 4 tasks, disclosed difficulty never worked: a frontier model transcribes any rule you write down and derives any property you merely describe. Two things have ever produced genuine failures. First, **execution/engineering difficulty the spec cannot hand over** (out-of-core limits, crash and concurrency correctness). Second, and far more reliably, **protocol and lifecycle semantics whose violation leaves every output byte correct** — signals that must not fire on a skipped path, first-boot races, crash-window ordering. The gate needs ≥3 fails of 5 **with ≥1 anchor**, which one trap at p≈0.3 cannot reach; you need two independent axes that each bite the *converged, correct* design. Budget one or two reruns per real read, because roughly half of all runs have been lost to provider rate limits.

---

## 0. Scoreboard — every attempt and its true root cause

The pattern that matters is **which task _shape_ can even in principle produce a valid agent failure**, and **whether infra let us read it**.

| # | Task / commit | Shape | Verdict | Real root cause |
|---|------|-------|------------------|-----------------|
| 1 | `expand-gtfs` | single-file exact-match ETL | **2/2 solved** | disclosed conventions transcribed |
| 2 | `expand-gtfs` +interp/dedup | same | **2/2 solved** | same |
| 3 | `expand-gtfs` +UTC/DST | same | `review` FAIL | self-inflicted instruction/golden contradiction |
| 4 | `expand-gtfs` realigned | same | **2/2 solved** | same paradox |
| 5 | `ecommerce-etl` | multi-output exact-match ETL | **1/2** (fail = timeout) | the 1 "fail" was infra, not analytical |
| 6 | `ecommerce-etl` +dedup +outlier | same | **2/2 solved** | composed disclosed rules still transcribed |
| 7 | `resolve-contact-graph` `f9c1b68` | **out-of-core** entity resolution | `pass2` PASS, `trials` FAIL | **verifier OOM'd itself** (task/verifier defect) |
| 8 | `resolve-contact-graph` `5ebdb7d` | same | `pass2` 0/2 both `RateLimitError` | **infra void** (rerun) — strongest difficulty signal seen (agents OOM'd 2–3×, burned 60 min) |
| 9 | `resolve-contact-graph` `7d45c18` | same | `pass2` 0/2 both `RateLimitError` | **infra void** (rerun) |
| 10 | `resolve-contact-graph` `30d6c43` | same | **`pass2` 2/2 solved** | too-easy at 12M — model solves out-of-core CC within the hour → pivot |
| 11a | `repair-order-etl` `0c74bae` | crash-safe concurrent ledger repair | `review` FAIL (`no_extraneous_files`) | pivot left 2 stray files; `git rm` fixed |
| 11b | `repair-order-etl` `f89353f` | same | **`pass2` 2/2 solved, "too easy"** | one global flock made the whole surface robust-by-construction |
| 11c | `repair-order-etl` `ce056a4` (concurrency hardening) | same | `review`+`pass2` PASS; **`trials` pass@5 FAIL** | **5/5 infra void** (OpenRouter) — 0 signal |
| 11d | `repair-order-etl` `63cc4b1` (rerun) | same | **pass@5 = 3 solved / 2 fail** | **CLOSEST EVER** — 2 clean-anchor fails; gate needs 3; one short |
| 11e | `repair-order-etl` `118777e` (+stale-clobber CAS test) | same | **pass@5 = 4 solved / 1 fail** | CAS test fired on **nobody** (disclosed invariant transcribed); only the stale-repair self-test blind spot bit |
| 12 | `repair-order-etl` `182930f` (+multi-file `customer_totals` + exact-int trap) | **multi-file** exact-match | `review`+`pass2` PASS; **`trials` pass@5 = infra void** | **4/5 OpenRouter `RateLimitError`**; 1 trial ran and solved 29/29 → **no difficulty read** |
| 12b | `repair-order-etl` `a77495a` (run 29235719274) | same | **`pass2` FAIL — 0 valid of 2** | **NOT infra: both trials in-progress-timeout.** The 5-module rewrite + publication scaffolding no longer fits the hard 3600 s cap. Trial 1: full rewrite, died mid-fix of a self-inflicted f-string SyntaxError (`state_store.py:248`). Trial 2: **28/29**, one-word typo `_STAGED_COLUMNS` vs `_STAGE_COLUMNS` in the intra-batch-duplicate `IntegrityError` branch, cut mid-generation. Both `low_timeout` FAIL → **labor regression, not difficulty signal** |
| 13 | `repair-order-etl` `7ff81a3` (starter pre-pays atomic publication) | same | `review`+`pass2`+`deep_review` PASS; **`trials` pass@5 = 4/5 solved, 1 anchor → "not hard enough"** (run 29288540489) | **First fully-clean read ever: 0 infra, 0 timeouts, all 7 trials graded** (`low_timeout` PASS ×7 — the labor fix worked). Both fails were the **stale-repair blind spot**: pass2's = hardlink-inode aliasing (`os.link` → `write_bytes` corrupts both → `_same_file` skips repair), pass@5's = symlink-target generation encoding (in-place corruption leaves symlink intact → CAS skips). **SQL `SUM` overflow trap fired on NOBODY** — all 5 pass@5 agents summed with Python ints; the disclosed "may exceed signed 64-bit" line was transcribed, even with `SUM` shipped in the starter |
| 14 | `repair-order-etl` `ce6a32b` (+3 independent traps: output-dir hygiene, concurrent-identical TOCTOU, after_metrics_replace crash) | same | **`review` Stage 2 FAIL — infra void** (run 29307194747) | **NEW infra flavor: Anthropic 429 on `claude-opus-4-8`** in the *Stage 2 rubric review* step (not OpenRouter, not trials). "rate limit of 13,000,000 input tokens/min" → `no verdict produced` → gate red. Static checks (Stage 1) PASS; pass2/similarity/validation/deep_review/trials never ran (all downstream of gate). Sticky "Automated Review" comment is **stale** (still shows 29 tests / line 730). **Traps unaffected** — local matrix still oracle 32/32, starter 21F/11P, 3 variants isolate cleanly. |
| 14-rerun | `repair-order-etl` `83d8bb6` (empty-commit rerun of 14) | same | **`review` Stage 2 FAIL — infra void AGAIN** (run 29307720499) | Same org key `4f8bcc30…`, `claude-opus-4-8`, but a **different limit**: "20,000 **requests** per minute" (vs 13M tokens/min before). Two reruns ~12 min apart both voided → the org key is **saturated by external load** (shared project-paid key, many concurrent Dynamo reviews), our one review call is collateral. **LESSON: rapid empty-commit reruns do NOT clear an org-wide Anthropic 429 — they land in the same saturated window and waste a push. Wait hours, not minutes, and/or escalate to a Dynamo admin in Slack (precedent: thread on `dynamo-4d2faae`).** Do NOT change the task. |
| 14-rerun2 | `repair-order-etl` (pending) | same | **SCHEDULED** — one-shot cloud routine `trig_01W2VkGwCLAQL8XFsRqcGKCj` fires **2026-07-14T09:20Z (12:20 PM EAT)** | Deliberately spaced ~4 h out (not another rapid retry) to let the org Anthropic window clear. Cloud agent (sonnet-5) pushes **one** empty commit to `submission`, then reads the new run's Stage 2 `review / review` job and reports whether the 429 cleared; instructed to push once and NOT retry on another void. Result lands in the cloud session (https://claude.ai/code/routines/trig_01W2VkGwCLAQL8XFsRqcGKCj), not the local session. Required a one-time GitHub connect (`/web-setup`) — the routine API 401s without it. ⚠ 09:20Z is mid-morning EU working hours = still likely-high review load; if it voids again, re-arm for a genuinely quiet UTC window and/or escalate. |
| 14-read | `7e61f70` (routine's empty commit; content = `ce6a32b`) — run 29321434451 | same (32 cases) | **`trials` pass@5 = 5/5 solved, avg 1.000 → "no anchor fail"** | The spaced routine rerun **cleared the 429** (mechanism works). First clean read of §9's Traps A/B/C: **fired on nobody at pass@5** (pass2 did pass with ≥1 counted fail; detail lost — sticky overwritten by later runs). Disclosed hygiene/TOCTOU surfaces transcribed like every disclosed rule before them |
| 15 | `197a6b5` (+`35a7c05` LF pin, no content change) — read via `bca5210`, run 29347978990 | deeper multi-contract repair, 32→37 cases (staging/writer-lock races, staged-ID TOCTOU, WAL first-open bootstrap, slow-reader coherence, crashed-newer fencing, in-place repair variants; Trap A + `after_metrics_replace` dropped with their contracts) | `pass2` **1/2** (symlink-**target** generation encoding — `task__R6WPKHg`); **`trials` pass@5 = 5/5 → "no anchor"** | Every added contract was **disclosed → transcribed**; the 12b labor fear did **not** recur (0 timeouts — agents complete ~600-line rewrites in ~44-55 min now). En route: **3× Anthropic-429 Stage-2 voids** (14:21 `197a6b5` run 29340009056, 14:43 `7db33ac` 29341862447, 15:14 `35a7c05` 29344194932) — 22/31-min gaps both re-voided; ~49-min gap cleared |
| 16 | `0e9a2b4` (de-disclosure: drop the SUM-overflow warning + "don't load event-ID set" prescription) — run 29368019041 | same | **`pass2` 2/2 solved → blocked before `trials`** | **Weights beat prose:** one agent (`task__MBK3zvp`) *explicitly identified the int64 SQL SUM overflow risk in its own step-13 reasoning* with the warning removed. `task_specification` stayed PASS ×2 → de-disclosure is **safe but insufficient**: disclosed mechanisms get transcribed, disclosed *properties* get derived, undisclosed on-idiom consequences get dodged by trained habit |
| 17 | `4815529` (stdlib-betrayal round: two-layer timestamp cases, hook-on-skip probes, BOM, scalar-value surface) — run 29374946300 | same (37 cases) | **✅ ACCEPTED** — `pass2` **1/2** (WAL first-open bootstrap race: `busy_timeout` instead of pre-connect flock — `task__KMsv7Uk`); **`trials` pass@5 = 2 solved / 3 good-valid anchors, avg 0.400**; all 8 gates green | **All three pass@5 kills = one blind spot: unconditional `reach('after_orders_replace')` on the stale-generation skip path** (2× unchecked return, 1× retry-loop re-render past a `>` fence). One agent (`task__bF9mFjF`) *predicted the bug in its own reasoning and shipped it anyway*. The strptime/BOM cruxes went untouched. Two independent axes (hook precision + WAL bootstrap) stacked to **4 analytical fails / 7 trials ≈ p 0.57** |
| 18 | stale-fence hardening round (2026-07-16, this session) | deeper publication protocol, 37→39 cases | **PENDING** — second reviewer rejected the accepted state ("pass@5 2/5 w/ 3 valid fails" needs rerun-robustness), prescribed Situation-C hardening of the same crux | All 3 prior kills converged on one path; reviewer wants the crux to survive a rerun. Implemented: stand-down/equal-retry instruction sentence, per-file fenced swaps in reference, `after_metrics_replace`+`after_publish` disclosed, graded races (a) untouched-bytes+mtime+markers, (b) equal-gen crash resume must signal, (c) mid-set fence with per-phase gating. See §11 |

**Two headline facts:**
1. **Difficulty:** attempts 1–6 (single-file / multi-output exact-match) never produced a valid fail. Attempts 7–12 (execution-hard shapes) did make the model struggle, and 11d got within one fail of the hardest gate.
2. **Infra:** at least **4 runs (8, 9, 11c, 12)** were voided by OpenRouter `gpt-5.4` rate limits before the verifier could score them. **You cannot read difficulty through an infra void — budget 1–2 reruns per real read.**

---

## 1. Wall A — the disclosure paradox / structural difficulty ceiling

Dynamo's gate needs **≥1 _valid_ agent failure** (genuine difficulty — not spec ambiguity, not verifier bug, not infra). A clean solve = "too easy" = blocked.

**The paradox (proved 8+ times):** exact-match verification *forces* full disclosure — every convention must be written into `instruction.md` or a correct-by-domain solution mismatches the golden (which is judged a *task bug*, and also blocks). But **once a rule is on the page, the frontier model transcribes it.** Difficulty that lives in a *convention* evaporates under the disclosure exact-match requires.

**Corollaries earned the hard way:**
- **Composition doesn't save it.** Stacked interacting rules (dedup-before-filter, iterative outliers, event-ordering joins, day-first dates) were all composed correctly — one trial even wrote a post-hoc audit script to self-check.
- **Genuine computation doesn't save it.** The GTFS DST "noon−12h" footgun was implemented correctly *and* the model authored synthetic DST tests before finishing.
- **A local "bite" ≠ difficulty.** Every hardening round mechanically worked locally (a naive/old solution failed the new fixture). All were solved anyway. A local bite proves the tests **discriminate**, not that the **frontier model fails** — the frontier model is never the naive solver.
- **Rule of thumb:** _if a competent engineer could one-shot it from the spec in <20 min, so will the model._

**What DOES survive disclosure (the only things that have ever bitten):**
1. **Execution/engineering under a hard limit** the spec can't hand over (out-of-core CC; crash/concurrency correctness).
2. **Self-test blind spots** — a requirement that is easy to implement subtly wrong AND easy for the agent's *own* verification to miss. This is the mechanism behind every `repair-order-etl` fail so far (see §4).
3. **Discovered implementation pitfalls** where the *rule* is disclosed but the *trap* is not obvious and small self-tests don't trigger it (e.g. SQLite `SUM` overflow — §5).

---

## 2. Wall B — infrastructure voids (the OpenRouter rate-limit tax)

**This has cost us as much as the difficulty problem.** Model A in trials = **`openrouter/openai/gpt-5.4`** in region `eastus2`. When OpenRouter rate-limits/there is capacity exhaustion, trials die with `litellm.RateLimitError`/`APIError` **before any code is written or the verifier runs**. These classify as `infra/setup-timeout` and **cannot anchor or fill** — the run yields **zero** difficulty signal.

- **Voided runs:** 8, 9, 11c (5/5), and 12 (4/5). Roughly **half** of all runs have been rate-limit-affected.
- **Second void surface (new, run 14):** the **Stage 2 rubric review** also calls an LLM — the **Claude CLI on `claude-opus-4-8`, project-paid via the `ANTHROPIC_API_KEY` org secret** — and hit an **Anthropic 429** ("rate limit of 13,000,000 input tokens/min", org `4f8bcc30…`). The step produced `no verdict produced` → `report.sh` exit 1 → **gate red before `pass2` even starts**. Distinct from the OpenRouter/trials tax: different provider, different model, different pipeline stage. Same remedy (rerun), but note this one is **org-token-budget** driven, so back-to-back pushes can re-trigger it; space reruns out. Tell it apart from a real content FAIL by (a) the job log 429, and (b) the sticky "Automated Review" comment staying **stale** (a real FAIL rewrites it with blocking bullets).
  - **Rerun mechanics that work:** since rapid retries just re-hit the saturated window (proved by 14-rerun), **schedule a spaced rerun instead of hammering.** Mechanism used: a one-shot claude.ai cloud routine (`/schedule` → `RemoteTrigger` create with `run_once_at`) that pushes a single empty commit and reads back Stage 2. Gotchas: (1) the routine API **401s unless GitHub is connected** for the account (`/web-setup` fixes it); (2) minimum cron interval is 1 h, but one-shots are exact; (3) the cloud agent reports into its own session, not the local CLI — check the routine URL for the outcome. Standing routine for this: `trig_01W2VkGwCLAQL8XFsRqcGKCj`.
- **Secondary, related failure — the "oversized-JSON-blob wedge":** `gpt-5.4` under `xhigh` reasoning sometimes emits its **entire module rewrite as one giant JSON `keystrokes` blob** → harness "No valid JSON found in response" → retries → burns the full 3600 s → dies with **0 lines of code written**. Seen in 11d (`task__9BNEqQu`), and 12's pass2 (`task__j9eyNM9`, which had *correctly diagnosed all six defects* first). This is an **agent-harness interaction artifact**, not analytical difficulty; it is partly correlated with the capacity crunch. It has been classified inconsistently (sometimes good-valid-fail, sometimes timeout).
- **Mitigation:** (1) treat any run with ≥1 `infra/setup-timeout` as **provisional**; (2) **rerun** (empty commit to `submission` — this is a fork, so `gh run rerun` returns 404; only a push re-fires `pull_request_target`); (3) if repeated, flag an admin in Slack (there is a known thread on task `dynamo-4d2faae`); (4) never change the *task* in response to an infra void — it confounds the next read.

---

## 3. The gates, precisely (this is subtle and cost us reads)

The pipeline runs on `pull_request_target` on the `submission` PR. Stages: `review` (static) · `similarity` · `validation` (docker/oracle/nop) · `pass2` · `deep_review` · **`trials` (pass@5)** · `gate`. **All must be green.**

### `pass2` (2 trials) — lenient
- Gate: **≥1 valid fail of 2.** One clean analytical fail (or, historically, a qualifying timeout-wedge) passes it. We pass this now.

### `trials` = `pass@5` (5 trials) — strict, and the real bar
- Gate: **≥3 fails total AND ≥1 "good valid fail" (anchor).**
- **Anchor = "good valid fail"** = a **clean reward-0** (analytical wrong/failed output) **OR** a **stuck-timeout with `approach_validity != FAIL`**.
- **Fill vs anchor:** a **soft-timeout** can *fill* the ≥3 count but **cannot anchor**. An **`infra/setup-timeout` counts for nothing** (neither fills nor anchors).
- **Breakdown taxonomy** (per the sticky comment): `solved · good-valid-fail · soft-timeout-fail · task/verifier-issue · in-progress-timeout · infra/setup-timeout · unanalyzed · avg@k`.
- **KEY BIND (Slack, task `dynamo-4d2faae`): in-progress / soft timeouts do NOT count as valid fails.** So hardening by raw scale is dangerous: bigger N tends to produce **timeouts (uncounted)**, not wrong output. **To count, a harder failure must produce WRONG/graded output, not a clock-out.**

**Implication:** `pass@5` needs the frontier model to **fail a majority-ish (≥3/5)** of the time with *wrong output*. That is a very high bar for a fully-disclosed exact-match task where a clean correct design exists.

---

## 4. The current task in full — `repair-order-etl`

Repair a crash-safe, concurrent, **incremental** order-event ledger ETL. Entry `/app/bin/process-orders <batch.jsonl…>`. SQLite (`/app/state/ledger.db`) is the authoritative ledger; three public files are derived from it.

### Disclosed invariants (all in `task/instruction.md`, 1111 tokens < 1500 gate)
- **Immutable event identity:** `event_id` is one immutable effective event; exact replay is a no-op; conflicting reuse is invalid → nonzero exit + full rollback.
- **Total-order winner:** per order, greatest `(version, event_time, event_id)` wins — `version` **numeric**, strings by **Unicode code-point**.
- **Durable tombstones:** a winning delete persists as a tombstone (absent from CSV, not undone by older, superseded by strictly newer upsert).
- **All-or-nothing** across all files in one invocation; unreadable/invalid/blank/conflict → nonzero exit, last-good snapshots unchanged.
- **Convergence:** repeated/overlapping/reversed/late batches converge.
- **Fine-grained concurrency:** disjoint invocations make **independent progress** — no lock may serialize an unrelated invocation across the slow publish; concurrent result = some serial order.
- **Generation-monotonic, atomic, self-repairing publication:** each published set reflects one committed generation; a public file is **never** replaced with an older generation than one already published; files are never observably torn/partial; every successful run (incl. duplicate-only) **repairs missing or stale** snapshots; crash may leave adjacent generations → later run reconciles all.
- **Streaming:** never load the complete historical event-ID set into Python memory.
- **Hook protocol** (test rendezvous): phases `ready_to_apply`, `after_db_commit`, `after_orders_header`, `before_publish_swap`, `after_orders_replace` via `ORDER_ETL_HOOK_DIR/ID/PAUSE_AT/FAIL_AT`.

### Three normative outputs
- `orders.csv` — live winners, header `order_id,version,event_time,event_id,customer_id,status,amount_cents`, code-point sorted, UTF-8/no-BOM/LF/minimal-quoting/base-10.
- `metrics.json` — compact, fixed key order `active_orders,delete_events,deleted_orders,unique_events,upsert_events`.
- **`customer_totals.csv` (NEW in 12)** — per customer owning ≥1 live order: `customer_id,live_order_count,total_amount_cents`, code-point sorted. Order attributed to its **winner's** customer (moves across versions); tombstones excluded; **total is an exact integer that may exceed signed 64-bit**.

### Reference architecture (`task/solution/ledger_etl/`)
- `state_store.py`: short `BEGIN IMMEDIATE` admit txn (write lock released at commit); `UNIQUE`/`ON CONFLICT` admission; winner CAS; persistent counters + **monotonic `generation`** + durable `published_generation`; `iter_live_orders()` streamed; **`iter_customer_totals()` streams live orders in customer order and sums with Python big-ints** (SQLite `SUM` raises on overflow, `TOTAL` is lossy — verified in-container).
- `snapshot.py`: lock-free render of all three files to candidates from one consistent read snapshot; `reach("before_publish_swap")` after the read-txn releases; brief `flock` critical section does **generation compare-and-swap** then atomic `os.replace` of each file (+`fsync`), skipping if superseded.
- `processor.py`: `ready_to_apply` → admit txn → `after_db_commit` → `publish(store)`.

### The discriminators, and which cohort each bites
| Test | Targets | Cohort it bites | Observed |
|---|---|---|---|
| `test_duplicate_run_rebuilds_missing_and_stale_outputs` | stale/missing snapshot repair | agents who **optimize staleness detection** (inode/hardlink, size, existence) and self-test with `unlink()`+write (new inode), missing the verifier's in-place `write_bytes` (same inode) | **the only thing that has ever bitten** — 2/5 (11d), 1/5 (11e) |
| `test_stale_publisher_does_not_clobber_newer_generation` (11e, CAS) | generation CAS-skip branch | agents who drop the CAS | **fired on nobody** — disclosed invariant (`instruction.md`) transcribed |
| `test_customer_totals_use_exact_integer_arithmetic` (12) | exact big-int sum vs SQL `SUM`/`TOTAL` | **majority** — anyone using the obvious SQL aggregation | **untested by pass@5 (infra void)**; ⚠️ 1 pass2 agent flagged "SUM overflow" on inspection |
| `test_order_amount_follows_winning_customer` (12) | customer-move + tombstone in a derived aggregate | incremental-maintenance cohort | untested (infra void) |

**The structural ceiling, stated plainly:** a clean correct design exists — **SQLite `published_generation` counter + unconditional re-render from the current-state table + Python-int aggregation** — and it is fairly obvious. When the frontier model finds it (60–80% of trials) it passes *everything*. The only fails come from cohorts that take a plausible shortcut and don't self-test the corner. So the fail rate ≈ the fraction of trials that pick a trap-prone shortcut. The `customer_totals` overflow trap was added specifically because it bites **anyone using SQL `SUM`/`TOTAL`** (the obvious choice), not just a niche shortcut — the hope is to lift that fraction above the ≥3/5 line. **We have not yet gotten a clean read to confirm it.**

---

## 5. Calibration data (clean reads only; infra voids excluded)

| Run | Commit | Solved | Fails | Fail type(s) | Gate |
|---|---|---|---|---|---|
| 29205457738 | `63cc4b1` (11d) | 3 | **2** | both anchors, both stale-repair (one inode-alias, one JSON-wedge) | short by 1 |
| 29213227212 | `118777e` (11e) | 4 | **1** | 1 anchor, stale-repair inode-alias; CAS test caught no one | short by 2 |
| 29226016128 | `182930f` (12) | 1 | (4 infra) | **VOID** — 4× `RateLimitError`, 1 solved 29/29 | no read |
| 29288540489 | `7ff81a3` (13) | 4 | **1** | 1 anchor, stale-repair (symlink-generation); companion pass2 fail = stale-repair (hardlink-inode); **overflow trap: 0 hits of 5** | short by 2 |
| 29321434451 | `7e61f70`≡`ce6a32b` (14-read) | 5 | **0** | §9 Traps A/B/C: 0 hits at pass@5 | blocked — no anchor |
| 29347978990 | `bca5210`≡`197a6b5` (15) | 5 | **0** | companion pass2 fail = symlink-**target** repair (stale-repair family, 5th distinct variant) | blocked — no anchor |
| 29368019041 | `0e9a2b4` (16) | (2/2 at pass2) | — | de-disclosure alone moved nothing; agent self-flagged SUM overflow unprompted | blocked at pass2 |
| 29374946300 | `4815529` (17) | 2 | **3** | **all 3 anchors = hook-precision** (`after_orders_replace` fired on stale skip); companion pass2 fail = WAL first-open bootstrap race | **✅ ACCEPTED** (avg@5 0.400) |

**Variance is large and adverse:** across the two clean reads, per-trial analytical-fail probability sits around **p ≈ 0.2–0.4**, so P(≥3 of 5) ≈ **16–32%** by variance alone — a plain rerun is low-EV. The `customer_totals` overflow trap is the first change targeting the **majority** rather than a shortcut cohort; its effect on p is **unmeasured** because run 12 was infra-voided.

**Verification status of run 12's change (all in the `ledger-env` container):** reference **29/29**; a variant identical except using SQL `SUM` fails **only** the exact-integer case (clean `integer overflow`, not a timeout); broken starter fails **18/29** incl. both new cases; **5× no flake** on the new + concurrency surface; instruction 1111 tokens. `review`/`pass2`/`deep_review` all green → **no task/verifier defect introduced.**

---

## 6. Pitfalls (strategy · engineering · harness)

### 6a. Strategy
- **Adding another disclosed rule never moves `pass@k`.** Done ~6× on ETL tasks and again with the 11e CAS test. Disclosed → transcribed. Stop doing this.
- **A local bite proves discrimination, not difficulty.** Necessary, not sufficient.
- **A 1/2 or 2/5 that's timeouts/infra is not progress** — only *analytical wrong output* counts. Engineer timeouts/infra out before reading the signal.
- **After any instruction edit, re-diff instruction ↔ solution ↔ tests** for contradictions (attempt 3 self-inflicted an ambiguity fail).
- **After a task pivot, sweep `solution/` and `environment/` for stray files** — the review gate hard-fails on any unreferenced file (attempt 11a).
- **Solution labor is a budget item (learned 12b).** Every added artifact/invariant inflates the required diff; at ~600 lines of rewrite the attempt no longer fits the 3600 s cap and yields **in-progress timeouts (uncounted)**. When hardening, pre-pay non-crux boilerplate in the *starter* instead of letting total labor grow — difficulty must live in the traps, not in typing volume.

### 6b. Out-of-core engineering (task 3 — kept for reuse)
- In-memory DuckDB `TEMP TABLE` ignores `memory_limit` → **file-backed DB + `CREATE OR REPLACE TABLE`**.
- `row_number() OVER (ORDER BY id)` = a full 12M sort (475 s, 1.8 GB) → `OVER ()` (no sort); components are numbering-invariant.
- `array_agg(DISTINCT)`/grouped join over ~8M groups peaked 2.24 GB → **streamed NumPy** (`np.minimum.at`/`bincount`/`bitwise_or.at`).
- Verifier stacked its golden peak on top of `pq.read_table` of the agent output → OOM. **Free golden arrays, then stream agent output in batches (`iter_batches`+`searchsorted`).** Peak 2 GB → 1157 MB.
- **"exit 0 locally" ≠ "fits in CI"** — measure **peak RSS (`ru_maxrss`)**, target a large margin.

### 6c. SQLite specifics that matter here
- **`SUM(int)` RAISES `OperationalError: integer overflow`** past int64; **`TOTAL()` returns a lossy float.** Exact big-int aggregation must be done in Python. (This is the run-12 majority trap.)
- **Rollback-journal, not WAL:** `publish()` holds a SHARED read lock from `read_snapshot()` until `commit()`, so a reader parked mid-render **blocks a concurrent writer's commit** (SHARED blocks EXCLUSIVE). This is why the stale-clobber test needed a *new* hook (`before_publish_swap`) **after** the read-txn releases, not the existing `after_orders_header` (which would deadlock the peer).
- `WITHOUT ROWID` + `ORDER BY … COLLATE BINARY` gives code-point order (SQLite default TEXT collation is already BINARY).

### 6d. Harness gotchas (Windows box, Docker works)
- Prefix docker **mount** commands with `MSYS_NO_PATHCONV=1`; but **do NOT** set it for `docker build <context>` (mangles the context path → "path not found") nor for native-Windows `python`/`cp` on `/c/...` paths (they need `C:\...`).
- Windows working tree has **CRLF** on extensionless entrypoints like `bin/process-orders` (repo index is LF, fine for CI) → hit `/usr/bin/env: python3\r`. **Obsoleted by §10d:** pin `* text=auto eol=lf` in `.gitattributes` from day one and the `sed 's/\r$//'` workaround is unnecessary. Note `*.sh` alone is not enough — extensionless scripts still check out CRLF.
- Building a discriminator variant by string-splicing a method: **splice to the _next_ `def`**, or you silently delete later methods (I once nuked `published_generation`/`mark_published` → false 28/29 failure).
- `gh run rerun` returns **404** (fork lacks actions-write) → rerun only by pushing (empty commit) to `submission`.

---

## 7. Decision framework (HISTORICAL — written at run 12; the "immediate" action below is ~6 runs obsolete)

> Kept for the *shape* of the branching logic and for the difficulty-axis ranking at the end, which is still the best summary of what to try first. The specific instruction to "rerun `182930f`" was resolved long ago; see §9-§11 for what actually happened.

**Immediate (run 12 was infra-voided):** **RERUN** `182930f` (empty commit). This is the correct move for an infra void — the multi-file/overflow change is Docker-verified and defect-free but **unread**. Do not make another task change on top of an unread run; it confounds the signal. Expect a ~30% chance the rerun itself hits another rate-limit void; budget 1–2 reruns.

**Then, conditioned on the first clean `pass@5` read of run 12:**
- **If ≥3 fails with ≥1 anchor → ACCEPTED.** Done.
- **If the overflow trap bit but total < 3** (e.g. 2 fails) → we are close; the trap works on the SQL-`SUM` cohort but the majority summed in Python. Add a *second* majority trap that also survives disclosure (candidates below), or broaden the stale-repair corruption variants to lock in the shortcut cohort as fill.
- **If the overflow trap fired on nobody** (the model reliably sums in Python — the pass2 n=1 diagnosis is a yellow flag) → the exact-integer axis is transcribable too; escalate to a genuinely non-disclosable axis.

**Difficulty axes ranked by how reliably each defeats a frontier model** (evidence + research):
1. **Long-horizon / multi-file debugging of a larger codebase** — a subtle, *discovered* defect graded on a hidden behavioral outcome. Targets the documented Verified→Pro cliff (single-file ~70% → multi-file/real ≤23%). Strongest; biggest build. (Run 12 is a *step* toward this — a coupled third artifact — but still a fully-disclosed repair.)
2. **Self-test blind spots at scale** — requirements easy to implement subtly wrong AND easy for the agent's own tests to miss (inode-aliasing, `SUM` overflow, customer-move aggregates). This is the vein that has actually produced fails here; **stack several independent ones** so P(all correct) drops below the ≥3/5 line.
3. **Out-of-core / resource-bounded execution** — proven to bite (task 3) but calibration is delicate and scale tends to yield **timeouts (uncounted)** unless engineered to yield *wrong output*.

**Do NOT** return to any single-file, fully-specified, exact-match, short-horizon ETL — that shape failed to bite 6× across 2 tasks.

**Candidate second/third majority traps if run 12 comes back close (all survive disclosure, all yield wrong output):**
- Broaden `test_duplicate_run_rebuilds_missing_and_stale_outputs` to defeat **every** staleness shortcut: in-place corruption preserving inode **and size**, mtime-newer-than-DB, single-file-stale-while-other-fresh. Locks in the shortcut cohort as reliable fill.
- A metrics/aggregate that requires **exact ordering of floating edge cases** or **big-int** elsewhere.
- A crash/recovery corner that requires reconciling the **third file** specifically (already partly covered — `customer_totals` now flows through the CAS/crash/stale machinery).

---

## 8. Reusable Docker harness

**The pattern generalizes to any task; the names below are from the ledger case study.** Build one image from `task/environment`, then **mount** `solution/` + `tests/` read-only rather than baking them, so reference and variant checks need no rebuild — only `environment/` changes require `docker build -t <img> task/environment`. Case-study counts (29/29 etc.) were valid at that revision only; the suite later grew to 39.

```bash
# reference full suite (substitute your own repo path, image name and expected count)
export MSYS_NO_PATHCONV=1
ROOT=/c/Users/ADMIN/Desktop/<your-dynamo-repo>/task
docker run --rm -v "$ROOT/solution:/solution:ro" -v "$ROOT/tests:/tests:ro" -v "$ROOT/environment/bin:/envbin:ro" \
  ledger-env bash -c '
    set -e
    cp /solution/ledger_etl/*.py /app/ledger_etl/
    sed "s/\r$//" /envbin/process-orders > /app/bin/process-orders; chmod 0755 /app/bin/process-orders
    pytest -q -p no:cacheprovider /tests/test_outputs.py 2>&1 | tail -20'
```
For a **discriminator variant**: copy `solution/` to scratchpad, edit one method, mount that dir as `/solution`. For the **starter**: omit the `cp` (uses the baked-in broken baseline). **Always** stress new concurrency/repair tests 5× for flake; **always** confirm a wrong variant fails **only** the intended test(s) and via **wrong output**, not a timeout.

**Resources used in that case study:** verifier 600 s · agent 3600 s (hard cap; a configured 7200 was ignored) · build 1800 s · cpus 2 · memory 2048 MB. Trial model observed at the time: `openrouter/openai/gpt-5.4` (`eastus2`) — **verify per run rather than assuming**, and note the pre-seeded `model_tested` label does not track it.

---

## 9. Addendum 2026-07-14 — run 13 (`7ff81a3`): cut labor, keep traps

**What 12b changed in the picture.** `a77495a`'s pass2 was the first read where the blocker was neither infra nor difficulty but **solution volume**: both agents converged on the correct architecture (staged admission, generation CAS, Python-int totals — i.e. the disclosed rules transcribed, as always) and still clocked out, because a wholesale 5-module rewrite + inventing the candidates/`os.replace`/generation-dir scaffolding + ad hoc concurrency harnesses ≈ 65–75 min > 60. Per §3, clock-outs count for nothing — worse than a solve, because pass2 blocks before `trials` even fires.

**The fix (only `environment/ledger_etl/snapshot.py` touched, +21/−5):** starter now renders all three files to `tempfile.mkstemp` candidates and swaps with `os.replace`, hooks at the instruction-defined phases. Nothing graded moved: no consistent read view (fresh conn + `fetchall`), no generation/CAS/lock (stale clobber intact), `if processed:` still gates publish (repair defect intact), `deleted_orders: 0` hardcode, **SQL `SUM`** totals, and all `state_store`/`processor`/`models`/`parser` defects untouched. Container re-verify: oracle **29/29**, starter **18F/11P** — same split, same categories (sigkill-torn test now fails via the repair defect instead of the torn file; fine).

**Why this should *help* the fail rate, not just completion:**
- The starter **hands the agent the SQL `SUM` trap as existing code**. A minimal-diff repairer keeps the aggregation; small self-tests never overflow int64. This is the §1.3 "discovered pitfall" mechanism at its best — the trap is now the *default*, not just the obvious choice.
- Smaller diff → less exposure to the oversized-JSON-blob wedge (§2) and to self-inflicted syntax/typo noise (both 12b deaths were unforced errors in bulk-emitted code).
- The stale-repair blind spot (§4's only proven biter) is untouched.

**Risk:** pre-paying scaffolding anchors the clean design harder → p(solve) up. If pass2 comes back **2/2 solved ("too easy")**, do NOT re-inflate labor; escalate trap density per §7: broaden stale-repair corruption variants (in-place same-inode+same-size, mtime-newer, one-file-stale), and/or a second majority trap.

**Decision tree for run 29288540489:**
- pass2 ≥1 valid fail → `trials` fires → read against the §5 calibration (need ≥3/5 fails + ≥1 anchor). First-ever clean read of the `customer_totals` traps.
- pass2 2/2 solved → too-easy branch above.
- pass2 infra void / wedge → rerun (empty commit), per §2. Budget 1–2 reruns.
- Any in-progress-timeout recurrence → labor is *still* too high; next candidates to pre-pay: starter emits correct-but-unconditional publish on duplicate-only runs (keeps repair trap? NO — that would delete the only proven biter; instead trim the parser/schema surface or pre-create the `stats` table shell without semantics).

**OUTCOME (read 2026-07-14, run 29288540489): pass@5 = 4 solved / 1 anchor → blocked "not hard enough" (need ≥3).**
- **The labor thesis is fully confirmed:** 0 infra, 0 timeouts, `low_timeout` PASS on all 7 trials, pass2 job 42 min (vs 68+ before). Every trial now produces graded output — the read is finally clean. Do not touch labor again.
- **Trap scorecard:** stale-repair blind spot bit **2 of 7** (pass2 hardlink-inode + pass@5 symlink-generation) — still the *only* thing that has ever bitten, now via a third and fourth distinct shortcut variant. **SUM-overflow fired on 0 of 5** even with `SUM` shipped in the starter: all five summed in Python. §7's third branch is now proven — **the exact-integer axis is transcribable**; the disclosed one-liner beats the inherited code. Same for CAS/tombstones/versioning: 5/5 transcribed the whole disclosed surface (all converged on WAL + PK + generations table + fcntl + temp/rename, near-identical designs).
- **Calibration:** clean-read per-trial analytical fail p = 2/5, 1/5, (1/2+1/5) ≈ **0.2–0.4, dominated by the single stale-repair axis**. To clear ≥3/5 needs p ≥ ~0.6 → **one axis cannot get there; independent blind spots must stack** (e.g. 3 independent traps at p≈0.25 → P(≥1 hit) ≈ 0.58 per trial; at 4 → ≈0.68).
- **Next move (§7 axis 2, escalated):** keep the stale-repair family (it works), and add **2–3 genuinely independent self-test blind spots** — non-disclosable implementation pitfalls where the agent's own tests pass. NOT more disclosed rules, NOT bigger N, NOT labor. Candidates must each be verified to (a) bite a *plausible majority/large-cohort* implementation choice, (b) yield **wrong graded output** (not a timeout), (c) be invisible to small self-tests.

**IMPLEMENTED + CONTAINER-VERIFIED (2026-07-14, uncommitted): three traps on independent axes (29 → 32 cases).**
- **Trap A — output-directory hygiene** (publication axis, new): disclosed as "`/app/output` holds exactly the three public files after any successful invocation". Enforced in *every* `assert_outputs` (directory inventory) + a dedicated kill-mid-render test. Bites candidates-rendered-in-output (the starter's own visible pattern — inherited like SUM, but this time the corner is a SIGKILL skipping `finally`, which no small self-test inventories) and lockfile-in-output designs; naive `*.tmp` sweeps race live peers and lose the disjoint-writers test instead. Golden fix: candidates render under `/app/state/publish-tmp` (same fs, `os.replace` stays atomic).
- **Trap B — concurrent identical batches / TOCTOU** (admission axis, new): **zero new disclosure** — pure composition of "exact replay is a no-op" × "concurrent invocations converge". Both invocations park at `ready_to_apply`, then race one 20k-event file; check-then-insert admissions self-collide (PK violation in a branch the agent proved "unreachable" serially, or a SHARED→RESERVED promotion deadlock for read-early deferred txns) → nonzero exit. **Batch size matters: at 600 events the ~10 ms release jitter let the loser start after the winner's commit and V2 escaped (32/32); at 20,000 events V2 fails 5/5.** Also catches double-counted metrics counters.
- **Trap C — crash between metrics and customer-totals swap** (stale-repair-family fill): new disclosed phase `after_metrics_replace`; FAIL_AT there leaves only the third file stale; heal on duplicate-only replay. Bites mark-published-early + per-file-staleness shortcuts.

**Verification matrix (all in `ledger-etl-check` container):** golden **32/32** (suite 89 s ≪ 600 s); starter **21F/11P**, reward 0, smoke/normal-input still passing; V1 (output-dir candidates) fails **only** the 4 interruption-hygiene tests; V2 (check-then-insert + deferred BEGIN) fails **only** `test_concurrent_identical_batches_admit_each_event_once`, 5/5 stress; V3 (CAS `<=` skip-if-equal) fails **only** the duplicate-run repair test; golden concurrency/interruption set (10 tests) × 5 rounds, **0 flake**; instruction 1161 tokens < 1500. All variant failures are wrong graded output, never timeouts. Per-trial fail estimate if each new axis lands ~0.2–0.3 alongside stale-repair's 0.2–0.4: P(≥1 hit) ≈ 0.55–0.7 — at or above the ≥3/5 line for the first time.
---

## 10. Addendum 2026-07-15 — runs 14-read→17: the acceptance (`4815529`)

**Outcome first: ACCEPTED.** Run 29374946300 — `pass2` 1/2, `pass@5` 2 solved / **3 good-valid anchors** (avg@5 0.400), 0 infra, 0 timeouts, `task_specification`/`approach_validity`/`reward_hacking` PASS on all 7 trials, all 8 gates green, PR labeled `accepted`. The scoreboard (§0 rows 14-read→17) and calibration (§5) carry the numbers; this section carries the *why*, because the mechanism that finally worked is the transferable asset for the next task.

### 10a. How the last difficulty ceiling actually fell

Three consecutive reads (14-read, 15, 16) sharpened Wall A into something more precise than "disclosure gets transcribed":

1. **Disclosed mechanisms get transcribed** (§1, unchanged — proved ~10× by now).
2. **Disclosed *properties* get derived.** Run 15 stated only behaviours (bounded staging, TOCTOU recheck, generation floor) and all five agents derived the reference architecture "with no meaningful variation" — the pass@5 analyst explicitly attributed the convergence to *training-data knowledge of these patterns*, not in-context derivation.
3. **Undisclosed consequences on the idiom path get dodged by habit.** Run 16 removed the SUM-overflow warning and the event-ID-set prescription entirely; an agent *flagged the SUM overflow risk in its own reasoning anyway*. The defenses live in the weights. De-disclosure is safe (`task_specification` stayed PASS) but moves p(fail) ~0.
4. **Corollary discovered while building run 17: the stdlib pre-springs traps too.** A lone-surrogate-rejection crux died on the bench because `sqlite3` refuses to bind unencodable text — every SQLite-staged design auto-rejects, so the no-guard mutant passed 37/37. **Mutant-verify a crux bites BEFORE counting it; the stack disarms your traps the same way it disarms its own bugs.**

What survives all four filters is a narrow family: **stdlib betrayal** (the trusted brick itself violates the stated contract — `strptime` accepting unpadded fields against an "exactly `YYYY-MM-DDTHH:MM:SSZ`" spec) and **protocol semantics whose violation leaves every output byte correct**. The winner was the second kind.

### 10b. Anatomy of the winning trap (2 assertion lines)

The instruction has always *defined* `after_orders_replace` as "`orders.csv` replaced". Run 17 added two assertions: after a stale publisher's generation fence makes it *skip* its swap, the marker file must be **absent** (stale-clobber test + crashed-newer-fence test). Reference already correct; a mutant firing the hook on the skip path fails exactly those 2/37.

It killed 3 of 5 trials, via two different implementations (unchecked boolean return ×2; a `while True` retry that re-rendered a *fresh* generation and legitimately republished past a `>` fence — so even its file contents stayed right). The profile that made it lethal:

- **Zero observable damage on every path the agent exercises.** File bytes correct, DB correct, exit codes correct. The only wrong thing in the universe is a marker file's existence in one adversarial interleaving the agent never constructs. Self-testing *cannot* see it — there is no output to diff.
- **It reads as instrumentation, not as a contract.** Agents treat hook emission as logging; `task__bF9mFjF` *wrote the failure scenario in its own step-7 reasoning* ("our instance A would only reach `after_orders_replace` even if it skipped") **and chose not to act on it**. Compare run 16, where an agent acted on an overflow risk *nobody mentioned*: the model triages risks by perceived blast radius, and protocol markers rank below data.
- **It needs no new disclosure.** The phase definition was already on the page; the trap is the precise reading of an existing sentence.

The pass2 companion fail was an **independent second axis** from run 15's additions: simultaneous first-open WAL bootstrap (`PRAGMA journal_mode=WAL` on a brand-new DB races; `busy_timeout` doesn't serialize it; the reference takes a pre-connect `flock`). Same family — a lifecycle window (first boot) that self-tests never race.

**Final arithmetic:** 4 analytical fails / 7 trials ≈ p 0.57 — right at the ≥3/5 line, exactly where §9's stacking math said it had to be, but reached with 2 axes that each bite the *converged* design, instead of 4-5 axes hoping to catch shortcut cohorts.

### 10c. Playbook for the next task (what I'd do first, not last)

1. **Assume the model ships the reference architecture.** Design difficulty for the agent that *finds* the clean design, not the one that misses it. Ask: "what can be subtly wrong in a correct-architecture implementation?"
2. **Hunt protocol/lifecycle semantics, not data semantics.** Contracts whose violation leaves outputs byte-perfect: observability markers gated on actual effect, idempotent-skip paths, first-boot races, crash-window ordering. Wrong *data* gets caught by the agent's own reducer; wrong *ceremony* never is.
3. **Two-sided traps beat one-sided ones.** Pair every reject-case with an accept-case so crude fixes fail from the other direction (unpadded-timestamp ↔ leap-second; lone surrogate ↔ astral scalar ↔ ignored unknown field).
4. **Mutant-or-it-didn't-happen.** For every intended crux, build the one-decision-different variant and demand it fails *exactly* the intended cases and nothing else. This bench-killed one dud crux (sqlite pre-sprung) and certified four real ones in a single session.
5. **Budget the meta-gates:** pass2 needs the trap to bite within n=2 — a p≈0.5 trap passes pass2 only ~75% of the time. Expect to lose one read to variance even when the design is right.
6. **Infra doctrine (updates §2):** Anthropic-429 Stage-2 saturation comes in *windows of hours*. Empirical spacing: 12-min and 22/31-min retry gaps all re-voided; ~49 min cleared; the ~4-h scheduled cloud-routine rerun also cleared. Space ≥45 min, never change content on a void, and use a real commit as the re-fire when one is pending anyway.

### 10d. Harness gotchas earned this round (extends §6d)

- **`.gitattributes` now pins `* text=auto eol=lf` (35a7c05)** — the `sed 's/\r$//'` workaround in §6d/§8 is obsolete; the working tree builds clean directly. (Root cause: only `*.sh` was pinned; extensionless `bin/process-orders` checked out CRLF → `python3\r` shebang → 36/37 "failures" with the only "pass" being the test that *expects* nonzero exit. A broken binary satisfies a rejection test — beware that imposter profile.)
- **git-bash mangles `"$VAR\$M"` in docker mounts** → literal `...$M` path → Docker silently **creates an empty host dir** → `/solution` empty → solve.sh never runs → **the starter gets graded** (26F/11P imposter, looks like a catastrophic mutant). Use forward-slash `C:/...` paths with variables, and guard every harness run with `set -e` on solve.sh + `cmp -s /solution/... /app/...` before pytest.
- **git-bash heredocs eat one backslash level** (observed: `"\ud83d"` reached Python as a real surrogate). Never pattern-match backslash literals through a heredoc — anchor on plain-text markers and filter lines instead.
- `docker run` needs `-i` for heredoc stdin (`python -` silently runs nothing without it).

### 10e. Post-acceptance state (superseded by §11 — a second reviewer reopened the task)

- Accepted head `4815529`: 37 cases; oracle 37/37 reward 1; starter 26F/11P reward 0; mutants: strptime-only 1/37-fail, regex-only 1/37-fail, hook-on-skip 2/37-fail, SQL-SUM 2-fail, list-staging RSS 1-fail — each green elsewhere.
- Suite runtime ~100-140 s ≪ 600 s verifier cap; instruction ~1.2k tokens < 1500 gate.
- Monitors/loops from the watch session are all stopped; nothing pending on the PR.

---

## 11. Addendum 2026-07-16 — second-reviewer rejection and the stale-fence hardening round

**Situation.** A second human reviewer reopened the accepted task: pass@5 read as 2 solved / 3 good-valid fails ("difficulty OK"), but all three fails converged on the *single* stale-generation publication path (unconditional `after_orders_replace` on the skip path, or an equal-generation retry loop). Verdict: harden the same crux so a rerun cannot slip through (their "Situation C: precisely observed blind spot"), with two constraints — solvable by a careful domain expert from instruction+repo alone, and deterministic acceptance of a correct solution.

**Prescribed and implemented (all four levers):**
1. **One terse instruction sentence** (end of the publication paragraph): *"From the moment a publisher observes a strictly newer visible generation it must stand down: no re-rendering, no further replacement, no further publication phase signaled. A retry that observes its own equal generation after a crash proceeds and signals every phase it performs."* Wordsmithing that mattered: "from the moment" makes the mid-set temporal cut explicit (phases already fired stay legitimate); "signals every phase it performs" avoids implying a crashed run's completed files must be re-signaled, and stays compatible with byte-compare-and-skip repair designs.
2. **Two new disclosed phases**: `after_metrics_replace` (metrics replaced, totals not yet) and `after_publish` (all three replaced). NOTE: `after_publish` was *already fired* by both starter and reference but never disclosed — a latent spec gap this round closes. Starter got the one-line `reach("after_metrics_replace")` so the visible hook surface matches the instruction; all starter defects untouched.
3. **Reference redesign forced by race (c)**: the old reference held one flock across all three `os.replace` calls and fired `after_orders_replace` *inside* it — a publisher paused at that phase would have serialized a peer, latently violating the already-disclosed independent-progress sentence (never tested at that pause point). New protocol: per-file brief critical sections; `claim_publication` (floor CAS, idempotent) re-checked before *every* replacement; fenced-out ⇒ discard remaining candidates and return silently; hooks fired *outside* the lock.
4. **Graded races** (37→39 cases): (a) extended stale-skip + crashed-newer tests with `snapshot_identity()` (st_ino + st_mtime_ns per public file) and all-three-marker absence — catches re-render-and-republish whose *bytes* are correct; (b) new `test_crashed_claim_is_resumed_by_equal_generation_retry` — crash after durable claim + orders replace, corrupt orders in place, retry must exit 0, heal all three, and *signal all three phases* (the in-place corruption keeps byte-compare-and-skip designs obligated to replace orders, so the marker demand never false-positives a legit design); (c) new `test_mid_publication_fence_gates_each_file_and_phase` — A parks at `after_orders_replace` (no lock), B publishes fully within a 15 s bound (whole-set-lock designs fail here as graded output, not verifier hang), A resumes, must stand down for metrics+totals with bytes+identity untouched, `after_orders_replace` marker present but `after_metrics_replace`/`after_publish` absent ⇒ hook gating cannot be one global boolean.

**Verification matrix (ledger-env container, 2026-07-16):**
| Run | Result | Notes |
|---|---|---|
| reference | **39/39**, 130 s | deterministic accept |
| starter | **28F/11P** (was 26F) | both new races fail on it |
| m1 claim-once/global-boolean | fails exactly **1**: mid-fence (c) | the reviewer's "cannot be one global boolean" |
| m2 signals-on-skip (run-17 mutant) | fails exactly **3**: the three fencing races | |
| m3 strictly-greater fence | fails exactly **4**: both crash-heals, repair, crashed-newer heal-tail | task__KYkuL6c side 1 |
| m4 re-render-and-republish | fails exactly **3**: fencing races via identity+markers (bytes correct!) | task__KYkuL6c side 2 |
| m5 replaces-but-suppresses-signals-on-equal | fails exactly **1**: resume race (b) | the overcorrection near-miss |
All mutant failures are wrong graded output (assertions), zero timeouts; every mutant green on all other cases.

**Design lessons this round:**
- **A graded race can force a protocol depth the happy path never needs.** Race (c) is only expressible if hooks are reachable without cross-peer locks, which forces per-file fencing in any passing design — the instruction already implied it ("no lock across the slow work of publishing"), the test now makes it load-bearing.
- **mtime_ns + inode is the cheap dual of the marker check**: markers catch silent-wrong ceremony, identity catches correct-bytes republication. Together they close both of task__KYkuL6c's escape hatches.
- **When demanding a signal, make the underlying effect mandatory first** (corrupt the file in place) or a compare-and-skip legitimate design becomes a false positive.
- Instruction now 6,197 chars ≈ 1.3k tokens (< 1500 gate); suite ~130 s (< 600 s).

**Fixture blindness preserved:** example.jsonl and all visible fixtures never exercise publication contention; a wrong answer remains well-formed artifacts plus one stray marker file (or one untouched-file mtime), invisible to self-tests.

**First read of run 18 (run 29527291349 on `2f47b0c`, pass2 read 2026-07-16 ~20:37Z):** static/similarity/validation/ratelimit all PASS with no Stage-2 429 despite the EU-morning window; **pass2 = 0 solved / 1 valid-fail / 1 in-progress-timeout / 0 infra-setup — gate PASSED (1/2), trials will fire.** But the read carries **zero crux signal**: the counted valid fail (`task__BAT3Wbv`) is the §2 **terminal JSON wedge** (six consecutive reasoning-only steps, "No valid JSON found in response", zero code written, graded against the unmodified starter → 28/39 fails, matching the local starter profile exactly); the other trial (`task__FrCUrUQ`) misused SQLite's UPSERT SELECT form, found the crash at step 6, and was mid-fix when the 3600 s cap fired (low_timeout FAIL → counts for nothing). Rubric verdict: `difficulty_crux` FAIL ×2 — "the cruxes are untouched; they remain unassessed difficulty for future trials"; task_specification/approach_validity/reward_hacking clean ×2, so the new instruction sentence and 39-case suite created no spec-gap flags. Whether the fence races bite rests entirely on the pass@5 trials. If those also wedge/timeout, that's the §2 tax — rerun, don't touch content.

---

## 12. Addendum 2026-07-22: first-pass accept, and why (dynamo-6a22900-security)

Task `prvs-record-encoder`, Security / Reverse Engineering. **Accepted on the
second push, first clean pass@5 read.** pass@5 = 0 solved / 4 good-valid-fail /
1 in-progress-timeout, avg@5 0.000, all eight gates green. The only iteration was
a substring false positive: a Dockerfile comment containing the literal
`tests/test.sh` tripped the "does not COPY tests/" static check. One-word reword,
re-push, done. Contrast the prior cycle: ~18 runs across 4 tasks to land one
accept, and that one got reopened.

**What actually made it fast, in order of impact.**

1. **Category, chosen not built.** Security / RE is the model's away turf, where a
   *discovered* crux bites. ETL is home turf and the docs are right that it is
   near-impossible to make hard. The whole difficulty problem was won at claim
   time by picking a category where the crux can live outside the prose.
2. **Two axes designed to bite the converged design, verified by arithmetic
   before a line of code.** A prime-modulus checksum recoverable only by gcd, and
   a latent flags bit recoverable only from the binary. Neither is in any prose.
   The trials confirmed both: five agents exhausted the checksum catalogue and
   none tried gcd recovery; none disassembled the binary, so none found bit0.
3. **Mutant-verify against the real verifier before trusting any axis.** Two
   candidate axes (label normalization, entry sort) died on the bench because
   they failed samples, so the agent's own checks would catch them. Cutting them
   early saved trials. The two survivors were surgical: bit0 failed exactly its 9
   records x 3 tests, wrong-modulus exactly 18 x 2.
4. **The reader-audit (see F19).** The shipped binary was almost a free oracle. A
   per-field audit caught that early and turned it into a fair discovery problem
   instead of a leak.
5. **Hygiene that prevents voided runs.** gitattributes/CRLF pinned before the
   first add, jobs/ ignored, clean-image checks, fairness pre-derived. Zero runs
   lost to infra or self-inflicted breakage this cycle.

**The lesson that generalizes:** the away-category plus the discovered-crux plus
mutant-verify-first recipe works, and it works on the first read when applied with
discipline. The 18-run saga was not the cost of learning to build hard tasks. It
was the cost of building them in the one category where the method cannot win.

**One honest footnote.** The axis-correlation worry (both latent rules in the same
disassembly) never materialized, because no agent disassembled at all. The
difficulty came from a route the model declined to take, not one it took and lost.
Worth remembering: sometimes the crux holds because the model avoids the path that
would crack it, not because the path is hard.
