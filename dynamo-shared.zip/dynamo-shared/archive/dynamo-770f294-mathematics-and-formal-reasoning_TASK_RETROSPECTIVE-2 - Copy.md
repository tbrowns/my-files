# Dynamo — Cross-Task Retrospective, Pitfalls & Strategy

_Local working doc. Not part of any submission (see `.gitignore`). Covers **10 tasks / ~28 pipeline runs**, ending 2026-07-27._

> **Start here.** The live strategy is §14 (stump field guide), §15 (qc_gate), and §17–§18 (the two cleanest reads: `vault-master-recovery` and `exact-result-recovery`). §12–§13 are the security accepts that established the workhorse. §1–§11 are compressed into one ETL case study (§4) — mine it for mechanism, not specifics.
>
> **Section numbers §12–§18 are load-bearing.** The rulebook, workflow and prompt docs cross-reference them; do not renumber. Anything here that contradicts the current repo's `README.md`, its `task.toml`, or a live PR bot comment is stale — the live pipeline wins.
>
> **The one-paragraph version.** Disclosed difficulty never stumps a frontier model: it transcribes any rule you write and derives any property you describe. Only two things have ever produced valid failures. First, on home turf (ETL/systems), execution/protocol semantics whose violation leaves every output byte correct — self-test blind spots, lifecycle races. Second, and far more reliably, on away turf (security/RE/math), a **required derivation from an undocumented construction** — above all the **gcd-secret-prime-modulus** recovery, now 6-for-6. The gate needs ≥3 fails of 5 with ≥1 anchor, which one p≈0.3 trap cannot reach; stack two *independent derivations* (proven 5/5 in §18: a covariate `a·r + b·seq` scheme forces an N+1-dimensional determinant elimination the model never reaches, where its catalogued 2×2 cross-product fails), and confirm each by mutant before trusting it. A newer blocking **qc_gate** additionally rejects any task whose answer is not uniquely determined by the visible data, which kills data-analysis shapes and favors exact-scalar recovery. Budget one or two reruns per real read; roughly half of all runs have been lost to provider rate limits.

---

## 0. Scoreboard — the reads that carried a lesson

| Task / repo | Shape | Verdict | Root cause / lesson |
|---|---|---|---|
| `expand-gtfs` ×4, `ecommerce-etl` ×2 | single/multi-output exact-match ETL | **all solved** | disclosed conventions transcribed (the disclosure paradox, §1) |
| `resolve-contact-graph` ×4 | out-of-core entity resolution | infra voids ×2, verifier OOM ×1, then **2/2 solved** at 12M | execution-hard bites, but scale yields *timeouts* (uncounted), and the model solves out-of-core CC in the hour |
| `repair-order-etl` (§4, ~14 runs) | crash-safe concurrent ledger ETL | ACCEPTED `4815529`, then reopened; unresolved | the only ETL vein that bit: self-test blind spots + lifecycle races. Closest clean reads 2–4 fails of 5 |
| `prvs-record-encoder` (§12) | Security / RE | **ACCEPTED, first clean read** (0 solved / 4 GVF / 1 timeout) | away-category + discovered gcd crux + mutant-verify. The 18-run ETL saga was the cost of home turf, not of learning |
| `beacon-frame-encoder` (§13) | Security / RE | **ACCEPTED after one pivot** (0/5, avg 0.000) | known-plaintext v1 too easy → many-to-one gcd reduction v2. A first "too easy" is one pivot, not a saga |
| `record-integrity-repair` (§15) | Sci-computing / RE | cleared qc_gate → pass2 | data-analysis attempts blocked by qc_gate; only the unique-answer gcd task survived |
| `badge-log-forensics` (§16) | Security / forensics | ava_review void, pre-empted | new adversarial verifier-audit gate; remove the surface it grabs, re-push |
| `vault-master-recovery` (§17) | Security / cryptography | **ACCEPTED, cleanest read** (0 solved / 5 GVF / avg 0.000, 15 checks green, no pivot) | the misdirection insurance axis bit *nobody*; the gcd carried 100%. A *noticing* axis scores zero |
| `exact-result-recovery` (§18) | Math / number theory | **ACCEPTED** (v2, 0 solved / 4 GVF / avg 0.000) | v1 solved 2/2 (single gcd→CRT chain); v2 stacked damaged-row consensus + a covariate-scheme second derivation + totals coupling. The covariate elimination bit **5/5** — the first *measured* proof (§17/Rule 2b) that a second derivation stumps where a noticing axis doesn't |

**Two headline facts.** (1) **Difficulty:** exact-match/disclosed shapes never produced a valid fail; discovered-derivation shapes reliably do. (2) **Infra:** at least 4 early runs were voided by provider rate limits before scoring — you cannot read difficulty through an infra void, so budget 1–2 reruns per real read.

---

## 1. Wall A — the disclosure paradox / structural difficulty ceiling

Dynamo's gate needs **≥1 _valid_ agent failure**. A clean solve = "too easy" = blocked.

**The paradox (proved 8+ times):** exact-match verification *forces* full disclosure — every convention must be written into `instruction.md` or a correct-by-domain solution mismatches the golden (itself judged a task bug, also blocking). But **once a rule is on the page, the frontier model transcribes it.** Difficulty that lives in a *convention* evaporates under the disclosure exact-match requires.

**Corollaries earned the hard way:**
- **Composition doesn't save it.** Stacked interacting rules (dedup-before-filter, iterative outliers, day-first dates) were all composed correctly.
- **Genuine computation doesn't save it.** A DST "noon−12h" footgun was implemented correctly *and* the model authored synthetic DST tests before finishing.
- **A local "bite" ≠ difficulty.** Every hardening round mechanically worked locally (a naive solution failed the new fixture). All were solved anyway. A local bite proves the tests **discriminate**, not that the **frontier model fails** — the frontier model is never the naive solver.
- **Rule of thumb:** if a competent engineer could one-shot it from the spec in <20 min, so will the model.

**What survives disclosure (the only things that have ever bitten):** execution/engineering under a hard limit the spec can't hand over; self-test blind spots (easy to implement subtly wrong AND easy for the agent's *own* verification to miss); and — the reliable winner — a **required derivation from an undocumented construction** (§12–§18).

---

## 2. Wall B — infrastructure voids

Roughly **half** of all early runs were rate-limit-affected. Two void surfaces:
- **Trials provider** (Model A) rate-limits before any code is written → `infra/setup-timeout`, which **cannot anchor or fill**; the run yields zero difficulty signal.
- **Stage-2 review LLM** (project-paid Anthropic key) hits a 429 or a workspace usage cap → `no verdict produced` → gate red before pass2 starts. Tell it from a real FAIL by the `429`/`usage limit` in the job log plus a *stale* sticky review comment (a real FAIL rewrites it with blocking bullets).

**Doctrine (F17):** treat any run with an infra timeout as provisional; **never change the task in response to a void** (it confounds the next read); rerun by pushing an empty commit (a fork cannot `gh run rerun` — 404s); **space reruns by hours, not minutes** — rapid retries land in the same saturated window (12/22/31-min gaps re-voided; ~49-min and ~4-h cleared). A monthly/workspace cap does not clear on any spacing — escalate to a Dynamo admin.

---

## 3. The gates, precisely

Pipeline runs on `pull_request_target` on the `submission` PR. **All stages must be green.** Order is version-dependent — read the live graph with `gh run view <id> --json jobs`, never assume (see §17d for the current topology).

**`pass2` (2 trials) — lenient.** Passes on **≥1 valid fail of 2.** A red-X on `pass2` is by design until a valid fail exists; read the verdict comment, not the X.

**`trials` = pass@5 — the real bar.** Gate: **≥3 fails total AND ≥1 "good valid fail" (anchor).**
- **Anchor = good valid fail** = a clean reward-0 (agent finished, output wrong) OR a stuck-timeout with `approach_validity != FAIL`.
- **Fill** = a soft-timeout: counts toward the ≥3 but cannot anchor. **`infra/setup-timeout` counts for nothing.**
- Breakdown keys: `solved · good-valid-fail · soft-timeout-fail · task/verifier-issue · in-progress-timeout · infra/setup-timeout · unanalyzed · avg@k`. Parse this line before reacting.

**Consequence for hardening: raw scale is a trap.** Bigger inputs produce timeouts (uncounted), not wrong answers. To count, a harder failure must produce **wrong graded output, not a clock-out**.

---

## 4. The `repair-order-etl` case study (compressed from ~14 runs)

The long ETL saga — kept because the *mechanisms* transfer, not because any of it describes current work. Repair a crash-safe, concurrent, incremental order-event ledger ETL: SQLite is the authoritative ledger, three public files derive from it, all-or-nothing per invocation, generation-monotonic atomic self-repairing publication, streaming (never load the full event-ID set), hook protocol for test rendezvous.

**What was tried and what it taught:**
- **Adding disclosed rules never moved pass@5** (~6×). Disclosed → transcribed. The customer-totals SQL-`SUM`-overflow trap, shipped *as inherited code* in the starter, still fired on **nobody** — all agents summed in Python. Disclosed *mechanisms* get transcribed; disclosed *properties* get derived; undisclosed on-idiom consequences get dodged by trained habit (F14).
- **The only vein that bit: self-test blind spots on the stale/missing-snapshot repair path.** Agents optimize staleness detection (inode/hardlink/size/existence) and self-test with `unlink()`+write (new inode), missing the verifier's in-place `write_bytes` (same inode). Bit 2/5, then 1/5, across four distinct shortcut variants.
- **The acceptance (`4815529`):** two independent axes that each bite the *converged* design — a hook-precision contract (`after_orders_replace` must be absent on a stale-generation skip path; killed 3/5, one agent *predicted the bug in its own reasoning and shipped it anyway*) plus a first-open WAL bootstrap race. 4 analytical fails / 7 trials ≈ p 0.57, right at the ≥3/5 line. Then **reopened by a second reviewer** for converging on one code path; hardening round implemented but the task was ultimately set aside (F18: know the honest stop).
- **Labor is a budget item (F9b).** A 5-module rewrite stopped fitting the 3600s cap → in-progress timeouts (uncounted). Fix: pre-pay non-crux boilerplate in the starter so difficulty lives in the traps, not typing volume. This produced the first fully-clean reads (0 infra, 0 timeouts).

**Reusable local harness (any task).** Build one image from `task/environment`, then **mount** `solution/` + `tests/` read-only rather than baking them, so reference and variant checks need no rebuild:

```bash
export MSYS_NO_PATHCONV=1
ROOT=/c/Users/ADMIN/Desktop/<your-dynamo-repo>/task
docker run --rm -v "$ROOT/solution:/solution:ro" -v "$ROOT/tests:/tests:ro" \
  <img> bash -c 'set -e; cp /solution/*.py /app/ 2>/dev/null; pytest -q -p no:cacheprovider /tests/test_outputs.py 2>&1 | tail -20'
```
For a **variant**: copy `solution/` to scratch, edit one method, mount that. For the **starter**: omit the `cp`. Always stress new nondeterministic surfaces 5× for flake; always confirm a wrong variant fails **only** the intended test(s), via **wrong output**, not a timeout.

**SQLite specifics that recur:** `SUM(int)` **raises** `integer overflow` past int64 and `TOTAL()` is a lossy float — exact big-int aggregation must be in Python. Rollback-journal SHARED read locks block a concurrent writer's commit, so a stale-clobber test needs a hook *after* the read-txn releases. `WITHOUT ROWID` + default TEXT collation gives code-point order.

**Harness gotchas (Windows box, Docker works):** prefix docker **mount** commands with `MSYS_NO_PATHCONV=1` but not `docker build <context>`; pin `* text=auto eol=lf` in `.gitattributes` from day one (extensionless entrypoints check out CRLF → `python3\r` → a broken binary that satisfies a *rejection* test, the imposter-pass profile); git-bash mangles `"$VAR\$M"` in mounts → an empty host dir → the starter gets graded silently; `docker run` needs `-i` for heredoc stdin; `gh run rerun` 404s on a fork → rerun via empty commit.

---

## 12. First-pass accept, and why (dynamo-6a22900-security, `prvs-record-encoder`)

Security / Reverse Engineering. **Accepted on the second push, first clean pass@5 read:** 0 solved / 4 good-valid-fail / 1 in-progress-timeout, avg@5 0.000, all eight gates green. The only iteration was a substring false positive (a Dockerfile comment containing `tests/test.sh` tripped the "does not COPY tests/" static check). Contrast the prior cycle: ~18 runs to land one accept, and that one got reopened.

**What made it fast, in order of impact:**
1. **Category, chosen not built.** Security/RE is the model's away turf, where a *discovered* crux bites. ETL is home turf and near-impossible to make hard. The whole difficulty problem was won at claim time.
2. **Two axes designed to bite the converged design, verified by arithmetic before code.** A prime-modulus checksum recoverable only by gcd, and a latent flags bit recoverable only from the binary. Trials confirmed both: five agents exhausted the checksum catalogue, none tried gcd; none disassembled, none found bit0.
3. **Mutant-verify against the real verifier.** Two candidate axes died on the bench (they failed samples, so the agent's own checks would catch them). The two survivors were surgical.
4. **The reader-audit (F19).** The shipped binary was almost a free oracle; a per-field audit caught it early and turned a leak into a fair discovery problem.
5. **Hygiene that prevents voided runs.** gitattributes/CRLF pinned before the first add, `jobs/` ignored, fairness pre-derived.

**The lesson that generalizes:** away-category + discovered-crux + mutant-verify-first works, and it works on the first read when applied with discipline. **One honest footnote:** the axis-correlation worry never materialized because no agent disassembled at all — the difficulty came from a route the model *declined to take*, not one it took and lost.

---

## 13. Second security task, one-pivot accept (dynamo-825bd62-security, `beacon-frame-encoder`)

Security / RE. **Accepted after one pivot.** v1 blocked at pass2 as too-easy; v2 landed 0 solved / 5 good-valid-fail, avg@5 0.000, all 8 gates green.

**v1 (too easy) — the known-plaintext trap.** v1 whitened the payload with a keyed xorshift keystream. pass2 solved it in ~17 min: keystream = plaintext XOR ciphertext, brute-force the xorshift params over a small space, read the enum codes off the hexdump. **Lesson: full known-plaintext over a reversible transform hands the agent the entire keystream, and any non-cryptographic generator with a small parameter space is then trivially recovered.** The crux must be **many-to-one** (a reduction) so the secret cannot be read off the output.

**v2 (accepted) — back to the opaque gcd modulus.** Integrity trailer = polynomial byte hash of the body mod a secret prime (gcd recovery); payload became plain sign-magnitude readings whose sign rule is latent (samples all non-negative, where sign-magnitude and two's complement agree) and disclosed only in a shipped stripped decoder. All 5 pass@5 agents failed on crux 1 (running z3 CRC search, byte-affine modular search, ARX catalogues — **none tried gcd**). One solved the sign rule and still lost on the gcd, confirming the gcd is the workhorse and the sign rule is insurance.

**What generalizes:**
1. **The gcd-secret-prime-modulus crux is the single most reliable RE stump.** Prefer a many-to-one reduction over any reversible per-value transform.
2. **A first "too easy" is one pivot, not a saga.** Converge on the proven declined-route immediately rather than iterating novelty.
3. **Reliability over distinctness, once chosen, is cheap and it works.** v2 rhymes with prvs; the pass was immediate.
4. **Compile any shipped RE binary in the runtime image itself** so glibc matches; mark the extensionless ELF `name binary` in `.gitattributes` or LF-normalization corrupts it.
5. **Gate the binary's oracle surface** (print values only in a verbose mode, so a naive dynamic run does not round-trip-confirm the encoding).

---

## 14. Stump-strategy field guide (the live palette)

Governed by the two rules that have decided every read.

**Rule 1 — DISCOVERED beats DERIVABLE.** A crux only stumps a frontier model when it must be uncovered from data or reverse-engineered; anything derivable from a careful reading of the prose gets transcribed.

**Rule 2 — one crux is fragile; stack at least two INDEPENDENT ones.** The gate needs ≥3 fails of 5. A single trap biting ~30% of trials reaches ≥3/5 only ~16% of the time by variance alone. Two axes that each bite the *converged, correct* design push per-trial fail into the ~0.55–0.6 band that has cleared the gate; three weaker independent traps at p~0.25 each also clear it. **Independence is load-bearing:** axes that lean on the same skill or evidence are correlated — the careful agent beats both, the careless one fails both — so they don't stack.

**Rule 2b — ONLY A DERIVATION COUNTS AS AN AXIS (measured, §17/§18).** An axis that asks the agent to *notice* something scores ZERO in the arithmetic. Proven beaten 5/5: version skew, a stale vendor tool, an unparsed trailing region, a hidden journal, a superseded record, a latent flag bit, "the obvious artifact is not authoritative." Frontier agents find all of it. What they do NOT do is reach a derivation they were not prompted toward. Build noticing traps for realism and fairness, but count only derivations toward the ≥3-of-5. Same for a graded field free to read off a header: verification surface, zero difficulty.

The discovered-crux patterns (letters match rulebook §9 / workflow B2):

**A — Latent crux (the master pattern).** The deciding case is invisible in the visible data, so the agent's own diligence deepens the error. *Anchor:* all calibration parts are steel, so the steel gauge table reproduces every sample; the held-out non-ferrous parts use a different standard. *Proven* (accrued-interest 8/8, bytecode-vm-debug); both security accepts are A at core. *Condition:* the rule must be real and determinate yet never fire on visible data.

**A-variant — I, stale authority.** Use the value authoritative *as of* the reference moment, not the one that looks current now. Sound but **conditional** — as-of joins are classic ETL (home turf, hardest to make hard); bites only as a genuinely latent correction, never a disclosed as-of rule.

**B — Wrong-default lure.** A cheap heuristic ≈ the correct costlier rule; they diverge only where the agent has no reason to look. *Proven* (experiment-readout 5/5, per-session vs per-user stats). *Condition:* the correct rule non-obvious enough to take the bait, the gap off-sample.

**C — Misdirection.** The environment offers an early, authoritative, wrong answer (plant tool, stale docs, decoy). ⚠️ **§17 revises this from top-tier to insurance-only:** all 5 agents beat a version-skewed stale-reader misdirection and lost on the gcd. Fair and reviewer-safe, but a *noticing* axis — **do not count it in the arithmetic.** The plant must be detectably wrong from agent-visible evidence (an uncorrectable red herring is a reviewer Reject).

**D — Evidence-forced reverse engineering (the proven workhorse).** Recover an undocumented rule, format, or constant from what can be observed. Both security accepts are D; the **gcd-secret-prime-modulus instance is the single most reliable crux we have** — agents run checksum catalogues, z3, ARX hashes, and decline gcd every time. *Condition:* discoverable from readable material, with a wide correctness margin so method differences can't flip it.

**E — Ordering assumption.** The data violates an invariant the agent never consciously chose (a year field that wraps; a log that jumps backward). *Proven* (gnss-log-decode 8/8, ~20 years off). *Condition:* the broken invariant must break in data the agent does not inspect.

**G — Multi-mechanism accumulation.** Many independent required fixes under an all-or-nothing bar; seven of eight still scores zero. *Condition:* the fixes genuinely independent, at least one hidden in a case the sample never exercises (G × A).

**Deliberately not built — H and F.** *H — entangled rules* (interactions that rewrite each other): documented-rule difficulty, a max-reasoning model derives and solves it; proven too-easy twice. *F — discovery hop* (a final opaque joint guess with no feedback): reject-prone, its difficulty comes from removing feedback rather than adding hardness, maps straight onto the coin-flip Reject triggers.

**Anti-fragility checklist (do all five, in order):**
1. **Mutant-or-it-didn't-happen, per axis.** Build the one-decision-different variant; prove it fails *exactly* the intended tests and nothing else. The stdlib or storage layer often pre-springs a trap so the buggy variant passes anyway — catch it on the bench.
2. **Wrong output, never a clock-out.** Timeouts count for nothing; keep solution labor inside the budget.
3. **Check the axes are actually independent** (different route, skill, evidence).
4. **Two-sided traps.** Pair every reject-case with an accept-case so a crude over-correction fails from the other direction; when a test demands a signal, make the underlying effect mandatory first or a legitimate design becomes a false positive.
5. **Do the arithmetic before building.** Estimate each axis's bite, confirm the combined per-trial fail lands in the accept band (0–2 solves of 5), treat a first "too easy" as calibration data.

Amplifiers: **silent failure** (wrong output looks normal), **no self-check** (grade on held-out cases), **all-or-nothing** (a single correct artifact). Fairness gut check: an expert seeing only what the agent sees gets it right AND calls the failure fair.

---

## 15. The qc_gate wall (dynamo-dde7b29-scientific-computing)

**Three task attempts in one session; the only one to clear the new gate was a reverse-engineering task, not a data-analysis one.** This reorders the playbook for any repo with the gate.

### 15a. The stage

Some repos add **`qc_eval` (an LLM soundness pass) feeding `qc_gate`**, **blocking and fail-closed**: if `qc_eval` yields no routing, `qc_gate` BLOCKs by default. **qc_gate is stricter than the rubric eval and overrules it** — a rubric PASS is not a qc_gate PASS. (Position in the pipeline is version-dependent; §17d has the current topology, which is *after* pass2.)

### 15b. What qc_gate demands: the output must be UNIQUELY DETERMINED by the visible data

Every block reduced to one principle: **the expected output must be uniquely determined by what the agent can see; anything the gate can read two ways, or fit with a rival, is "underdetermined/ambiguous/hidden-knowledge" and BLOCKED.**

- **Attempt 1 — calibration (continuous prediction).** Bounced twice. Even well-sampled, the gate constructed a rival function that vanishes on the grid and differs off it. **Predicting a continuous function at new points is inherently underdetermined** — you can always add a function that vanishes on finite samples. The only fix (disclose the response form) conceded the crux.
- **Attempt 2 — assay (wrong-default estimator).** Rubric PASS; qc_gate BLOCK naming "Ambiguous Rule / Underdetermined Mapping / Unstated Data-Anomaly Policy." The gate treats the naive method as a *defensible alternative reading*, so it demands the deciding rules be stated — but stating them makes the model follow them → too easy. Dead either way. The disclosure paradox, now enforced by an automated gate.
- **Attempt 3 — record-integrity repair (gcd-secret-prime RE): CLEARED qc_gate → pass2.** The recovered fields are **objectively unique** (intact records fix M = gcd(pack − check), a large prime; each field < M so its residue is the single valid value). A wrong modulus yields wrong integers, not a defensible alternative.

### 15c. The load-bearing conclusion

**In a qc_gate repo, the discovered-difficulty strategy that works everywhere else is largely dead for data-analysis shapes.** Both the latent crux (A) and the wrong-default lure (B) were blocked as ambiguous, because a data-analysis answer that depends on a method or interpretation choice is exactly what the gate calls ambiguous.

**What survives qc_gate:** a task whose answer is **OBJECTIVELY UNIQUE** — where a wrong answer is objectively wrong, not a defensible alternative — recovered via a **deterministic rule the agent must reverse-engineer.** That is Pattern **D**, specifically the gcd-secret-prime-modulus family.

**The one-question test before building anything in a qc_gate repo:** *could two competent, good-faith experts produce different answers from the same inputs?* If yes → blocks. If no → passes. Prefer exact outputs (a decode, a recovered constant, a hash, an exact scalar) over any statistic, estimate, ranking, or prediction. Reverse-engineering and forensics are naturally unique-answer; data-analysis is naturally ambiguous. Pick the category accordingly.

### 15d. Infra/pipeline gotchas earned here
- **Workspace usage-cap void:** a hard monthly-style cap ("regain access on 2026-08-01"), not a transient 429. Spacing reruns does NOT help; escalate to an admin.
- **A fork-PR push can fail to fire the synchronize event** (index.lock collisions leave the PR head frozen). Push another commit to reconcile.
- **The pipeline is path-filtered on `task/` and `qc_eval` runs on the incremental push diff.** An empty commit triggers no run; a tests-only commit can make `qc_eval` skip → fail-closed. To get a real qc read the triggering push must change an **agent-facing** file. (⚠️ §17d partly walks this back — a metadata-only `task.toml` push *did* route qc_eval PASS; push the real fix and read the result, don't manufacture churn.)

---

## 16. The ava_review union gate (dynamo-8a66825-security, `badge-log-forensics`)

Same gcd DNA as §15's attempt 3. New gate mechanic: the pipeline now includes **`ava_review`**, an LLM **verifier audit** that is **fail-closed and blocks on _potential_ majors** — low-confidence, unconfirmed findings, not just confirmed ones (`potential_major=7 → routing=block`). It can red-check a sound task on speculation alone.

**It blocked on two false positives** (a brute-force range it wrongly called empty; a skew computation its own text resolved to "Same"), every other stage green.

**Clearing an adversarial LLM gate (transferable):** you cannot argue with it in comments; you **remove the surface it grabs and re-push** (it re-runs on push). What worked, none of it touching graded values: document that a search range is the *vendor-documented* value space (so it cannot "miss"), add a round-trip re-check of the recovered value, give bare asserts descriptive messages, and tighten the verifier to the instruction's declared types (require a genuine JSON int, reject str/float/bool). **Lesson:** budget for an ava_review void the way you budget for infra voids — pre-empt it by making the reference self-evidently robust (documented-complete searches, round-trip checks) and the verifier type-strict, so the audit has nothing speculative to latch onto. Tell an AVA void from a real FAIL by the `<!-- AVA-GATE -->` sticky's routing line (`potential_major=N` with `confirmed=0`).

---

## 17. The cleanest read yet (dynamo-42e68f1-security, `vault-master-recovery`)

Security / **Cryptography**, built as a **break/recover**. A decommissioned appliance's bespoke key-escrow vault survives; the master key does not. Each sealed record carries an 8-byte trailer the shipped firmware reader parses and never uses: `int.from_bytes(body,"big") % M` for a secret **62-bit prime M**. `M = gcd(body − trailer)`; then `derive_key(M)` and a sha256 keystream open the slot. Graded: `master_key`, `active_slot_id`, `recovered_secret` — exact value + exact JSON type, all-or-nothing.

### 17a. Result: 0 solved / 5 good-valid-fail, avg@5 = 0.000, all 15 checks green
pass@2 0/2 (7/7 per-trial criteria PASS ×2); pass@5 0 solved · 5 good-valid-fail · 0 timeouts · 0 infra · avg@5 0.000; everything else green. **The best read in the file** — zero infra loss, zero timeouts, no pivot, the two revisions both packaging not design.

### 17b. The load-bearing finding: the insurance axis bit nobody

Axis 1 = the gcd modulus. Axis 2 = **pattern C misdirection** (the shipped reader is firmware 1.4.2, declares `SUPPORTED_FORMAT = 1`, walks only the slot table, while the vault on disk is format 2 with an appended re-key journal — trusting it returns each slot's superseded revision).

**Agents beat axis 2 and lost on axis 1, uniformly.** Both pass2 agents parsed v2, found the journal, identified the active slot — and neither ever computed `body − trailer` or called `math.gcd()`. One flagged the trailer was "parsed but never used" and speculated it "might encode master key," and still never formed the residue model. pass@5 the same across all five.

**Conclusion (revises §14):** a *noticing* axis does not stump a frontier model; a required **derivation** does. C is fair and passed every fairness probe, but on this evidence it is **insurance that does not bite**. Do not count a C-style axis in the arithmetic. **Corollary — we still have exactly one proven mechanism.** gcd-secret-prime is now 5-for-5; every accept has been carried by it. Reliability asset and concentration risk at once (§17e / F23).

### 17c. Both failed rounds were self-inflicted packaging, both already in our docs
- **Round 1 static FAIL:** `.dockerignore` missing (adding `environment/data/` makes the context non-trivial). Rulebook §0.6 / workflow F6.
- **Round 2 Dynamo-eval FAIL (30/31):** `difficulty_explanation` never stated data provenance (synthetic vs real) or named the real-world practitioner — required *in that field*, not in `instruction.md`. Rulebook §6.

**The fix is process, not knowledge: run the rulebook's static list and the three-essay list as a pre-flight before the first push** (F21).

### 17d. Current pipeline topology (2026-07-25)
```
review (static + rubric) · similarity · validation · ratelimit · pass2 ·
{deep_review, adversarial_review, ava_review} · tier1 · qc_exec · qc_eval · qc_gate · trials · gate
```
- **qc_exec/qc_eval/qc_gate run AFTER pass2, not before** (§15a states the older position). Read the live graph.
- **New jobs:** `ratelimit` (explicit provider-void guard), `tier1`, `claude-cost-report`.
- A metadata-only push routed qc_eval PASS — don't manufacture agent-facing churn.
- `gh pr checks` lists only jobs already created; use `gh run view <id> --json jobs` for the true graph.
- **`concurrency: cancel-in-progress: true`** — any push while `trials` is running cancels it. Freeze pushes once pass2 is green.

### 17e. What carried, confirmed
- **qc_gate cleared first try** — three graded scalars, each objectively single-valued.
- **ava_review PASS first try** — the §16 pre-emption recipe (documented-complete bounds, round-trip re-check, descriptive asserts, type-strict verifier) is confirmed.
- **Mutant-verify-first paid again** — three variants, each failing exactly its intended fields via wrong output, zero timeouts.
- **A free graded field costs nothing:** `active_slot_id` is a plain header field, so discriminating power rested on two fields. Don't count a free field toward difficulty.

### 17f. Local bar that produced this
Oracle 1.0 and nop 0.0 under both harbor and the mount harness · oracle ×5 no flake · three mutants each failing exactly their fields · full-filesystem leak sweep (clean) · `.gitattributes` `* text=auto eol=lf` plus an explicit binary line, pinned before the first add · instruction ~430 tokens · suite 0.3 s.

---

## 18. Two stacked derivations, on math turf (dynamo-770f294-mathematics, `exact-result-recovery`)

**Repo:** `dynamo-770f294-mathematics-and-formal-reasoning`, subcategory Number theory and exact arithmetic, model_tested Opus-4.8, agent_tested Terminus-2. **The first task built off home security turf onto Mathematics, and the first to answer §17's open question — can a *second derivation* replace the noticing axis that bit nobody? It can, and it did, 5/5.** Status: **ACCEPTED** (v2 `d386cc3`; pass@5 = 0 solved / 4 good-valid-fail / 1 in-progress-timeout, avg@5 = 0.000; every gate green).

### 18a. v1 was too easy for the reason §17 predicted
v1 shipped one derivation dressed as three steps: a node's checkpoint is `result mod q` for a secret 63-bit modulus (q = gcd of `result − check` differences), with vn03 re-keyed into two generations and vn04 storing `a·result mod q` (scale cancels in cross-products `v_i·c_j − v_j·c_i`), closed by CRT over three moduli into a signed field. **pass@2 solved it 2/2** in ~12–14 min. The trial analysis is the §14 Rule-2b lesson verbatim: one agent derived the cross-product elimination, the other just trialed `2^64` as a candidate scale (algebraically identical since `2^64 mod q` is exactly the hidden `a`). The re-key split and the signed range were *noticing* steps every agent walked through. **One gcd chain, however dressed, is one derivation — and the model owns gcd.**

### 18b. v2 stacked three obstacles so that gcd is necessary but nowhere near sufficient
Fresh seeded data (new moduli, new answers — v1 values live in trial logs and cannot be reused), same output contract (four null job ids → `/app/output/recovered.json`, exact integers, all-or-nothing):

1. **Unflagged restore damage.** Eleven checkpoint values are corrupted and unmarked; ARCHIVE.md discloses only the count. Every node now has at least one poisoned row, so the whole-group gcd — v1's entire opening move — collapses on *every* node. Parameters only emerge from **consensus over subsets**, with damaged rows identified afterward as the ones the recovered parameters refuse to explain. This is pattern D turned on the *method itself*: the catalogue move (gcd the group) is pre-broken.
2. **A covariate second scheme (the load-bearing derivation).** vn04 was re-keyed in Feb 2020; its gen-2 checkpoints obey `check = a·result + b·seq mod q`, where `seq` is a per-node certification counter now visible in the schema. The cross-product trick that cracks gen 1 **provably dies** on gen 2, and so does the memorized `2^64` guess. Recovery needs one more elimination level — 3×3 determinants over difference rows `(Δresult, Δseq, Δcheck)` in which both unknown coefficients cancel, whose gcd pins the modulus; two clean rows then solve `(a,b)` by a 2×2 system mod q. **All four blanked jobs were certified under this key**, so an agent who stops at "gcd of differences" gets nothing here.
3. **A totals-coupling closure.** Two of the four nulls each lost one checkpoint to the damage. They land *outside* the signed 168-bit field on the full triple (the detection certificate) and their two surviving congruences pin them no tighter than ~2^42 candidates. Closure comes only from the reconciler's **per-year ledger totals** in ARCHIVE.md, captured pre-restore: the 2020 line fixes the exact *sum* of the two, and that sum joined to the surviving congruences admits exactly one in-field pair across all nine choices of which checkpoint to distrust. Uniqueness is asserted at generation time (qc_gate-native: no ambiguity).

### 18c. The read (v2 `d386cc3`, run 30197725901)
- **pass@2: 0/2** (1 good-valid-fail + 1 in-progress-timeout) — enough to proceed. Note v1 was the *opposite*: pass@2 **2/2 solved** in ~12–14 min, the §18a too-easy read that forced the rebuild.
- **pass@5: 0 solved · 4 good-valid-fail · 0 soft-timeout · 1 in-progress-timeout · 0 infra · avg@5 0.000.** All 15 checks green, `difficulty_crux` PASS ×5, `approach_validity` PASS ×5, label `accepted`.
- **The decisive number, and the answer to §17's open question: the covariate derivation bit 5/5.** Every one of the five agents recovered the four bare-residue moduli by gcd, most recovered vn04 gen-1 by 2×2 cross-products, and **not one ever attempted a 3×3 determinant over `(Δresult, Δseq, Δcheck)`** — the step that cancels both unknown coefficients of `check = a·result + b·seq mod M`. All five plateaued applying the 2×2 cross-product (correct for one unknown) to a two-unknown form, where the `b·seq` residual collapses the gcd to 1. Because all four blanked jobs sit under that key, no output file was ever written — a clean zero-output failure on all 7 tests, all five trials. One agent recognized at step 65 that `seq` belonged in the formula *and still applied 2×2 cross-products*; another tried to bypass gen-2 via CRT from the other moduli and the 2020 sum, and failed on a real non-coprimality of the moduli (vn03 gen-2), not a task defect.

### 18d. What this cycle confirms (measured, not projected)
- **A second *derivation* is the right upgrade over a noticing axis (§17/Rule 2b) — now proven on a fresh build, not argued.** §17's pattern-C insurance bit 0/5; §18's covariate elimination bit 5/5. The difference is exactly the one Rule 2b names: the model reaches for its catalogued moves (gcd-of-differences, 2×2 cross-products) and does not generalize to the *N+1-dimensional determinant elimination* a multi-coefficient scheme needs. Every *noticing* step here was walked through — null jobs identified, the 2020 deficit computed, 6 of 11 damaged rows flagged, gen-1 scale recovered — and none of it was where the task held.
- **The biting mechanism, stated for reuse: force a scheme with ≥2 unknown coefficients so the plain cross-product fails and a higher-dimensional determinant cancellation is required.** This is gcd-adjacent (it still GCD-votes the modulus at the end) but it is a *distinct derivation the model does not have in hand* — the closest thing to a second workhorse in the corpus. It is the concrete lever for hardening any gcd-family task: don't dress up one elimination, raise the coefficient count.
- **The other two obstacles behaved as designed but were not the wall.** The damaged-row consensus was *partially* solved (agents flagged 6 of 11 corrupted rows) — it slowed them, it did not block them; and the totals-coupling never got exercised because nobody cleared gen-2 to reach it. Lesson: in a stack, only the *hardest* forced derivation sets the fail rate; the softer obstacles are realism and insurance, not the load. Budget accordingly — one genuinely un-reached derivation carried the whole 5/5.
- **Mutant-verify-first paid again, four variants:** v1's golden solution dies immediately on v2 data; a no-`seq` model cannot explain the vn04 gen-2 group; skipping the drop-one-and-couple step fails exactly the two coupled jobs; an unsigned representative fails exactly the two negatives. Each via wrong graded output, green elsewhere. Oracle 7/7 in ~0.05 s, nop 0/7.

### 18e. Advisory notes carried forward (task accepted, do NOT change it now — these are for the next build)
- **avg@5 = 0.000 with a 3600s cap against a 6h estimate produced no "close" anchor.** 4/5 fails were idle-loop stagnation (a valid anchor: agent finished-wrong by never writing output), 1 was an in-progress-timeout (fill, not anchor). It cleared the gate comfortably (4 good-valid ≥ 3, ≥1 anchor), but the reviewer flagged the 6× cap-vs-estimate gap: a task this hard yields *zero-output* fails, never near-misses. Fine here; worth knowing that a very hard analytical crux gives wide-miss anchors, not threshold ones.
- **Two labels where one fits:** `artifact_type = dataset_or_tabular_file` is a stretch for a 4-key JSON map; `generated_output_artifact` alone is the clean fit. Harmless (PASS), but a human reviewer may want the second label dropped.
- **Ground truth is present verbatim in `tests/truth.json`** (`target["expected"]`). Not a FAIL (tests/ is isolated from the agent image, and exact-match makes copying == correctness), but AVA's defense-in-depth suggestion is sound for next time: store only a salted commitment of each expected value, or derive it purely from moduli+checkpoints without recording the plaintext.
- **`sympy==1.13.3` is baked but unused** (the oracle is stdlib-only). Not a leak (generic CAS), just a leaner-image opportunity.
- The gate topology matched §17d exactly, including `qc_eval`/`qc_gate` *after* pass2 and a metadata push routing clean.

---

_Compiled from the official Dynamo guide, dynamo-rubric.toml, diversity-taxonomy.toml, common-error cards, live-example runs, and completed task cycles. Where a rule matters for approval and a live source is uploaded, the live source wins. Known stale-text resolutions live in the Rulebook §12._
