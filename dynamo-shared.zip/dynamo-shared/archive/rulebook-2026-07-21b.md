# Project Dynamo — Complete Reference Rulebook · v2

*v2 folds in field lessons from completed task cycles. The most important additions: §0 (Field Lessons, read first), plus corrections to the instruction final-line rule, the difficulty strategy, and Docker/git operational rules. Where this rulebook and older written guidance conflict, and where the live pipeline and this rulebook conflict, the LIVE PIPELINE is authoritative — flag the conflict and follow the pipeline.*

**Scope: this file is category-agnostic.** It carries rules that hold for every Dynamo task. Anything specific to the repo you are working in — category, subcategory, `model_tested`, `agent_tested`, repo name, the assigned rubric/taxonomy copies — comes from **that repo's `task/task.toml` and root `README.md`**, which outrank this file on those facts. Read them at the start of every task and never edit the pre-seeded values (§0.2).

## 0 · Field Lessons (read before building — these override older text on conflict)

1. **Discoverable crux, not documented difficulty.** A max-reasoning model derives and solves ANY fully-documented ruleset, however intricate (proven across two revisions). The deciding knowledge must be *uncovered* from data or reverse-engineered, never merely read. Rank categories accordingly: Security/RE, Debugging, Systems, Scientific first; Data-Processing/ETL last (home turf, hardest to make hard). The operator picks the category by choosing which task to claim.
2. **Pre-seeded task.toml fields are sacred** (category, subcategory, `model_tested`, `agent_tested`) — never edit, even if `model_tested` seems not to match the model that actually runs trials. Editing them is an integrity failure.
3. **No "You have N seconds…" final line in instruction.md** — the live deep-review FAILs it as boilerplate; older guide text that requires it is stale.
4. **Humanize reviewer-facing text; no em dashes** (instruction, the three essays, README, PR body, reviewer notes). Keep specs terse-dry.
5. **Gitignore `jobs/` before the first Harbor run** — it holds the solved answer; committing it leaks the answer. Check tracking with `git ls-files jobs/`.
6. **`.dockerignore` in `environment/`** is a required static-check item.
7. **Keep `[task].description` non-empty**; a blocking static check requires it. Blocking checks outrank advisory notes — never drop a scaffold field on an advisory alone.
8. **Windows:** `git config core.autocrlf false` + `.gitattributes eol=lf`; deliver files via structure-carrying zips or (better) write directly in Claude Code.
9. **Timeout is a difficulty dial** with a narrow valid band: too short → invalid mid-work timeouts; too long → solves. Raise it to fix invalid timeouts; deepen the crux to fix too-many-solves. A few hundred seconds matters.
10. **Prime modulus beats power-of-two** for a reverse-engineered hash crux (defeats Hensel/2-adic lifting; forces modulus discovery).
11. **Pipeline:** static → rubric → similarity → validation → Pass@2 → deep_review → Pass@5 → gate. `gate` is an aggregator. `pass2` red-X is by design until ≥1 valid fail; "skipped" = an upstream failed. Trials ~6/day; fork can't `gh`-rerun (404) → empty commit re-triggers.
12. **Read verdicts from PR comments** (`gh pr view <n> --comments` or `gh api …/issues/comments/<ID> --jq .body`); the Pass@ Breakdown line is the whole story.
13. **Know the honest stop:** if sound hardening rounds keep missing the band (common for clean ETL), write it up for Slack and move on — that's a finding, not a failure.
14. **The Pass@5 gate needs an ANCHOR, not just fails.** ≥3 fails **and** ≥1 "good valid fail" (clean reward-0, or a stuck-timeout whose approach was sound). Soft-timeouts fill the count but cannot anchor; infra timeouts count for nothing. This one rule has decided more reads than any other — §5 has the full taxonomy.
15. **Hard cap is 3600s on the agent run, for Pass@2 and Pass@5 alike.** Any "900s" figure in older text is stale (§12).
16. **Mutant-or-it-didn't-happen.** For every intended crux, build the one-decision-different variant and prove it fails *exactly* the intended tests and nothing else. Cruxes die silently: the stdlib or the storage layer often pre-springs your trap so the buggy variant passes anyway. A local "bite" proves your tests discriminate, never that the frontier model will fail.

---

*The exact rules, checklists, commands, and tables in one searchable place. Companion to the Dummy Explainer (which teaches; this one looks things up).*
*Version 2.0 — July 2026. Sources: official guide site, dynamo-rubric.toml, diversity-taxonomy.toml, common-error cards, audit-practice answers, live-example runs, and completed task cycles.*

**Your task's fixed facts — fill these in per repo, from `task/task.toml`:** Category `___` · Subcategory `___` · model_tested `___` · agent_tested `___`. All four are pre-seeded by the Dynamo team. Never edit them, even when a value looks wrong (§0.2). The operator effectively chooses the category by choosing which task to claim; once claimed, it is fixed.

---

## 1 · Pipelines, pay, and roles

**Task pipeline:** Attempt ($5–10/hr) → R1 review → R2 review → Ready to Deliver (RTD) = accepted, bonus $80–120 stacks on base. Turnaround to RTD verdict: 36–72h from submission.

**Revision pipeline:** Sent back (R1 or R2, with feedback) → Revision 1 → re-review → Revision 2 (last attempt) → still not approved = **Holding-Rejection** (task dropped, unpaid; start a new one). Holding-Rejection also triggers immediately if a reviewer deems the task unsalvageable. Two-revision limit ≈ both reviewers judged fixing it would take >10h. Always revise sent-back tasks before claiming new ones.

**Roles ladder:** Attempter (Under Review → Attempter → Unthrottled) → R1 Reviewer (Onboarding → Unthrottled) → R2 Reviewer. Promotion = consistent R2-aligned quality; quality drops demote. Reviewers: $30–55/hr by geography.

**Time rules:** 8-hour cap per task including revisions (flag in Slack near 7h). Time tracked by having the claimed task open on the platform; don't idle it; one chance to edit tracked time at submission. ≤40 hrs/week (aim ≥20). One active claim at a time; release non-fits promptly.

---

## 2 · Setup (one-time)

Prerequisites: **Docker** (Desktop on macOS/Win; on Linux `curl -fsSL https://get.docker.com | sh`, `sudo usermod -aG docker $USER`, `newgrp docker`; verify `docker --version` + `docker ps` prints an empty table) · **uv** (`curl -LsSf https://astral.sh/uv/install.sh | sh`) · **Python 3.11+** · **GitHub CLI** (`gh auth login`).

Install Harbor: `uv tool install harbor` then `harbor --version`. ⚠️ Package is `harbor`, NOT `harbor-cli` (different product). No model API key needed for scaffold/oracle/local calibration.

**Core commands (run from inside `task/`):**

| Command | Purpose | Expected |
|---|---|---|
| `harbor run -p . --agent oracle` | Build image, run YOUR solve.sh, then verifier | reward **1.0** |
| `harbor run -p . --agent nop` | Run do-nothing agent | reward **< 1.0** |
| `cat /logs/verifier/reward.txt` | Read the score | 1 or 0 |
| `docker run --rm <image> /bin/bash -lc 'find / \( -name solve.sh -o -name test.sh \) 2>/dev/null'` | Prove image is clean | **no output** |

**Calibration loop:** stub solve.sh (`echo '#!/bin/bash' > solution/solve.sh`) → oracle run → expect reward < 1.0 → restore (`git checkout solution/solve.sh`) → oracle run → expect 1.0. If nop ever passes, the verifier is too weak — tighten assertions.

---

## 3 · Required layout & file rules

```
task/
├── task.toml            # manifest — metadata + timeouts
├── instruction.md       # agent's prompt; NO "You have N seconds" line (live rubric FAILs it, §0.3)
├── solution/solve.sh    # reference solution (+ helpers, e.g. solve.py); mounted at /solution/, never in image
├── environment/
│   ├── Dockerfile       # THE single image (agent + verifier)
│   └── data/            # optional inputs, COPYed to /app
├── tests/
│   ├── test.sh          # runs pytest; writes 1/0 to /logs/verifier/reward.txt
│   └── test_outputs.py  # pytest assertions, 1:1 with instruction.md
├── .dynamo/ .harbor/    # PROVIDED when present — never edit
└── (repo root)
    ├── .github/         # PROVIDED pointer workflows — never edit
    ├── references/      # read-only copies: dynamo-rubric.toml, diversity-taxonomy.toml, check-base-image.sh
    └── README.md        # the provided submission instructions; replace with a short task description before final submit
```

Task lives under `task/` — not repo root, not `tasks/<id>/`. **Where the rubric/taxonomy live varies by repo generation:** older scaffolds put them in `task/.dynamo/`, current ones in `references/` at repo root. Check which your repo has and read from there; wherever this file says `.dynamo/<file>`, substitute your repo's actual path. Both are read-only reviewer copies.

### instruction.md
- The ONLY thing the agent sees. Handed verbatim.
- Prompt style: no title, no headers, no roleplay, no fluff; reads as written by a terse human domain expert (LLM-sounding prose is a graded red flag).
- Absolute paths only (`/app/...`); backticks for paths/commands/code; `$...$`/`$$...$$` for math.
- Name every output file and its exact format. Structured output (JSON/CSV/config/schema) must be documented **as normative** in the prompt or a referenced spec file shipped in `environment/` — examples alone are insufficient.
- WHAT, not HOW: no step-by-step, no mandated tools/libraries/methods (exception: mechanistic anti-cheat constraints and output-format requirements). Do not list available tools or environment contents — the agent discovers them. Don't restate field-standard expert knowledge.
- No subjective goals ("make this better") — every requirement needs an objective, assertable criterion.
- Never claim a tool/service/dataset exists unless it's actually in the environment.
- Hard cap **1,500 tokens**.
- **Do NOT append the "You have N seconds… do not cheat" line.** Older guide text required it and referenced a `check-instruction-suffix`; the LIVE deep-review FAILs that suffix as TB3 boilerplate and the live static checks contain no suffix rule. Omit it entirely (§0.3). This is the canonical example of live-pipeline-over-written-guidance.

### solution/solve.sh
- Shebang `#!/bin/bash` first line. Keep real logic in helpers (`solution/solve.py` etc.) that solve.sh calls; shell for CLI work, Python for libraries/data.
- Writes to the absolute `/app/...` paths the instruction names.
- No package installs (no apt-get/pip) — the Dockerfile owns all setup.
- Must genuinely compute the answer; no hardcoded/echoed results; expected values in tests derived, not pasted. Files >~20 lines are separate files in `solution/`, not giant heredocs.
- Humanly written (LLM assistance allowed, but it must read and behave like a real expert's work).

### tests/test_outputs.py
- One test function per success criterion; each with a docstring stating what it conceptually checks. Atomic, deterministic, hand-written, concise (sprawl signals over-specification).
- Asserts on observable artifacts only: files at the declared `/app` paths, exit codes. Never stdout, never source-code string/keyword/regex matching, never references solve.sh.
- Every assertion traces to a stated (or clearly implied) requirement; every stated requirement is tested. One trivially-minor untested requirement of many = score 4, non-blocking; material gaps = Revise.
- Fixed seeds and inputs; no unseeded randomness, live-generated data, or wall-clock/date dependence.
- Ground-truth/oracle data lives in `tests/` (overlaid at `/tests` only at verify time; never present during the agent run), NEVER in `environment/`.
- If reading ground truth from an agent-writable path (e.g. `/app/data/`), re-copy to a trusted tmp location or SHA-256 integrity-check it first (tamper independence).
- Numeric bands: wide enough for any sound method, tight enough to reject wrong ones; every band justified in `verification_explanation`.
- Comparison hygiene: parsed values, not raw bytes; normalize whitespace/case; tolerances for floats. Never demand byte-exact text, fixed key order, exact float formatting, or trailing newlines unless the instruction states them.

### tests/test.sh
- Reference shape: run `pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py -rA`; if exit 0 → `echo 1 > /logs/verifier/reward.txt` else `echo 0 > ...`.
- Must always exit 0 itself and ALWAYS write the reward (0 or 1), even on missing prerequisites or no-op.
- Installs/downloads NOTHING at verify time (static checks reject verify-time setup). All deps pre-baked in the Dockerfile.
- Outputs go to `/logs/verifier/` (Harbor mounts it) — anywhere else records a silent failure. No reward.txt may ship in the environment.

### environment/Dockerfile
- ONE image for agent + verifier. `[verifier].environment_mode` stays unset; Harbor overlays `tests/` at verify time; no tests/Dockerfile.
- `FROM` an allowlisted base **pinned by digest** `@sha256:...` — never `:latest`, never a bare tag. Another allowed version in the same family is fine but needs its own digest. Non-allowlisted bases only if none support your deps — and document why.
- Pin pip/npm to exact versions (incl. `pytest==8.4.1 pytest-json-ctrf==0.3.5`). Do NOT pin apt versions; `apt-get update` before install, `--no-install-recommends`, `rm -rf /var/lib/apt/lists/*` in the same layer; never `apt-get upgrade`; consolidate installs into one RUN.
- COPY inputs from `environment/data/` to `/app/...`. NEVER COPY `solution/` or `tests/` (CI enforces; verify with the find command in §2).
- `RUN mkdir -p` the parent dir of every output path (else artifact upload fails).
- Multi-stage builds for compiled artifacts (toolchain/cache must not reach runtime). `.dockerignore` present; COPY scoped narrowly (never .git/caches/unrelated files). Layers least→most volatile. Source/fixtures live on disk and get COPYed — no `RUN cat <<EOF` heredocs; extract .tar.gz fixtures at build time. `chmod` specific files only, never `chmod -R` a tree. No files only the oracle needs (they hint the solution). Services must start reliably, expose expected ports, have health checks. LF line endings everywhere.

**Allowlisted base images** (pin by the digest shown; other versions in-family need their own digest):

| Runtime | Versions | Image (registry `public.ecr.aws/docker/library/`) |
|---|---|---|
| Go | 1.21–1.26 | `golang:1.24-bookworm@sha256:1a6d4452c65dea36aac2e2d606b01b4a029ec90cc1ae53890540ce6173ea77ac` |
| Python | 3.10–3.13 | `python:3.13-slim-bookworm@sha256:01f42367a0a94ad4bc17111776fd66e3500c1d87c15bbd6055b7371d39c124fb` |
| Debian | bookworm/bullseye/12.x | `debian:bookworm-slim@sha256:4724b8cc51e33e398f0e2e15e18d5ec2851ff0c2280647e1310bc1642182655d` |
| Rust | 1.75–1.95 | `rust:1.85-slim@sha256:9f841bbe9e7d8e37ceb96ed907265a3a0df7f44e3737d0b100e7907a679acb36` |
| Node | 18/20/22/24 | `node:22-bookworm-slim@sha256:f3a68cf41a855d227d1b0ab832bed9749469ef38cf4f58182fb8c893bc462383` |
| Ubuntu | 22.04/24.04 | `ubuntu:24.04@sha256:0d39fcc8335d6d74d5502f6df2d30119ff4790ebbb60b364818d5112d9e3e932` |
| Java | 17/21 | `eclipse-temurin:21-jdk-jammy@sha256:25d1276565738d3c805e632a4542c3a7598866ef967f4def6544c15de3a74b14` |
| Ruby | 3.2–3.4 | `ruby:3.3-slim-bookworm@sha256:e76733e94b3a5893e4a141024ef3a583dc10781dc24becebf74f9c9f9a33e3df` |
| Maven | temurin 17/21 | `maven:3.9.9-eclipse-temurin-21@sha256:3a4ab3276a087bf276f79cae96b1af04f53731bec53fb2e651aca79e4b10211e` |
| GCC | 12–15 | `gcc:13-bookworm@sha256:930f2ebe239275fa67226654cb79273ea34eee672ae61c8a39f689c37fb7ac5c` |

### task.toml — canonical template & field reference
```toml
artifacts = []                       # TOP-LEVEL, above first [section]: absolute paths the verifier reads

[task]
name = "dynamo/your-task-name"       # org/name REQUIRED (slash mandatory); name part lowercase kebab-case, ≤3 words, specific
description = ""                     # one-line summary

[metadata]
category = "<pre-seeded>"            # PRE-SEEDED — do not edit
subcategory = "<pre-seeded>"         # PRE-SEEDED — do not edit
model_tested = "<pre-seeded>"        # FIXED — do not edit; a label, not a promise about the trial model (§0.2, §12)
agent_tested = "<pre-seeded>"        # FIXED — do not edit
task_objective = []                  # closed set, lowercase snake_case (see §7)
artifact_type = []                   # closed set, lowercase snake_case (see §7)
expert_time_estimate_hours = 0       # must become non-zero, plausible, consistent with difficulty
difficulty_explanation = ""          # graded essay — see §6
solution_explanation = ""            # graded essay — see §6
verification_explanation = ""        # graded essay — see §6

[verifier]
timeout_sec = 120.0                  # fit your test suite
# environment_mode: LEAVE UNSET (single shared image; Harbor overlays tests/)

[agent]
timeout_sec = 120.0                  # verifier; raise for a heavy suite. [agent].timeout_sec is a DIFFICULTY dial (§0.9): narrow valid band, ≤3600

[environment]
build_timeout_sec = 600.0
cpus = 1                             # raise only for genuine need — difficulty ≠ compute
memory_mb = 2048
storage_mb = 10240
gpus = 0                             # max 1 (H100), only if truly needed
allow_internet = true                # default; answer must still not be findable online; set false only if no network needed
mcp_servers = []                     # leave [] unless genuinely needed
```
Hard rules: name goes INSIDE `[task]` as `name` — a root-level `task = "..."` string makes Harbor resolve zero tasks and abort ("Either datasets or tasks must be provided"). Only Harbor-recognized fields allowed (invented fields like "skills", "notes", "estimated_difficulty" fail `task_toml_schema`; legacy author_* fields recognized but unused; `avg_at_8` injected downstream — don't add it). NO personal info (name/email) anywhere. Carry proposal answers into the three explanations.

---

## 4 · Workflow steps with their official checklists

**Before building:** skim examples & strategies; read your repo's rubric copy (`references/dynamo-rubric.toml` or `task/.dynamo/dynamo-rubric.toml`) for what "good" looks like. Difficulty must come from reasoning, not CPU/memory/wall-clock. Agent has open internet → answer must not be findable online.

**Step 1 · Claim.** Filter queue by category/subcategory → Claim (locks it; timestamp starts your window) → note Category+Subcategory → accept the repo invite (repo link then appears). Release promptly if not a fit.

**Step 2 · Proposal.** Judged on the idea, no code yet. Must contain: (1) difficulty — the specific reasoning/domain knowledge/multi-step problem-solving; who does this in the real world; data provenance and realism (never "this is hard"); (2) intended approach — strategy + key insight proving you hold a solution; best-case expert-hours; (3) verification — the output and its deterministic check; any tolerance band justified (what it brackets, why it admits valid variation but rejects wrong methods); (4) category/subcategory justification (fields pre-filled, don't edit; justify in the answer). Automated pass/fail with per-criterion feedback; revise until pass; DO NOT build before it passes.
*Pass bar (all 6):* hard for a competent expert (not an average undergrad in days; not tedious/high-volume) · requires real multi-step terminal work (not paper-solvable/one-shot) · not textbook/well-known · solution plausibly exists and is bounded (sketchable) · deterministically checkable, not lookupable/shortcuttable/hardcodable · graded on result never method.
*Common fails:* vague difficulty; approach that only asserts existence; unjustified tolerances; no time estimate; reasoning-only solvable; standard problem; method-dependent grading.

**Step 3 · Fork & scaffold.** `gh repo fork handshake-project-dynamo/<repo> --clone` → `cd <repo>/task` → `git checkout -b submission`. Confirm layout; don't rename/move top-level files; seed files → `environment/data/`.
☑ forked+cloned, on submission ☑ layout confirmed ☑ seed files placed.

**Step 4 · solve.sh.** Author; oracle to 1.0; then write the numbered list of observable success criteria (existence, schema, ordering, arithmetic relationships) — it drives Steps 5 and 8.
☑ calls helper logic ☑ absolute /app outputs ☑ no installs ☑ oracle 1.0 ☑ criteria list captured.

**Step 5 · Tests.** Verifier runs post-agent in a fresh container from the same image; can read only: declared /app outputs, image contents, compose sidecars.
☑ one function per criterion w/ docstring ☑ observable /app artifacts, no stdout/source-matching ☑ test.sh installs nothing ☑ reward to /logs/verifier/reward.txt ☑ oracle 1.0 & nop <1.0 ☑ no shipped reward.txt; reward always written ☑ fixed seeds/inputs.

**Step 6 · Dockerfile.**
☑ allowlisted digest-pinned base ☑ pip/npm pinned, apt not ☑ no COPY solution|tests ☑ data in environment/data → /app ☑ pinned test deps baked + mkdir -p ☑ oracle 1.0 & nop <1.0 ☑ no unnecessary files ☑ no oracle-only deps ☑ services start/ports/healthcheck ☑ LF endings.

**Step 7 · instruction.md + task.toml.**
☑ prompt-style, no title/headers/roleplay/fluff ☑ absolute paths; outputs+formats named; solution not revealed ☑ NO "You have N seconds" final line (§0.3 — live deep-review FAILs it) ☑ ≤1,500 tokens ☑ metadata complete (objectives/artifacts from taxonomy; hours; 3 explanations; pre-seeded untouched) ☑ timeouts set ☑ no phantom tools/datasets claimed.

**Step 8 · Full local validation.** Reviewer reads but never runs — you're the only proof. (1) oracle 1.0; (2) nop 0; (3) image clean (find command); (4) repeatable — oracle & nop twice from clean checkout, identical results (fix seeds otherwise). Then self-review against the reviewer guideline.

**Wrap-up checklist (all pass/fail):** scaffold complete + provided dirs unmodified · instruction harbor-clean (absolute paths, outputs named; WHAT not HOW; no solution reveal; NO "N seconds" line; ≤1500 tokens; humanized, no em dashes) · task.toml complete (fellow fields filled; pre-seeded untouched; description non-empty; environment_mode unset) · agent image clean (no solution/tests; data COPYed; pip pinned; no answer/ground-truth agent-reachable) · outputs↔verifier wired (paths match; ground truth in tests/; 1 test per criterion; nothing graded that's unstated) · verifier correct (reward to /logs/verifier/; behavior not string-matching; deps baked; parent dirs pre-created) · solvable/novel/deterministic (genuinely computes, humanly written; not a reworded TB2/TB3 task; no mutable live services; not online-findable). Hard gate: oracle 1.0, nop <1.0.

**Final pre-push checklist (10):** task under task/ with all files · instruction humanly-written (no em dashes), absolute paths, outputs named, NO "N seconds" line · Dockerfile no solution/tests, pip pinned · oracle 1.0 / nop <1.0 · tests↔instruction 1:1 with docstrings · solution genuinely computes · novel vs TB2/3 · agent timeout set as a difficulty dial (§0.9), not padded/guessed · jobs/ gitignored & untracked · .dockerignore present · description non-empty · Pass@2 cleared (≥1 valid fail) · Pass@5 in accept band: ≥3 fails AND ≥1 anchor (read the Breakdown line, §5).

---

## 5 · Submission, PR checks, pass@, platform

**Push/PR:** `git add -A && git commit -m "Task submission" && git push -u origin submission && gh pr create --repo handshake-project-dynamo/<repo> --fill`. Iterate by pushing to the same branch (checks re-run, comments update in place; never open a new PR).

**PR body template:** `## One-sentence problem` (The task is done when ___) · `## Success criteria` (numbered, mirroring instruction.md) · `## Calibration results` (golden 1.0; nop <1.0) · `## How to run` (both harbor commands) · `## Notes / open questions`.

**Automated checks on every push:**

| Check | What | Passes when |
|---|---|---|
| Static checks | Structure/format: absolute paths, Dockerfile hygiene, pinning, single-verifier, instruction suffix | all rules satisfied |
| Rubric review | LLM grades vs the Dynamo rubric, per-criterion | verdict ✅ PASS |
| Duplicate check | instruction.md vs TB2 & TB3 task sets | novel (same domain/technique OK; same underlying problem not) |
| Validation | builds env, runs verifier | oracle passes, nop fails |
| Timeout pre-check (Pass@2) | 2 trials under the hard 3600s agent budget | ≥1 valid agent failure; BLOCKED if both solved, both errored, or a failure looks like a task/verifier bug |
| Automated Review (deep_review) | LLM deep-review: every requirement tested, deciding rules discoverable, spec internally consistent, traces clean | **BLOCKING** — its comment lists Blocking Issues (stay red until fixed and pushed) and Advisory Notes (never block) |
| Agent trials (Pass@5) | model attempts the task 5× | ≥3 fails AND ≥1 "good valid fail" anchor (see Pass@ rules below) |

**Reviewer Notes flags to know:** `fixtures/fixtures_and_tamper_independence` (verifier trusts agent-writable ground truth → copy to tmp or SHA-256 check) · `coverage/complete_test_coverage` (untested edge case / ambiguity → tighten wording + add hidden test) · `alignment/no_orphaned_behavior` (dead code/template leftovers → remove).

**Pass@ rules.** Both gates run the agent under a **hard 3600s cap on the agent's run** (environment startup excluded); your `[agent].timeout_sec` sets the budget below that ceiling. Pass@5 only auto-runs after Pass@2 passes. Trials are quota-limited (~6 runs/day/fellow/task).

**Pass@2 (2 trials) — lenient, but it is a real gate, not a formality.** Passes on **≥1 valid agent failure of 2**. It is BLOCKED if the agent solved both runs (too easy), both runs errored out, or a failure looks like a task/verifier bug. A red X on `pass2` is by design until a valid fail exists (§0.11) — read the verdict comment, never the X. Older text calling Pass@2 "a 900s cost gate reviewers disregard" is **stale on both counts**: the cap is 3600s and a failed Pass@2 stops the pipeline before trials ever fire.

**Pass@5 (5 trials) — the real bar.** Gate: **≥3 fails total AND ≥1 "good valid fail" (anchor).** The table below is indexed by **solves**, not failures:

| Pass@5 solves | Meaning | Outcome |
|---|---|---|
| 0–2 of 5 solved (i.e. ≥3 fails) **with ≥1 anchor** | genuinely hard; failures are real wrong answers | **Accepted** (0 solved = best) |
| ≥3 of 5 solved (fewer than 3 fails) | too easy / verifier too loose | Rejected — raise real difficulty |
| ≥3 fails but **no anchor** | fails are all soft-timeout/infra; difficulty unread | Blocked — not a difficulty verdict |
| Fails are invalid (crash, setup/infra error, broken task, mid-progress timeout) | broken, not hard | Rejected — fix the cause |

**Fail taxonomy — this decides your read, so parse the Breakdown line before reacting:**
- **anchor = "good valid fail"** = a clean reward-0 (agent finished, output wrong) **OR** a stuck-timeout with `approach_validity != FAIL`.
- **fill** = a soft-timeout: counts toward the ≥3 but **cannot anchor**.
- **worthless** = `infra/setup-timeout`: neither fills nor anchors. A run with these is provisional — rerun, and never change the task in response to an infra void, it confounds the next read.
- Breakdown keys: `solved · good-valid-fail · soft-timeout-fail · task/verifier-issue · in-progress-timeout · infra/setup-timeout · unanalyzed · avg@k`.

**Consequence for hardening: raw scale is a trap.** Bigger inputs produce timeouts (uncounted), not wrong answers. To count, a harder failure must produce **wrong graded output, not a clock-out**.

Remedies: too many solves → deepen the crux (§9), never the clock. Mid-work timeouts → raise the agent timeout toward the ceiling, or cut the typing volume the solution demands (pre-pay boilerplate in the starter). Ambiguous prompt → tighten to one interpretation. Brittle verifier → fix to accept any sound answer. Unsolvable → re-prove the oracle. **NEVER lower the timeout or add busywork to game the score** — reviewers detect and reject it.

**Platform submission:** PR must be green first (submitting red wastes a reviewer slot and bounces). Walk the checklist; write reviewer notes (subtle/tricky/non-obvious things: challenging areas, failure modes, implementation assumptions); screenshot the pass@ comment from the PR's github-actions bot; attach + enter score; read the Job Analysis before submitting. Then replace README.md with a short task description (overview, approach, environment, verification).

---

## 6 · The three graded explanation essays (task.toml)

**difficulty_explanation** — must let a NON-expert understand why it's fundamentally hard for humans AND agents: the expertise required; the conceptual/methodological traps; data provenance (synthetic or real; realistically challenging?); who in the real world solves this and why. Framed on the task ("requires deep knowledge of X"), never on results — no pass rates or model performance. Empty/vague/circular = FAIL. ⚠️ A wrong "correct answer" stated here can fool the trial-analysis panel into misgrading trials — keep it accurate.

**solution_explanation** — high-level strategy + key insights such that another expert could reimplement from the instruction's priors alone: assumptions, methodology choices and why, what each computation/fix accomplishes. Must match what solve.* actually does (mismatch = defect). If no solution provided (only acceptable when implementation would take a team weeks+), rigorously justify and describe what it would involve.

**verification_explanation** — what each test checks, how, and why that's sufficient (tests can only see the requested output files). Must match the test files. EVERY inequality-based check (ranges, tolerances, thresholds, fuzzy comparisons) must be justified: what the band brackets; what legitimate variation it absorbs (float precision, alternative valid algorithms, rounding); validated against alternative correct methods, not just the reference. Bare "[29,31]" with no rationale = insufficient. Reference-only-hittable = too tight; wrong-answer-passable = too loose.

---

## 7 · Taxonomy (closed vocabularies — exact values)

`task_objective` (pick all that genuinely fit the END GOAL, not tools used): implement · fix · configure · analyze · transform · validate · optimize · migrate · refactor · test · debug · build_or_package · deploy_or_operate · recover_or_repair_artifact · generate · compare_or_select · secure_or_harden · automate_workflow

`artifact_type` (the CENTRAL artifacts, not incidental helpers/logs/temp): codebase · single_script_or_program · test_suite_or_benchmark · build_system_or_package_metadata · configuration_file · shell_environment · service_or_daemon · container_or_virtual_environment · database_or_structured_store · dataset_or_tabular_file · text_or_log_file · document_or_report · archive_or_compressed_artifact · binary_executable_or_library · media_artifact · model_or_checkpoint · hardware_or_firmware_artifact · network_endpoint_or_protocol_artifact · repository_history_or_version_control_state · security_artifact · mathematical_or_scientific_model · generated_output_artifact

Rules: closed sets — anything else fails `check-diversity-labels.py`. Matching is case/separator-insensitive but write lowercase snake_case. Non-empty arrays; best fit, not just valid (debug task tagged "implement" = wrong-fit fail). Unlisted *subcategory* = warning only, and yours is pre-seeded anyway.

`category` and `subcategory` are **not** author-chosen — they arrive pre-seeded and the full list of valid pairs lives in `[categories]` in your repo's `diversity-taxonomy.toml`. Look yours up there when you need the sibling subcategories for context; do not copy a category list into this file, it goes stale. Only `task_objective` and `artifact_type` are yours to pick.

---

## 8 · Rubric — all 31 criteria (25 core + 6 Harbor-packaging; name → PASS means / FAIL means)

*What the task tests:*
1. **code_dependent** — needs genuine multi-step terminal work (explore, run, debug, iterate); passes the "Pen & Paper test." FAIL: solvable by one generation, reasoning alone, or trivial code.
2. **essential_difficulty** — hard via expert reasoning/system design/methodological judgment; multi-step with dependent chains; tool-choice can be the difficulty. FAIL: undergrad-in-days, tedium, obscure recall, formatting minutiae, volume.
3. **interesting_realistic** — someone would be paid to do this; outputs a practitioner wants. FAIL: gimmick/trick/toy; irrelevant outputs.
4. **novel** — not memorization-solvable. FAIL: textbook/well-known with available solutions.
5. **solvable** — working solve.* provided; expert-with-the-idea implements in hours. FAIL: absent w/o rigorous justification; doesn't solve it; weeks of labor.

*The instruction:*
6. **unambiguous** — competent expert with a sound approach can pass; check EVERYTHING agent-visible before calling something undisclosed; field standards assumed; only arbitrary/non-standard must-match choices need disclosure. Default PASS; benefit of the doubt; to FAIL, name a specific sound approach that clearly fails, or show grading on unestablished criteria. Don't fail on unverifiable tolerance speculation — note it instead.
7. **outcome_verified** — grades end state; goal upfront; latitude in method (exceptions: anti-cheat constraints, output formats — which must stay easy). FAIL: enforced approach/tool; step-by-step.
8. **instruction_concision** — human-written, terse, absolute paths, backticks, no headings/preamble/roleplay, no solution hints, no tool listings, no over-explained standard knowledge. FAIL: any of those.
9. **structured_data_schema** — exact schema normative in instruction or referenced env spec. FAIL: examples only. N/A if none.

*The verifiers:*
10. **verifiable** — deterministic, on the explicitly requested files, paths consistent instruction↔tests, resists online/analytical/manufactured bypasses; LLM-judge only with rigorous documented justification. 
11. **functional_verification** — behavior via execution, never source string/keyword/regex matching.
12. **deterministic_reproducible** — pinned where pinnable; no mutable live services; stochastic tasks robust across many trials (an oracle that intermittently fails itself is unacceptable).
13. **test_instruction_alignment** — 1:1 both directions; atomic functions with docstrings; filenames named in instruction; existence/format checks failing = red flag pointing at the instruction.
14. **anti_cheat** — no answer/oracle/solution agent-reachable (env, instruction, fixtures, git history of shipped repos); resists wrapper-fabrication, monkey-patching, caching/hardcoding, framework tampering.

*The solution:*
15. **solution_quality** — derives via real computation; no unexplained hardcoding; big files as files not heredocs.
16. **task_security** — no exfiltration, supply-chain risk, host escapes, destructive ops, obfuscated payloads (unless the domain), prompt injection, pipeline interference — in ANY file.

*Metadata:*
17. **difficulty_explanation_quality** · 18. **solution_explanation_quality** · 19. **verification_explanation_quality** — see §6.
20. **accurate_taxonomy_labels** — meaning-fit; author fields judged strictly, pre-seeded leniently (flag only clear mismatch).
21. **expert_time_estimate** — non-zero, plausible, consistent with difficulty.
22. **open_internet** — compatible with open internet; internet must not enable answer lookup.

*Reviewability & hygiene:*
23. **reviewable** — non-specialist can verify from files + explanations; expected values derived not hardcoded.
24. **typos** — none in filenames/paths/commands/variable names.
25. **no_extraneous_files** — only what defines/solves/verifies; no cruft/scratch/backups/unreferenced inputs.

*Harbor packaging (read-only from task.toml + Dockerfile):* **verifier_configuration** (artifacts top-level & complete; tooling baked pinned, nothing installed at verify time; ground truth in tests/ not the image) · **environment_hygiene** (no COPY solution|tests; runtime + verifier deps baked; apt update→install→clean-lists, unpinned) · **resource_configuration** (timeouts/resources fit; difficulty intellectual not computational) · **task_name** (`[task].name`, org/name, descriptive kebab ≤3 words; root-level `task=` string breaks Harbor) · **task_readme** (optional; adds reviewer context; no duplication/misleading) · **task_toml_schema** (only recognized fields).

---

## 9 · Stumping playbook (patterns A–I, amplifiers, fairness)

Through-line: the model stops at the first green result. Target: 90% done right, one decisive determinate failure point it can't pattern-match, recall, or self-verify past.

| # | Pattern | Mechanism | Generalizes to |
|---|---|---|---|
| A | Latent crux | Deciding case invisible in sample; the agent's own diligence deepens the error | any real, determinate rule that never fires on visible data (cache key breaking on repeats, off-by-one past 10 records, policy clause the sample omits) |
| B | Wrong-default lure | Plausible cheap heuristic ≈ correct-but-costlier rule; diverges only where the agent won't look | prefix-vs-sum rollups; any near-equivalent shortcut |
| C | Misdirection | Environment offers an early, authoritative, wrong answer (plant tool, misleading comments, decoys, stale docs) | verifying tools vs ground truth — fair, but must be detectably wrong from agent-visible evidence (deliberate uncorrectable red herrings = reviewer Reject) |
| D | Evidence-forced reverse engineering | Undocumented conventions inferable only from data (sentinels, unit quirks, custom checksums, hidden constants); wide margins so method differences can't flip it | binary formats bit-by-bit; structurally-unfittable models |
| E | Ordering assumption | Data violates an unstated invariant the agent assumes ("sorted", "well-formed", "anomalies terminal") | wraparound counters; non-chronological logs |
| F | Discovery-hop | Final joint opaque guess; identical failure signal | fail-closed endpoints; ⚠️ riskiest — value must be derivable or it's a coin flip |
| G | Multi-mechanism accumulation | Many independent required fixes; all-or-nothing; ≥1 hidden à la A | 8-bug relinkers; breadth under an all-or-nothing bar |
| H | Entangled rules | Simple rules whose interactions rewrite each other; natural incremental replay fails | resets discarding prior approvals; bitemporal data; ledger reversals |
| I | Stale authority | "Latest value" ≠ "authoritative at the time"; sample never shows the gap | as-of joins; effective vs posting dates; superseded versions |

Amplifiers: silent failure (wrong looks normal — no crash, no hint) · no self-check (grade on held-out cases; sample friendly but unrepresentative) · all-or-nothing (single correct artifact).
Fairness: figure-out-able from givens · punishes avoidable pro mistakes, not gotchas · no hair-thin tolerances deciding pass/fail · hidden deciding cases OK, uncorrectable stated lies never. Gut check: an expert seeing only what the agent sees gets it right AND calls the failure fair.

Proven results: bytecode-vm-debug (A; 5/8 fail; quit at green in 77–137s of 900) · accrued-interest (A; 8/8; named the UK ex-dividend rule then dismissed it) · gnss-log-decode (E; 8/8; ~20 years off) · experiment-readout (B; 5/5; per-session vs per-user stats, error bar 5× small; one run computed both and picked wrong) · legacy-formatter-clone (D; 5/5; guessed famous checksums instead of deriving).

---

## 10 · Rejection catalogue & self-checks

**Six documented rejection causes:** undisclosed string literal · unspecified naming convention · unspecified aggregation semantics (single-assignment + tie-break) · unspecified duplicate/redelivery handling · over-strict/broken verifier (byte-exact demands or wrong golden — most common audit defect) · metadata/proposal/PR mismatch (7%→13% of flags; includes edited model_tested, wrong category, stale PR title).

**8-point pre-submit self-check:** formats/naming fully specified (IDs, enums, exact literals) · verifier checks only stated things · canonical rule named wherever multiple valid computations exist (assignment, tie-breaks, sort order) · duplicates/edge cases explicit · a reasonable alternative implementation still passes · no agent-readable file leaks bug/fix/answer · nothing undisclosed steers the agent to a wrong answer; every needed file named in the instruction · no malicious/injection content or obfuscated payloads anywhere.

**Audit-practice canon (6 graded items):** "the output folder" = violation (ambiguous; use `/app/output/clean.csv`) · "correct and well-formatted" = violation (not assertable; state header + exact row property) · `pip install pandas==2.2.2 pytest` = violation (pytest unpinned; pin everything) · author_name/email in task.toml = violation (no identity fields) · `#!/bin/bash` line 1 = correct · `echo 1 > /logs/verifier/reward.txt` = correct. Key lesson: exact /app paths, assertable criteria, pinned test deps in the single Dockerfile, reward to /logs/verifier/, no personal info.

**Reviewer Reject triggers (fatal — difficulty was never real):** most failures from an undisclosed verifier-enforced requirement · failures from an ambiguous term whose clarification yields a perfect answer · agents correct except an unpinned-but-valid choice (ordering/naming/format) · deliberate red herrings toward a wrong answer · manufactured difficulty (e.g. commit history shows a clarifying line removed to flip passes to fails) · undisclosed wrong info in instruction/inputs · all failures from an over-strict verifier · rebuild-from-scratch issues · ignored/disputed prior feedback without addressing it. The dividing question: *fix it — is it still hard?* Yes → Revise; no → Reject.

**Reviewer scoring map:** 5 no issues → Accept · 4 minor non-blocking (typos; one trivially-minor untested requirement) → Accept · 3 blocking-but-fixable not difficulty-collapsing → Revise (special case: clean task, wrong platform category → Accept at 3) · 2 major → Revise if fixable, Reject if fix flips difficulty/rebuild · 1 bad faith (ignored feedback, spam) → Reject. Score = quality on arrival; verdict = salvageability; set independently.

---

## 11 · FAQ nuggets & practicalities

reward.txt/ctrf.json → `/logs/verifier/` only. pytest → baked pinned in the single Dockerfile; no tests/Dockerfile exists; environment_mode unset. Internet on by default; design so the answer isn't fetchable. Instruction length: as short as possible (shortest good examples: three sentences). solve.sh shell-vs-python: whichever fits, logic in helpers. Dashboard: Available tasks / My tasks; filters Stage·Sort·Priority·Task type; sent-back tasks appear as "Needs Fixing" with comments in the quality-checks panel (resolve or formally disagree with each; unresolved checks block). "Unknown/holding" stage = project-lead look, no action. Slow task loads: don't refresh; wait 2× expected then Slack. "Failed to submit": check required fields/IDs → wait 1–2h → Chrome/incognito/clear cache → restart, no mobile/Chromebook → Slack. Reviews ~48h (weekends active; follow up Monday+). LLM use allowed everywhere; fact-check; repeated low quality = offboarding. No VPN (contact Support before travel). CPT/OPT possible but not on all projects. Payments Stripe (legacy Deel); Wednesdays for prior week; escalate only after Friday 12pm PST; disputes after funds land (payouts can arrive in parts). Meetings unpaid unless stated.

---

## 12 · Known discrepancies (authoritative resolutions)

| Where texts conflict | Resolution |
|---|---|
| `model_tested` in the guide vs the repo's pre-seeded value | Repo wins; leave as-is; editing = integrity failure (CE #6) |
| "fail ≥4 of 5" / pass@8 remnants | Current: pass@5, **fail ≥3/5 AND ≥1 anchor**, accept band 0–2 solves (June 30 update) |
| Reviewer guide "timeout ≤900s cap" | Stale; **3600s hard ceiling on the agent run, for Pass@2 and Pass@5 alike**. The 900s figure is obsolete everywhere |
| "Pass@2 is a cost gate reviewers disregard" | Stale; a failed Pass@2 blocks the pipeline before trials run (§5) |
| "Reviewer Notes / deep-review is advisory" | Stale; the live **Automated Review is blocking** on its Blocking Issues list. Only its Advisory Notes never gate |
| Guide: instruction must end with "You have N seconds…" | CONFIRMED STALE by live run — deep-review FAILs the suffix; omit it (§0.3) |
| `model_tested` value vs the model that runs trials | The pre-seeded value is a fixed label; trials may run a different model; never edit (§0.2) |
| "pass2 red-X means failure" | FALSE — red-X is by design until ≥1 valid fail; read the verdict comment (§0.11) |
| `harbor run -p tasks/<id>` in Step 8 | Use `harbor run -p . …` from `task/` |
| Strategies "A–G" + "playbook 1–12" | Nine patterns A–I exist; playbook never published (moves only referenced: #1 keep tuning past the visible sample, #3 rebuild layouts, #4 rebuild don't guess, #6 one common footing, #7 stats at the right unit, #9 right convention, #13 keep checking after green) |
| nop "reward <1.0" vs "= 0" | Binary reward in practice; treat requirement as nop = 0, oracle = 1 |
| README: "replace with description" vs rubric "optional" | Write the short overview (satisfies both); no duplication of task content |
| Pass@2 failed but Pass@5 in band | Fine — reviewers must disregard Pass@2; it's a cost gate only |
