# Next-Task Build Prompts

_Local working doc, gitignored, never part of a submission. Paste-ready kickoff prompts for the
next Dynamo task in a **fresh** repo/session. Distilled from `TASK_RETROSPECTIVE.md` §12-§18._

---

## ⚑ CURRENT RECOMMENDATION (2026-07-27, after `exact-result-recovery` — ACCEPTED)

**§E is now executed and MEASURED — its second derivation bit 5/5. Build §F next (second-workhorse
hunt); keep §E/§D as the guaranteed-reliable fallback.** Last cycle ran §E — stacked derivations — as
`dynamo/exact-result-recovery` (Mathematics/number-theory, retrospective §18), the first task off
Security turf. **Accepted:** pass@5 0 solved / 4 good-valid-fail / 1 in-progress-timeout, avg@5 0.000,
every gate green. v1 was a single gcd→CRT chain in three costumes (re-key split, signed range, a
hidden scale that cancels in 2×2 cross-products) and Opus solved it 2/2 — one trial shortcut the scale
by trialing `2^64`, textbook §17/Rule-2b "everything but the derivation is noticing." v2 stacked
corrupted-row consensus + a covariate `a·r + b·seq` re-key scheme behind all four answers + a
totals-coupling closure. Four mutants each bit exactly their fields; oracle 7/7, nop 0/7.

Three findings, now backed by the read:

1. **A second *derivation* stumps where a noticing axis doesn't — proven, not projected.** §17's
   pattern-C insurance bit 0/5; §18's covariate elimination bit **5/5**. All five agents did the gcd
   and the 2×2 cross-product and **none ever tried the 3×3 determinant over `(Δr, Δseq, Δcheck)`** the
   two-unknown form needs. The concrete lever this hands you: **to harden a gcd task, raise the number
   of unknown coefficients** so the plain cross-product fails and a higher-dimensional determinant
   cancellation is required. That elimination is gcd-adjacent but a *distinct derivation the model
   lacks* — the nearest thing to a second workhorse we have found.
2. **Only the hardest un-reached derivation sets the fail rate.** The corrupted-row consensus merely
   slowed agents (they flagged 6 of 11); the totals-coupling was never reached. Stack for realism and
   insurance, but budget the fail rate on the single derivation you are most confident the model can't
   reach — here one covariate crux carried the whole 5/5.
3. **The gcd family stretched to Mathematics/number-theory** — now **6-for-6**, no longer
   Security-only. Math is a proven away-turf home; keep it in the rotation. Still no *fully gcd-free*
   workhorse, which is why **§F** (the portfolio probe) is the deliberate next experiment; if you want
   a guaranteed read instead, **§D/§E on the raise-the-coefficient-count lever** is now the safest bet
   in the corpus.

§D remains the validated cryptography recipe; §A/§B/§C are forensics/network fallbacks. **Before the
first push, pre-flight the rulebook checklists** — two of three runs on `vault-master-recovery`, and
one on `exact-result-recovery`, were lost to rules already written down (`.dockerignore`;
`difficulty_explanation` needs provenance + a named practitioner *in that field*). Two fresh
defense-in-depth notes from §18's AVA pass: prefer a single `generated_output_artifact` label, and
store a salted commitment of each expected value rather than the plaintext answer in `truth.json`.

---

## ⚑ HOW TO WRITE THE PROPOSAL (convention — follow `Example.txt`, do not improvise)

**When.** Write it **after the task is built and locally validated**, so every detail is accurate to
what actually ships — but write it **forward-looking**, describing the design rather than reporting
on it. Never cite pipeline results, pass rates, gate outcomes or model performance; rulebook §6
fails a difficulty essay framed on results instead of on the task. (Workflow Phase 3 drafts the
proposal before building; this is the final write-up of the same four answers, done last so it
matches the shipped task.)

**Format — plain prose, zero decoration.** A `.txt` file with no formatting of any kind: no
Markdown, no bold or asterisks, no bullets, no tables, no emoji, no `====` bars, no `---` rules, no
numbered section headings, no title line. Just four plain-text headings with paragraphs under them.
**No em dashes** (workflow F3). Around 9 KB total.

**Structure — exactly four headings, written verbatim, in this order:**

```
Task difficulty
  Para 1: what the task provides and what the solver must recover.
  Para 2: the professional who does this work and why the skill matters, in both
          the recovery and the defensive direction.
  Para 3: synthetic or real data, and how it reproduces realistic complexity.
  Para 4: the pitfalls. One lead-in sentence, then (1) (2) (3) (4) each starting
          its own sentence, closing on a "the key point is..." line.

Intended solution approach
  The strategy in the order an analyst reaches it, the key move called out
  plainly, then the expert effort estimate as the last sentence.

Solution verification
  What the agent writes and how it is graded, then why the answer is uniquely
  determined and what each intended failure mode produces.

Category and sub-category justification
  "Category: X. Sub-category: Y." then the justification, including why it is not
  a neighbouring sub-category.
```

**The proposal stops there.** Artifact types and task objectives are NOT part of this document —
they are answered separately.

**Voice.** Write like a person, not a spec. Use contractions ("there's", "doesn't", "can't"), vary
sentence length, and break long paragraphs across lines. Leave out status headers, the generator's
existence, measured byte counts, and any literal secret value.

`Example.txt` in this repo is the reference to match — copy its shape exactly.

---

## Historical decision (2026-07-25, now executed — kept for context)

**Next task is Security / Cryptography.** The subcategories actually offered
in this repo family are **cryptography, vulnerability_analysis, security_hardening,
digital_forensics** — there is no "cryptanalysis" label. Of those, **cryptography** is the one that
clears both gates *when built as a break/recover task*: it keeps everything that has worked —
objectively-unique outputs and reverse-engineered, discovered difficulty — and it is the natural
home of the proven gcd-secret-prime-modulus stump. (Runners-up: digital_forensics — proven, but §16
just shipped one; vulnerability_analysis — unique only with a flag-output, and exploit-dev risks
uncounted timeouts; security_hardening — avoid: many valid states + disclosed best-practices →
ambiguous / too easy.)

**Why this fits both gates.** Repos carry a blocking **`qc_gate`** that rejects any task whose
answer is not **uniquely determined** by the visible data (it killed two data-analysis attempts —
a latent continuous crux and a wrong-default estimator — even with the rubric eval PASS). Breaking a
bespoke cryptographic scheme yields a **recovered key / seed / modulus / plaintext**: an exact
scalar with exactly one correct value, so it is **qc_gate-native**. The gcd-modulus family is now
4-for-4 at reaching the difficulty gate (`prvs`, `beacon`, `record-integrity-repair`,
`badge-log-forensics`).
⚠️ **Two category-specific traps.** (1) Build it as a **break/recover**, NEVER an
*implement-a-cipher* task — implementation is disclosed/derivable → too easy, and "is this
implementation secure?" is exactly the method-choice ambiguity qc_gate rejects. (2) Named textbook
attacks (single-byte / repeating XOR, Vigenère, hash length-extension, textbook small-e /
common-modulus RSA) are **memorization-solvable → "too easy" / not novel** — a frontier model
one-shots them. The break MUST reverse-engineer a **custom, undocumented construction** (RULE 1),
never apply a catalogued attack.

**How to use.** Open a fresh Claude Code session in the new repo. Paste **§0 (guardrails) first**,
then **exactly one** concept block. D/B are the recommended cryptography shapes; A/C are
forensics/network fallbacks if the pre-seeded subcategory turns out to be forensics instead.

- **D - break a bespoke cryptographic construction** (recover a secret key/seed/modulus + decrypt).
  The cryptography top pick; carries the proven gcd-modulus DNA. *Top pick.*
- **B - reverse-engineer a custom artifact** (decode / recovered constant / gcd-modulus). The
  proven `prvs`/`beacon` recipe; the single most reliable stump — sibling of D.
- **A - multi-field exact `findings.json`** from a synthetic incident (latent evidence + temporal
  authority). Forensics fallback; naturally unique, several independent cruxes.
- **C - network forensics** (trimmed pcap + secondary artifact) -> exact fields. Keep as a variant.

---

## §0 - Shared guardrails (PASTE THIS FIRST, for every concept)

```
You are building one hard Project Dynamo task (Terminal-Bench / Harbor "TB2" format) for
Handshake AI, in Security / Digital Forensics. The whole game is to clear qc_gate AND the pass@5
gate. Internalize these before designing anything. If my working docs are in the repo
(Dynamo_Reference_Rulebook_v2.md, Dynamo_Workflow_Claude_v2.md, TASK_RETROSPECTIVE.md), follow
them; essentials are inlined below.

QC_GATE REALITY (READ FIRST - this is what sank two prior tasks; TASK_RETROSPECTIVE §15):
- Many repos now have a BLOCKING, fail-closed `qc_gate` (LLM soundness probes) between validation
  and pass2. It BLOCKS any task whose expected output is NOT UNIQUELY DETERMINED by what the agent
  can see. It reads a method/interpretation choice, a continuous prediction, or an underdetermined
  mapping as "ambiguous / underdetermined / hidden-knowledge" and fails it - EVEN WHEN THE RUBRIC
  EVAL PASSES (qc_gate overrules the rubric).
- THE ONE-QUESTION TEST, applied before you build: "could two competent, good-faith experts
  produce DIFFERENT answers from the same inputs?" If yes -> qc_gate blocks. If no (exactly one
  correct value) -> qc_gate passes. Make every graded field OBJECTIVELY UNIQUE: an exact id, host,
  account, hash, timestamp, decoded integer. A wrong answer must be objectively wrong, not a
  defensible alternative. NEVER grade free-form prose, a "root cause", a ranking that ties, or any
  statistic that rests on an aggregation/modeling choice.
- Difficulty still comes from DISCOVERY (the deciding evidence or rule is hidden and must be
  uncovered/reverse-engineered), but the ANSWER it yields must be singular and determinable from
  the shipped artifacts alone.

PASS@5 GATE REALITY (after qc_gate):
- The trials job needs >=3 agent FAILS of 5, AND >=1 "good-valid" anchor (clean reward-0 wrong
  output, or a stuck-timeout that is not an approach-validity fail). 0 solved is best. Oracle must
  score 1.0; nop/baseline < 1.0. ONLY WRONG GRADED OUTPUT COUNTS - in-progress/soft timeouts count
  for nothing, so difficulty must yield a determinate WRONG ANSWER, never a clock-out. Keep the
  required solution diff small (pre-pay boilerplate in the starter) so agents finish inside 3600s.

RULE 1 - DISCOVERED beats DERIVABLE. A frontier model transcribes any rule you write in prose and
derives any property you describe. The deciding evidence/rule must be UNCOVERED from the artifacts,
never stated. The instruction says what to produce and where; it must NOT reveal which artifact is
authoritative, that a clock is skewed, that a record was corrected, or how a custom format decodes.

RULE 2 - one crux is fragile; STACK >=2 INDEPENDENT axes. Two axes that each bite the converged,
correct approach push per-trial fail into ~0.55-0.6. "Independent" is load-bearing: different
artifact, different skill, different evidence - if cracking axis 1 hands you axis 2, they don't
stack. (A strong single crux with a proven ~1.0 bite, like gcd-modulus, can carry a task; still
add an independent insurance axis.)

RULE 2b - ONLY A DERIVATION COUNTS AS AN AXIS (measured 2026-07-25, retrospective §17). An axis
that asks the agent to NOTICE something scores ZERO in the arithmetic. Proven beaten 5/5 on a real
read: version skew between a shipped reader and the artifact, a stale vendor tool that silently
returns superseded values, an unparsed trailing region, a hidden journal, a superseded record, a
latent flag bit, "the obvious artifact is not authoritative". Frontier agents find all of it. What
they do NOT do is reach a derivation they have not been prompted toward - the same five agents
never computed body-minus-trailer or called gcd, and one of them had already written down that the
trailer "might encode master key". Build noticing traps for realism and fairness if you like, but
count only derivations toward the >=3-of-5. Same rule for a graded field that is free to read off a
header: verification surface, zero difficulty, do not count it.

ANTI-FRAGILITY CHECKLIST (do all five, in order):
1. Mutant-or-it-didn't-happen, PER AXIS. Build the one-decision-different variant of the reference
   and prove it fails EXACTLY the intended fields, via wrong output, not timeouts. Watch for a
   parser/library pre-springing the trap so the buggy variant passes anyway.
2. Wrong output, never a clock-out.
3. Confirm the axes are actually independent (different artifact + skill + evidence).
4. Two-sided traps: pair a reject-case with an accept-case so a crude over-correction fails from
   the other direction.
5. Do the arithmetic BEFORE building: estimate each axis's bite; confirm combined per-trial fail
   lands in the accept band (0-2 solves of 5).

AMPLIFIERS: silent failure (a wrong host/hash looks like a legitimate finding); no self-check
(grade on evidence the agent's own tooling won't surface); all-or-nothing (every field must be
right). FAIRNESS gut check for every field: an analyst seeing only the shipped artifacts reaches
it AND calls the failure fair. A red herring not correctable from agent-visible evidence is a
reviewer REJECT - never ship one.

VERIFICATION (this category is qc_gate-native, keep it that way):
- Grade EXACT scalar equality (string / int / sha256 / id / RFC3339 timestamp), all-or-nothing.
  No tolerance bands, no fuzzy matching, no prose. Each field independently, exactly checkable.
- Every graded field must be recoverable from the shipped artifacts to a SINGLE value. If any
  field could be argued two ways, cut it or disambiguate the artifacts (not the instruction).

HYGIENE (prevents voided runs and self-inflicted blocks):
- Secrets (ground truth, the hidden authoritative values, keys, the decode rule) live ONLY in
  task/tests/ (verifier side). NEVER in task/environment/ or the starter.
- Dockerfile must not COPY task/tests, and must not even contain the literal string "tests/test.sh"
  in a comment (a substring static check trips on it).
- Pin `* text=auto eol=lf` in .gitattributes from the first commit; mark binary artifacts
  (pcap, sqlite db, ELF, .gz) explicitly `name binary` so they are not LF-corrupted. Compile any
  shipped binary inside the pinned base image so glibc matches.
- gitignore jobs/ and task/jobs/ (they hold the solved answer). Keep instruction.md < ~1500 tokens.
- The pipeline is path-filtered on task/ and qc_eval runs on the incremental push diff: to get a
  real qc read, the triggering push must change an agent-facing task file, not be empty or
  tests-only (§15d).
- Do NOT commit or push. I do that. Your job ends at a locally-validated task tree.

DELIVER the standard tree and validate locally with harbor before handing back:
  task/instruction.md, task/task.toml (DO NOT edit pre-seeded category/subcategory/model_tested/
  agent_tested), task/environment/Dockerfile (+ data/), task/solution/ (reference oracle),
  task/tests/test.sh + test_outputs.py. Local bar: oracle 1.0, nop/starter < 1.0, image builds
  clean, every mutant fails EXACTLY its intended field(s) via wrong output, 5x no-flake on any
  nondeterministic surface. Report the per-axis bite estimate and the arithmetic.
```

---

## §A - Multi-field exact `findings.json` from a synthetic incident (FORENSICS FALLBACK)

_The only forensics shape that carries >=2 independent deterministic cruxes without collapsing to
one opaque guess. Latent evidence (A) + stale-authority/temporal (I). Every field an exact scalar
-> qc_gate-native._

```
Build the task in the guardrails above. Category/subcategory: Security / digital_forensics (or
network_forensics) - use whatever is pre-seeded in task.toml; do not change it.

CONCEPT. Ship a small, self-contained synthetic incident: an obvious application/auth log PLUS at
least one SECONDARY artifact (a rotated/compressed .gz log, a SQLite audit db + its -wal file, a
systemd/binary journal, a trimmed pcap, a shell history, a browser/download sqlite). The agent
writes /app/output/findings.json with SEVERAL EXACT scalar fields, each a separate discovered
crux, e.g. {"entry_host": ..., "actor_account": ..., "exfil_object_sha256": ...,
"first_malicious_event_id": ..., "c2_domain": ...}. Grade exact string/int/hash/id equality,
each field independently, all-or-nothing. NEVER grade a timeline or prose.

AXIS 1 (workhorse, A - latent evidence). The DECISIVE fact (true entry point, or the true exfil
object) is ABSENT from the obvious log and lives ONLY in the secondary artifact the agent must
think to parse: the uncommitted row in the SQLite -wal that never made it to the main table, the
entry inside the rotated .gz, the record only in the binary journal. An agent reasoning over the
headline log alone produces a plausible-but-wrong value (silent). Discovered: the instruction
lists the artifacts but never says which is authoritative.

AXIS 2 (insurance, INDEPENDENT route, I - stale authority / temporal). Attribution depends on time
reasoning the naive path gets wrong, on a DIFFERENT artifact/skill from axis 1: clocks are skewed
across sources and must be reconciled against a shared anchor event (a request that appears in two
logs), OR a record was corrected/superseded after the fact so "latest wins" / raw wall-clock sort
MISATTRIBUTES and the correct answer uses the value authoritative AS OF the incident moment. All
skew/corrections are present in the data (fair), just not flagged. Confirm independence: locating
the hidden evidence does not reveal the clock skew, and vice versa.

WHAT THE INSTRUCTION MAY / MAY NOT SAY. It lists the artifact paths, the exact findings.json schema
and field semantics (each field's meaning and exact format - e.g. "entry_host: the hostname of the
first compromised host; exfil_object_sha256: lowercase hex sha256 of the exfiltrated file"), and
all-or-nothing. It must NOT say which artifact is authoritative, that clocks are skewed, or that a
record was corrected.

VERIFY. Reference emits every field correctly -> 1.0. A headline-log-only solver gets the axis-1
fields wrong; a naive-latest / raw-clock solver gets the axis-2 fields wrong; a mutant isolates
each (fails exactly its fields, wrong output). Every field exactly checkable, no ambiguity.
FAIRNESS: an analyst with only the shipped artifacts reaches every field and calls each failure
fair - no field a coin-flip. Report the arithmetic.
```

---

## §B - Reverse-engineer a custom artifact (the proven gcd-modulus / decode recipe)

_Pattern D. This is the shape that has cleared every gate it met: 2 security accepts (prvs, beacon)
and the qc_gate in §15. The answer is an exact decode -> objectively unique -> qc_gate-native, while
the recovery route is one models decline._

```
Build the task in the guardrails above. Category/subcategory: Security / reverse_engineering or
digital_forensics - use the pre-seeded value.

CONCEPT. Ship a proprietary/undocumented artifact the agent must DECODE or REPAIR: a custom binary
event export, a firmware/telemetry blob, a log in a non-standard record format, or a table with an
integrity trailer. The agent recovers EXACT values (decoded readings, repaired fields, the payload
of flagged records) to /app/output/*.csv or findings.json, graded exact-equality, all-or-nothing.

AXIS 1 (workhorse, D - the many-to-one reduction; PREFER gcd-secret-prime). The integrity/derived
field is a deterministic function of the record reduced modulo a SECRET PRIME (or a keyed/custom
transform), recoverable ONLY by a reduction the catalogue-first instinct misses:
  - gcd-modulus (6-for-6, most reliable): each intact record satisfies hash(fields) = trailer
    (mod M) for a fixed unrecorded prime M; M is uniquely recovered as gcd(hash - trailer) over the
    intact records; corrupted/blank fields are then the unique residue. Agents run named-checksum
    catalogues, z3/CRC search, byte-affine and power-of-two (Hensel) attacks - a LARGE PRIME M
    defeats all of them and forces gcd. Disclose the packing/hash formula if needed for uniqueness;
    keep M secret. Every field < M so recovery is unique -> qc_gate-safe.
  - Prefer a many-to-one REDUCTION over any reversible per-value transform: full known-plaintext
    over a reversible xor/keystream hands the agent the whole secret (a v1 was solved this way in
    §13). The secret must not be readable off the output.

AXIS 2 (insurance, INDEPENDENT route, A - latent value convention). A second recovered field
follows a latent, determinate convention read from a DIFFERENT part of the artifact: a sign rule
(sign-magnitude vs two's complement, where the shipped samples are all non-negative so they agree,
and only held-out negatives expose it), an offset/bias, an endianness, or a units quirk - disclosed
only in a shipped stripped decoder/reader the agent must disassemble, or inferable from a header.
Confirm independence: cracking the modulus does not reveal the sign rule (beacon: one agent solved
the sign rule and still lost on the gcd).

SHIPPED-TOOL AUDIT (F19, do this before trusting any axis). If you ship a reader/decoder binary,
audit it per field: if round-tripping an answer through it reveals the graded value, it is a free
oracle. Fix with version skew - an older tool that parses a superset and predates the graded field,
so it answers "this parses" but never "this is the writer's value." Gate any verbose/round-trip
mode.

VERIFY. Reference decodes/repairs every field -> 1.0. Mutant M1 = wrong/ignored modulus (or a
power-of-two guess) fails exactly the reduction fields; mutant M2 = wrong sign/convention fails
exactly the convention fields; each via wrong output, green elsewhere. Compile any shipped binary
in the pinned base image (glibc match) and mark it `name binary` in .gitattributes. Report the
per-axis bite (gcd historically ~1.0) and the arithmetic.
```

---

## §D - Break a bespoke cryptographic construction (CRYPTOGRAPHY TOP PICK)

_The break/recover form of Pattern D (Security / cryptography). Output is a recovered secret / plaintext -> objectively
unique -> qc_gate-native. Difficulty lives in reverse-engineering a CUSTOM construction; catalogued
named attacks are banned (memorization-solvable -> "too easy")._

```
Build the task in the guardrails above. Category/subcategory: Security / cryptography - use
whatever is pre-seeded in task.toml; do not change it. Build it as a BREAK/RECOVER task (recover a
secret + decrypt), never an implement-a-cipher task.

CONCEPT. Ship a small, self-contained artifact protected by a BESPOKE, undocumented scheme (a
custom keystream/PRNG cipher, a homebrew keyed checksum/MAC, a telemetry or event stream under a
non-standard reduction) together with enough intact/known structure to PIN the secret. The agent
writes /app/output/findings.json (or *.csv) with EXACT scalars - the recovered secret and/or the
decrypted values of flagged records, e.g. {"modulus": <int>, "seed": <int>,
"recovered_plaintext": ..., "blanked_field": <int>}. Grade exact string/int/hash equality, each
field independently, all-or-nothing. NEVER grade prose, a "method", or anything tolerance-based.

HARD NOVELTY RULE (category-specific, non-negotiable). The break must require uncovering a CUSTOM
construction from the artifact. BANNED because a frontier model one-shots them: single-byte / repeating-key
XOR, Vigenere, classic hash length-extension, textbook RSA (small-e, common-modulus, shared-factor),
ECB pattern galleries, any named CTF-catalogue attack. If the crux has a Wikipedia name, it is too easy.

AXIS 1 (workhorse, D - the many-to-one reduction; PREFER gcd-secret-prime). The secret is
recoverable ONLY by reverse-engineering the construction, not by catalogue:
  - gcd-secret-prime-modulus (6-for-6, most reliable): each intact record satisfies
    hash(fields) = trailer (mod M) for a fixed unrecorded prime M; M = gcd(hash - trailer) over the
    intact records (prime -> gcd lands exactly); blanked/forged fields are then the unique residue
    (every field < M -> unique). Agents run named-checksum catalogues / CRC / z3 / Hensel and a
    billions-wide search for M instead of gcd. Disclose the packing/hash formula if uniqueness needs
    it; keep M secret.
  - custom LCG/PRNG keystream: recover multiplier/increment/modulus (or seed) from consecutive
    outputs via gcd-of-differences / a small lattice, then decrypt. Keep parameters NON-standard so
    named-generator fingerprinting fails; ship no generator name.
  - Prefer a many-to-one REDUCTION over any reversible per-value transform. Full known-plaintext
    over a reversible xor/keystream hands the agent the whole secret (a v1 was solved this way in
    §13). The secret must NOT be readable off the shipped output.

AXIS 2 (insurance, INDEPENDENT route, A - latent convention). A second exact field follows a latent
determinate convention read from a DIFFERENT part of the artifact: a sign rule (sign-magnitude vs
two's complement, samples all non-negative so they agree, only held-out negatives expose it), an
endianness/offset/bias, an IV/nonce-derivation or per-record-salt quirk - disclosed only in a shipped
stripped decoder the agent must disassemble, or inferable from a header. Confirm independence:
recovering the modulus/seed does NOT reveal the convention (beacon: one agent cracked the sign rule
and still lost on the gcd).

SHIPPED-TOOL AUDIT (F19, before trusting any axis). If you ship a reader/decoder binary, audit per
field: if round-tripping an answer through it reveals the graded value, it is a free oracle. Fix with
version skew (an older tool that parses a superset but predates the graded field). Gate any
verbose/round-trip mode.

VERIFY. Reference recovers every field -> 1.0. Mutant M1 = wrong/guessed modulus or wrong PRNG params
fails EXACTLY the reduction fields; M2 = wrong sign/convention fails EXACTLY the convention fields;
each via wrong output, green elsewhere. Compile any shipped binary in the pinned base image (glibc
match), mark it `name binary` in .gitattributes. Report per-axis bite (gcd historically ~1.0) and the
arithmetic (confirm combined per-trial fail lands 0-2 solves of 5).
```

---

## §C - Network forensics variant (trimmed pcap + secondary artifact)

_Same A + I structure as §A, on network evidence. Keep exact-scalar outputs._

```
Build the task in the guardrails above. Category/subcategory: Security / network_forensics - use
the pre-seeded value.

CONCEPT. Ship a small trimmed .pcap (a few hundred packets: a beaconing implant, a DNS-tunnel, a
staged exfil over HTTP/TLS-metadata) plus a SECONDARY artifact (a proxy/DNS log, a netflow export,
a host process log). The agent writes /app/output/findings.json with EXACT scalars, e.g.
{"c2_ip": ..., "beacon_interval_seconds": <int>, "exfil_bytes": <int>,
"first_beacon_frame": <int>, "decoded_token": ...}. Exact equality, all-or-nothing.

AXIS 1 (workhorse). The true C2 / exfil channel is NOT the loudest flow: the obvious high-volume
talker is benign (an update service, a CDN), and the real implant is a low-and-slow beacon whose
period is only visible by reconstructing inter-packet timing (a determinate integer interval) - or
the exfil is chunked so per-flow byte counts mislead and the correct total needs reassembly. The
decisive detail is present in the pcap but invisible to a headline "top talker" read.

AXIS 2 (insurance, INDEPENDENT). A decoded field: a token/payload is encoded (base32/xor with a key
present in a header, a length-prefixed field) and must be reconstructed deterministically; OR clocks
between the pcap and the proxy log are skewed and must be reconciled against a shared anchor packet
to attribute the session. Different skill (byte reconstruction vs timing) from axis 1.

INSTRUCTION lists the artifacts and the exact findings.json schema/field semantics and
all-or-nothing. It must NOT name the C2, say which talker is benign, or state the encoding/skew.

VERIFY. Reference emits every field; a top-talker solver misses axis 1; a naive-decode / raw-clock
solver misses axis 2; mutants isolate each; exact equality, no ambiguity. Bake the pcap-reading dep
(scapy/dpkt, pinned) into the Dockerfile; ship the pcap as `name binary`. Report the arithmetic.
```

---

---

## §E - Stacked derivations: the gcd workhorse plus a SECOND forced derivation (BUILD THIS NEXT)

_The direct fix for §17's finding, now VALIDATED: `exact-result-recovery` (retrospective §18) ran
exactly this shape and accepted at 0 solved / 5, the covariate second derivation biting 5/5. Same
proven qc_gate-native shape, but the insurance axis is upgraded from "did you notice the hidden
thing" (bite ~0, beaten 5/5) to "did you reach the second derivation" (the only kind of axis that has
ever bitten). The most reliable form of the second derivation, measured: a multi-coefficient scheme
(`check = a·x + b·y mod M`) that forces an N+1-dimensional determinant elimination where the model's
catalogued 2×2 cross-product fails. Expected outcome: 0-1 of 5, difficulty no longer on a single
point._

```
Build the task in the guardrails above (§0). Category/subcategory: whatever is pre-seeded in
task.toml - do not change it. This shape fits cryptography, cryptanalysis, reverse_engineering,
digital_forensics or vulnerability_analysis with only the cover story changed.

CONCEPT. Ship a bespoke, undocumented artifact whose secret cannot be recovered by ONE derivation.
The agent writes exact scalars to /app/output/findings.json, graded exact value + exact JSON type,
all-or-nothing. Every graded field must be objectively single-valued (qc_gate, §15c).

AXIS 1 (workhorse, unchanged - gcd-secret-prime, 6-for-6). Records carry an integrity trailer that
is a deterministic function of the body reduced modulo a secret prime M. M = gcd(f(body) - trailer)
over intact records; prime, so the gcd lands exactly. Keep the reduction many-to-one so no amount of
known plaintext surrenders the secret. Do NOT disclose the trailer relation; a field the shipped
reader parses and never uses is enough of a breadcrumb (proven fair: decisive_rule_disclosed PASS).

AXIS 2 (insurance - MUST BE A DERIVATION, NOT A NOTICING TASK). Recovering M must be NECESSARY BUT
NOT SUFFICIENT. Pick one, and confirm it needs different evidence and a different skill:
  - SEGMENTED MODULI. Records span two key epochs with different secret moduli, marked by a visible
    epoch/channel byte. A naive gcd over ALL records returns 1 or a tiny value, which reads as "not
    a modulus scheme" and pushes even a gcd-aware agent off the route; the correct move is to
    segment first, then gcd per epoch. Fair (the field is visible and labelled), determinate, and it
    specifically defends the workhorse against an agent who HAS learned the gcd trick.
  - CRT RECOMBINATION. The graded value exceeds every single modulus and is carried as residues
    across several channels with unrecorded moduli. Recover each modulus by gcd, then reconstruct by
    CRT. Uniqueness holds as long as the value is below the product of the moduli - state that bound
    implicitly by construction, and verify it.
  - A SECOND UNRECORDED CONSTANT recoverable only by a different reduction (a per-record offset or
    multiplier that must be solved from a small linear system once M is known).
Whichever you choose, the acid test is: an agent who computes the gcd correctly still produces a
WRONG GRADED VALUE unless they also make the second derivation.

BANNED as axis 2 (this is the §17 lesson): version skew, a stale shipped reader, a hidden trailing
region, an unparsed journal, a superseded record, a latent flag bit, "the obvious artifact is not
authoritative". All of these are FAIR and REVIEWER-SAFE and they were ALL beaten 5/5. Use one if you
want realism, but score it at ZERO in the arithmetic.

ARITHMETIC. Axis 1 historical bite ~0.9-1.0. Axis 2 target bite >=0.3 measured by mutant, not
assumed. Do the estimate before building and confirm 0-2 solves of 5.

VERIFY. Mutants: M1 = no/wrong modulus fails exactly the reduction fields; M2 = correct gcd but the
second derivation skipped or done naively fails exactly its fields; M3 = the crude over-correction
of M2 fails from the other direction. Each via wrong graded output, never a timeout, green
elsewhere. Oracle 1.0, nop 0.0, 5x no flake. Do NOT grade a field that is free to read off a header
- it adds verification surface and zero difficulty (§17e).
```

---

## §F - Second-workhorse hunt: a forced derivation that is NOT gcd (FOLLOW-ON)

_A deliberate portfolio experiment, not a reliability play. Every accept so far has been carried by
one mechanism; we do not know whether a second exists. Run this when there is appetite for one
calibration probe, and keep §D/§E as the fallback if it comes back too easy._

```
Build the task in the guardrails above (§0). Category/subcategory: whatever is pre-seeded.

GOAL. Find out whether a forced derivation OTHER than gcd-of-differences can carry a task. Success
is not just an accept - it is learning whether we have a second reliable stump, so record the read
either way (a "too easy" here is worth more than another gcd accept, because it is information we
do not have).

REQUIREMENTS the candidate crux must satisfy (all four, or it is not a candidate):
  1. FORCED DERIVATION. The answer is reachable only by a derivation step, not by a search, a
     catalogue lookup, or noticing a hidden artifact. Test: write down the one line of reasoning
     that cracks it. If that line is a recalled technique with a Wikipedia name, reject it
     (memorization-solvable -> too easy, and a novelty risk).
  2. LARGE SEARCH SPACE. Brute force must be hopeless (>=2^50), so the derivation is the only route.
  3. EXACT SCALAR ANSWER. Objectively single-valued, recoverable from the shipped artifacts alone,
     verifiable by a consistency condition that does NOT double as a cheap search oracle. This is
     the qc_gate bar (§15c) and it is non-negotiable.
  4. MANY-TO-ONE. The secret must not be readable off the output under known plaintext (§13's v1
     died exactly there).

CANDIDATES worth trying, roughly in order:
  - Hidden-state recurrence: a custom generator whose outputs are TRUNCATED or filtered (only high
    bits, or every k-th output, or values passed through a lossy quantizer), so the state must be
    reconstructed by solving a small system rather than by replaying the generator. Keep the
    parameters non-standard so named-generator fingerprinting fails, and ship no generator name.
  - Simultaneous congruences over unrecorded moduli (the CRT half of §E, promoted to workhorse).
  - A recurrence whose coefficients must be solved from observed transitions, where the naive
    fit is under-determined until the solver notices which observations are independent.
  - A structural invariant that pins a constant only when combined ACROSS records, so per-record
    analysis - the instinctive move - yields nothing.

MUTANT-FIRST, HARDER THAN USUAL. This mechanism is unproven, so bench it before investing: build the
one-decision-different variant and confirm it fails exactly its fields via wrong output. Watch
specifically for the stdlib or a library pre-springing the trap, and for the derivation collapsing
into a feasible search once concrete numbers are chosen. If the candidate dies on the bench, do not
iterate novelty - fall back to §E immediately (§13 lesson 2: a first "too easy" is one pivot, not a
saga).

INSURANCE. Because the workhorse is unproven, pair it with the gcd axis as the SECOND axis rather
than the first. That way a failed experiment still lands a task that clears the gate, and the read
tells you what the new mechanism contributed on top.
```

---

_Reminder: qc_gate is the new first hurdle - every graded field must be OBJECTIVELY UNIQUE and
recoverable from the shipped artifacts, or the gate blocks it before pass2 (§15). Difficulty lives
in what must be DISCOVERED (the hidden artifact, the skew, the reduction), never in the prose.
Mutant-verify each axis against the real verifier before trusting it._
