# Taxonomy cheat-sheet — task_objective and artifact_type

## Where each thing lives

| Thing | Where | Editable? |
|---|---|---|
| **The answer for one task** | that repo's `task/task.toml`, `[metadata]` | **Yes — you fill these in** |
| **The allowed values** (closed sets) | `references/diversity-taxonomy.toml`, shipped in every repo | No — read only |
| **`category` / `subcategory`** | same `[metadata]` block | **No — pre-seeded by Dynamo, never edit** |

Both lists are **closed sets**: a value not on the list is a hard static-check failure, not a
warning. `category`/`subcategory` are different — an unlisted subcategory is only a warning, but
you must not touch them anyway because Dynamo assigns them.

## task_objective — allowed values

```
implement   fix        configure   analyze     transform   validate
optimize    migrate    refactor    test        debug       build_or_package
deploy_or_operate      recover_or_repair_artifact          generate
compare_or_select      secure_or_harden                    automate_workflow
```

## artifact_type — allowed values

```
codebase                          single_script_or_program
test_suite_or_benchmark           build_system_or_package_metadata
configuration_file                shell_environment
service_or_daemon                 container_or_virtual_environment
database_or_structured_store      dataset_or_tabular_file
text_or_log_file                  document_or_report
archive_or_compressed_artifact    binary_executable_or_library
media_artifact                    model_or_checkpoint
hardware_or_firmware_artifact     network_endpoint_or_protocol_artifact
repository_history_or_version_control_state
security_artifact                 mathematical_or_scientific_model
generated_output_artifact
```

## ⚠ What has actually been claimed — 14 tasks

**`task_objective`**

| value | used |
|---|---|
| `analyze` | **12/14** |
| `recover_or_repair_artifact` | 5/14 |
| `fix` · `debug` · `implement` | 2/14 each |
| `optimize` · `transform` · `generate` | 1/14 each |
| everything else | **0** |

**`artifact_type`**

| value | used |
|---|---|
| `generated_output_artifact` | **8/14** |
| `security_artifact` | 3/14 |
| `codebase` · `database_or_structured_store` · `media_artifact` · `document_or_report` | 2/14 each |
| 6 others | 1/14 each |
| remaining 12 values | **0** |

**Read this alongside §24a.** Dynamo monitors *submission similarity* by human review, and
`analyze` + `generated_output_artifact` is the label pair on most of the corpus. That is a
consequence of the strategy — §24b says claim categories where the deliverable is a *computed
answer*, and a computed answer is almost always `analyze` → `generated_output_artifact`. It is not
wrong, and the labels must describe the task honestly rather than be varied for appearance.

But it is worth knowing that the label history makes the pattern legible at a glance to anyone
scrolling the submissions. Where a second label genuinely fits — `recover_or_repair_artifact` for a
recovery framing, `media_artifact` for image/audio output — use it. Where it does not, do not
invent it: §25e records a reviewer noting `dataset_or_tabular_file` was a stretch for a 4-key JSON
map, and a stretched label is worse than a repeated one.

## How to choose, so this stops compounding

Run these four questions in order when filling in a new `task.toml`. They take about a minute and
they are the whole fix.

**1. What does the agent physically produce?** Answer that first, before looking at any list. A
JSON file of computed values is `generated_output_artifact`. A repaired archive is
`archive_or_compressed_artifact`. A decoded image or audio file is `media_artifact`. Write the
answer down before you open the closed set, so the list does not anchor you.

**2. Is there a more specific accurate label than the one you reached for?** `analyze` is the
default reflex and it is correct 12 times out of 14 so far. But if the task recovers something that
was damaged or lost, `recover_or_repair_artifact` is more specific and equally true. If it produces
a file in a target format, `transform` may fit better. Take the more specific label when it is
honestly accurate.

**3. Does a second label genuinely apply?** Both fields are arrays. Two accurate labels beat one
accurate label. Two labels where the second is a stretch is worse than one, so this is not a licence
to pad.

**4. Check it against the history above.** If your pair is `analyze` + `generated_output_artifact`
again, that is a signal to look at the *task shape*, not the label. The labels are downstream of
what you built. The right response to a repeated pair is a differently shaped task, never a
differently worded label.

### The thing not to do

Do not vary the labels to look diverse. §25e records a reviewer calling out
`dataset_or_tabular_file` as a stretch for a four-key JSON map. A stretched label reads worse than
a repeated one, and the static check does not care either way. Honest first, specific second,
varied only as a consequence of the two.

## Sanity check before pushing

- Every value in both arrays appears in the closed sets above.
- `category` / `subcategory` / `model_tested` / `agent_tested` are **untouched** from the seed.
- The labels describe what the task actually produces, not what would look diverse.
- You ran the four questions rather than copying the previous task's pair.
