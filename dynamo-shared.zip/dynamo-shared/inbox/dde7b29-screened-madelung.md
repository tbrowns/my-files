# inbox — dde7b29 / screened-madelung

Task `dynamo/screened-madelung`, repo `dynamo-dde7b29-scientific-computing-and-domain-science`.
**Still in progress** — this file is findings-so-far, not a task-boundary merge. Do not merge into
`TASK_RETROSPECTIVE.md` until the task is accepted, released, or abandoned.

Head `2a43c29`. PR #1 labels: `in-progress`, `needs-revision`.

## 1. The labor trim converted discounted timeouts into solves, not into valid fails

This is the finding worth carrying forward, and it corrects a reading in §15/§18c that looked safe.

Eight runs. The trim ("cells to 6–8 ions so slow attempts end graded") did exactly what §12b and
§18c prescribe:

| | Run `30160348295` (pre-trim) | Run `30362296680` (post-trim) |
|---|---|---|
| in-progress timeouts | 2 of 5 — **discounted** | **0** |
| valid fails | 2 | **0** |
| solved | 1 of 5 (avg@5 = 0.200) | **2 of 2** |
| gate | "Not hard enough" | "no valid agent failure" |

**The two agents who had been timing out did not start producing countable fails. They started
solving.** Cutting labor removes clock pressure; if the clock pressure *was* the difficulty, cutting
it does not reveal a crux, it removes the last obstacle.

**Rule:** before trimming labor to rescue discounted timeouts, establish that the crux kills
*independently* of the clock. If the only evidence that a task is hard is that agents run out of
time, the task is not hard — it is long. §12b says labor regression is not difficulty signal; this
adds the converse, which is the trap: **a timeout is not evidence of a crux, and trimming will tell
you so at the cost of a full round.**

## 2. A crux that is a change of variables is not a crux at any magnitude

The kernel:

```
E(q_i, q_j, d) = q_i q_j · e^(−κ s) / (√det ε · s),    s = √(d · ε⁻¹ · d)
```

One metric, used twice — the exponential and the Coulomb denominator measure distance the same way.
Since ε is symmetric positive-definite, `s = |ε^(−1/2) d|`, so the single linear map
`A → A ε^(−1/2)` isotropizes the whole kernel and leaves textbook Yukawa Ewald with a published
closed form.

The gate's root-cause analysis, verbatim:

> Both agents independently identified the ε^(−1/2) metric transform (Cholesky of ε⁻¹) within the
> first few steps and reduced the problem to a textbook isotropic screened-Coulomb (Yukawa) Ewald
> sum. The task's stated crux — a kernel for which "standard Ewald formulas do not apply verbatim" —
> is defeated by exactly that standard, well-represented reduction, which the `solution_explanation`
> itself confirms maps each crystal "EXACTLY onto an isotropic screened-Coulomb crystal in a
> transformed frame."

**Raising the anisotropy could never have helped.** A change of variables dissolves it at any
magnitude; extremity buys clock only — which is what generated the discounted timeouts to begin
with. The two failure modes were the same defect wearing different clothes.

**Design test, general:** if the difficulty is a *parameter* of the problem rather than a *structure*
of it, ask whether some transformation normalises that parameter away. Anisotropy, scale, offset,
units and basis are all in this family. A reviewer's "this is hard because the numbers are extreme"
should trigger it.

**The tell was in the task's own `task.toml`.** `solution_explanation` insight (1) states the exact
reduction that defeats the task. A solution explanation that names a step which *removes* the stated
crux is a self-refuting difficulty claim, and it was sitting in the file through eight runs and a
passing `deep_review`. Worth adding to a pre-push read: *does my own solution explanation describe
the crux being dissolved rather than confronted?*

## 3. `deep_review` passing all 24 criteria did not mean the task was hard

Run `30275593052` had `deep_review` PASS with **all 24 gap-rubric criteria green** and *"no blocking
gap-rubric failures or material coverage holes"*, plus an adversarial cheat-pass of *"the only way
through is the right answer."* That was true and beside the point: the way through *was* the right
answer, and the right answer took a few steps.

**The review gates audit specification quality and verifier integrity. Only `pass2`/`trials` measure
difficulty.** A fully green review row is not evidence of a crux, and on this task it coexisted with
2/2 solves. Do not read review clearance as difficulty reassurance.

## 4. `ava_review`'s undisclosed block was never resolved — it was bypassed

Two runs (`30157545130`: `potential_major=5, parse_failures=1`; `30275593052`: `6` and `2`) blocked
with `confirmed_major=0 supported_major=0` and disclosed nothing — `ava.json` goes to a runner temp
path, is not published as an artifact, and the sticky comment redirects to the deep-review comment,
which said PASS.

The three advisory fixes pushed as `2a43c29` (zero-dipole statement, dropping the unasserted "12
significant digits" clause, dropping orphaned `pandas`) were a **proxy** for the six unnamed
potentials. Whether they addressed them is unknown and now unknowable: `pass2` failed first, so
`ava_review` was **skipped**, not passed.

**Carry forward:** an undisclosed AVA block is not evidence that the task's *content* is wrong. It
may simply never be re-reached. Do not redesign against it.

## 5. A proposed fix that died on the math — worth recording as a design test

The first redesign specified was a **split-metric kernel**: give the screening its own metric,
`E ∝ e^(−κ·s_μ)/s_ε` with `s_ε = √(d·ε⁻¹·d)`, `s_μ = √(d·μ⁻¹·d)`, ε and μ non-proportional. It
does defeat the reduction — no congruence isotropizes two non-proportional forms at once.

**It was rejected before any code was written, because it also destroys the closed form.** Ewald
needs the Fourier transform of the long-range part; for `e^(−κ√(xGx))/|x|` with `G ≠ gI` that is a
convolution of `det(G)^(−1/2)·8πκ/((k·G⁻¹k)+κ²)²` with `4π/k²`, which has none. The Schwinger
representation survives — a 2D quadrature over `(s,t)` with a Poisson-summed Gaussian lattice sum
inside — but that is expensive and delicate at 1e-10.

**Rule: "the reflex method fails here" is only half of a crux. The other half is that an exact
method still exists and is cheap.** A design that defeats the shortcut by making the problem
analytically intractable converts the task into maximum labor, which is §18c's failure mode — the
one the whole redesign existed to escape. Check tractability at design time, on paper, in the same
pass that checks non-reducibility.

## 6. What was built instead — `1598a4d`

Keep the ε^(−1/2) reduction as a legitimate, findable first step. Put the difficulty on a term the
reduction does not reach: the **k = 0 reciprocal-space term on net-charged screened cells**.

Four crystals added (`c18`–`c21`, net charge +2/+2/−1/+2, κ = 1.6/0.9/2.2/1.25, 6–8 ions), every
one screened. A charged cell is physical in a screened medium — the carriers supply the
compensating cloud — so no neutralizing background is imposed. Because κ > 0 the k = 0 weight is
the finite `exp(−κ²/4α²)/κ²` rather than the divergent Coulomb `1/k²`, so
`(2π/V)·exp(−κ²/4α²)·(Σq)²/κ²` must be summed.

Why it survives where the anisotropy did not:

- **It is in no reference.** Coulomb Ewald skips k = 0 unconditionally (there it diverges and is
  cancelled by a background); published Yukawa-Ewald treatments assume neutrality and never
  exhibit the term. It must be derived from the screened Poisson kernel at k = 0.
- **The searchable adjacent answer is wrong.** The documented Coulomb non-neutral fix
  `−π(Σq)²/(2α²V)` damps the α-drift ~20-fold — so it reads as a repair — while still missing by
  ~150%.
- **No uniform rule works.** Unscreened members need k = 0 skipped; net-charged screened members
  need it summed. One branch cannot serve both.
- **It is invisible on the old corpus.** The term is identically zero on a neutral cell, so all
  fifteen original energies are unchanged and nothing in the neutral part of the set reveals its
  absence. Grading is all-or-nothing, so 15 of 19 scores zero.
- **It costs nothing.** Oracle 5.0 s, verifier 11.7 s against a 180 s cap. The labor trim is kept
  and the difficulty is analytical — which terms belong in the sum, not how many pairs it has.

Benched before building: α-independence < 7e-15 per crystal, and agreement with brute-force direct
summation — which contains no reciprocal space and no k = 0 term at all — to 3e-14…4e-13. Mutant
matrix: oracle 1.0, nop 0.0, and five mutants all failing on a **wrong number, none crashing** —
skip k=0 (9.62), Coulomb background (9.89), erf-for-erfc self-energy (3.98), dropped (κ/2)erfc
(5.17), missing √det ε (28.0).

**The generalisable move: when a task's difficulty is dissolved by a reduction, do not fight the
reduction. Keep it, and find the term it does not produce.** That is far cheaper than inventing a
new kernel, and it preserves every gate clearance that rested on the existing physics.

## 7. Process

- `2a43c29` carries a **`Co-Authored-By` trailer**, against the standing rule. Already pushed;
  rewriting needs a force-push and buys nothing. Left in place, noted here.
- The gate posts at most **2 pass@2 difficulty suggestions per task per UTC day**. On this run,
  suggestion 2 of 2 was **stale** — it described a Daytona authorization error and carried a reset
  date of `2026-07-25`. Suggestion 1 was the real analysis. Read them by content, not by number.

## 8. Run `30393600658` (`1598a4d`) — the k = 0 crux worked; `trials` is the last gate

**The crux change did its job.** `pass2` **passed** — as did `qc_gate`, `deep_review`, `ava_review`,
`adversarial_review`, `tier1`, `qc_exec`, `qc_eval`. `qc_gate` and the review stack had never
cleared on this task before. **`trials` (pass@5) is now the only failing gate.**

pass@5: **4/5 solved, avg@5 = 0.800**, one fail. Gate needs ≥3 fails with ≥1 *good valid* fail;
got `0 good valid + 0 soft-timeout of 5`. The single fail (`task__NT3wvzJ`) was an **in-progress
timeout** — `rcut = 35/κ` OOM-killed at step 62, then a fixed-α retry diverged on small-volume
cells. It counts for nothing.

### 8a. The disclosure was the giveaway — measured, not suspected

`instruction.md` line 15 read: *"the mobile carriers of a screened medium supply the compensating
charge, so **no neutralizing background is imposed and none is to be added**."* That sentence
**hands over the crux**. It disarms the designed bait — the searchable Coulomb background
correction `−π(Σq)²/(2α²V)` — before the agent can reach for it. Trial `izFQNp6` identified "the
k=0 distinction at step 2"; all five got the term. The task's own `difficulty_explanation` calls
the bait "sharp", but the instruction defused it.

Fixed by cutting the rationale and the method hint, keeping well-posedness: *"This is deliberate,
not an error in the file: for κ > 0 the sum above converges absolutely exactly as written, and the
value of that sum is what is graded."* Absolute convergence alone pins the answer — a stronger
uniqueness argument than an appeal to the instruction, and it is the one `verification_explanation`
now makes. **Generalisable: a fairness disclosure that names the method, not just the graded
quantity, is a solution hint. State what is graded; never state what not to add.**

### 8b. The pre-registered lever was refuted by measurement

`CLAUDE.md` pre-registered "more net-charged members or smaller |U|" (c20's k=0 term is 953% of its
energy). **Measured, that lever is backwards.** Small |U| maximises the *relative error* of the bait
but also its *relative α-drift* — the very signal that exposes it:

| member | κ | U | bkg-bait error | α-drift after bait |
|---|---|---|---|---|
| c20 | 2.2 | −0.124 | 9.90 | **5.7e-3** ← loudest |
| c19 | 0.9 | 25.45 | 1.11 | **9.6e-6** ← quietest |

c20's shape is the most *wrong* and the most *detectable*. c19's is the better trap.

### 8c. Why the crux cannot be moved onto extreme geometry — refuted numerically

The obvious idea: the four charged members sit in the *mildest* geometry (anisotropy 2.1–3.4) with
the *largest* κ (0.9–2.2), which is exactly where brute-force direct summation — the agent's
independent oracle, and the one that let `MjHw2un` self-detect its k=0 bug at step 27 — is
cheapest (1.5e5–2.2e6 images, seconds). Move the charge onto small-κ extreme cells and that oracle
dies.

**It does not work.** The k=0 term scales as `1/κ²`, so the same κ that kills the oracle makes the
term swamp the energy. Scanned 120 re-parameterisations: at κ = 0.2, `k0/U → 1.003` — the energy
*is* the closed-form scalar, the lattice sum drops to a 0.3% correction, and the task gets
**easier**. No candidate satisfied both `k0/U ≤ 25` and an expensive oracle. The two properties are
controlled by one parameter and pull opposite ways.

### 8d. The structural ceiling on this task

**α-independence is a near-complete oracle for the whole trap family.** Every wrong method leaves
drift ≥ 1e-8 relative; the reference itself certifies at 1e-11. Skipped k=0, the background bait, a
dropped self-energy term, a fixed index cube — a two-α check catches all of them, and it is cheap
*because* the labor trim made cells 6–8 ions. **The trim that fixed the timeouts also made
verification free.** So `P(fail) = P(agent does not check α-independence carefully)`, which for a
strong model is small. That is the ceiling, and no re-parameterisation lifts it.

### 8e. `expert_time_estimate_hours = 4.0` converts every timeout into an invalid fail

The analyzer cited it directly: *"Given the task's expert estimate of 4 hours vs. the 1-hour limit,
the timeout is a real constraint."* → `low_timeout = FAIL` → in-progress → invalid. **While that
field says 4.0 against a 3600 s cap, this task can never bank a clock-based valid fail**; only a
*clean reward-0* counts. Left at 4.0 — it is honest, and removing the disclosure (8a) restores the
4-hour narrative (notice α-drift → reject the background → derive the term) that the giveaway had
been pre-paying. Lowering it to farm valid fails would be gaming, not accuracy.
