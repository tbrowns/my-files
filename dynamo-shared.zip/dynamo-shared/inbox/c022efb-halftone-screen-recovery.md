# inbox: c022efb `halftone-screen-recovery` (File and Media Operations / Image and design)

**Green at `33c68c9`** (run `30407053208`, all 16 checks SUCCESS), PR #1 open, awaiting human
review. Four rounds: two lost to fail-closed gate machinery (§6, §9), one to agent timeouts (§10),
one green. Findings recorded as measured. Merge at task boundary.

Final pass@5: **0/5 solved, 3 good-valid-fail, 0 task/verifier-issue, avg@5 = 0.000.**
`combined_repeat_area` was the universal failure point — three trials recovered all four plate
areas and then broke on the exact lattice intersection, one of them returning 0 from a finite-set
intersection *inside* the crop when the true period is ~97,671 px against a 2048 px window. One
trial hit the FFT cell-vs-tile trap at 12-15x too small. One scored PASS on every rubric row.

## 1. §25d generalises past the covariate set: it is method disclosure, not just variable naming

§25d says naming the *variables* of a hidden relation converts a derivation into an exercise.
This build hit the same wall on a non-gcd mechanism, and the disclosed thing was not a variable
but **the test that settles the question**.

The task grades the exact tile a RIP stepped across a plate. The trap is that the raster does
*not* repeat on the halftone cell, only on a much larger threshold array; the cell answer fits
every dot centre, so an agent's own self-check confirms it. v1's instruction said:

> Call a whole pixel offset a period of a plate when sliding the written pattern by that offset
> changes nothing. Inside a crop that shows up as the shifted and unshifted rasters agreeing at
> every pixel where the two still overlap.

That is the one check that defeats the trap, written out as a procedure. An agent following the
instruction literally cannot fall into the trap. v2 asks the same question in production terms
("the smallest tile the RIP could have stepped to give what is on the plate") and leaves the
agent to work out what establishes it.

**Rule to add to §25d: the disclosure audit is not only "does the instruction name the variables",
it is "does the instruction name the check".** Write out the sentence an agent would need in
order to avoid the trap; if the instruction already contains it, the crux is decorative.

## 2. Defining a property by "the crop agrees with its own translate" has a corner hole

v1 defined a period operationally by overlap agreement. A full offset-space sweep (FFT template
matching over all offsets, plus brute force in the corners) found **0 bogus periods anywhere with
meaningful overlap** but **thousands in the extreme corners**, where the overlap is one to three
pixels and agreement is vacuous. By the stated definition those were periods, and the lattice they
generate is all of Z², so the literal answer to the graded question was 1.

The data was fine; the wording was not. Fixed by anchoring the definition to the written pattern
the crop is a window onto. **Transferable: any task defining a property by self-translation
agreement over a crop needs the degenerate-overlap case closed explicitly.**

## 3. The Hermite basis of a skew lattice can be far longer than the lattice's own steps

Cost a debugging cycle. A plate's step lattice had Hermite basis `(7, 6041), (0, 13650)` while its
actual shortest steps were `(364, 182)` and `(-63, 231)`. A generation-time assertion that each
basis vector "is a period of the 4096 px raster" failed, not because the lattice was wrong but
because the Hermite rows do not fit in the crop.

**Rule: any "does this fit inside the data" test must run on a Gauss-reduced basis, never on the
Hermite one.** The same applies to checking that a graded repeat is too large to be measured: use
the shortest vector, not the Hermite diagonal.

## 4. Two corrections to this repo's concepts doc, both found before any code shipped

- **The phase/coset escalation it proposes is void.** If screen *i* puts dots on `L_i + t_i`, a
  translation `u` fixes that coset iff `u ∈ L_i`. The combined period is `∩L_i` **regardless of
  phase**. Phase selects which rosette appears inside a period, never the period.
- **The graded quantity as specced failed §23b outright.** If each plate's raster has period `L_i`,
  the composite's period is exactly `∩L_i`, so the whole lattice derivation is bypassable by
  autocorrelation on the stacked plates. The doc had declared this the one place with no
  independent check. Fixed by making the shared repeat far larger than the crop (198,037 px
  against 4,096), so per-plate work stays checkable but the graded figure cannot be measured.

**Transferable: when a design claims "this quantity has no independent check", the check to look
for first is whether the quantity is a directly measurable property of the shipped artifact.**

## 5. Measured, v2

```
plate      cell   tile     ratio   independent-steps answer  ratio
black      6272   75264    12x     301056                    4x too large
cyan       6370   95550    15x     286650                    3x
magenta    6370   89180    14x     624260                    7x
yellow     6400   76800    12x     460800                    6x

combined 44,518,656,000   shortest shared step 198,037 px = 49.5 in = 48x the crop
  halftone-cell answer      52,998,400   840x too small
  independent-steps answer  1,869,783,552,000   42x too large
  every single-plate error also moves the combined, by 0.14x to 7x
  +-1 on any cell vector: 0 collisions in 32
  dot areas within a plate: a single value, so no histogram tell
FFT + limit_denominator: returns 1/4, 2/7, 7/4 against a true 3/11, worse at larger n
```

Oracle 1.0 / nop 0.0, twice each from a clean clone, on both v1 and v2. Mutant matrix of eleven
variants: only the correct one passes.

## 6. A green `deep_review` can still block the PR: the gate is fail-closed on the *job*, not the verdict

Cost a full pipeline round (2h41m) on a task that had actually passed. Run `30356982058` on
`4617975`:

```
14:25:03  marocchino/sticky-pull-request-comment   (posting automated-review.md)
14:25:13  ##[error]Connect Timeout Error            <- step fails, job marked failed
14:25:13  verdict line: **Verdict:** PASS
14:25:13  Automated Review PASS - proceeding to pass@5.
```

The verdict step ran *after* the comment step, read PASS and exited 0 — but the job was already
failed by the POST timeout, so `gate` blocked with `deep_review=failure` and `qc_gate` / `trials` /
`tier1` were skipped. The review body is lost: only `claude-costs-*` artifacts are uploaded, not
`automated-review.md`, and the sticky comment never posted. The PR shows the pre-review placeholder
("running the automated deep review...") as the last comment, which reads exactly like a review
that never ran.

**Rule: when a review job fails, read the job log before changing anything.** Grep the log for
`verdict line:`. If it says PASS, the task is not the problem and editing the task in response is
strictly negative — it re-rolls every stochastic gate for nothing.

**And there is no cheap retry.** The fork owner has `{"admin":false,"push":false,"pull":true}` on
the upstream repo, so `gh run rerun --failed` is not available — the run belongs to upstream via
`pull_request_target`. The only re-trigger is a push to the fork, which re-runs *every* gate from
scratch. So an infra flake anywhere in the pipeline costs a full fresh set of stochastic verdicts,
which is the real argument for batching any pending task edits into that push rather than pushing
a bare retry.

## 7. pass@2 calibration point: a budget-exhaustion failure can score as a valid fail

v1 went 1/2 and the analysis classified the failing trial as `valid-fail`, not `in-progress-timeout`
and not `low_timeout`, with all seven rubric rows PASS. The reasoning: the agent picked
`scipy.signal.correlate2d` on a 256x256 patch (~13-22 min/plate) where the passing agent used a
2048 crop with a `min_overlap` filter, so the analysis judged the approach *structurally* too slow
rather than merely unlucky on time. Both agents tried FFT first, flagged the result as suspicious,
and abandoned it.

**Transferable: §18c ("timeouts count for nothing") is about the agent running out of road on a
sound, adequately fast approach. A failure caused by choosing an algorithm that cannot finish is
graded as a genuine failure.** But it is graded that way only because a sibling trial finished the
same problem comfortably — the passing trial is what proves the budget was adequate. A design with
no fast route would have been scored `low_timeout` instead.

## 8. Measured: de-disclosing the check flipped the trap from avoided to fallen-into, 2/2 both ways

This is the controlled test of finding 1, on the same task and the same benchmark model, with the
instruction rewrite as the only change to what the agent reads. (The v2 push also deepened the
tiles, so the *magnitude* of the error is not attributable to disclosure alone — but which object
the agents computed is.)

```
v1 4617975  pass@2 1/2 solved   "Both agents correctly avoided the main stated trap"
                                failure kind: speed-only, budget exhaustion
v2 abe8049  pass@2 0/2 solved   "All failures share the same root cause: the halftone-cell-area
                                 trap"  -- both agents ran 2D FFT autocorrelation, recovered the
                                 cell lattice, and returned its determinant
                                failure kind: analytical
                                0 in-progress-timeout, 0 task/verifier-issue, all rubric rows PASS
```

In v1 the instruction spelled out the test that defeats the trap ("sliding by that offset changes
nothing", "agreeing at every pixel"). Both agents applied it and stepped over the trap. In v2 the
same question is asked in production terms with no method named, and both agents walked straight
into it by the most standard move in the field.

**This is worth more than the pass rate.** The failure *kind* changed, not just the count. An
analytical failure is unambiguously a "genuine, valid agent failure" at the pass@5 bar; a
budget-exhaustion failure is a judgment call the analyzer re-makes on every trial and may score as
"still making progress", which does not count and whose prescribed remedy (raise the agent timeout)
is unavailable at the 3600 s cap. **De-disclosing the check does not merely make a task harder — it
converts the failures into the kind that the trials gate actually credits.**

## 9. The AVA/deep-review union gate can BLOCK while both halves report nothing blocking

Second fail-closed block in two rounds, different trigger from §6. Run `30379828820` on `abe8049`:

```
wrote ava.json  routing=block  confirmed_major=0 supported_major=0
                potential_major=4 gaps=5 parse_failures=1
##[error]AVA verifier audit did not PASS (routing=block; fail-closed on block/empty).
```

- AVA's own comment lists no issue: *"Blocked by the union gate; see the deep-review comment for
  the per-criterion findings."*
- The deep-review comment says **Verdict: PASS**, *"Blocking Issues: None"*, and all 24 gap-rubric
  criteria PASS or N/A — including `correct_expected_results` and `decisive_answer_discoverable`.
- **Nothing survived AVA's own verification**: `confirmed_major=0` and `supported_major=0`. The four
  `potential_major` items were never substantiated, and there is a `parse_failures=1`.

**The findings are unrecoverable.** They are not in the sticky comment, not in the job log (which
carries only the counts), and not in the artifacts (only `claude-costs-*` is uploaded; `ava.json`
stays in the runner temp dir). So the gate blocks on reasons the author cannot read.

**What made the call decidable anyway: AVA audits the verifier, so diff the verifier.**
`test_outputs.py`, `test.sh` and the `Dockerfile` were byte-identical to the v1 revision where AVA
had returned "No blocking verifier / ground-truth issue found by AVA". A genuine verifier finding
would have fired on v1 too. Ground truth *had* changed, but was independently confirmed three ways
(deterministic regeneration matching bit-for-bit, the solution re-deriving all five values from the
rasters alone, and CI oracle 1.0 / nop 0.0).

**Rule: when a gate blocks with `confirmed=0 supported=0`, treat it as unproven and re-trigger;
do not edit a verified-correct verifier against an unstated suspicion.** Establish "verified
correct" independently first — `git diff` the verifier against the last revision that gate passed,
and re-derive the ground truth by a route that does not share code with the generator.

**Corollary, now twice-confirmed: never spend a re-trigger bare.** Both rounds blocked on
machinery, and both re-triggers were the only way forward. Batch every queued advisory into them —
this one carried the removal of an orphaned `sympy` that the deep review had flagged as a mild
telegraph toward integer/lattice math.

## 10. `low_timeout=FAIL` is the failure mode with no sanctioned fix, and the auto-suggestion for it is wrong

pass@2 on `a2ed987` went **0 solved / 0 valid-fail / 2 in-progress-timeout**, `low_timeout=FAIL`
on both trials, every other rubric row PASS. Blocked. One agent had already recovered three of
four plate values correctly and was cut off mid-way through the final step; the other wedged on an
unbounded pixel-space search. Both were *mid-productive-work* at the cutoff, so neither counted.

**The pipeline's own auto-suggestion said to raise `[agent].timeout_sec` to 7200-10800 s. That
does nothing.** The pass@2 pre-check "runs the agent twice under a hard 3600-second (1 hour)
budget" (seeded README), and the pass@2 comment header in the very same run says
"capped 3600s/1hr". The knob the suggestion points at is *not* the binding constraint. Following it
costs a full round and changes nothing.

**Its fallback was worse:** add a line to `instruction.md` saying the repeat tile is a sublattice
of the halftone-cell lattice. That hands over the bounded search *and* the fact that the cell is not
the answer — the entire crux, by finding 1's own rule. The suggestion admits it "risks lowering the
difficulty". **Treat the auto-suggestion as a description of the symptom, not a prescription.**

**The only real lever is execution cost.** Difficulty and cost are separable here, and the fix is
to hold the first constant while cutting the second:

```
                      before          after
crop                  4096 px         2048 px      (4x fewer pixels)
longest step to reach  504 px          364 px      (compact skew tiles)
reference solution      22.4 s          3.7 s
tile index over cell   12-15           12-15       unchanged
all four tiles skew    yes             yes         unchanged
shared repeat / crop     48x             48x       unchanged, still unmeasurable
```

**Rule: when trials time out, do not reach for the timeout or the instruction. Ask what the agent
is spending the hour on, and make that cheaper without making it simpler.** Raster size is pure
cost. Tile *index* is difficulty; tile *shape* is only how far a search must reach before it finds
anything, so an elongated tile buys reach rather than depth and is the first thing to trade away.

Two generator guards came out of re-picking the geometry, both of which caught real errors:

- **`q % r == 0` makes a tile separable, not skew.** `q` is only meaningful modulo `r`, so `(4,3,3)`
  is `(4,0,3)` in disguise: the step lattice becomes a product of two independent runs and reading
  the two cell directions separately gives the right answer by accident. Assert `q % r`.
- **A no-finer-period scan must only judge offsets the crop can decide.** Widening the scan alone
  produced false alarms: offsets past the crop edge are untestable, and offsets near it agree over
  a sliver and say nothing (finding 2 again, from the other side). Skip `|d| >= SIZE` and require a
  real overlap floor.

## 11. Operational

- **Docker Desktop does not share the Windows `%TEMP%` path.** Harbor reports "Docker daemon is
  not running" for a task tree cloned there, and **retrying never clears it** — distinct from the
  genuine intermittent flake already in the handoff, which does clear on retry. Clone to a shared
  location (Desktop) for validation runs. The same non-shared path silently broke `-v` mounts,
  and left host directories in a state where the files inside were no longer readable.
- **`python script.py > list.txt` on Windows writes CRLF**, so `for x in $(cat list.txt)` gets a
  trailing `\r` on every entry except the last, and every derived path fails with "No such file or
  directory" while the final one works. That asymmetry is the tell. Write with
  `open(..., newline="\n")` or pipe through `tr -d '\r'`.
- `harbor run` output piped to `tail` buffers until the process exits; redirect to a file if you
  want to watch a long run.
