# 4. Writing the Prompt

[← Input files](03-input-files.md) · [Index](README.md) · Next: [Golden deliverables →](05-golden-deliverables.md)

---

The prompt commits the analyst to **one recommendation**, the files supply the
evidence, and the golden deliverables are the outputs that evidence forces — in the
file types and quantity the prompt names.

> **Draft the trap before you write the prompt.** A prompt written first tends to
> signpost the catch: it names the metric that matters, or fixes a window that
> quietly rules the trap out. Write the trap, then write the message a stakeholder
> would send if the trap were invisible to them. → [Traps](06-traps.md#why-the-trap-comes-first)

---

## The task contract

Every prompt carries one contract:

| Element | Requirement |
|---|---|
| **One deterministic recommendation** | A single committed call with one defensible answer. It anchors the whole task. |
| **3+ named deliverables** | Each with a filename and extension. Three is the floor; **there is no upper limit**. |
| **Coverage across the two assigned families** | Two format families are assigned to you per task. Your deliverables span both. More is fine. |
| **3+ asks per file** | A supplementary question *or* a concrete requirement about what that file must contain. |

> **The per-file asks are the body of the prompt.** There is no separate
> supplementary-questions section anymore — the asks replaced it.

**Scope rule for asks:** an ask stays valid only when it lives in the **same data
universe** as the recommendation and supports it, compares against it, or gives it
context. An ask that pulls in a separate dataset or a separate decision **is a second
task**.

### The four format families

| Family | What it is | Example formats |
|---|---|---|
| **Data** | Tables, records, structured exports | CSV, TSV, JSON, XLSX, Parquet |
| **Visual** | Charts, decks, rendered pages | PPTX, PNG, SVG, HTML, JPG |
| **Text** | Memos, reports, briefs | PDF, DOCX |
| **Code** | A script or notebook that runs and prints the answer | PY, IPYNB, SQL, R |

Formats are examples, not a fixed menu. The rule is **variety across families**.

---

## The kinds of asks

Across the task you want **more than one kind**, so the evaluation reaches more than
one kind of evidence. An ask is either a question or a content requirement.

| Kind | Purpose | Example |
|---|---|---|
| **Supporting** | A metric that backs the recommendation. | "By what percentage did the selected product's revenue change from FY24 to FY25?" |
| **Comparison** | How the winner sits against the runner-up. | "By how many dollars did its FY27 value exceed the runner-up?" |
| **Context or flip** | A related conclusion, including what would move the runner-up into first. | "Excluding FY27, which year was the best entry point?" |
| **Content requirement** | A concrete thing the file must contain. | "The PDF includes a chart of weekly retention by acquisition cohort." |

> ### ⛔ What an ask must not do
> It must not **enumerate the methodology, name the trap, identify the decisive file,
> or walk the model through the answer path.** A content requirement names *what the
> file holds*, never *how to compute it*.

---

## Prompt anatomy

Situation, then decision, then the requested deliverables with their asks. It should
read like **a message a busy stakeholder would send**.

| # | Part | Content |
|---|---|---|
| 1 | **Stakeholder context** | The trigger and the stakes: what happened, who disagrees, what is at risk. |
| 2 | **The decision or analytical ask** | The one call being asked for, with the objective fixed so it cannot mean three things. |
| 3 | **Necessary scope or constraints** | Only the constraints the stakeholder would state, such as choosing exactly one option. |
| 4 | **Requested deliverables** | 3+ named files across at least two format families, each with 3+ asks from the same data universe. |
| 5 | **Asks per file** | Each named file states what it must answer or contain; the set states the committed call. |
| 6 | **No answer-path leakage** | Silent on scope, cleaning, window, and method. The trap is never named or hinted. |

---

## The five non-negotiable rules

1. **One committed decision.** No hedge, no blend, no "it depends." Determinate — and ten domain experts land on it.
2. **Vague on method, precise on answer.** Withhold scope, cleaning, window, and methodology. Every valid approach still converges.
3. **No leak.** Never name the trap, the file that defuses it, or hint that a metric is misleading.
4. **Fair and self-contained.** Everything is derivable from the bundle, and the losing option is refuted on the data.
5. **3+ deliverables across the two assigned families, 3+ asks each.** Each file named with its extension.

> ### ⛔ What gets sent back
> A prompt that names the method or the trap · allows a hedged answer · requires
> outside knowledge · asks for a separate dataset or decision · requests fewer than
> three files · keeps every file in one family · or leaves a file with fewer than
> three asks.

---

## The shape, illustrated

The generic skeleton every prompt now follows — a short stakeholder context, one
committed recommendation ask, then a bullet list of deliverables with their asks:

> **One deterministic recommendation** — anchors the whole task.
>
> **`decision_memo.pdf`** *(Text)* — "Give me a one-page decision memo I can take to the review."
> - Open with the recommended option, name the strongest option it beats, and say in one sentence why the runner-up loses.
> - State the gap between them on the deciding metric in that metric's own unit (for example percentage points or dollars), to one decimal place, and cite the file and field the number came from.
> - Close with the one condition that would flip the recommendation, stated as a numeric threshold on that same metric, in its unit.
>
> **`options_scan.xlsx`** *(Data)* — "Attach the full comparison so the team can audit it."
> - One row per option with its deciding-metric value in the metric's unit to one decimal place, and its rank as a whole number.
> - A final column naming the one change that would flip the recommendation.
> - A total row that reconciles to the figure cited in the memo, so the audit trail ties out.
>
> **`margin_chart.png`** *(Visual)* — "Include this so the recommendation reads at a glance."
> - Plot the deciding metric by option in the metric's unit, with the recommended option and the runner-up labeled.
> - Order the bars from best to worst on that metric.
> - Mark the numeric threshold that would flip the recommendation.

---

## Worked example A — Anomaly detection & diagnostics

*(3 deliverables. Adapted from the "Recovery block round nomination" example task.)*

> **Context.** Mobile checkout conversion fell 6 percent day over day on Tuesday, and
> the on-call PM has to decide tonight whether to page the payments team. The team
> ships continuously and traffic mix swings a lot between weekdays and weekends.
>
> **Decision.** Tell me whether to escalate this drop to payments tonight or treat it
> as normal fluctuation.

**`checkout_conversion_triage.pdf`** *(Text)* — "Write up the escalate-or-hold call so the on-call PM can act on it immediately."
- State plainly whether Tuesday's 6 percent drop clears the bar to page payments tonight.
- Explain how much of the day-over-day move, in percentage points to one decimal place, is attributable to the shifting weekday-to-weekend traffic mix versus a genuine funnel regression.
- State the escalation threshold in percentage points and whether Tuesday's move exceeds it.
- Name the single traffic segment driving the largest share of the genuine, mix-adjusted drop, and give that share in percentage points to one decimal place.
- Name the funnel step where the genuine regression concentrates and its step-conversion change in percentage points to one decimal place.

**`conversion_by_day_and_segment.csv`** *(Data)* — "Give me the underlying numbers so the call can be sanity-checked."
- Show daily conversion, as a percentage to one decimal place, for the recent window alongside the comparable prior baseline the decision rests on.
- Break the numbers out by the traffic segments that changed mix, so the Tuesday gap can be traced to its source.
- Include one row per day-segment with sessions as a whole-number count and conversion as a percentage to one decimal place.

**`conversion_triage_chart.png`** *(Visual)* — "Include this so the on-call PM can see the move at a glance."
- Plot daily mobile checkout conversion, as a percentage to one decimal place, across the recent window with Tuesday marked.
- Overlay a mix-adjusted conversion line so genuine regression is separable from mix shift.
- Show the comparable prior baseline as a reference band, in conversion percent to one decimal place.

**Why it holds up:** the prompt states the stakeholder's frame (a 6% drop), names the
files and what they must contain, and says **nothing** about mix adjustment being the
method, which file settles it, or what the answer is.

---

## Worked example B — Forecasting

*(3 deliverables. Note the Code family in place of Visual.)*

> **Context.** A subscription app owes Finance one committed Q3 renewal-revenue
> number by Thursday, from three years of billing history.
>
> **Decision.** Give a single committed Q3 renewal-revenue figure and say whether the
> current trend supports the board's growth target.

**`forecast.py`** *(Code)* — "Hand me a runnable script that reproduces the number from the shipped files."
- Print the committed Q3 renewal-revenue figure in USD rounded to the nearest thousand, with its 80% interval in the same unit.
- Print the holdout error for each of the last four quarters as MAPE in percent to one decimal place.
- Print whether the current trend clears the board's growth target, as a yes or no with the gap in USD to the nearest thousand.

**`finance_note.docx`** *(Text)* — "Write the one-page note I can forward to the board."
- State the Q3 figure in USD to the nearest thousand and whether it clears the board's growth target.
- Name the single assumption that would move the number most, and by how much, in USD to the nearest thousand.
- Close with the one trend condition that would put the target out of reach, stated as a numeric threshold in USD to the nearest thousand.

**`monthly_actuals.csv`** *(Data)* — "Include the data backing the estimate."
- One row per month with actual and fitted renewal revenue in whole USD.
- Flag the months excluded from training and give the reason.
- A total row that reconciles fitted revenue to the committed Q3 figure.

---

## The example-prompt library

The handbook ships **60 example prompts** — 10 per analytical objective — all written
in this format, filterable by objective and domain. Adapt the closest match rather
than starting from a blank page.

| Objective | Prompts |
|---|---|
| Descriptive & Distribution Analysis | 10 |
| Anomaly Detection & Diagnostics | 10 |
| Root-Cause Analysis | 10 |
| Experiment & Causal Analysis | 10 |
| Forecasting & Predictive Modeling | 10 |
| Data Extraction & Conformation (ETL / Pipeline Build) | 10 |

---

## Readiness checks this stage owns

*(Part of Readiness stage 4, "Prompt and solution." See [Readiness](09-readiness-and-submission.md).)*

- [ ] Prompt asks for exactly one deterministic main recommendation that 10 domain experts would converge on
- [ ] Prompt adds related supplementary questions drawn from the defined buckets *(see [contradiction note](10-reference.md#internal-contradictions-in-the-source))*
- [ ] Prompt leaks no methodology and no answer path
- [ ] Prompt prescribes three or more deliverables spanning at least two assigned format families, and every golden output file matches its assigned format and filename

---

> ⚠️ **Not captured in the source export.** The "Why this one holds up" panel on the
> worked example was collapsed and empty in the HTML snapshot. The summary above is
> reconstructed from the surrounding rules.
