# 1. Overview & Pipeline

[← Index](README.md) · Next: [Task types →](02-task-types.md)

---

## What you are building

> A precise decision over messy, multi-source real files, with one deterministic answer —
> hard enough that a frontier model gets it wrong for a genuine analytical reason,
> while a careful analyst working from the same files gets it right.

Difficulty must come from **honest data and hard, discriminating asks**, never from a
planted defect, ambiguous wording, or sheer file volume.

---

## The three artifacts

This is the **conceptual** relationship, not the build order.

```
        Prompt                Input files            Golden deliverable
      prompt.md              inputs.zip           3+ files across families
   The committed          The raw, load-bearing      Your reference answers
   question the           evidence the answer        to the recommendation
   analyst must answer    has to reconcile          and every ask, written as
                                                    the matching output files
           │                      │                          ▲
           └──── prescribes ──────┴──── forces ──────────────┘
```

- The **prompt** commits the decision and prescribes which output files must come back.
- The **input files** supply the evidence that forces the answer.
- The **golden deliverable** is that exact prescribed set of files, filled in correctly.

Once all three exist, the task moves downstream and out of your hands:

| Stage | What happens |
|---|---|
| **Rubric generation** | A rubric is generated internally from the prompt contract + golden, fixed at **25+ criteria**. Fellows do not edit it. |
| **Model validation** | **12** recorded model responses decide the task. It passes when the **top 2 average under 50%**. |

**You build in the procedural order:** task type → input files → prompt → golden
deliverable → validate → readiness & submit.

---

## The four hard gates

Everything you do feeds these four bars. Clear all four and the task is ready to submit.

| # | Gate | Requirement |
|---|---|---|
| **01** | **Rubric breadth** | The generated rubric reaches **25+ criteria**, weighted 30 / 5–10 / 60. The task cannot advance below 25. |
| **02** | **Top-2 under 50%** | Run **12** responses, submit the bottom 10 unchecked; the **top 2 must average below 50%** against the rubric. |
| **03** | **A deterministic, fair stump** | Models fail for analytical and methodological reasons on honest data — never a planted defect — and ten experts working the files land on the same recommendation. |
| **04** | **Deliverable contract** | The prompt requests **3+ named deliverables** across the **two assigned format families**, each carrying **3+ specific asks**. |

---

## The sequence, at four levels of detail

The handbook describes the same pipeline at four granularities. They are the same
work, not four different processes.

| 4 stages (progress bar) | 8 steps (Start page) | 9 platform steps | 12 authoring steps (3 phases) |
|---|---|---|---|
| **1 Understand** | Select task type & objective | 1 Select task type and objective | **A1** Task type, domain, data families |
| **2 Build** | Assemble input files | 2 Assemble the necessary input files | **A2** Prompt and input files |
| | Write the recommendation + asks | 3 Write the recommendation request and supplementary questions | **B3** Model responses |
| | Prescribe 3+ deliverables across two families | 4 Design the trap that makes it hard | **B4** Final recommendation |
| | Complete the golden deliverables | 5 Assign the deliverables and their asks | **B5** Supplementary answers |
| | | 6 Complete the golden deliverables and matching output files | **B6** Critical components |
| **3 Validate** | Read the generated rubric | 7 Read the generated rubric | **C7** Rubric |
| | Run 12 responses, confirm top-2 < 50% | 8 Run and evaluate the model responses | **C8** Step-by-step solution |
| | | | **C9** Justification |
| | | | **C10** Determinism QC check |
| | | | **C11** Golden solution |
| **4 Submit** | Clear Readiness and submit on Handshake | 9 Clear Readiness and submit on Handshake | **C12** Final model rollouts |

### The 12 authoring steps in full

**Phase A — Set up the task.** *Choose the shape of the problem and assemble the raw material.*

1. **Task type, domain, and data families.** Pick one domain. One primary analytical objective and two output families are assigned to you; the rest is your call. — *Gate: deterministic decision.*
2. **Prompt and input files.** Write the ambiguous, stakeholder-style prompt and upload one ZIP of real, license-clean inputs. — *Gate: 10+ files, 3+ formats, one 10k+ row table.*

**Phase B — Solve and specify.** *Commit the answer, then spell out every ask it has to satisfy.*

3. **Model responses.** Generate the model rollout on your prompt and inputs.
4. **Final recommendation.** Commit the single deterministic recommendation the task resolves to. — *One committed answer; 3+ deliverables, 3+ asks each.*
5. **Supplementary answers.** Answer each per-deliverable ask. These carry **~60% of the rubric**, so they must be hard and discriminating.
6. **Critical components.** Record the load-bearing intermediates the recommendation rests on. — *Part of the ~30% recommendation block.*

**Phase C — Validate and deliver.** *Prove the answer is forced, then ship the finished golden set.*

7. **Rubric.** Generated for you and fixed; you do not edit it. — *Gate: 25+ criteria, weighted 30 / 5–10 / 60.*
8. **Step-by-step solution.** Lay out the path from the inputs to the committed answer.
9. **Justification.** State why the answer is forced and the difficulty is honest-data, not a planted lie.
10. **Determinism QC check.** A rollout check that the committed answers are uniquely forced by the shipped files.
11. **Golden solution.** Ship the finished golden version of every requested deliverable.
12. **Final model rollouts.** Run the model responses and score them. Non-blocking as long as the top responses already clear the 50% bar. → see [Validation](07-validation.md#the-scoring-bar)

---

## Your first task, in four outputs

| Stage | Do | Output |
|---|---|---|
| **1 Understand** | Learn what shape of decision counts as a valid task. | A chosen task type and domain. |
| **2 Build** | Assemble the real files, then write the prompt they answer and the output it prescribes. | A ZIP of real input files plus a prompt naming its deliverables. |
| **3 Validate** | Ship the golden set, read the generated rubric, prove models miss the answer. | Golden output files, the fixed rubric, a recorded model run. |
| **4 Submit** | Clear Readiness, then submit yourself on Handshake. | A task submitted on Handshake, awaiting review. |

---

## What the handbook does *not* do

The handbook **never uploads files, runs models, or submits anything for you.**
It holds guidance and local browser-saved progress only.

- **Stash** (external) — browse and claim starter data packages. Not a submission surface.
- **Handshake** (external) — where tasks are actually submitted and reviewed. You do this yourself.
- Handbook readiness state is **not** a Handshake status and **not** an approval.
