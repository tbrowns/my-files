# Project MARK — Authoring Handbook

Restructured from `structure.html` (a 16-page export of the MARK handbook site,
last updated **July 30, 2026**).

MARK is a program in which **fellows author analytical tasks that stump frontier
models**. A task is a precise decision over messy, multi-source, real files, with
exactly one deterministic answer. You build it, you prove models miss it, and you
submit it yourself on Handshake.

> **Guidelines in force: the 8/27/2026 revision.** Every rule in these docs is the
> post-8/27 version — 10+ input files across 3+ formats with one 10,000+ row table,
> 3+ deliverables spanning two assigned format families, 3+ asks per file, a
> 25-criteria generated rubric weighted 30 / 5–10 / 60. Tasks approved under these
> guidelines pay **$800 per approval**.

### This submission's assignment

| Field | Value |
|---|---|
| Analytical objective (`Task_Type` on the form) | **Forecasting & Predictive Modeling** — assigned, not a choice |
| Assigned format families | **Data** (CSV/XLSX/JSON/TSV) + **Code** (PY/SQL/R/IPYNB) — at minimum; more is allowed |
| Domain | Your call, from the six in [Task types](02-task-types.md) |
| Deliverables | **3+** named files, ≥2 families, **3+ asks each** |

---

## Read in this order

| # | Document | What it settles |
|---|---|---|
| 1 | [Overview & pipeline](01-overview.md) | What a task is, the three artifacts, the four hard gates, the full sequence |
| 2 | [Task types](02-task-types.md) | Domains, analytical objectives, reasoning phases — the classification you pick first |
| 3 | [Input files](03-input-files.md) | Sourcing, starter kits, package rules, the 7-point package checklist |
| 4 | [Writing the prompt](04-prompt.md) | The deliverable contract, kinds of asks, anatomy, five non-negotiable rules |
| 5 | [Golden deliverables](05-golden-deliverables.md) | The reference answer set, traceability, QC |
| 6 | [Traps & stumping](06-traps.md) | What counts as a stump, fairness criteria, the trap catalog, recipes |
| 7 | [Validation & iteration](07-validation.md) | The five gates, calibration targets, the 12-response rollout |
| 8 | [The rubric](08-rubric.md) | Generated and fixed, the 25-criteria floor, the 30/5-10/60 weighting |
| 9 | [Readiness & submission](09-readiness-and-submission.md) | All 51 readiness checks, the Handshake handoff |
| 10 | [Reference](10-reference.md) | Glossary, source-page map, contradictions found, gaps in the export |

**In a hurry?** [Overview](01-overview.md) and the [numbers table](#the-numbers-that-gate-a-task) below carry most of the rules. Everything else is detail.

---

## The one-paragraph version

Pick one domain and one analytical objective. Assemble **10+ real, license-clean
input files** whose signal is fragmented across them. Write a stakeholder-style
prompt that commits to **one deterministic recommendation** and names **3+
deliverable files** across your **two assigned format families**, each carrying
**3+ asks**. Build the golden version of those files. A rubric of **25+ criteria**
is then generated for you — you do not edit it. Run **12 model responses**; the
task passes when the **top 2 average under 50%**. Clear the **51 readiness
checks**, export your evidence, and submit on Handshake.

---

## The numbers that gate a task

| Rule | Value |
|---|---|
| Counted input files | **≥ 10** |
| Independently necessary files (remove one → answer unreachable) | **≥ 4** |
| Substantial (long, dense) input files | **≥ 2** |
| Distinct file formats in the package | **≥ 3** |
| Rows in the largest table | **≥ 10,000** |
| Tables the recommendation must join | **≥ 2** |
| Requested deliverables | **≥ 3** (no upper limit) |
| Format families the deliverables span | **2** (assigned to you per task) |
| Asks per deliverable | **≥ 3** |
| Rubric criteria | **≥ 25** |
| Weight of any single criterion | **≤ 20%** |
| Recommendation + critical components block | **~30%**, across ≥ 3 criteria |
| Instruction-following block | **5–10%** |
| Supplementary asks block | **~60%** |
| Model responses per rollout | **12** (bottom 10 submitted unchecked) |
| Pass condition | **top-2 average < 50%** against the rubric |
| Readiness checks | **51**, across 6 stages |

---

## The five standards every task is judged against

| Standard | Meaning |
|---|---|
| **Deterministic** | Competent domain experts converge on the same recommendation. |
| **Reproducible** | Every number and step in the golden comes back from the shipped files. |
| **Analytically difficult** | Difficulty lives in reasoning and method, not ambiguous wording. |
| **Self-contained** | Every load-bearing fact is in the prompt, the files, or standard domain knowledge. |
| **Supported by necessary files** | Each shipped file does work; nothing load-bearing is missing. |

---

## Getting help

- **Drop-in hours:** Tuesday & Thursday, 1–5 PM PT
- **1:1 sessions:** Monday, Wednesday, Friday, 11 AM–6 PM PT — book with James Clark or Dallas Banks
- **Compensation ($800/approval as of 8/27/2026), bonuses, task limits, payment timing, domains:** the Program details page
