# 2. Task Types — Domain, Objective, Reasoning Phase

[← Overview](01-overview.md) · [Index](README.md) · Next: [Input files →](03-input-files.md)

---

Every task carries **one domain** and **one primary analytical objective**, chosen
before you write a word of the prompt. You also tag **one reasoning phase**. Two
**format families** are assigned to you.

> **Classification is for you and the reviewers — never for the model.**
> It must not leak into the prompt as a recipe.

**Done when:** you can state the domain, the one primary objective, the reasoning
phase, and the decision in a single sentence.

> If **two objectives fit equally well, the decision is not deterministic yet.** Go back and tighten it.

---

## Axis 1 — The six accepted domains

Pick the one whose decision-maker would actually own the call.

1. Product Analytics
2. Supply Chain & Logistics
3. Economics
4. Policy & Education
5. Demographic & Social Science
6. Nonprofit & Grant-making

---

## Axis 1 — The six analytical objectives

| Objective | The decision turns on… |
|---|---|
| **Descriptive & Distribution Analysis** | How a population is composed or how a metric is distributed — not why it moved. |
| **Anomaly Detection & Diagnostics** | Separating a real event from an artifact when something looks wrong. |
| **Root-Cause Analysis** | Naming the driver of a move, with rival explanations ruled out on evidence. |
| **Experiment & Causal Analysis** | A causal claim, from a designed test or observational data with confounders. |
| **Forecasting & Predictive Modeling** | A future value or predicted outcome the supplied history can pin down. |
| **Data Extraction & Conformation (ETL / Pipeline Build)** | Reconciling messy multi-source inputs into one analysis-ready, contract-conforming dataset. |

> **Forecasting is an objective, not a seventh domain.** Any accepted domain can
> carry it when the evidence pins the answer down — and **more of those are wanted.**
> Its traps must be methodological (leakage, validation scheme, regime change),
> never cosmetic.

---

## The reasoning phase

Tag the phase where the hard thinking happens:

`Explore` · `Hypothesize` · `Analyze/Validate` · `Synthesize` · `Recommend`

---

## The four format families

Two are assigned to you per task; your deliverables must span **both**. Doing more is fine.

| Family | What it is | Example formats |
|---|---|---|
| **Data** | Tables, records, structured exports | CSV, TSV, JSON, XLSX, Parquet |
| **Visual** | Charts, decks, rendered pages | PPTX, PNG, SVG, HTML, JPG |
| **Text** | Memos, reports, briefs | PDF, DOCX |
| **Code** | A script or notebook that runs and prints the answer | PY, IPYNB, SQL, R |

The formats are **examples, not a fixed menu**. The rule is variety across families.

---

## Step 1 checklist

**Do this**

- Choose one of the six accepted domains and one primary analytical objective.
- Tag the reasoning phase where the hard thinking happens.
- Name the decision a practitioner would actually face, and the single deterministic recommendation it resolves to.
- Plan the plausible **wrong** analytical path, and keep the difficulty analytical: a smart generalist working from one file should not be able to land it.

**Watch for**

- Classification leaking into the prompt.
- Generic, textbook-style questions.
- Traps that no file in the workspace can settle.

**Output**

- A one-line classification: domain, one primary objective, one reasoning phase, and the decision it resolves.

---

## Readiness checks this stage owns

*(Readiness stage 2, "Task shape" — 4 checks. See [Readiness](09-readiness-and-submission.md).)*

- [ ] Task clearly belongs to one accepted Project MARK domain
- [ ] Task has one clear primary analytical objective from the taxonomy
- [ ] Task requires meaningful analytical reasoning from evidence to recommendation
- [ ] Domain, analytical objective, and reasoning-phase tags use the defined taxonomy values
