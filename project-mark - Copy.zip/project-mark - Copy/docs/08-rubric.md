# 8. The Rubric

[← Validation](07-validation.md) · [Index](README.md) · Next: [Readiness & submission →](09-readiness-and-submission.md)

---

> ### The rubric is generated for you and fixed. You do not edit it.

It is generated internally from three things you already produced:

1. the **prompt contract**
2. the **golden solution**
3. the **requested output files**

> ### ⛔ There is no review pass anymore
> The old flow — where you opened the rubric and fixed genuine problems — is
> **retired**. The rubric arrives fixed and stays as generated.
>
> **If it looks wrong, the fix is upstream:** correct the prompt contract or the
> golden output, and the rubric is regenerated from the corrected pieces.

Your job is to build a prompt, a golden, and an evidence package strong enough that
**the generated rubric is hard for a model to satisfy**.

---

## The 25-criteria floor

> **A task cannot move on under 25 criteria.**

Breadth is what forces a model to be right **across the whole task**, not just on the
headline call — so the surface has to be wide.

---

## Weighting

The score splits into three blocks totalling **100%**.

| Block | Weight | Spread |
|---|---|---|
| **Deterministic recommendation + critical components** | ~**30%** | across **3 or more** criteria |
| **Instruction-following** | **5–10%** | the requested files and output-shape asks |
| **Supplementary questions and asks** | ~**60%** | must be hard and discriminating, never trivial lookups |

**Two structural rules**

- **No single criterion carries more than 20%** of the total score.
- **Unit and rounding fold into the value criterion** they belong to — never their own criteria.

### What instruction-following covers

The 5–10% block grades the **requested files and the shape of the output**:

> the file is present and named as asked · one row per period · a required total row ·
> a named column set · a specified ordering · a page length · printing the required figures.

Unit and rounding are **not** their own criteria here; they fold into the value they belong to.

### Why supplementary is the largest block

Because it is the biggest weight, **the supplementary questions carry most of the
difficulty**. A wrong analytical path should get them wrong. **A question a model can
answer with a surface lookup does not belong in this block.**

---

## What a good criterion evaluates

> Criteria grade **observable outcomes in the answer** — the conclusion reached, the
> values reported, the questions answered, the file delivered. **They never grade how
> the analyst thought.**

| Topic | ✅ Good | ➖ Neutral | ❌ Bad |
|---|---|---|---|
| **Reaching the conclusion** | States that mobile web regressed and recommends reverting only that surface, with direction and magnitude consistent with the shipped data. | Names the regression but leaves the recommended action implicit. | Explains its full chain of thought before answering, showing every intermediate calculation. |
| **Method** | Reaches a result the shipped files support, **by any defensible route**. | Mentions a method without tying it to a result. | Requires a two-proportion z-test on the deduplicated holdout specifically. |
| **Numbers** | Reports the corrected lift with correct sign, unit, and rounding, **allowing equivalent representations and reasonable tolerance**. | Reports the right value with a missing unit. | Requires the exact string `+0.62pp, z = 2.45`. |

**On numeric criteria.** They can still require the correct value, unit, rounding, and
conclusion. The criterion is written so **equivalent representations pass**:
`0.62 percentage points`, `+0.62pp`, and *"roughly six tenths of a point in favour of
treatment"* are the same answer. **Reasonable calculation tolerance is allowed** rather
than string-matching a figure.

> ### ⛔ Never reward disclosure
> A criterion that awards points for **showing work, naming a method, or narrating
> steps** rewards verbosity instead of correctness. If a step genuinely matters, **the
> result it produced is graded** — not the fact that it was mentioned.

---

## What the generated rubric guarantees

The generator satisfies every row below. **You do not tune these by hand — you make
them true upstream, in the prompt and the golden.**

- [ ] The rubric holds **25 or more** criteria
- [ ] The deterministic recommendation and its critical components carry about **30%**, spread across **3 or more** criteria
- [ ] **No single criterion is worth more than 20%**
- [ ] Instruction-following covers the requested files and output-shape asks at **5–10%**
- [ ] The supplementary block is about **60%** and **every question in it is hard and discriminating**
- [ ] **Every requested ask is covered exactly once**, with no two criteria overlapping or contradicting
- [ ] **The golden output satisfies every positive criterion**
- [ ] **Nothing rewards methodology disclosure or chain-of-thought**
- [ ] **Weights sum to 100%**

---

## When the rubric is generated

The generated-rubric panel stays **locked until the Prompt, Input files, and Golden
output are all confirmed** in the Build workspace.

If you later change the prompt contract or the golden output, **the rubric is
regenerated**. That is expected — the rubric is downstream of both.

---

## Readiness checks this stage owns

*(Part of Readiness stage 4, "Prompt and solution." See [Readiness](09-readiness-and-submission.md).)*

- [ ] The generated rubric is fixed with **25 or more criteria**, and the fellow does not edit it
- [ ] Rubric weighting holds: the recommendation and its critical components take about **30%** across three or more criteria, supplementary questions take about **60%**, instruction-following takes **5–10%**, no single criterion exceeds **20%**, and all criteria total **100%**
