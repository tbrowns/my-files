# 7. Validation & Iteration

[← Traps](06-traps.md) · [Index](README.md) · Next: [The rubric →](08-rubric.md)

---

**Five sequential gates** stand between a drafted trap and a first rollout. Work them
in order. Nothing here grades your task or records completion — these are your own
reads, and **the rollout is the evidence**.

| Gate | Proves |
|---|---|
| **1 Reproduce** | The golden comes back out of the frozen archive. |
| **2 Fork** | There is one defensible recommendation, not two. |
| **3 Live trap** | Every trap is load-bearing and every counted file earns its place. |
| **4 Robustness** | The winner survives ordinary expert variation. |
| **5 Rollout** | The task is solvable cold, clean to ship, and reported honestly. |

---

## Gate 1 — Reproduce

**Purpose.** Prove the golden solution comes back out of the frozen archive, so every
later gate is testing the same task you will ship.

**Test: deterministic rerun.** Re-run the golden against the frozen archive and
reproduce **every load-bearing finding from the actual files**:

> filters · joins · denominators · cohort and sample inclusion rules ·
> transformations and normalization · time windows · superseding revisions ·
> thresholds · QC or variant-filtering rules · exposure and outcome definitions ·
> comparison groups · and model-evaluation choices such as target definition,
> leakage checks, training and evaluation periods, split design, metric, and forecast horizon.

**Also:** freeze the archive and ship a **manifest listing every file with its SHA-256
hash, byte size, and role**.

| | |
|---|---|
| **Pass** | The golden reproduces end to end from the frozen archive, with no step that depends on knowledge outside the files. |
| **Revise** | A finding only reproduces with an assumption living in your head, or a hash changed without a re-run. |

---

## Gate 2 — Fork

**Purpose.** Prove the task has one defensible recommendation, not two. **A fork here
is a determinism bug, not difficulty.**

**Test: alternative-defensible-cleaning sensitivity.** Re-solve under each defensible
expert choice — not just cleaning:

> alternative dedup keys · inclusive vs exclusive date bounds · null handling ·
> outlier rules · population or cohort definition · metric choice · time window ·
> analytical method.

For statistical or predictive work this includes reasonable **model specifications,
validation splits, normalization choices, and multiple-testing handling**.

The winner must also survive **estimation variation**: confidence intervals, forecast
uncertainty, and reasonable metric choices. **A knife-edge winner that needs one exact
computation fails.**

| | |
|---|---|
| **Pass** | Every defensible analytical choice lands on the same recommendation. |
| **Revise** | Any defensible choice changes the recommendation — which makes the task unfair rather than hard. Pin the open definition in the prompt or the files. |

---

## Gate 3 — Live trap

**Purpose.** Prove each trap is load-bearing, and that every counted file earns its place.

**Test A: neutralize-one-trap.** Repair **one trap at a time**, leaving the others in
place, and re-solve. The trap is live only when mishandling it moves something that
matters: a load-bearing intermediate value, the interpretation, the ranking of
options, the prediction, or the final recommendation. Also state **why a strong
analyst would plausibly take the bait**.

> A trap whose repair changes nothing is **decorative**. A trap that only catches
> careless reading or an absurd analytical choice **is not a trap**.

**Test B: remove-one-file.** Delete each counted input in turn and re-solve. Record,
per file, whether the correct answer becomes **unreachable**, **changes**, or
**survives untouched**.

> A counted file that survives removal is **not load-bearing**. Give it a real
> dependency or drop it. Volume, exotic formats, and unused noise are not difficulty.

### How to measure difficulty

**Wall-clock solve time is not evidence.** These three replace it:

| Measure | What to record | Replaces |
|---|---|---|
| **Evidence coverage** | Count the inputs a correct answer must actually touch, and confirm the relationships between them are recoverable. If the recommendation is reachable from fewer than the load-bearing set, the task is under-built. | Wall-clock solve time |
| **Decision materiality** | For each trap, state what the recommendation loses when it is missed: the decision itself, its scope, its justification, or its robustness. For a predictive task, whether the miss changes the forecast, the model choice, or the operational decision. | Wall-clock solve time |
| **Trace visibility** | Each defused trap leaves a checkable trace in the final output, so grading reads **destinations rather than routes**. | Impression of effort |

| | |
|---|---|
| **Pass** | Every trap changes something material when repaired, and every counted file changes the answer when removed. |
| **Revise** | A trap whose repair changes nothing, or a counted file that survives removal. |

---

## Gate 4 — Robustness

**Purpose.** Prove the winning recommendation survives ordinary expert variation, not
just the one computation you ran.

- Vary the estimation: confidence intervals, forecast uncertainty, alternative model specifications, and reasonable metric choices.
- Run the **knife-edge check**: a winner that needs one exact computation to stay ahead is not validated.

| | |
|---|---|
| **Pass** | The same option wins across reasonable estimation variation. |
| **Revise** | The recommendation flips under normal estimation noise. |

*A specialized "Predictive or statistical work" lens exists here; its body was not
captured in the export. See [Reference → Gaps](10-reference.md#gaps-in-the-source-export).*

---

## Gate 5 — Rollout

**Purpose.** Prove the task is solvable cold, clean to ship, and reported honestly.

**Test A: archive-only blind solve.** Hand the archive and the prompt to **someone who
did not build the task** and have them solve it cold. Confirm the workspace is coherent:

- necessary files can be connected
- identifiers and joins are recoverable
- versions and revisions reconcile
- the valid population or period is identifiable from the supplied documentation
- definitions are pinned **by a document rather than by intent**
- any conflict between sources is resolvable from the materials alone

> Any step that needed outside context, a guessed definition, an unstated threshold,
> or evidence not in the archive is **unfair ambiguity, not analytical difficulty**.
> Any step that needed builder memory is an **undiscoverable convention**.

**Test B: compliance pass.** Check the prompt for leaks, the corpus for personal data,
and every artifact for provenance and licensing **before the archive is frozen**.

> A named file, a method verb, a real person's data, or an unlicensed source is a
> **submission blocker** regardless of how good the trap is.

| | |
|---|---|
| **Pass** | A cold solver reaches your recommendation from the archive alone, the compliance pass is clean, and the rollout report carries its denominator. |
| **Revise** | A step needed outside context or builder memory, a name/method/personal record leaked, or a number was cited without its denominator. |

---

## Calibration targets

**Heuristic targets, not tests.** They tell you which gate to strengthen when a
rollout comes back off-target.

### Weak model under 30%

**Fails at:** breadth of file coverage · long-file reading · any join beyond one key ·
row-count anomalies · multi-step arithmetic · resisting the bait.

**Lever:** Layer 1 gate plus the bait file.

> If a weak model is scoring **25–35%**, the usual culprit is a rubric with too many
> easy positive criteria, **not** insufficiently hard data.

### Strong model under 50%

**Fails at:** silent statistical traps · chronology and supersession reasoning ·
identifying the valid population · overturning the stakeholder's frame · combining
several correct sub-analyses into a counterintuitive conclusion.

**Lever:** Layers 2 and 3, drawn from **different families**.

---

## Failure-texture diagnosis

Where the wrong answers land tells you what the task actually tested.

| Pattern | Reading | Verdict |
|---|---|---|
| **Consensus on your designed decoy** | Every wrong response lands on the bait's answer, and you can name the analytical step it skipped. The trap works exactly as built. | ✅ Healthy |
| **Consensus on an answer you did not design** | There is a second self-consistent reading of your materials. That is a **determinism bug on your side**. Fix the files — do not submit. | 🚩 Red flag |
| **Scatter across different wrong answers** | Responses dying at different layers is a good sign — but scatter **plus low-effort responses** suggests unfair ambiguity rather than difficulty. | Usually healthy |
| **Zero partial progress anywhere** | Near-zero across the board reads as *impossible* to reviewers. The sweet spot is one or two attempts making real partial progress while the recommendation is still missed on average. | ⚠️ Watch it |

---

## The scoring bar

Every rollout is **twelve responses**, scored against the fixed rubric.

- **You submit all 12 responses.** The bottom 10 can be submitted without checking.
- **The gate is the top 2.** The task passes only when the two highest-scoring responses **average under 50%** against the rubric.
- **Difficulty still has to be honest.** It comes from the data shapes — forecasting, method selection, a binding constraint, decomposition, confirm-the-number, hold — never from surface-read rejection or flipping a wrong number.

### Why supplementary asks must be hard

The recommendation and its critical components carry **~30%** of the rubric; the
supplementary asks carry **~60%**.

> A response **cannot stay above 50% on the recommendation alone.** The supplementary
> asks have to be hard and discriminating, or the top two will clear the bar too easily.

Keep supplementary asks **answerable from the shipped files**, make each one **depend
on the correct analytical path**, and never leave them as **trivial lookups a wrong
path answers for free**.

> A low bar in the bottom ten never rescues a task the strongest responses already solve.

### Classifying each response

Every response gets one classification. Only the first is a genuine stump.

| Classification | Means |
|---|---|
| **Genuine analytical error** | ✅ A qualifying failure. |
| Prompt ambiguity | ❌ Task defect |
| Missing or conflicting evidence | ❌ Task defect |
| Golden defect | ❌ Task defect |
| Formatting-only failure | ❌ Not a stump |
| Alternative wording only | ❌ Not a stump |
| Missing or unreadable file | ❌ Task defect |
| Arbitrary rubric interpretation | ❌ Not a stump |
| Grader, packaging, or provider failure | ❌ Harness failure |
| Other, review required | — |

> **Score every response honestly.** An ambiguous prompt, a broken golden, or a
> missing file is a **task defect, not a hard task**: it blocks the pass until you fix
> the task itself.

---

## Required rollout reporting

> **Any threshold you cite is meaningless without its denominator.**

- The **model and version string** for every model in the rollout.
- **Run count** per model, and the exact **pass denominator** used.
- The **rubric version** the responses were graded against.
- **Where transcripts are retained**, and for how long.
- **Which thresholds are hard gates** and which are soft.
- For each failed response, **the substantive analytical mistake** behind the wrong result — not just the wrong answer.

---

## The iteration loop

1. **Read the passing response and find the defusal moment** — the exact step where it caught the trap.
2. **Trace every failure back to the analytical mistake that caused it.** If you cannot name the mistake, you cannot defend the stump.
3. **Fix the leak, not the difficulty.** Heuristic, not a measurement: most passing responses were *tipped off* rather than brilliant.
4. **Repair at the source rather than through the rubric** — correct the golden, add the missing evidence, pin the definition, strengthen the trap, widen the decision margin, or remove complexity that does no analytical work.
5. **If the response legitimately reasoned through it**, add a layer from a **different family** than the one it beat.
6. **If responses fail but the stumps are invalid**, determinism is the problem. Tighten the files until competing approaches converge.
7. **Re-run the golden after every change.** A 100% self-score is your regression test.

---

## Readiness check this stage owns

- [ ] Recorded rollout clears the scoring gate: across **12** model responses, the **top 2 average below 50%** against the rubric.
