# 5. Golden Deliverables

[← Writing the prompt](04-prompt.md) · [Index](README.md) · Next: [Traps & stumping →](06-traps.md)

---

The golden deliverables are the **fourth and last step of the build**: the finished
set of files a fully correct analyst would hand back.

> **There is no five-field form anymore.** There are no separate Justification or
> Assumptions fields to fill in. **Everything a grader needs lives inside the
> deliverables themselves.**

---

## What must ship

| Requirement | Detail |
|---|---|
| **Every requested file** | Types, filenames, and count match the prompt exactly. If the prompt asks for a PDF, a CSV, and a Python file, the golden is those three files. **A missing file or a mismatched format blocks confirmation.** |
| **One set of numbers** | The recommendation, every answer, and every table and chart agree exactly, file to file. **A grader will diff them against each other.** |
| **Nothing extra** | No answers to asks the prompt did not make, no placeholders, no files the prompt did not request. |

---

## What goes inside

The recommendation is stated in whichever file most naturally carries it (usually the
**text or code** deliverable), in **one or two sentences, first**, naming what it
rejects. Every other ask is answered in the specific file the prompt attached it to.

Across the whole set, each of these must be covered somewhere:

- [ ] The **committed recommendation**, stated first in its file, in one or two sentences, naming what it rejects
- [ ] **One clearly labelled answer per ask**, placed in the file the prompt attached it to
- [ ] The **load-bearing figures** behind each answer, each traceable to a shipped input file
- [ ] The **path from raw files to the decision**, including **at least one trap refused**, stated as a decision
- [ ] A short closing passage on **why no other conclusion survives** the prompt, the files, and standard domain knowledge

**Placement rules**

- The recommendation carries the most weight, so it goes **first in its file and stands alone**.
- Each remaining ask is answered **in the file that requested it**, labelled so a grader can find it without reading the whole set.
- **Reasoning sits with the answer it supports** — not in a separate section.

---

## Traceability

> Every claim and every number in every file must trace back to a shipped input file.

The chain is **broken** — and the golden set is not ready — if:

- a figure appears in one deliverable that no step of your analysis produced, or
- a claim rests on knowledge that is not in the workspace.

> **Numbers that disagree across files are the most common defect.** Reconcile them
> before you upload.

---

## Manual QC checklist

Run these against your draft before you upload. This is the **only** thing that sets
the Golden deliverable status in your task workspace.

- [ ] Answers the recommendation question and every supplementary question in the prompt
- [ ] Contains no placeholders, TODOs, or unfinished sections
- [ ] No chat-style introduction, invented citation, or generic filler
- [ ] Reads and looks like a normal professional deliverable in this format

The prompt contract must name the requested deliverables **before** this surface can
be confirmed.

---

## What happens next

The rubric is **generated internally** from the prompt contract and these golden
deliverables, and **you do not edit it**. If you later change the prompt contract or
the golden output, the rubric is **regenerated** — that is expected, because the
rubric is downstream of both. → [The rubric](08-rubric.md)

---

## Readiness checks this stage owns

*(Part of Readiness stage 4, "Prompt and solution." See [Readiness](09-readiness-and-submission.md).)*

- [ ] The golden output completely answers the main recommendation and every supplementary question, and **was committed before any model was run**
- [ ] The golden output carries **no obvious LLM artifacts**
- [ ] The parts of the solution agree: main recommendation, supplementary answers, step-by-step results, the determinism basis, and the golden output files *(see [contradiction note](10-reference.md#internal-contradictions-in-the-source))*

---

> ⚠️ **Not captured in the source export.** The "Structure by output type" section held
> four collapsed panels whose bodies were empty in the HTML snapshot:
> *Text goldens (PDF, DOCX)* · *Data goldens (CSV, JSON, XLSX)* ·
> *Visual goldens (PPTX, PNG, HTML)* · *Code goldens (PY)*.
> See [Reference → Gaps](10-reference.md#gaps-in-the-source-export).
