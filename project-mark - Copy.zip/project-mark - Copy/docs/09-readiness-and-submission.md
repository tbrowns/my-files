# 9. Readiness & Submission

[← The rubric](08-rubric.md) · [Index](README.md) · Next: [Reference →](10-reference.md)

---

The Readiness Center is **one place to confirm a task is ready**: policy checks, trap
checks, evidence notes, and an export you attach when you submit.

**51 blocking requirements across 6 stages.**

| Stage | Name | Checks |
|---|---|---|
| 1 | Policy | 6 |
| 2 | Task shape | 4 |
| 3 | Inputs | 7 |
| 4 | Prompt and solution | 10 |
| 5 | Trap validation | 24 |
| 6 | Submission | 0 *(handoff steps, not checks)* |
| | **Total** | **51** |

> **Nothing here is scored, and nothing leaves your browser.** Progress is saved
> locally. Handbook readiness state is **not** a Handshake status and **not** an approval.

> **When a rule changes**, the checks that depend on it are **cleared and flagged**, so
> you re-read the rule instead of shipping against a stale version.

---

## How to use it

For each check: **review the requirement → verify it against your task → add an
evidence note (which file or step proves it) → mark it complete.**

1. **Review each check.** Read the requirement and confirm your task satisfies it.
2. **Add evidence.** Record the file, calculation, result, or reasoning that proves it.
3. **Mark it complete.** Tick the box **only after you have verified that evidence yourself**.
4. **Resolve what is missing.** Open the linked guidance, fix the gap, then come back and re-check.
5. **Submit when the review is done.** The counter at the top shows how many checks are satisfied.

**Numeric rules want your real count, not an estimate.**

### Controls

| Control | Does |
|---|---|
| **Import** | Load a previously exported progress file. |
| **Export JSON** | Save progress and evidence in a structured file you can import again later. |
| **Export Markdown** | Save a human-readable copy of the checklist and evidence. |
| **Reset** | Clear all progress and start over. **Destructive — use it intentionally.** |

> Progress is per-browser. **If you worked on another browser, import your exported
> report to restore it.**

---

## The 51 checks

### Stage 1 — Policy (6)

*The hard rules. → [Input files](03-input-files.md)*

- [ ] A task ships with at least **10** input files. *(numeric)*
- [ ] At least **4** of the shipped files are independently necessary: remove any one of them and the solution can no longer be reached. *(numeric)*
- [ ] At least **2** of the inputs are substantial rather than token: long, dense files that take real work to read and reconcile. *(numeric)*
- [ ] Optional distractor files are allowed and encouraged, but they never count toward the four independently necessary files.
- [ ] *(One Policy row rendered without label text in the source export — see [Gaps](10-reference.md#gaps-in-the-source-export).)*
- [ ] Scenario documents and derived files carry explicit provenance stating what they are and how they were produced.

### Stage 2 — Task shape (4)

*→ [Task types](02-task-types.md)*

- [ ] Task clearly belongs to one accepted Project MARK domain
- [ ] Task has one clear primary analytical objective from the taxonomy
- [ ] Task requires meaningful analytical reasoning from evidence to recommendation
- [ ] Domain, analytical objective, and reasoning-phase tags use the defined taxonomy values

### Stage 3 — Inputs (7)

*→ [Input files](03-input-files.md)*

- [ ] Multiple files or sources create genuine analytical dependencies needed to reach the recommendation
- [ ] Input data contains realistic complexity or mess that must be handled correctly when relevant to the analysis
- [ ] All load-bearing definitions, rules, and facts are supplied in the workspace or are standard domain knowledge experts apply consistently
- [ ] Reaching the recommendation requires multiple substantive analytical steps, not a single lookup or trivial calculation
- [ ] The workspace is internally coherent: files, versions, identifiers, populations, dates, and supporting documentation can be reconciled
- [ ] The workspace is complex for analytical reasons, not because of irrelevant file volume or artificial clutter
- [ ] All input files have clear provenance and are permitted for use and redistribution in the task

### Stage 4 — Prompt and solution (10)

*→ [Prompt](04-prompt.md) · [Golden deliverables](05-golden-deliverables.md) · [Rubric](08-rubric.md) · [Validation](07-validation.md)*

**Prompt**
- [ ] Prompt asks for exactly one deterministic main recommendation that 10 domain experts would converge on
- [ ] Prompt adds three to five related supplementary questions drawn from the defined buckets ⚠️ *[stale wording](10-reference.md#internal-contradictions-in-the-source)*
- [ ] Prompt leaks no methodology and no answer path
- [ ] Prompt prescribes three or more deliverables spanning at least two assigned format families, and every golden output file matches its assigned format and filename

**Rollout**
- [ ] Recorded rollout clears the scoring gate: across 12 model responses, the top 2 average below 50% against the rubric

**Golden**
- [ ] The golden output completely answers the main recommendation and every supplementary question, and was **committed before any model was run**
- [ ] The golden output carries no obvious LLM artifacts
- [ ] The five parts of the solution agree: main recommendation, supplementary answers, step-by-step results, the determinism basis, and the golden output file ⚠️ *[stale wording](10-reference.md#internal-contradictions-in-the-source)*

**Rubric**
- [ ] The generated rubric is fixed with 25 or more criteria, and the fellow does not edit it
- [ ] Rubric weighting holds: recommendation and critical components ~30% across 3+ criteria, supplementary ~60%, instruction-following 5–10%, no single criterion over 20%, all criteria total 100%

### Stage 5 — Trap validation (24)

*→ [Traps](06-traps.md) · [Validation](07-validation.md)*

**The trap is real and documented (4)**
- [ ] The trap targets a named, reproducible model failure.
- [ ] The expected trapped conclusion is documented.
- [ ] The corrected conclusion is documented.
- [ ] Missing the trap materially affects the requested decision.

**The trap is naturally placed (5)**
- [ ] The trap appears in a realistic source, field, period, or workflow.
- [ ] Its placement resembles organic data mess.
- [ ] The trap-carrying file remains straightforward to load.
- [ ] File names and formatting do not announce the trap.
- [ ] No unnecessary clue in the prompt points toward it.

**The antidote is in-corpus and reachable (5)**
- [ ] A correcting fact exists inside the corpus.
- [ ] The antidote is not readable in the same glance or the same analytical step as the bait.
- [ ] The evidence path is discoverable using normal analytical work.
- [ ] Dates, definitions, or authority rules resolve any conflict.
- [ ] No outside knowledge or arbitrary assumption is required.

**The stack composes (5)**
- [ ] At least one missed trap changes or invalidates the recommendation.
- [ ] Every remaining trap independently affects scope, justification, or robustness. None is decorative.
- [ ] All traps push toward the same corrected recommendation.
- [ ] The result is not a knife edge.
- [ ] The conclusion survives reasonable alternative cleaning choices.

**Verified by testing (5)**
- [ ] The lazy path lands on the intended wrong answer.
- [ ] Removing each trap changes the analysis or makes the answer unreachable.
- [ ] Defusing each trap leaves a visible trace in the final analysis.
- [ ] A cold solver can locate every antidote without designer knowledge.
- [ ] The final trap stack has no second defensible interpretation.

> **The trap trace table** lives inside this stage, on its own tab. Fill **one row per
> trap**: a purpose, a location, a correction path, and an observable effect. Rows
> persist in your browser.

### Stage 6 — Submission

Not checks — the three handoff steps below.

---

## The final handoff to Handshake

Three steps, in this order. **You do all three yourself.**

### Step 1 — Export evidence

Export stays available whether or not blockers remain. Both formats contain the same
readiness record: **Markdown** to read and paste, **JSON** to re-import later.

### Step 2 — Open Handshake (external site)

The external Handshake platform is where MARK tasks are actually **submitted and
reviewed**. It opens in a new tab.

> **Opening it does not submit your task.** Nothing is sent for you, and the handbook
> has no connection to it. You complete the submission yourself. Your task plan and
> readiness checks stay stored locally in your browser.

### Step 3 — Confirm submission requirements

> **What a submission must contain is decided on Handshake, not in the handbook.**

The **Program details → submission and approval requirements** page is the
authoritative source. Read it against your export before you submit.

---

## If a check cannot be satisfied

If a check cannot be satisfied because **the task shape itself is the problem**, read
**Invalid stumps** before you revise further — it lists the task shapes that get
rejected in review.
