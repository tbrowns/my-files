# 10. Reference

[← Readiness & submission](09-readiness-and-submission.md) · [Index](README.md)

---

## Glossary

| Term | Meaning |
|---|---|
| **Ask** | A supplementary question *or* a concrete content requirement attached to one named deliverable. Minimum 3 per file. Replaced the old standalone supplementary-questions section. |
| **Antidote** | The correcting fact inside the corpus that overturns a trap's bait reading. Must always be in-corpus. |
| **Bait** | The evidence that encourages the wrong reading. Fair to ship, as long as the antidote ships too. |
| **Critical components** | The load-bearing intermediates the recommendation rests on. Part of the ~30% recommendation block. |
| **Decoy / designed decoy** | The intended wrong answer the lazy path lands on. |
| **Deliverable** | A named output file the prompt requests, with its extension. Minimum 3 per task. |
| **Fellow** | A MARK task author. |
| **Format family** | One of Data / Visual / Text / Code. Two are assigned per task; deliverables must span both. |
| **Golden deliverable** | The finished reference set of exactly the files the prompt requested, correctly filled in. |
| **Handshake** | The external platform where tasks are actually submitted and reviewed. |
| **Knife edge** | A winner that needs one exact computation to stay ahead. Fails validation. |
| **Load-bearing** | A file, figure, or step the correct answer cannot be reached without. |
| **Objective (Axis 1)** | One of six analytical objectives; one is chosen per task. |
| **Proven in production** | Catalog view of traps that have already broken a strong model in a shipped task (14). |
| **Reasoning phase** | Explore / Hypothesize / Analyze-Validate / Synthesize / Recommend. Tagged, never leaked. |
| **Recipe** | A layered chain of traps from different families, all pushing toward the same wrong answer. |
| **Rollout** | A run of 12 model responses scored against the fixed rubric. |
| **Scenario document** | A document you wrote yourself. Not source data; must carry explicit provenance. |
| **Stash** | The external registry where starter data packages are browsed and claimed. |
| **Stump** | A strong model getting a genuine analytical question wrong that a careful analyst gets right from the shipped files. |
| **Trap** | A designed analytical hazard in the evidence. Must be discoverable, consequential, deterministic, and fair. |
| **Trap trace table** | One row per trap: purpose, location, correction path, observable effect. Lives in Readiness stage 5. |

---

## Source-page map

`structure.html` is a 16-page export. This is where each page landed.

| Source page | Route | Restructured into |
|---|---|---|
| Task walkthrough | `/task-walkthrough` | [01 Overview](01-overview.md) |
| Example prompts | *(unlisted)* | [04 Prompt](04-prompt.md) |
| Start (home) | `/` | [01 Overview](01-overview.md), [README](README.md) |
| Platform walkthrough | `/task-flow` | [01 Overview](01-overview.md), [02 Task types](02-task-types.md) |
| Starter data kits | `/starter-kit` | [03 Input files](03-input-files.md) |
| Build | `/build` | [01 Overview](01-overview.md) |
| Input files | `/input-files` | [03 Input files](03-input-files.md) |
| Writing the prompt | `/prompt-design` | [04 Prompt](04-prompt.md) |
| Example traps | `/trap-examples` | [06 Traps](06-traps.md) |
| Writing the golden deliverables | `/solution` | [05 Golden deliverables](05-golden-deliverables.md) |
| Stumping essentials | `/stumping-strategies` | [06 Traps](06-traps.md) |
| Trap catalog | `/trap-design/catalog` | [06 Traps](06-traps.md) |
| Composition & Recipes | `/trap-design/composition` | [06 Traps](06-traps.md) |
| Validation & Iteration | `/trap-design/validation` | [07 Validation](07-validation.md) |
| The rubric | `/rubric` | [08 Rubric](08-rubric.md) |
| Readiness center | `/readiness` | [09 Readiness](09-readiness-and-submission.md) |

### Pages referenced but not present in the export

| Page | Route |
|---|---|
| 8/27 Updates *(six worked examples of non-"flip the number" difficulty)* | `/818-updates` ⚠️ label/route mismatch |
| Program details *(compensation, bonuses, task limits, payment timing, domains, submission requirements)* | `/program-details` |
| Invalid stumps *(task shapes that get rejected in review)* | `/invalid-stumps` |
| Task types / taxonomy | `/taxonomy` |
| Trap fundamentals | `/trap-design/fundamentals` |
| Trap design (hub) | `/trap-design` |
| Proven examples library | `/examples` |
| Enterprise Search Answers incident *(worked golden example)* | `/examples/enterprise-search-incident-rca` |
| Recovery block round nomination *(worked prompt example)* | `/examples/recovery-block-round-nomination` |
| Office hours | `/office-hours` |
| Final submission guidance | *(sidebar only)* |

### External sites

| Site | URL | Purpose |
|---|---|---|
| **Stash** | `https://unlock-the-stash.lovable.app/` | Browse and claim starter data packages. Not a submission surface. |
| **Handshake** | *(not configured in the export)* | Where tasks are submitted and reviewed. |
| 1:1 booking — James Clark | `https://calendly.com/james-clark-ctr-ai` | |
| 1:1 booking — Dallas Banks | `https://calendly.com/dallas-banks-ctr-joinhandshake` | |

---

## Handbook mechanics

- **Task workspace carries across pages** and is saved **in your browser only** — nothing is uploaded and no file contents are stored.
- The **Build workspace** tracks three artifacts (Input files, Prompt, Golden deliverable). **Rubric review stays locked** until all three are confirmed.
- Workspace controls: **Copy as text**, **Reset workspace**.
- The handbook **never uploads files, runs models, or submits anything for you.**

---

## Internal contradictions in the source

The export contains rules from two eras. Where they conflict, **the newer rule is the
one stated on the dedicated page**; the older wording survives mostly in the Readiness
checklist and the Starter-kit page. Flagged here rather than silently smoothed over.

| # | Conflict | Where | Which to follow |
|---|---|---|---|
| 1 | **Input file count: 10 vs 6** | Input files, Policy checks, and walkthrough gate all say **10+**. The Starter data kits page says *"Six or more input files is the bar"* and *"clear the six-file bar."* | **10+** — it is the blocking policy check. |
| 2 | **Rollout size: 12 vs 10** | Everywhere: **12 responses**, bottom 10 unchecked, top 2 average < 50%. Walkthrough step 12 says *"Run 10 model responses… as long as the top 2 mode responses already hit the 50% bar."* | **12 responses, top-2 average under 50%.** |
| 3 | **Supplementary questions: 3+ per file vs 3–5 standalone** | Prompt page: *"3+ asks per deliverable… there is no separate supplementary-questions section anymore."* Readiness check: *"Prompt adds three to five related supplementary questions drawn from the defined buckets."* | **3+ asks per deliverable.** The readiness wording is stale. |
| 4 | **Golden: no five-field form vs "the five parts of the solution"** | Golden page: *"There are no separate Justification or Assumptions fields anymore, and no five-field form."* Readiness check still names five parts. | **Everything lives inside the deliverables.** The five-part check is stale. |
| 5 | **Rubric review exists vs is retired** | Rubric page: *"There is no review pass anymore."* But the breadcrumb reads "Rubric review", the Build workspace has a "Rubric review" card, and walkthrough step 7 says *"Read the generated rubric."* | **Read it; do not edit it.** The surface name is legacy. |
| 6 | **Trap totals: 83 vs 104** | Trap catalog: 83 across 6 families (A17 B17 C13 D18 E12 F6). Example traps: 104 across 6 objectives (15/18/16/19/18/18). | **Different collections**, not a contradiction — a structural taxonomy vs an objective-tagged example set. |
| 7 | **Weights: "about" vs "total 100%"** | 30% + (5–10%) + 60% = 95–100%, yet criteria must total exactly 100%. | The block figures are approximate; **the criteria themselves sum to 100%.** |
| 8 | **Readiness deep links point to the wrong pages** | Rubric checks link to "Writing the prompt"; trap checks link to "Fundamentals"; the 10-file and 4-necessary-file checks link to "Platform walkthrough". | Use the [source-page map](#source-page-map) above. |

---

## Gaps in the source export

`structure.html` is a static DOM snapshot. **Collapsed accordions were exported with
empty bodies**, so the following content exists on the live site but is absent here.
Thirteen panels in total.

| Page | Missing panel |
|---|---|
| Input files | Where to find real documents |
| Input files | When a supporting file earns its place |
| Input files | Input file formats and the tells to avoid |
| Input files | Licensing and provenance in detail |
| Writing the prompt | Why this one holds up *(the worked-example rationale)* |
| Golden deliverables | Text goldens (PDF, DOCX) |
| Golden deliverables | Data goldens (CSV, JSON, XLSX) |
| Golden deliverables | Visual goldens (PPTX, PNG, HTML) |
| Golden deliverables | Code goldens (PY) |
| Stumping essentials | The twelve model failure behaviors to design against |
| Stumping essentials | When relevant: forecasting and predictive modeling |
| Validation & Iteration | Predictive or statistical work *(the specialized robustness lens)* |
| Readiness / Policy | One Policy check row rendered with no label text |

**Also collapsed to titles only:** Platform walkthrough steps 2–9 (only step 1 was
expanded in the snapshot). Their titles are preserved in
[01 Overview](01-overview.md#the-sequence-at-four-levels-of-detail); their
*Do this / Done when / Watch for / Output* detail is not in the export.

**Also not in the export:** the 60 example prompts, the 83 catalog trap entries, and
the 104 objective-tagged traps are all **counted** but their individual bodies load on
demand and were not present. Only the 35 trap names cited in the recipes survive —
see [06 Traps](06-traps.md#named-traps-referenced-in-the-handbook).

---

## Support

- **Drop-in hours:** Tuesday & Thursday, 1–5 PM PT
- **1:1 sessions:** Monday, Wednesday, Friday, 11 AM–6 PM PT
- **Hosts:** James Clark, Dallas Banks

**Source:** `structure.html`, last updated **July 30, 2026**.
