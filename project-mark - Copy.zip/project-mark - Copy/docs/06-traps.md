# 6. Traps & Stumping

[← Golden deliverables](05-golden-deliverables.md) · [Index](README.md) · Next: [Validation →](07-validation.md)

---

## What a stump is

> **Stumping** means a strong model response gets a genuine analytical or
> methodological question **wrong**, while a careful analyst gets it **right** using
> only what was shipped.

**A different final sentence is not a stump.** The failure has to trace to a real
mistake: the wrong denominator, an invalid join, a mishandled cohort, an unjustified
causal claim, an invalid validation scheme.

### What does not count as a qualifying failure

These mean the **task or the harness** is broken, not the model:

- formatting-only failures
- alternative wording
- an invalid or underspecified prompt
- a broken or unsupported golden
- a missing file
- a grader or packaging failure
- a failure caused only by an arbitrary rubric interpretation

### Aim the trap at the main recommendation

The recommendation anchors the deterministic answer. A response that gets the
recommendation **fully correct** should not fall below the pass threshold merely by
missing minor supplementary details. Supplementary questions deepen the evaluation,
but they must never become **artificial gotcha items** or replace the central
recommendation as the main difficulty target.

---

## Why the trap comes first

**Draft the trap before the prompt.** A prompt written first tends to signpost the
catch: it names the metric that matters, or fixes a window that quietly rules the
trap out.

> Write the trap, then write the message a stakeholder would send **if the trap were
> invisible to them**.

---

## The four fairness criteria

*This is the canonical statement. Every trap answers to these, everywhere.*

| Criterion | Requirement |
|---|---|
| **In-corpus antidote** | Every deception has a correcting fact **inside the files**. Supersession must be reconstructible from dates and documents. |
| **Deterministic outcome** | Ten competent analysts reach the same recommendation. All defensible cleanings converge. |
| **No parsing puzzles** | Every file loads with standard tooling in one or two obvious attempts. Difficulty is spent on reasoning, not I/O. |
| **No fabricated source data** | A self-written memo is a scenario document, not source data, and it is recorded as such. |

### Expanded: the four tests a trap must pass

**1. Discoverable — the correcting evidence exists in the workspace.**
The model must be able to find, inside the prompt, files, and standard domain
knowledge, everything it needs to reject the wrong path. A fair trap **may** ship
evidence that encourages the wrong reading, but the material that overturns it must
be present.

*Not discoverable when:* a required rule or definition is absent · a necessary file
was never shipped · the analyst has to guess an unstated threshold · the deciding
fact lives outside the provided materials.

*The strongest traps live **between** files:* reconciling a summary against raw
records · joining at the wrong grain · a definition buried in supporting
documentation · one file that silently supersedes another.

**2. Consequential — the correction changes the analysis.**
If the recommendation, an interpretation, or a decisive intermediate result would be
identical whether or not the model corrects course, **the trap is decorative**.

**3. Deterministic — the correct path leads to one recommendation.**
Ten competent analysts land on the same call. If the final answer changes depending
on a reasonable but **unpinned** choice of metric, scope, population, threshold, time
window, or definition, the task is **underspecified**.

**4. Fair — difficulty comes from analysis, not guessing.**
Semantic ambiguity, missing information, and arbitrary gotchas are disqualifying even
when they make a task hard. The prompt and supporting documents must **never narrate
the trap**: never say which file is misleading, which metric is wrong, which join to
avoid, or which conclusion is expected.

---

## Valid failure vs. invalid difficulty

> If two strong analysts could reasonably choose different definitions, thresholds,
> scopes, metrics, populations, or time windows, and nothing in the prompt or files
> resolves the choice — that is an **underspecified task, not a stump**.

| | Valid | Invalid |
|---|---|---|
| **Source of the failure** | A genuine analytical mistake: wrong cohort, invalid method, missed reconciliation | An undefined term, unstated threshold, or missing fact |
| **What "correcting" it looks like** | Recovering evidence already in the workspace and revising the recommendation | Guessing at a definition nobody pinned down |
| **Whether experts agree on the fix** | Every competent analyst converges on the same corrected answer | Equally reasonable experts could defensibly disagree |
| **What ships in the prompt** | Evidence that makes the correct path findable | A hint, or narration, of what the trap is |

---

## ⛔ The one trap shape to avoid

> **Do not build the "flip the wrong number" trap.**
>
> The overused shape: a stakeholder cites a number, a planted defect proves that
> number wrong, and the answer is to flip to the other option. **If the headline
> number your task overturns is actually wrong and catching that is the whole stump,
> it gets sent back** — however many steps the flip takes.

**Keep the reported figures honest and put the difficulty elsewhere:**

- **Confirm the number** — it is right, and the trap is over-correcting it
- **Forecasting**
- **Method selection**
- **A binding constraint**
- **Decomposition**
- **Hold** (the correct call is to do nothing)

---

## Preflight — confirm all five before you go looking for a trap

- [ ] The failure is a genuine analytical or methodological mistake, not a different final sentence.
- [ ] No reasonable expert could defensibly choose a different definition, threshold, or scope and still be right.
- [ ] The evidence that corrects the wrong path is present in the workspace, not narrated in the prompt.
- [ ] A careful analyst using the materials correctly always lands on the same recommendation.
- [ ] Catching the trap changes the recommendation or a decisive intermediate result, not just wording.

---

## The trap catalog

Two collections exist, grouped differently. They are **views, not rival lists**.

| Collection | Grouping | Count |
|---|---|---|
| **Trap catalog** | By **family** (A–F) — the structural taxonomy, with antidotes and pairings | **83** traps |
| **Example traps** | By **analytical objective** — traps that have already stumped models on that objective | **104** traps |
| *Forecasting & predictive modeling* | Cross-cutting view | 10 |
| *Proven in production* | Cross-cutting view — already broke a strong model in a shipped task | 14 |

### The six trap families

| Family | Name | The failure in one line | Count |
|---|---|---|---|
| **A** | Aggregation and statistics | The number is computed correctly and still means the wrong thing. | 17 |
| **B** | Experiment and causality | The comparison looks clean but the design underneath it is broken. | 17 |
| **C** | Time and comparability | Two periods are placed side by side that were never comparable. | 13 |
| **D** | Plumbing and joins | The data loads fine and the grain, keys, or units are lying. | 18 |
| **E** | Documents and formats | The decisive fact is present, just not where a skim will find it. | 12 |
| **F** | Definitions and framing | The metric named in the prompt is not the metric the decision needs. | 6 |

### Traps by objective (the "Example traps" view)

| Objective | Traps |
|---|---|
| Descriptive & Distribution Analysis | 15 |
| Anomaly Detection & Diagnostics | 18 |
| Root-Cause Analysis | 16 |
| Experiment & Causal Analysis | 19 |
| Forecasting & Predictive Modeling | 18 |
| Data Extraction & Conformation (ETL / Pipeline Build) | 18 |

**How to read the catalog.** Every pattern is **domain-neutral**: the same shapes
appear in operational, economic, policy, demographic, nonprofit, and predictive
workspaces. Many of the strongest entries are **reconciliation problems across
artifacts** — a summary against authoritative raw records, two tables at different
grains, a dictionary that redefines a field, a revision file that supersedes an older
dataset. **The analytical dependency is the trap, not the file count.**

Each entry expands to its **failure mode, a realistic example, the in-corpus
antidote, and cross-family pairings**. Every trap has a stable deep link, e.g.
`/trap-design/catalog?family=A#trap-A1`.

**Symptom search seeds:** `leakage` · `wrong denominator` · `forecast breaks` ·
`double counting` · `wrong test` · `chart is wrong` · `no data yet`

---

## Named traps referenced in the handbook

These 35 are the ones cited by ID in the worked recipes. *(The catalog holds 83 in total.)*

**A — Aggregation and statistics**

| ID | Trap |
|---|---|
| A1 | Simpson's paradox and mix shift |
| A4 | Mean vs median under heavy tails |
| A8 | Seasonality read as effect |
| A10 | Small-sample overgeneralization |
| A14 | Compounding error |
| A15 | Percentile blindness |

**B — Experiment and causality**

| ID | Trap |
|---|---|
| B1 | Sample ratio mismatch |
| B2 | Pre-existing difference between arms |
| B4 | Novelty effect |
| B7 | Contamination between arms |
| B9 | Hidden confounder |
| B12 | Survivorship bias |
| B14 | Reactivations counted as new |

**C — Time and comparability**

| ID | Trap |
|---|---|
| C2 | Partial final period |
| C6 | Cohort maturity mismatch |
| C7 | Refund and chargeback lag |
| C8 | Definition change mid-series |
| C9 | Packaging change breaks comparability |
| C10 | Retention triangle misread |
| C11 | One-off event contamination |
| C12 | Instrumentation change, not behavior change |

**D — Plumbing and joins**

| ID | Trap |
|---|---|
| D2 | Wrong key among lookalikes |
| D3 | Partial duplicates |
| D5 | Bot and fraud traffic |
| D7 | Stale derived column |
| D13 | Event vs user vs session grain |
| D17 | Slowly changing dimension |
| D18 | Missingness that is not random |

**E — Documents and formats**

| ID | Trap |
|---|---|
| E1 | Footnote overrides the table |
| E3 | Authoritative but stale document |
| E7 | Long-file burial |
| E8 | Detail in a chart annotation |

**F — Definitions and framing**

| ID | Trap |
|---|---|
| F3 | Wrong denominator population |
| F5 | Attribution window mismatch |
| F6 | Non-linear funnel paths |

---

## Composition — layering traps into a recipe

> **Single traps get caught by strong models about half the time.**

**The recipe:** layer a **gate**, a **flip**, and a **confirmation** drawn from
**different families**, then check that **all three push toward the same wrong
answer**, so a partial analysis plausibly lands there.

**Rules for every layer**

- Every layer must **materially change the answer on its own**. A layer that only adds reading time is decoration — it makes the task longer without making it harder.
- All traps push toward the **same corrected recommendation**.
- The result must **not be a knife edge**.
- The conclusion survives **reasonable alternative cleaning choices**.
- Fairness rules still apply: deterministic, discoverable, analyzable, source-authentic.

---

## The 17 worked recipes

Reference scenarios already paired with traps from different families. Take one and
build it out rather than starting from a blank page. Every pattern is
**domain-transferable** — swap the subject matter and the shape still works.

| Scenario | The decision | Traps | The mechanism |
|---|---|---|---|
| **Program funding reallocation** | Which single program or channel gets the incremental budget? | F5 + D5 | A crediting-rule bait document plus an exclusion list that lives in a separate export. |
| **Why did the measured rate drop** | Reverse last period's change or not? | C12 + C2 | The stakeholder's wrong causal theory is stated in the prompt; a methodology note explains the measurement break. |
| **Kill or keep the initiative** | Retire or invest? | B12 + C6 + A4 | Three heavy participants carry the headline number; a second table at a different grain exposes it. |
| **Intervention targeting** | Which group receives the intervention? | A1 + D18 + A10 | A small-sample subgroup looks like the obvious winner until the eligible population is pinned. |
| **Did the new terms work** | Extend the terms to everyone? | A1 + C9 + C7 | Nominal versus adjusted values, and a discontinued category, separate the apparent winner from the real one. |
| **Forecast next period** | Commit to the target or re-plan? | A8 + C11 + A14 | A prebuilt forecast makes the compounding error, and a structural break invalidates the fitted trend. |
| **Which variant won** | Adopt A or B? | B7 + B4 + B2 | An early-read summary deck serves as the bait; the arms were never comparable. |
| **Where is the process leak** | Which stage gets the fix? | D3 + F3 + F6 | Denominator drift across stages hides the true bottleneck. |
| **Is the increase real** | Is there actually a problem? | C8 + C10 + B14 | Three separate comparability breaks, all pointing the same way. |
| **Program redesign readout** | Roll the redesign out to everyone? | B9 + B1 + E1 | Eligibility rules in a definitions document confound the cohort comparison. |
| **Which sector gets the retention program** | Point the budget at one sector — which? | D13 + B14 + E3 | A rollup, a one-pager, and a leadership email crown the same wrong sector; the raw records refute all three. |
| **Which configuration ships** | Which single configuration ships for peak season? | E3 + A15 + E7 | The winner on the stale revision fails a fine-grained capacity gate, and the fallback dies on a buried clause. |
| **Is the spike real** | Act on the drop or wait? | C6 + C2 + A1 | The alarming spike is made entirely of cases too recent to have reached the outcome yet. |
| **Approve the plan or not** | Does the plan clear the investment hurdle? | E1 + E3 + D7 | Subtracting the large headline cost flips the decision; three chained documents prove it is fully reimbursed. |
| **Which pairing rule launches** | Which single directional pairing gets promoted? | E8 + D3 + E1 | The obvious winner is ineligible under a ceiling that appears only in an image inside the requirements doc. |
| **Where does the next allocation go** | Which single option gets funded next period? | D3 + F3 + D2 | Two artifacts agree with each other and disagree with the authoritative ledger; the dedup decides who is right. |
| **Certify the period or reverse the adjustment** | Sign off as filed, or reverse the adjustment? | E3 + E1 + D17 | The adjustment is applied and endorsed, and a precedent seems to bless it; the timestamps say otherwise. |

---

## Readiness checks this stage owns

*(Readiness stage 5, "Trap validation" — 24 checks, the largest stage. See [Readiness](09-readiness-and-submission.md).)*

**The trap is real and documented**
- [ ] The trap targets a named, reproducible model failure.
- [ ] The expected trapped conclusion is documented.
- [ ] The corrected conclusion is documented.
- [ ] Missing the trap materially affects the requested decision.

**The trap is naturally placed**
- [ ] The trap appears in a realistic source, field, period, or workflow.
- [ ] Its placement resembles organic data mess.
- [ ] The trap-carrying file remains straightforward to load.
- [ ] File names and formatting do not announce the trap.
- [ ] No unnecessary clue in the prompt points toward it.

**The antidote is in-corpus and reachable**
- [ ] A correcting fact exists inside the corpus.
- [ ] The antidote is not readable in the same glance or the same analytical step as the bait.
- [ ] The evidence path is discoverable using normal analytical work.
- [ ] Dates, definitions, or authority rules resolve any conflict.
- [ ] No outside knowledge or arbitrary assumption is required.

**The stack composes**
- [ ] At least one missed trap changes or invalidates the recommendation.
- [ ] Every remaining trap independently affects scope, justification, or robustness. None is decorative.
- [ ] All traps push toward the same corrected recommendation.
- [ ] The result is not a knife edge.
- [ ] The conclusion survives reasonable alternative cleaning choices.

**Verified by testing** *(see [Validation](07-validation.md))*
- [ ] The lazy path lands on the intended wrong answer.
- [ ] Removing each trap changes the analysis or makes the answer unreachable.
- [ ] Defusing each trap leaves a visible trace in the final analysis.
- [ ] A cold solver can locate every antidote without designer knowledge.
- [ ] The final trap stack has no second defensible interpretation.

---

> ⚠️ **Not captured in the source export.** Two collapsed panels under
> "Advanced: Know your enemy" were empty in the HTML snapshot:
> *The twelve model failure behaviors to design against* and
> *When relevant: forecasting and predictive modeling*.
> See [Reference → Gaps](10-reference.md#gaps-in-the-source-export).
