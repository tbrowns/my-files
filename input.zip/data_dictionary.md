# Data room dictionary -- Meridian anchor sourcing file

Assembled by Network Analytics for the sourcing committee, 2026-09-01. One section per file. Field lists are complete; enumerations are the values present in this extract.

## Conventions

- Quantities: `uom` = `EA` (retail units / eaches) or `CS` (cases). Case packs are effective-dated; see `pack_change_history.tsv`. `item_master.xlsx` carries each item's case pack currently in effect (as at 2026-09-01).
- Timestamps: each warehouse system exports its native basis -- see `site_directory.json` (`ledger_timestamp_basis` per DC). ATLAS sites export UTC; NAVIS sites record site local time. The EDI ingest log records hub receipt times in UTC (`Z` suffix).
- Site codes: ATLAS documents carry legacy site codes; `site_directory.json` maps legacy codes to DC codes.
- Transfer references: `ref` on transfer movements is `TR-<origin DC>-<destination DC>-<sequence>`.

## movement_ledger_2026.csv
Consolidated network movement extract, 2026-01-01 through 2026-08-31, assembled by the integration layer from ATLAS and NAVIS. The extract images every received batch (including retransmissions and rejected submissions); batch posting status lives in `edi_ingest_log.jsonl`.

| field | meaning |
|---|---|
| txn_id | extract row id |
| batch_id | integration batch the row arrived in |
| doc_no / line_no / revision | source document, line, and revision number |
| posted_ts | document event timestamp, in the source system's native basis (no zone suffix) |
| source_system | ATLAS or NAVIS |
| site | site code as exported (legacy for ATLAS) |
| movement_type | ISSUE_ORDER, RECEIPT_PO, TRANSFER_IN, TRANSFER_OUT |
| item_code | item |
| lot_no | production lot (receipts and returns; blank on issues) |
| qty / uom | document quantity in EA or CS |
| ref | transfer reference where applicable |

Sign conventions: RECEIPT_* and TRANSFER_IN add stock; ISSUE_* and TRANSFER_OUT remove it. Quantities are unsigned.

## certified_stock_statements_2025-12_2026-07.csv
Inventory Control's certified month-end on-hand by DC and item for the Meridian assortment, 2025-12-31 through 2026-07-31, filtered to the assortment for this data room. Certified totals include stock under quality hold. August certification is issued around the 19th of the following month and is therefore not yet available.

## edi_ingest_log.jsonl
One JSON object per integration batch: `batch_id`, `source_system`, `site`, `received_at_utc`, `row_count`, `status` (ACCEPTED, DUPLICATE_RETRANSMISSION with `duplicate_of`, or REJECTED_VALIDATION with `reject_reason`).

## item_master.xlsx
Sheet `items`: item_code, product_name, brand, category, size_ml, units_per_case (current), case_gtin, status, abc_class, introduced. The Meridian agreement names products by name and size; this sheet is the name-to-code mapping.

## pack_change_history.tsv
Effective-dated case pack configuration per item: item_code, units_per_case, effective_from, effective_to (blank = current).

## site_directory.json
Network master data: DC codes, names, WMS, `ledger_timestamp_basis`, IANA timezone, legacy site codes, NAVIS cutover dates, and lane transit days (origin, destination, transit_days).

## open_orders_extract.csv
Open customer order lines as at 2026-09-01: status one of ALLOCATED, CANCELLED, COMMITTED, CREDIT_HOLD, DRAFT, QUOTE. Fields: order_line_id, customer, dc, item_code, qty, uom (CS), requested_ship_date, status, entered_on.

## po_inbound_schedule.csv
Inbound purchase schedule as at 2026-09-01: status one of CLOSED, CONFIRMED, FORECAST, PLANNED, TENTATIVE. CLOSED lines are already received and posted in the ledger. Fields: po_line_id, vendor, dc, item_code, qty, uom (CS), promise_date, status.

## quality_hold_register.csv
Quality holds at lot level: hold_id, dc, item_code, lot_no, qty_units, grade (1 = stop-sell lot), placed_on, released_on (blank = open), disposition_note. A lot hold withholds the listed quantity from sellable stock; it is not a site-wide stop-ship instruction.

## sop_demand_plan_2026.csv
The Sales & Operations Planning consensus plan for 2026: one row per week_commencing (Monday) per dc per family, with committed_volume_units and planned_inbound_units. Families include SPARKLING-355 (the Meridian assortment aggregate) and others. This is Planning's forecast of demand and supply; it is not the order book or the purchase schedule, and it is not a record of obligations.

## prior_anchor_register.csv
The filed floor positions of completed anchor assignments, retained per OSP-12 6.2. One row per assignment per DC: assignment_id, programme, position_date, first_week_commencing, weeks, assortment (semicolon-separated item codes), programme_units_per_week, dc, filed_floor_units, anchored (Y for the DC the programme was assigned to). Used for the section 5.7 basis validation.

## order_book_snapshots_2026.csv / po_schedule_snapshots_2026.csv
Point-in-time snapshots of the open order book and the inbound purchase schedule as retained with each prior assignment's file, keyed by as_at (the assignment's position date). Same columns as the current open_orders_extract.csv and po_inbound_schedule.csv, prefixed with as_at. Used to reconstruct the filed floors in prior_anchor_register.csv.

## osp12_order_sourcing_procedure.pdf
Controlled procedure OSP-12 rev 4 -- governs anchor assignment. The committee is held to it.

## meridian_supply_agreement_extract.pdf
Extract of the executed supply agreement: term, fulfilment, failure-to-supply, and Schedule B programme quantities.

## network_compliance_audit_fy26.pdf
Internal audit's FY2026 network compliance cycle summary, including the corrective-action register.

## preread_dc_scorecard.md
Dana Okafor's pre-read to the committee, 2026-09-02. Her figures are her own workbook's, built on the S&OP demand plan.

## Provenance
This data room was assembled on 2026-09-01 by Network Analytics from the integration layer's consolidated extract, Inventory Control's certification file, network master data, the open order and purchase schedules and their prior-assignment snapshots, the S&OP demand plan, the quality hold register, the prior-anchor register, Internal Audit's FY2026 report, the executed Meridian agreement, and controlled procedure OSP-12 rev 4. All materials relate to Brightwater Beverage Group's five-DC network.
