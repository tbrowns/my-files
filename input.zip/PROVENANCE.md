# Provenance & Licensing

**Package:** Calmarra SUT Revenue Estimation Pack · **Snapshot:** 2026-09-04

## Nature of the material

The **State of Calmarra**, the **Calmarra Department of Revenue**, its **Office of
Revenue Estimates**, the **Calmarra Bureau of Economic Research**, and every filer,
person, sector code, region, and dollar figure in this package are **fictional and
simulated**. Nothing here is real government data or refers to any real jurisdiction,
organization, or person. Any resemblance to a real entity is coincidental.

The package was constructed for an analytical exercise. It is internally consistent by
design: the collection record, the summary series, the rate history, the calendar, and
the operational events all reconcile with one another under the rules stated in
`revenue_data_dictionary.md`.

## How each file was produced

- **Data files** (`sut_returns_ledger_2016_2026.csv`, `monthly_receipts_revised.xlsx`,
  `monthly_receipts_preliminary.csv`, `ctrai_activity_index.csv`, `filer_directory.csv`,
  `sector_reference.json`, `filing_calendar.csv`) were generated programmatically from a
  single seeded simulation of a mid-size state's SUT collections. The simulation applies
  a trend, a monthly seasonal pattern, the statutory rate history, and a small number of
  documented operational events, then records the result at the return-line grain.
- **Scenario documents** (`revenue_data_dictionary.md`,
  `collections_operations_log_2016_2026.md`, `ctrai_methodology_note.md`,
  `statutory_rate_schedule.pdf`, `revision_policy_note.pdf`, `enacted_budget_fy2027.pdf`,
  `vendor_forecast_memo.pdf`, `DATA_NOTES.md`, this file) were authored for the exercise
  to describe, govern, or comment on the data. They are **scenario documents, not source
  data**. The vendor memo in particular is an external work product included as received;
  its analysis is the consultant's own and is not endorsed by the Department.

## Licensing

All files are synthetic and are released for use and redistribution without restriction
(CC0 1.0 / public-domain equivalent). No personal data, no third-party copyrighted
material, and no licensed data are included.
