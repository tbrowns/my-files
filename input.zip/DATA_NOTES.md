# Data Package — Calmarra SUT Revenue Estimation Pack

**Prepared for:** Office of Revenue Estimates, forecast round FY2027 Q1.
**Snapshot date:** 2026-09-04. All files reflect data as known on that date.

This pack contains the state sales-and-use tax (SUT) collection record and the
supporting documents an estimator would work from. Read
`revenue_data_dictionary.md` first — it governs how the collection files are read.

## Files

**Collection record**
- `sut_returns_ledger_2016_2026.csv` — the return-level ledger, Jan 2016 – Jul 2026, one
  row per filing line (~24.5k lines). The system-of-record source. Transactional and not
  pre-deduplicated; apply the line-status rules in the dictionary.
- `monthly_receipts_revised.xlsx` — final revised monthly recognized net receipts,
  through the last closed revision month.
- `monthly_receipts_preliminary.csv` — early accrual estimates for recent months,
  provisional (see `revision_policy_note.pdf`).

**Rules, calendar, and reference**
- `revenue_data_dictionary.md` — field definitions, line-status codes, recognized-
  receipts basis, rate application, series definitions.
- `statutory_rate_schedule.pdf` — statutory SUT rate history and enabling instruments.
- `filing_calendar.csv` — per-period due date, close date, statutory rate, period status.
- `revision_policy_note.pdf` — preliminary-vs-revised policy, revision timing and bias.
- `collections_operations_log_2016_2026.md` — processing events that affected posting.
- `filer_directory.csv`, `sector_reference.json` — filer and sector reference.

**Targets and external material**
- `enacted_budget_fy2027.pdf` — the enacted FY2027 revenue plan and its FY2027 Q1 SUT
  estimate.
- `vendor_forecast_memo.pdf` — an outside consultant's forecast memo circulated to the
  office. Provided as received; it is an external work product, not a Department figure.
- `ctrai_activity_index.csv`, `ctrai_methodology_note.md` — an advisory activity index
  and its methodology (note the publication lag).

## How the files relate

The ledger is the source; the revised and preliminary monthly files are derived views
of it. The rate schedule, dictionary, and calendar define how lines are valued and
aggregated. The operations log explains timing anomalies in specific months. The budget
supplies the enacted target; the vendor memo is one outside view of whether it will be
met. CTRAI is supplementary context.

*No file here is decorative; each is what an estimator on this round was actually
working from.*
