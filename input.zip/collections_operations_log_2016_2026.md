# SUT Collections & Processing — Operations Log (2016–2026)

**Calmarra Department of Revenue · Collections Operations · running journal**
*Maintained by the Processing & Treasury Operations unit. Entries record events that
affected how or when SUT remittances posted. This log is operational; it does not
adjust any figure — figures are what the ledger and revised series report.*

Most-recent entries first.

---

**2026-08-24 — FY2027 Q1 periods open.** Reference months 2026-07 onward are OPEN.
July returns were due 2026-08-20 and are still clearing; a large share of July lines
remain `PENDING` in the ledger as of this log. June 2026 (2026-06) closed on schedule;
a handful of late June lines are still marked `PENDING` but the June period is
otherwise complete on the recognized basis. Treat any month flagged `OPEN` in
`filing_calendar.csv` as not-yet-complete.

**2026-06-30 — Lockbox vendor transition.** Paper-check lockbox processing moved to a
new vendor over the last week of June. No change to posting rules; a small number of
check lines cleared 2–3 business days later than usual. No period reopened.

**2026-02-11 — Portal 2.0 rollout.** The filer portal was upgraded. Duplicate-submission
detection improved; a modest rise in `DUPLICATE`-flagged lines in Feb–Mar 2026 reflects
better flagging of re-files, not new activity. Recognized figures are unaffected.

**2025-07-01 — Annual revision cycle closed for FY2025.** Revised final figures through
2025-06 were published and locked. See `revision_policy_note.pdf` for cycle timing.

**2024-11-15 — Holiday-season staffing note.** Routine. Extended processing hours for
the Nov–Dec peak; no posting-rule change.

**2024-03-27 — One-time audit settlement remittance.** A single filer remitted
**$135.0M** under a negotiated closing agreement resolving a multi-year audit. The
remittance posted to reference month **2024-03** as a single `CLEARED` line. It is a
**one-time, non-recurring** settlement and is not part of ordinary monthly collections;
it does not recur in any later period. Recorded here so downstream users are aware the
March 2024 total carries this one-off.

**2023-08-02 — Sector remap (cosmetic).** Two minor sector codes were merged in the
reference table. No effect on receipts or on filer totals.

**2023-04-01 — Statutory rate change took effect.** The state SUT rate rose from 5.50%
to 6.50% for taxable activity on and after this date (Public Act 2022-114). Systems
applied the new rate to reference months 2023-04 onward; earlier periods remain at
5.50%. Reported dollar collections step up accordingly from April 2023. See
`statutory_rate_schedule.pdf`.

**2022-10-05 — September catch-up posting.** Remittances delayed by the September
processor outage (below) posted during **2022-10**, on top of normal October activity.
October 2022 therefore reads high; the excess is recovered September volume, not new
October activity.

**2022-09-26 — Payment-processor outage (Sep 12–26).** The primary ACH/portal processor
was degraded or offline for parts of 12–26 September. A material share of September
remittances did not clear within the month and instead posted in October (see above).
Reference month **2022-09** consequently reads low relative to seasonal norms. No
receipts were lost; timing only.

**2021-05-18 — Routine reconciliation.** Quarterly Treasury reconciliation completed;
no exceptions.

**2020-04-09 — Filing-relief window.** A short penalty-relief window was offered in
spring 2020; filing timing was unaffected for the vast majority of filers and no
reference month was reclassified. Recorded for completeness.

**2019-02-01 — Ledger system of record established.** The current return-ledger schema
(the basis for `sut_returns_ledger_2016_2026.csv`) became the system of record;
history back to 2016-01 was migrated and reconciled.
