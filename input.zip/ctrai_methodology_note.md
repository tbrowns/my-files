# Calmarra Taxable Retail Activity Index (CTRAI) — Methodology Note

**Calmarra Bureau of Economic Research · advisory indicator · Rev. 2026-07**

## What CTRAI is

CTRAI is a monthly, seasonally-adjusted index of taxable retail activity in the state,
indexed to 2016-01 = 100. It is built from a fixed panel of high-frequency payment and
point-of-sale feeds and is intended as a **coincident, advisory indicator** of the SUT
taxable base. It is published in `ctrai_activity_index.csv` with three fields:
`reference_month`, `ctrai_index`, and `published_date`.

## Publication lag — read this before using CTRAI in any time-sensitive analysis

CTRAI is **not** available in real time. Each month's value is compiled only after the
source panels settle, and the Bureau publishes a reference month's index on
approximately the **15th of the second month following** the reference month — a lag of
roughly **ten to eleven weeks**. The `published_date` field records the actual release
date for each observation and is the authoritative statement of when that value became
available.

Consequences:

- For any reference month, the CTRAI value is unknown until its `published_date`. As of
  a given analysis date, only observations with `published_date` on or before that date
  exist.
- The most recent one to two reference months are therefore **absent** from CTRAI at any
  point in time, even though SUT receipts for those months may already be posting.
- Any use of CTRAI as an input to an estimate must align each observation to its
  `published_date`, not to its `reference_month`, so that the estimate uses only values
  that were actually available at the time.

## Coverage and status

CTRAI covers the same window as the SUT files but ends one to two months short of the
latest SUT reference month, by construction of the lag. It is an **advisory** series:
it is not a Department of Revenue product, is not used to set statutory figures, and is
provided here as supplementary context only.
