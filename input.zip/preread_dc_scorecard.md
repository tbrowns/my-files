# Pre-read: Meridian anchor scorecard

**From:** Dana Okafor, Network Analytics  
**To:** Sourcing committee  
**Date:** 2026-09-02  
**Re:** Where the Meridian programme should sit

Ahead of Tuesday, here is the position scan the committee asked me to circulate. I pulled the consolidated movement extract for the year through August 31, valued it against the item master, and set it against the Meridian weekly programme plus everything the inbound schedule shows arriving over the eight weeks. Units on hand below are the assortment only, all five DCs.

| DC | Assortment units on hand, 8/31 | Projected low point over the 8 weeks (units) |
|---|---:|---:|
| Delran (DEL) | 178,722 | 158,862 |
| Ostrander (OST) | 98,457 | 100,623 |
| Plainview (PLV) | 52,772 | 56,432 |
| Carswell (CAR) | 54,430 | 45,754 |
| Winterset (WNT) | 20,538 | 16,188 |

**Read:** Delran is not a close call on the numbers -- it is holding far and away the deepest assortment position and it never comes near a stock-out across the programme window. Ostrander is the clear second. Carswell, which I know some of the room assumed would carry this because it carried Halloran's overflow, sits mid-pack at best; its book is thinner than the room thinks. Plainview is healthier than its reputation this summer. Winterset is not a serious candidate at these volumes.

**Recommendation:** nominate **Delran (DEL)** as the anchor, with Ostrander as the named fallback if Commercial wants one in the file.

Method note: figures come straight off the consolidated extract and the open schedules, so the committee can retrace every number; happy to walk anyone through the workbook before Tuesday. -- D.O.
