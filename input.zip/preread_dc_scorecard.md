# Pre-read: Meridian anchor scorecard

**From:** Dana Okafor, Network Analytics  
**To:** Sourcing committee  
**Date:** 2026-09-02  
**Re:** Where the Meridian programme should sit

Ahead of Tuesday, here is the position scan the committee asked me to circulate. I took each DC's sellable assortment position at August 31 and ran it forward across the eight programme weeks against the S&OP demand plan -- committed volumes out, planned inbound in -- for the sparkling 355 mL family, less the Meridian weekly draw. The demand plan is the cleanest weekly view we have, so the committee can read it straight off.

| DC | Sellable assortment, 8/31 | Projected low point over the 8 weeks (units) |
|---|---:|---:|
| Delran (DEL) | 102,906 | 112,076 |
| Ostrander (OST) | 98,895 | 79,385 |
| Plainview (PLV) | 18,630 | 37,350 |
| Winterset (WNT) | 22,740 | 24,720 |
| Carswell (CAR) | 81,502 | 5,192 |

**Read:** Delran is not a close call on the plan -- it holds far and away the deepest position and never comes near a stock-out across the window. Ostrander is the clear second. Carswell draws down hard on the plan's demand and dips lowest of the large DCs; its book is thinner than the room thinks. Plainview looks healthier than its summer reputation. Winterset is not a serious candidate at these volumes.

**Recommendation:** nominate **Delran (DEL)** as the anchor, with Ostrander as the named fallback if Commercial wants one in the file.

Method note: I ran this off the demand plan rather than picking through the raw order book -- it is already weekly and by DC, so every number is easy to retrace. Happy to walk anyone through it before Tuesday. -- D.O.
