# Project Dynamo: session handoff

Written 2026-07-27, at the end of a session covering four tasks. Read this before
starting a new one. It is the accumulated theory, the measured evidence, the
process facts, and the operating method.

This is not a replacement for `TASK_RETROSPECTIVE.md`. That file holds the run
by run history through 2026-07-25. This handoff carries what came after it, plus
the working method, plus the current state of every open thread.

---

## 1. Track record

Four tasks in this session. Three accepted, one still open.

| Task | Category / sub | Crux | Result |
|---|---|---|---|
| PRVS record encoder | Security / Reverse Engineering | gcd secret prime in a record trailer | ACCEPTED. pass@5 0/5, 4 good valid fails, avg@5 0.000 |
| VM devirtualization | Security / Reverse Engineering | gcd secret prime in a Horner fold VM opcode | ACCEPTED. pass@5 1/5, 4 good valid fails, avg@5 0.200 |
| Chunk store forensics | Security / Digital Forensics | gcd secret prime behind a base confounder | ACCEPTED. pass@5 0/5, 5 good valid fails, avg@5 0.000 |
| Page cache durability | Debugging and Repair / Concurrency | boolean flag cannot express which version persisted | OPEN, blocked at pass@2 |

The VM task is the important one to understand. Its first design was rejected as
too easy at 2/2 solved, its hardening was blocked by qc_gate as underdetermined,
and it was rescued by pivoting the crux to the gcd family. That pivot is what
produced the accept. See section 5.

---

## 2. The core theory: what actually stumps a frontier model

The single most important finding, from the retrospective's section 17b and
confirmed again this session:

**A noticing axis does not stump a frontier model. A required derivation does.**

Noticing means spotting something: version skew, a stale tool, an unused field, a
suspicious code pattern. Frontier models are very good at this. Every misdirection
axis ever shipped in this corpus has been seen through by every agent.

Derivation means computing something the model will not think to compute. The gcd
recovery of a secret modulus is the only mechanism in the corpus that has held,
and it has held because agents run checksum catalogues, z3, and named hash
searches, and never form the residue model.

The corollary, learned the hard way on the concurrency task: **a task whose
difficulty lives in finding the defect is a noticing task, however it is dressed.**

### The shape of a good stump

From the platform guide, and it matches every accept in the corpus:

> A good stump does not make a task broadly hard. It makes the agent do 90% of
> the work correctly and then fail on one decisive point that is determinate
> (there is exactly one right answer), but that the agent cannot pattern-match,
> recall, or self-verify its way past.

Three amplifiers, all of which the accepted tasks have:

- **Silent failure.** Wrong output looks well formed. Nothing crashes.
- **No self-check.** The agent's own testing goes green on a wrong answer.
- **All or nothing.** One wrong field fails the run.

---

## 3. The wall, stated precisely

Every task that failed in this session failed at the same place, and it is worth
naming because it will recur.

**Fair enough to clear qc_gate often means easy enough to solve.**

qc_gate demands that the graded output be uniquely determined by agent-visible
material. Anything with two defensible readings is blocked as underdetermined.
But the natural way to make a crux hard is to hide it, and hiding it is exactly
what makes it underdetermined.

The VM task hit this from both sides in one build:

- Addressing mode rendered plainly: fair, and 2/2 solved. Too easy.
- Addressing mode hidden: hard, and qc_gate blocked it as underdetermined.
- The gate's own suggested fix disclosed the rule, returning it to too easy.

**The escape is determinate-but-declined.** The answer must be uniquely fixed by
what ships, and hard only because the recovery technique is one the model does
not reach for. The gcd modulus qualifies: every sample constrains it, the gcd of
the differences pins it exactly, and no agent has ever tried it.

That is the test to apply to any new crux at proposal time. Not "is it hidden"
but "is it determined and declined".

---

## 4. Proven mechanisms and their status

### gcd secret prime modulus: the only proven mechanism

An integrity field is a value reduced by a secret large prime. Recovery requires
taking the greatest common divisor of the differences between unreduced values
and stored residues across many samples.

Why it works, measured across every accept:

- Agents run named checksum catalogues (CRC32, CRC64, Adler32, FNV, xxHash,
  MD5, SHA, BLAKE2b), constraint solvers, and ARX hash searches.
- None has ever formed the residue model or called gcd.
- On the VM task, one agent explicitly concluded no constant satisfied the
  equations modulo 2^32, which is the correct signal that the modulus is not a
  power of two, and still pivoted to XOR and shift searches rather than gcd.

Design requirements:

- Prime, 62 bits. Large enough that brute force fails, and prime so the 2-adic
  or Hensel lifting shortcut that cracks a mod-2^k hash does not apply.
- Off catalogue. Not 10^9+7, not 2^31-1, not FNV or Knuth or djb2 constants, not
  near a power of two.
- Uniquely recoverable. Bench it: gcd of the differences must equal the modulus
  exactly, not a multiple. Confirm the gcd of the wrap multipliers is 1 and that
  every stored residue is below the modulus.

### The base confounder

Added on the chunk store task after a reviewer flagged the plain gcd as
POSSIBLY EASY. Instead of the value read as a big integer, use a Horner fold
with a non-obvious base, reduced by the prime.

Reading content as a big-endian integer is exactly that fold with base 2^32, so
the reflexive assumption is a specific wrong base and a gcd computed under it
returns 1, which reads as "there is nothing here". The base stays uniquely
recoverable from a degenerate sample whose fold is the base itself.

Bench requirement: every wrong base must return gcd 1, including bases adjacent
to the true one, so there is no gradient to hill-climb.

### Concentration risk

The gcd family is now six for six. Every accept rests on it. That is
simultaneously the most reliable asset in the corpus and its largest single
risk, given the explicit warning that repeated submissions get a contributor
offboarded.

See section 11 for the similarity rules and how to think about this.

---

## 5. The five hard lessons from this session

These are new, measured, and not in the retrospective.

### 5.1 A graded field's name is agent-visible surface

The chunk store task originally graded a field called `integrity_modulus`. That
name tells the solver the trailer is a modular reduction, which is precisely the
step no agent has ever taken unprompted.

It was renamed at Phase 9, one hour before the push. The result was 0 of 5 with
five clean anchors, and the trial analysis confirmed all five agents ran the
checksum catalogue and none formed the residue model.

**Rule: name a graded field for what it is to the solver, never for its
mechanism.** If the field cannot be named without disclosing the mechanism,
consider a bare value with no key at all.

### 5.2 Loud traps funnel, silent traps score

The shipped seeds are the solver's own verification. A repair that fails loudly
on them, with a deadlock, a stall, or a reproduction that still reproduces, is
caught by the agent before submission and never reaches the verifier.

Measured on the concurrency task: widening the lock livelocked in 0.1 seconds on
essentially every seed. That trap contributes nothing to pass@5. Its only
function is to push a solver off one repair form and onto another.

**Only silent failures count toward the arithmetic.** A trap scores when the
solver's verification goes quiet: shipped seeds green, held-out seed red.

This imposes a seed selection rule: shipped seeds must be ones every wrong
repair passes, and held-out seeds must be ones each wrong repair fails.

### 5.3 Write the correct repair first

For any repair-category task, before building anything, write the correct fix.

**If the correct fix is a reorder, a guard, or a one-line move, the difficulty is
all in the finding and the task is a trace task wearing a repair task's clothes.**
Section 17b says trace tasks do not stump.

Three separate defect designs on the concurrency task collapsed to a one-line
repair. That is a property of the category, not three unlucky picks: a defect
that is hard to find is usually easy to fix once found.

This test costs ten minutes at proposal time and would have killed that concept
in Phase 3 rather than after four days in Phase 4.

### 5.4 Prove a metric discriminates AND cannot manufacture failures

Five measurement failures in a single build, each producing a confident wrong
conclusion before being caught:

1. **Per-seed variant comparison.** Adding a lock changes yield ordering, which
   changes RNG consumption, which re-randomises the whole schedule. "Seed 2
   before and after" are different executions. Returned 7 of 7 "fixed" for a
   repair that fixed nothing. Only distributional comparison over the same seed
   range is valid.
2. **Per-worker version counters.** Each worker had its own counter, so "this
   page holds an older version" compared incomparable sequences. Produced 5,319
   phantom failures.
3. **Call-time high-water mark.** Recording the highest sequence at call time
   and comparing against concurrent reads gives a constant background
   independent of correctness. All four variants scored the same, including one
   built to be correct.
4. **Stale-read counter.** Same shape as 3.
5. **Shutdown flush-all.** Flushed any frame whose page field was set without
   checking ownership, so a dead tenancy clobbered a live durable value. Reported
   3 losses on a reference that had lost none.

**The rule, in two parts. Before reading any result off a new metric:**

1. Prove it separates a known-correct from a known-broken component.
2. Prove it cannot manufacture the failure it reports, by running it against the
   known-correct component and requiring exactly zero.

Separation was never the weak point. Four of the five were the instrument
creating the signal, and separation is blind to that. Numbers from an
unvalidated metric are withdrawn, not reinterpreted.

### 5.5 Build correct first, then inject the defect

Do not patch a broken component toward correct. Build a genuinely correct
implementation, prove it clean, snapshot it, then introduce exactly one defect.

This gives three things: proof the task is solvable at all, which is a hard gate;
a reference to measure every variant against; and a component that can be
reasoned about rather than a pile of patches.

On the concurrency task, patching toward correct produced a component with two
defects where one was intended, and it was only untangled by inverting the order.

### 5.6 Disclosure of an invariant is worse than disclosure of a fact

A wording that hands the solver a machine-checkable invariant collapses the task
regardless of log density. Measured: a proposed instruction sentence handed over
the residency invariant, and a six-line scan then returned exactly one candidate
from a 120,000 event log.

Density is a statistical defence. An invariant is a structural filter. It cuts
straight through any volume.

---

## 6. The gates, in order, and what each demands

Observed pipeline order as of 2026-07-27:

```
review (static + rubric) · similarity · validation · ratelimit · pass2 ·
{deep_review, adversarial_review, ava_review} · tier1 ·
qc_exec · qc_eval · qc_gate · trials · gate
```

Position varies by version. Read the live job graph with
`gh run view <id> --json jobs` rather than assuming. `gh pr checks` lists only
jobs already created.

### Static checks

Plain-text greps. The strings `tests/` and `solution/` must not appear anywhere
in the Dockerfile, **including comments**. This cost a full review cycle once.

### Rubric review

31 criteria. The three essays in `task.toml` are graded here.
`difficulty_explanation` must state data provenance (synthetic or real) and name
the real-world practitioner, in that field specifically.

### similarity

Compares your `instruction.md` against the Terminal-Bench 2 and 3 task sets, not
against your own history. Sharing a domain or technique is explicitly fine. Only
solving the same underlying problem is a duplicate.

### validation

Builds the image, runs oracle and nop. Must be 1.0 and 0.0.

### pass2

Two agent trials under a hard 3600 second budget. **This is the gate.** It needs
at least one genuine agent failure. Blocked if the agent solved both (too easy),
if both errored (timeout or infra), or if a failure looks like a task bug.

Read the Breakdown line, never the banner. The line reads: solved,
good-valid-fail, soft-timeout, task/verifier-issue, in-progress-timeout,
infra/setup-timeout, unanalyzed, avg@5.

An in-progress-timeout counts for nothing. It means the agent was still making
progress when the clock hit.

### ava_review

Fail-closed and blocks on **potential** majors with zero confirmed. Pre-empt it:

- Documented-complete search bounds, so it cannot claim the search might miss.
- A round-trip re-check in the reference before writing output.
- Descriptive message on every assert, no bare asserts.
- Type-strict verifier: require a genuine JSON int where an int is declared and
  reject strings, floats and bools rather than coercing.
- Reject outputs that are symlinks or whose realpath escapes the output dir.

A routing line reading `potential_major=N` with `confirmed=0` is a void.

### adversarial_review

Advisory, does not gate, but exits zero even on FAIL so **read the comment, not
the check status**. It attempts to construct a passing-but-incorrect submission.
On the concurrency task it found a live exploit that would otherwise have
shipped.

### qc_gate

Fail-closed, and overrules a rubric PASS. Demands the expected output be
uniquely determined by what the agent can see. Anything with two readings is
blocked as Ambiguous Rule, Missing Definition, Undocumented Requirement
Enforced, or Underdetermined Mapping, with every finding naming
`instruction.md`.

Also blocks nondeterminism: the graded data or accepted answer must not change
run to run.

### trials (pass@5)

Five attempts. Needs at least 3 valid failures of 5, with at least 1 good valid
fail as an anchor. Soft timeouts fill the count but cannot anchor. Infra voids
count for nothing.

**`cancel-in-progress: true`.** Any push while trials is running cancels it and
forfeits the read. Freeze pushes once pass2 is green.

---

## 7. The arithmetic

Gate: at least 3 fails of 5, with at least 1 anchor.

| Per-trial fail p | P(at least 3 of 5) |
|---|---|
| 0.30 | 0.163 |
| 0.40 | 0.317 |
| 0.50 | 0.500 |
| 0.5625 | 0.615 |
| 0.60 | 0.683 |
| 0.67 | 0.790 |

The band that has actually cleared is roughly 0.55 to 0.60. One axis at 0.3 to
0.4 is not enough. Two independent axes stacking to about 0.56 has cleared.

Two riders:

- pass2 runs n=2, so a p of about 0.5 clears it only about 75% of the time.
  Budget for losing one read to variance even when the design is right.
- **Every axis benched in this session came in weaker than designed.** Five for
  five. Treat any combined figure as a ceiling, not an estimate, and assume the
  next bench costs 20 to 40% of whatever it tests.

---

## 8. Design rules

**Two independent axes minimum.** Axes that lean on the same skill or the same
evidence are correlated and do not stack. Test independence explicitly: if
cracking axis 1 hands the agent axis 2, they are one axis.

**Do not count a misdirection axis.** Pattern C, version skew and stale tooling,
is insurance that does not bite. Every agent sees through it.

**Two-sided traps.** Punish the wrong rule and the crude overcorrection. A
one-sided trap gets patched by accident.

**Mutant or it did not happen.** For every intended crux, build the
one-decision-different variant and confirm it fails exactly the intended tests
and nothing else. This has killed dud cruxes and certified real ones repeatedly.

**Wrong output, never a clock-out.** A timeout counts for nothing and blocks the
read. Keep the work small enough that the difficulty is the insight, not the
volume. Pre-pay boilerplate the agent should not spend its hour on.

**Ground truth lives in `tests/`,** overlaid only at verify time. Never in
`environment/`.

**No answer reachable from the image.** Sweep the built image for every graded
constant, as ASCII and as little-endian and big-endian bytes.

---

## 9. Pre-flight checklist

Run before the first push, not after a red check. Two of three runs on one task
were lost to items already written down.

- [ ] `.dockerignore` present, mandatory once the build context is non-trivial
- [ ] No `tests/` or `solution/` string anywhere in the Dockerfile, comments
      included
- [ ] Base image is an approved digest. Run `references/check-base-image.sh`
      **with the task dir as an argument**, and confirm it discriminates by
      feeding it a bad digest
- [ ] pip pinned, `mkdir -p` for every output parent
- [ ] `difficulty_explanation` states synthetic provenance and names the
      practitioner, in that field
- [ ] Taxonomy labels validated against `references/diversity-taxonomy.toml`
- [ ] `instruction.md` under 1500 tokens, absolute paths, no time-budget line
- [ ] Zero em dashes across instruction, README and the three essays
- [ ] README replaced with a task overview before pushing
- [ ] `.gitattributes` with `* text=auto eol=lf` plus binary lines, pinned
      **before the first `git add`**
- [ ] Pre-seeded `task.toml` fields untouched
- [ ] `git ls-files jobs/` returns nothing
- [ ] Oracle 1.0 and nop 0.0, at least three times, from a real clone

---

## 10. Operational facts

**PR target.** The PR must go to `handshake-project-dynamo`, not your fork. A
PR against the fork runs no pipeline at all. Use:

```
gh pr create --repo handshake-project-dynamo/<repo> --base main \
  --head <you>:submission --title "..." --body-file PR_BODY.md
```

Confirm `isCrossRepository: true`.

**Never use `--fill`.** It takes the title and body from the commit. Use an
explicit `--title` and `--body-file`.

**`/rerun` requires write access** on the upstream org, which a contributor does
not have. The workflow runs, checks collaborator permission, and declines. The
fallback is an empty commit, which does fire the pipeline since there is no path
filter.

**Git Bash mangles leading-slash arguments.** `/rerun` became
`C:/Program Files/Git/rerun`. Use `MSYS_NO_PATHCONV=1`.

**Docker daemon flake.** Harbor reports "Docker daemon is not running" while
`docker info` works. A plain retry clears it. Do not chase it.

**Buffered background jobs lose everything on kill.** Write per-seed results to
a file and flush after each line. This cost roughly two hours across five killed
jobs in one session.

**One job at a time.** Three jobs competing for two cores produced a 98-minute
wedge and two runs with nothing to show.

**`grep -c $'\r'` silently becomes `grep -c ''`** and reports every line as a CR
line. Count CR bytes directly with `tr -cd '\r' | wc -c`.

**Windows CRLF.** Set `core.autocrlf false` and pin `.gitattributes` before any
data files exist. An extensionless entrypoint checked out CRLF has produced a
phantom mass failure.

---

## 11. Similarity and the offboarding warning

Two separate rules, often conflated.

**The automated check** compares `instruction.md` against the Terminal-Bench 2
and 3 task sets. Its stated rule: sharing a domain or technique is fine, only
solving the same underlying problem is a duplicate. It has passed every gcd task.

**The human monitoring** compares your submissions against each other and is
judged by people:

> We are actively monitoring submission success rates and the similarity of your
> submissions. If we find the same task being submitted multiple times, that
> fellow will be offboarded immediately.

The practical test: **could a reviewer describe this as the same problem as one
I have already submitted?** Same mechanism, different problem is fine. Same
problem, different dressing is not.

"Recover a modulus by gcd" is a mechanism. "Reconstruct a file from a backup
appliance's chunk store" is a problem.

Nobody has said where the human line sits. Six uses of one mechanism is a lot.
Diversify the surface, and spend a task hunting a second proven mechanism while
the reliable one is still available as a fallback.

---

## 12. Category strategy

The test that should drive the pick:

**Claim a category where the model's default toolkit is a catalogue, and the
answer needs arithmetic the catalogue does not contain.**

This is why gcd works in format and forensics surfaces and would probably fail in
Cryptography: a crypto surface primes the model for number theory, and gcd is in
that toolkit. The derivation has to sit outside what the surface primes.

**Also prefer categories where the deliverable is a computed answer over ones
where it is a repaired artifact.** Repair tasks put difficulty in the finding,
and finding is a noticing axis.

### Recommended

**File and Media Operations.** Best fit. The reflex is `ffprobe`, `ffmpeg`,
`exiftool`, PIL, and format-identification catalogues. Container and codec
formats natively carry integrity fields, frame indices and packing rules. The
deliverable is exact values plus recovered content. Untouched by this corpus.

Sub-categories, in order of preference:

1. **Audio and music processing.** Best. Codec internals are less familiar to the
   model than image formats, frame-based decoding gives exact integer answers,
   and no task in the corpus touches signal data.
2. **Image and design processing.** Same logic, slightly weaker, since image
   formats are better known.
3. **Archiving and compression.** Strongest technical fit for a recovered
   constant, since integrity fields are native and CRC32 is exactly the
   catalogue the model reaches for. But it rhymes with the chunk store task:
   both are "recover content from a container with an integrity field". Adjacent
   enough to spend later rather than now.

Avoid within the category: File format conversion and Text editing are
ETL-shaped, applying a documented mapping. Batch rename, File search and File
permissions are too thin to carry a derivation. Video Processing carries real
timeout risk.

### Also viable

**Security**, in a sub-category not yet used. Reverse Engineering and Digital
Forensics have each been used twice.

**Hardware Embedded and Low Level Systems.** Untouched, and firmware surfaces
prime for catalogues.

### Avoid

**Debugging and Repair**, for the reason in 5.3.

**Data Processing and ETL.** The retrospective's early rounds are all here and
section 10a explains why: disclosed mechanisms get transcribed and undisclosed
on-idiom hazards get dodged by trained habit.

**Machine Learning and AI**, since graded outputs tend to be models or metrics
rather than exact values, and determinacy is hard.

**Cryptography**, for the priming reason above.

---

## 13. Working method

The phase order that has produced three accepts:

**Phase 2, ideation.** Two or three competing concepts. Often skippable if one
concept is clearly strongest.

**Phase 3, proposal.** Four questions, roughly 1200 words, no em dashes. Submit
and iterate until the automated check passes. An ACCEPT with strengthening
feedback means build decisions, not a rewrite.

**Phase 4, design gate.** Author the reference, bench every crux on paper and
then in code, record the numbers. **The gate to leave is a pasted oracle 1.0
from a clean checkout plus recorded bench numbers, not a belief that it would
work.**

**Phase 5, verifier and mutants.** One pytest function per criterion group, each
docstringed, type-strict. Then the mutant matrix.

**Phase 6, Dockerfile.**

**Phase 7, instruction and task.toml.**

**Phase 8, full validation from a real clone**, not an export. The
commit-and-clone cycle is where binary and line-ending problems surface.

**Phase 9, in-chat red team.** Cold re-derive from `instruction.md` alone. Walk
all 31 rubric criteria and the six rejection causes explicitly. This phase caught
the `integrity_modulus` disclosure one hour before the push that produced 0 of 5.

**Phase 10, push and read the gates.**

### Two working docs per task, both gitignored

- `PROPOSAL_APPROVED_<name>.md`: the proposal verbatim plus the reviewer's
  verdict and strengthening items, so the build cannot drift from the approved
  concept.
- `BUILD_BRIEF_<name>.md`: the design guidance, the bench record, and every
  decision made during the build.

Both must be gitignored. They contain the crux.

### .gitignore pattern that works

```
# Local working docs: every root markdown is local-only except README.md
/*.md
!/README.md

.claude/
jobs/
```

Root-anchored, so `task/instruction.md` stays tracked and any future root doc is
covered on arrival.

---

## 14. Open thread: the page cache durability task

Repo `dynamo-656b38e-debugging-and-repair`, PR #1 against
`handshake-project-dynamo`. Blocked at pass@2.

Three pass@2 reads, all measured:

| Commit | Change | pass@2 | Breakdown | Outcome |
|---|---|---|---|---|
| 8ab0561 | as designed | 1/2 | 1 solved, 1 valid fail | cleared |
| 0ca5ca6 | verifier hardening | 1/2 | 1 solved, 1 in-progress-timeout | blocked |
| e7e13c4 | log version + quiesce sentence | 2/2 | 2 solved, 0 valid fail | blocked, too easy |

What the trajectories showed, which is the finding worth keeping:

- **All four agents derived the mechanism by reading the source in 2 to 4
  minutes.** Localization was never the cost.
- 48% to 100% of each session went to building a durability harness before any
  honest signal. One trial spent 91% of its hour correctly diagnosing what
  instrument it needed and ran out of clock before building it.
- Three of four failures were on getting the repair exactly right, not on
  finding the defect.

That inverts the design assumption. The task assumed the defect would be hard to
find. It is easy to find and moderately hard to fix precisely.

The last untested lever, and the one to try if this is resumed: the loss window
is two dispatches inside the write-back. Widening the simulated I/O yield count
was measured as roughly free in runtime and moved the loss rate for the shipped
defect, but was never swept against the **near-miss repairs**. The question is
whether a width exists where the snapshot-and-recheck family fails while the
correct reference stays clean. If it does, that is a one-constant fix with no
redesign, no new graded field, and no essay rewrite.

Assets that survive regardless: a deterministic cooperative scheduler with proven
byte-identical replay, a livelock detector (an event-based ceiling structurally
cannot see a livelock, since the signature is millions of dispatches producing
almost no events), and a validated end-state durability audit.

---

## 15. Files to carry into the next task

**Carry forward unchanged:**

- `TASK_RETROSPECTIVE.md`, the 904-line one running to section 17f, covering 8
  tasks and ending 2026-07-25. **Check this.** There are older copies in
  circulation, and the naming has been backwards: a file named `_v2` was the
  older one. Verify by checking the last section number is 17.
- `Dynamo_Reference_Rulebook_v2.md`
- `Dynamo_Workflow_Claude_v2.md`
- This handoff.

**Create fresh per task, after the proposal passes:**

- `PROPOSAL_APPROVED_<name>.md`
- `BUILD_BRIEF_<name>.md`

**Do not carry forward** any previous task's proposal or build brief. They
describe a finished task and will mislead.

**Note on the retrospective:** it does not yet include the four tasks in this
session. Sections 5.1 through 5.6 of this handoff are the new material and are
worth folding into it when there is time.

---

## 16. The first prompt for a new task

Once the repo is cloned and the docs are in place:

```
Read the retrospective, the rulebook, the workflow doc and the handoff at the
repo root, in full. New task, reuse nothing from previous repos. Confirm
.gitignore excludes every root markdown except README.md, plus .claude/ and
jobs/, then show me git status --short and git check-ignore -v on each doc.
Summarize back to me: what the handoff says stumps a frontier model, and what
it says to avoid. Do not write any task code yet.
```

Then the proposal, then the design gate. Do not let it build before the bench
numbers exist.
