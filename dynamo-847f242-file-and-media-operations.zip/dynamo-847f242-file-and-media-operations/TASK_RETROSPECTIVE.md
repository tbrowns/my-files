# Dynamo — Cross-Task Retrospective, Pitfalls & Strategy

_Local working doc. Not part of any submission (see `.gitignore`). Covers **8 tasks / ~25 pipeline runs**, ending 2026-07-25._

> **Start here if you are new to this file.** §17 is the current state of the art: the cleanest read in the
> corpus (0 solved / 5 good-valid-fail, avg@5 0.000, all 15 checks green, no difficulty pivot) and the
> section that revises §14's pattern ranking. §15 (qc_gate) and §12-§14 (the security accepts and the stump
> field guide) are the strategy. §1-§11 are the ETL case study — mine them for mechanism, not specifics.

> **⚠️ Scope and status.** This is a **historical log**, not a status board. Everything below happened on **earlier repos** — the long-running case study is `repair-order-etl` in the `data-processing-and-etl` repo. It is kept because the *mechanisms* transfer to any category, not because any of it describes current work.
>
> **Where that case study actually ended:** ACCEPTED on `4815529` (run 29374946300 — pass@5 = 2 solved / 3 good-valid anchors, avg@5 0.400, all 8 gates green), then **reopened by a second human reviewer** who judged the 3 fails too convergent on one code path and required rerun-robust hardening. §11 covers that round; its first read (run 29527291349) passed pass2 on a JSON-wedge fail and carried **zero crux signal**. So: accepted once, reopened, unresolved. §10e is superseded by §11.
>
> **How to read this file.** §1-§3 and §6-§7 are the transferable strategy: the disclosure paradox, the infra tax, and the gate mechanics. §10c and §11 are the most valuable pages — they describe the only trap family that has ever reliably worked. §0, §4, §5, §8, §9 are task-specific evidence for a ledger-ETL task; mine them for mechanism, ignore the specifics. **Anything here that contradicts the current repo's `README.md`, its `task.toml`, or a live PR bot comment is stale — the live pipeline wins.**
>
> **The one-paragraph version.** Across 4 tasks, disclosed difficulty never worked: a frontier model transcribes any rule you write down and derives any property you merely describe. Two things have ever produced genuine failures. First, **execution/engineering difficulty the spec cannot hand over** (out-of-core limits, crash and concurrency correctness). Second, and far more reliably, **protocol and lifecycle semantics whose violation leaves every output byte correct** — signals that must not fire on a skipped path, first-boot races, crash-window ordering. The gate needs ≥3 fails of 5 **with ≥1 anchor**, which one trap at p≈0.3 cannot reach; you need two independent axes that each bite the *converged, correct* design. Budget one or two reruns per real read, because roughly half of all runs have been lost to provider rate limits.

---

## 0. Scoreboard — every attempt and its true root cause

The pattern that matters is **which task _shape_ can even in principle produce a valid agent failure**, and **whether infra let us read it**.

| # | Task / commit | Shape | Verdict | Real root cause |
|---|------|-------|------------------|-----------------|
| 1 | `expand-gtfs` | single-file exact-match ETL | **2/2 solved** | disclosed conventions transcribed |
| 2 | `expand-gtfs` +interp/dedup | same | **2/2 solved** | same |
| 3 | `expand-gtfs` +UTC/DST | same | `review` FAIL | self-inflicted instruction/golden contradiction |
| 4 | `expand-gtfs` realigned | same | **2/2 solved** | same paradox |
| 5 | `ecommerce-etl` | multi-output exact-match ETL | **1/2** (fail = timeout) | the 1 "fail" was infra, not analytical |
| 6 | `ecommerce-etl` +dedup +outlier | same | **2/2 solved** | composed disclosed rules still transcribed |
| 7 | `resolve-contact-graph` `f9c1b68` | **out-of-core** entity resolution | `pass2` PASS, `trials` FAIL | **verifier OOM'd itself** (task/verifier defect) |
| 8 | `resolve-contact-graph` `5ebdb7d` | same | `pass2` 0/2 both `RateLimitError` | **infra void** (rerun) — strongest difficulty signal seen (agents OOM'd 2–3×, burned 60 min) |
| 9 | `resolve-contact-graph` `7d45c18` | same | `pass2` 0/2 both `RateLimitError` | **infra void** (rerun) |
| 10 | `resolve-contact-graph` `30d6c43` | same | **`pass2` 2/2 solved** | too-easy at 12M — model solves out-of-core CC within the hour → pivot |
| 11a | `repair-order-etl` `0c74bae` | crash-safe concurrent ledger repair | `review` FAIL (`no_extraneous_files`) | pivot left 2 stray files; `git rm` fixed |
| 11b | `repair-order-etl` `f89353f` | same | **`pass2` 2/2 solved, "too easy"** | one global flock made the whole surface robust-by-construction |
| 11c | `repair-order-etl` `ce056a4` (concurrency hardening) | same | `review`+`pass2` PASS; **`trials` pass@5 FAIL** | **5/5 infra void** (OpenRouter) — 0 signal |
| 11d | `repair-order-etl` `63cc4b1` (rerun) | same | **pass@5 = 3 solved / 2 fail** | **CLOSEST EVER** — 2 clean-anchor fails; gate needs 3; one short |
| 11e | `repair-order-etl` `118777e` (+stale-clobber CAS test) | same | **pass@5 = 4 solved / 1 fail** | CAS test fired on **nobody** (disclosed invariant transcribed); only the stale-repair self-test blind spot bit |
| 12 | `repair-order-etl` `182930f` (+multi-file `customer_totals` + exact-int trap) | **multi-file** exact-match | `review`+`pass2` PASS; **`trials` pass@5 = infra void** | **4/5 OpenRouter `RateLimitError`**; 1 trial ran and solved 29/29 → **no difficulty read** |
| 12b | `repair-order-etl` `a77495a` (run 29235719274) | same | **`pass2` FAIL — 0 valid of 2** | **NOT infra: both trials in-progress-timeout.** The 5-module rewrite + publication scaffolding no longer fits the hard 3600 s cap. Trial 1: full rewrite, died mid-fix of a self-inflicted f-string SyntaxError (`state_store.py:248`). Trial 2: **28/29**, one-word typo `_STAGED_COLUMNS` vs `_STAGE_COLUMNS` in the intra-batch-duplicate `IntegrityError` branch, cut mid-generation. Both `low_timeout` FAIL → **labor regression, not difficulty signal** |
| 13 | `repair-order-etl` `7ff81a3` (starter pre-pays atomic publication) | same | `review`+`pass2`+`deep_review` PASS; **`trials` pass@5 = 4/5 solved, 1 anchor → "not hard enough"** (run 29288540489) | **First fully-clean read ever: 0 infra, 0 timeouts, all 7 trials graded** (`low_timeout` PASS ×7 — the labor fix worked). Both fails were the **stale-repair blind spot**: pass2's = hardlink-inode aliasing (`os.link` → `write_bytes` corrupts both → `_same_file` skips repair), pass@5's = symlink-target generation encoding (in-place corruption leaves symlink intact → CAS skips). **SQL `SUM` overflow trap fired on NOBODY** — all 5 pass@5 agents summed with Python ints; the disclosed "may exceed signed 64-bit" line was transcribed, even with `SUM` shipped in the starter |
| 14 | `repair-order-etl` `ce6a32b` (+3 independent traps: output-dir hygiene, concurrent-identical TOCTOU, after_metrics_replace crash) | same | **`review` Stage 2 FAIL — infra void** (run 29307194747) | **NEW infra flavor: Anthropic 429 on `claude-opus-4-8`** in the *Stage 2 rubric review* step (not OpenRouter, not trials). "rate limit of 13,000,000 input tokens/min" → `no verdict produced` → gate red. Static checks (Stage 1) PASS; pass2/similarity/validation/deep_review/trials never ran (all downstream of gate). Sticky "Automated Review" comment is **stale** (still shows 29 tests / line 730). **Traps unaffected** — local matrix still oracle 32/32, starter 21F/11P, 3 variants isolate cleanly. |
| 14-rerun | `repair-order-etl` `83d8bb6` (empty-commit rerun of 14) | same | **`review` Stage 2 FAIL — infra void AGAIN** (run 29307720499) | Same org key `4f8bcc30…`, `claude-opus-4-8`, but a **different limit**: "20,000 **requests** per minute" (vs 13M tokens/min before). Two reruns ~12 min apart both voided → the org key is **saturated by external load** (shared project-paid key, many concurrent Dynamo reviews), our one review call is collateral. **LESSON: rapid empty-commit reruns do NOT clear an org-wide Anthropic 429 — they land in the same saturated window and waste a push. Wait hours, not minutes, and/or escalate to a Dynamo admin in Slack (precedent: thread on `dynamo-4d2faae`).** Do NOT change the task. |
| 14-rerun2 | `repair-order-etl` (pending) | same | **SCHEDULED** — one-shot cloud routine `trig_01W2VkGwCLAQL8XFsRqcGKCj` fires **2026-07-14T09:20Z (12:20 PM EAT)** | Deliberately spaced ~4 h out (not another rapid retry) to let the org Anthropic window clear. Cloud agent (sonnet-5) pushes **one** empty commit to `submission`, then reads the new run's Stage 2 `review / review` job and reports whether the 429 cleared; instructed to push once and NOT retry on another void. Result lands in the cloud session (https://claude.ai/code/routines/trig_01W2VkGwCLAQL8XFsRqcGKCj), not the local session. Required a one-time GitHub connect (`/web-setup`) — the routine API 401s without it. ⚠ 09:20Z is mid-morning EU working hours = still likely-high review load; if it voids again, re-arm for a genuinely quiet UTC window and/or escalate. |
| 14-read | `7e61f70` (routine's empty commit; content = `ce6a32b`) — run 29321434451 | same (32 cases) | **`trials` pass@5 = 5/5 solved, avg 1.000 → "no anchor fail"** | The spaced routine rerun **cleared the 429** (mechanism works). First clean read of §9's Traps A/B/C: **fired on nobody at pass@5** (pass2 did pass with ≥1 counted fail; detail lost — sticky overwritten by later runs). Disclosed hygiene/TOCTOU surfaces transcribed like every disclosed rule before them |
| 15 | `197a6b5` (+`35a7c05` LF pin, no content change) — read via `bca5210`, run 29347978990 | deeper multi-contract repair, 32→37 cases (staging/writer-lock races, staged-ID TOCTOU, WAL first-open bootstrap, slow-reader coherence, crashed-newer fencing, in-place repair variants; Trap A + `after_metrics_replace` dropped with their contracts) | `pass2` **1/2** (symlink-**target** generation encoding — `task__R6WPKHg`); **`trials` pass@5 = 5/5 → "no anchor"** | Every added contract was **disclosed → transcribed**; the 12b labor fear did **not** recur (0 timeouts — agents complete ~600-line rewrites in ~44-55 min now). En route: **3× Anthropic-429 Stage-2 voids** (14:21 `197a6b5` run 29340009056, 14:43 `7db33ac` 29341862447, 15:14 `35a7c05` 29344194932) — 22/31-min gaps both re-voided; ~49-min gap cleared |
| 16 | `0e9a2b4` (de-disclosure: drop the SUM-overflow warning + "don't load event-ID set" prescription) — run 29368019041 | same | **`pass2` 2/2 solved → blocked before `trials`** | **Weights beat prose:** one agent (`task__MBK3zvp`) *explicitly identified the int64 SQL SUM overflow risk in its own step-13 reasoning* with the warning removed. `task_specification` stayed PASS ×2 → de-disclosure is **safe but insufficient**: disclosed mechanisms get transcribed, disclosed *properties* get derived, undisclosed on-idiom consequences get dodged by trained habit |
| 17 | `4815529` (stdlib-betrayal round: two-layer timestamp cases, hook-on-skip probes, BOM, scalar-value surface) — run 29374946300 | same (37 cases) | **✅ ACCEPTED** — `pass2` **1/2** (WAL first-open bootstrap race: `busy_timeout` instead of pre-connect flock — `task__KMsv7Uk`); **`trials` pass@5 = 2 solved / 3 good-valid anchors, avg 0.400**; all 8 gates green | **All three pass@5 kills = one blind spot: unconditional `reach('after_orders_replace')` on the stale-generation skip path** (2× unchecked return, 1× retry-loop re-render past a `>` fence). One agent (`task__bF9mFjF`) *predicted the bug in its own reasoning and shipped it anyway*. The strptime/BOM cruxes went untouched. Two independent axes (hook precision + WAL bootstrap) stacked to **4 analytical fails / 7 trials ≈ p 0.57** |
| 18 | stale-fence hardening round (2026-07-16, this session) | deeper publication protocol, 37→39 cases | **PENDING** — second reviewer rejected the accepted state ("pass@5 2/5 w/ 3 valid fails" needs rerun-robustness), prescribed Situation-C hardening of the same crux | All 3 prior kills converged on one path; reviewer wants the crux to survive a rerun. Implemented: stand-down/equal-retry instruction sentence, per-file fenced swaps in reference, `after_metrics_replace`+`after_publish` disclosed, graded races (a) untouched-bytes+mtime+markers, (b) equal-gen crash resume must signal, (c) mid-set fence with per-phase gating. See §11 |

**Two headline facts:**
1. **Difficulty:** attempts 1–6 (single-file / multi-output exact-match) never produced a valid fail. Attempts 7–12 (execution-hard shapes) did make the model struggle, and 11d got within one fail of the hardest gate.
2. **Infra:** at least **4 runs (8, 9, 11c, 12)** were voided by OpenRouter `gpt-5.4` rate limits before the verifier could score them. **You cannot read difficulty through an infra void — budget 1–2 reruns per real read.**

---

## 1. Wall A — the disclosure paradox / structural difficulty ceiling

Dynamo's gate needs **≥1 _valid_ agent failure** (genuine difficulty — not spec ambiguity, not verifier bug, not infra). A clean solve = "too easy" = blocked.

**The paradox (proved 8+ times):** exact-match verification *forces* full disclosure — every convention must be written into `instruction.md` or a correct-by-domain solution mismatches the golden (which is judged a *task bug*, and also blocks). But **once a rule is on the page, the frontier model transcribes it.** Difficulty that lives in a *convention* evaporates under the disclosure exact-match requires.

**Corollaries earned the hard way:**
- **Composition doesn't save it.** Stacked interacting rules (dedup-before-filter, iterative outliers, event-ordering joins, day-first dates) were all composed correctly — one trial even wrote a post-hoc audit script to self-check.
- **Genuine computation doesn't save it.** The GTFS DST "noon−12h" footgun was implemented correctly *and* the model authored synthetic DST tests before finishing.
- **A local "bite" ≠ difficulty.** Every hardening round mechanically worked locally (a naive/old solution failed the new fixture). All were solved anyway. A local bite proves the tests **discriminate**, not that the **frontier model fails** — the frontier model is never the naive solver.
- **Rule of thumb:** _if a competent engineer could one-shot it from the spec in <20 min, so will the model._

**What DOES survive disclosure (the only things that have ever bitten):**
1. **Execution/engineering under a hard limit** the spec can't hand over (out-of-core CC; crash/concurrency correctness).
2. **Self-test blind spots** — a requirement that is easy to implement subtly wrong AND easy for the agent's *own* verification to miss. This is the mechanism behind every `repair-order-etl` fail so far (see §4).
3. **Discovered implementation pitfalls** where the *rule* is disclosed but the *trap* is not obvious and small self-tests don't trigger it (e.g. SQLite `SUM` overflow — §5).

---

## 2. Wall B — infrastructure voids (the OpenRouter rate-limit tax)

**This has cost us as much as the difficulty problem.** Model A in trials = **`openrouter/openai/gpt-5.4`** in region `eastus2`. When OpenRouter rate-limits/there is capacity exhaustion, trials die with `litellm.RateLimitError`/`APIError` **before any code is written or the verifier runs**. These classify as `infra/setup-timeout` and **cannot anchor or fill** — the run yields **zero** difficulty signal.

- **Voided runs:** 8, 9, 11c (5/5), and 12 (4/5). Roughly **half** of all runs have been rate-limit-affected.
- **Second void surface (new, run 14):** the **Stage 2 rubric review** also calls an LLM — the **Claude CLI on `claude-opus-4-8`, project-paid via the `ANTHROPIC_API_KEY` org secret** — and hit an **Anthropic 429** ("rate limit of 13,000,000 input tokens/min", org `4f8bcc30…`). The step produced `no verdict produced` → `report.sh` exit 1 → **gate red before `pass2` even starts**. Distinct from the OpenRouter/trials tax: different provider, different model, different pipeline stage. Same remedy (rerun), but note this one is **org-token-budget** driven, so back-to-back pushes can re-trigger it; space reruns out. Tell it apart from a real content FAIL by (a) the job log 429, and (b) the sticky "Automated Review" comment staying **stale** (a real FAIL rewrites it with blocking bullets).
  - **Rerun mechanics that work:** since rapid retries just re-hit the saturated window (proved by 14-rerun), **schedule a spaced rerun instead of hammering.** Mechanism used: a one-shot claude.ai cloud routine (`/schedule` → `RemoteTrigger` create with `run_once_at`) that pushes a single empty commit and reads back Stage 2. Gotchas: (1) the routine API **401s unless GitHub is connected** for the account (`/web-setup` fixes it); (2) minimum cron interval is 1 h, but one-shots are exact; (3) the cloud agent reports into its own session, not the local CLI — check the routine URL for the outcome. Standing routine for this: `trig_01W2VkGwCLAQL8XFsRqcGKCj`.
- **Secondary, related failure — the "oversized-JSON-blob wedge":** `gpt-5.4` under `xhigh` reasoning sometimes emits its **entire module rewrite as one giant JSON `keystrokes` blob** → harness "No valid JSON found in response" → retries → burns the full 3600 s → dies with **0 lines of code written**. Seen in 11d (`task__9BNEqQu`), and 12's pass2 (`task__j9eyNM9`, which had *correctly diagnosed all six defects* first). This is an **agent-harness interaction artifact**, not analytical difficulty; it is partly correlated with the capacity crunch. It has been classified inconsistently (sometimes good-valid-fail, sometimes timeout).
- **Mitigation:** (1) treat any run with ≥1 `infra/setup-timeout` as **provisional**; (2) **rerun** (empty commit to `submission` — this is a fork, so `gh run rerun` returns 404; only a push re-fires `pull_request_target`); (3) if repeated, flag an admin in Slack (there is a known thread on task `dynamo-4d2faae`); (4) never change the *task* in response to an infra void — it confounds the next read.

---

## 3. The gates, precisely (this is subtle and cost us reads)

The pipeline runs on `pull_request_target` on the `submission` PR. Stages: `review` (static) · `similarity` · `validation` (docker/oracle/nop) · `pass2` · `deep_review` · **`trials` (pass@5)** · `gate`. **All must be green.**

### `pass2` (2 trials) — lenient
- Gate: **≥1 valid fail of 2.** One clean analytical fail (or, historically, a qualifying timeout-wedge) passes it. We pass this now.

### `trials` = `pass@5` (5 trials) — strict, and the real bar
- Gate: **≥3 fails total AND ≥1 "good valid fail" (anchor).**
- **Anchor = "good valid fail"** = a **clean reward-0** (analytical wrong/failed output) **OR** a **stuck-timeout with `approach_validity != FAIL`**.
- **Fill vs anchor:** a **soft-timeout** can *fill* the ≥3 count but **cannot anchor**. An **`infra/setup-timeout` counts for nothing** (neither fills nor anchors).
- **Breakdown taxonomy** (per the sticky comment): `solved · good-valid-fail · soft-timeout-fail · task/verifier-issue · in-progress-timeout · infra/setup-timeout · unanalyzed · avg@k`.
- **KEY BIND (Slack, task `dynamo-4d2faae`): in-progress / soft timeouts do NOT count as valid fails.** So hardening by raw scale is dangerous: bigger N tends to produce **timeouts (uncounted)**, not wrong output. **To count, a harder failure must produce WRONG/graded output, not a clock-out.**

**Implication:** `pass@5` needs the frontier model to **fail a majority-ish (≥3/5)** of the time with *wrong output*. That is a very high bar for a fully-disclosed exact-match task where a clean correct design exists.

---

## 4. The current task in full — `repair-order-etl`

Repair a crash-safe, concurrent, **incremental** order-event ledger ETL. Entry `/app/bin/process-orders <batch.jsonl…>`. SQLite (`/app/state/ledger.db`) is the authoritative ledger; three public files are derived from it.

### Disclosed invariants (all in `task/instruction.md`, 1111 tokens < 1500 gate)
- **Immutable event identity:** `event_id` is one immutable effective event; exact replay is a no-op; conflicting reuse is invalid → nonzero exit + full rollback.
- **Total-order winner:** per order, greatest `(version, event_time, event_id)` wins — `version` **numeric**, strings by **Unicode code-point**.
- **Durable tombstones:** a winning delete persists as a tombstone (absent from CSV, not undone by older, superseded by strictly newer upsert).
- **All-or-nothing** across all files in one invocation; unreadable/invalid/blank/conflict → nonzero exit, last-good snapshots unchanged.
- **Convergence:** repeated/overlapping/reversed/late batches converge.
- **Fine-grained concurrency:** disjoint invocations make **independent progress** — no lock may serialize an unrelated invocation across the slow publish; concurrent result = some serial order.
- **Generation-monotonic, atomic, self-repairing publication:** each published set reflects one committed generation; a public file is **never** replaced with an older generation than one already published; files are never observably torn/partial; every successful run (incl. duplicate-only) **repairs missing or stale** snapshots; crash may leave adjacent generations → later run reconciles all.
- **Streaming:** never load the complete historical event-ID set into Python memory.
- **Hook protocol** (test rendezvous): phases `ready_to_apply`, `after_db_commit`, `after_orders_header`, `before_publish_swap`, `after_orders_replace` via `ORDER_ETL_HOOK_DIR/ID/PAUSE_AT/FAIL_AT`.

### Three normative outputs
- `orders.csv` — live winners, header `order_id,version,event_time,event_id,customer_id,status,amount_cents`, code-point sorted, UTF-8/no-BOM/LF/minimal-quoting/base-10.
- `metrics.json` — compact, fixed key order `active_orders,delete_events,deleted_orders,unique_events,upsert_events`.
- **`customer_totals.csv` (NEW in 12)** — per customer owning ≥1 live order: `customer_id,live_order_count,total_amount_cents`, code-point sorted. Order attributed to its **winner's** customer (moves across versions); tombstones excluded; **total is an exact integer that may exceed signed 64-bit**.

### Reference architecture (`task/solution/ledger_etl/`)
- `state_store.py`: short `BEGIN IMMEDIATE` admit txn (write lock released at commit); `UNIQUE`/`ON CONFLICT` admission; winner CAS; persistent counters + **monotonic `generation`** + durable `published_generation`; `iter_live_orders()` streamed; **`iter_customer_totals()` streams live orders in customer order and sums with Python big-ints** (SQLite `SUM` raises on overflow, `TOTAL` is lossy — verified in-container).
- `snapshot.py`: lock-free render of all three files to candidates from one consistent read snapshot; `reach("before_publish_swap")` after the read-txn releases; brief `flock` critical section does **generation compare-and-swap** then atomic `os.replace` of each file (+`fsync`), skipping if superseded.
- `processor.py`: `ready_to_apply` → admit txn → `after_db_commit` → `publish(store)`.

### The discriminators, and which cohort each bites
| Test | Targets | Cohort it bites | Observed |
|---|---|---|---|
| `test_duplicate_run_rebuilds_missing_and_stale_outputs` | stale/missing snapshot repair | agents who **optimize staleness detection** (inode/hardlink, size, existence) and self-test with `unlink()`+write (new inode), missing the verifier's in-place `write_bytes` (same inode) | **the only thing that has ever bitten** — 2/5 (11d), 1/5 (11e) |
| `test_stale_publisher_does_not_clobber_newer_generation` (11e, CAS) | generation CAS-skip branch | agents who drop the CAS | **fired on nobody** — disclosed invariant (`instruction.md`) transcribed |
| `test_customer_totals_use_exact_integer_arithmetic` (12) | exact big-int sum vs SQL `SUM`/`TOTAL` | **majority** — anyone using the obvious SQL aggregation | **untested by pass@5 (infra void)**; ⚠️ 1 pass2 agent flagged "SUM overflow" on inspection |
| `test_order_amount_follows_winning_customer` (12) | customer-move + tombstone in a derived aggregate | incremental-maintenance cohort | untested (infra void) |

**The structural ceiling, stated plainly:** a clean correct design exists — **SQLite `published_generation` counter + unconditional re-render from the current-state table + Python-int aggregation** — and it is fairly obvious. When the frontier model finds it (60–80% of trials) it passes *everything*. The only fails come from cohorts that take a plausible shortcut and don't self-test the corner. So the fail rate ≈ the fraction of trials that pick a trap-prone shortcut. The `customer_totals` overflow trap was added specifically because it bites **anyone using SQL `SUM`/`TOTAL`** (the obvious choice), not just a niche shortcut — the hope is to lift that fraction above the ≥3/5 line. **We have not yet gotten a clean read to confirm it.**

---

## 5. Calibration data (clean reads only; infra voids excluded)

| Run | Commit | Solved | Fails | Fail type(s) | Gate |
|---|---|---|---|---|---|
| 29205457738 | `63cc4b1` (11d) | 3 | **2** | both anchors, both stale-repair (one inode-alias, one JSON-wedge) | short by 1 |
| 29213227212 | `118777e` (11e) | 4 | **1** | 1 anchor, stale-repair inode-alias; CAS test caught no one | short by 2 |
| 29226016128 | `182930f` (12) | 1 | (4 infra) | **VOID** — 4× `RateLimitError`, 1 solved 29/29 | no read |
| 29288540489 | `7ff81a3` (13) | 4 | **1** | 1 anchor, stale-repair (symlink-generation); companion pass2 fail = stale-repair (hardlink-inode); **overflow trap: 0 hits of 5** | short by 2 |
| 29321434451 | `7e61f70`≡`ce6a32b` (14-read) | 5 | **0** | §9 Traps A/B/C: 0 hits at pass@5 | blocked — no anchor |
| 29347978990 | `bca5210`≡`197a6b5` (15) | 5 | **0** | companion pass2 fail = symlink-**target** repair (stale-repair family, 5th distinct variant) | blocked — no anchor |
| 29368019041 | `0e9a2b4` (16) | (2/2 at pass2) | — | de-disclosure alone moved nothing; agent self-flagged SUM overflow unprompted | blocked at pass2 |
| 29374946300 | `4815529` (17) | 2 | **3** | **all 3 anchors = hook-precision** (`after_orders_replace` fired on stale skip); companion pass2 fail = WAL first-open bootstrap race | **✅ ACCEPTED** (avg@5 0.400) |

**Variance is large and adverse:** across the two clean reads, per-trial analytical-fail probability sits around **p ≈ 0.2–0.4**, so P(≥3 of 5) ≈ **16–32%** by variance alone — a plain rerun is low-EV. The `customer_totals` overflow trap is the first change targeting the **majority** rather than a shortcut cohort; its effect on p is **unmeasured** because run 12 was infra-voided.

**Verification status of run 12's change (all in the `ledger-env` container):** reference **29/29**; a variant identical except using SQL `SUM` fails **only** the exact-integer case (clean `integer overflow`, not a timeout); broken starter fails **18/29** incl. both new cases; **5× no flake** on the new + concurrency surface; instruction 1111 tokens. `review`/`pass2`/`deep_review` all green → **no task/verifier defect introduced.**

---

## 6. Pitfalls (strategy · engineering · harness)

### 6a. Strategy
- **Adding another disclosed rule never moves `pass@k`.** Done ~6× on ETL tasks and again with the 11e CAS test. Disclosed → transcribed. Stop doing this.
- **A local bite proves discrimination, not difficulty.** Necessary, not sufficient.
- **A 1/2 or 2/5 that's timeouts/infra is not progress** — only *analytical wrong output* counts. Engineer timeouts/infra out before reading the signal.
- **After any instruction edit, re-diff instruction ↔ solution ↔ tests** for contradictions (attempt 3 self-inflicted an ambiguity fail).
- **After a task pivot, sweep `solution/` and `environment/` for stray files** — the review gate hard-fails on any unreferenced file (attempt 11a).
- **Solution labor is a budget item (learned 12b).** Every added artifact/invariant inflates the required diff; at ~600 lines of rewrite the attempt no longer fits the 3600 s cap and yields **in-progress timeouts (uncounted)**. When hardening, pre-pay non-crux boilerplate in the *starter* instead of letting total labor grow — difficulty must live in the traps, not in typing volume.

### 6b. Out-of-core engineering (task 3 — kept for reuse)
- In-memory DuckDB `TEMP TABLE` ignores `memory_limit` → **file-backed DB + `CREATE OR REPLACE TABLE`**.
- `row_number() OVER (ORDER BY id)` = a full 12M sort (475 s, 1.8 GB) → `OVER ()` (no sort); components are numbering-invariant.
- `array_agg(DISTINCT)`/grouped join over ~8M groups peaked 2.24 GB → **streamed NumPy** (`np.minimum.at`/`bincount`/`bitwise_or.at`).
- Verifier stacked its golden peak on top of `pq.read_table` of the agent output → OOM. **Free golden arrays, then stream agent output in batches (`iter_batches`+`searchsorted`).** Peak 2 GB → 1157 MB.
- **"exit 0 locally" ≠ "fits in CI"** — measure **peak RSS (`ru_maxrss`)**, target a large margin.

### 6c. SQLite specifics that matter here
- **`SUM(int)` RAISES `OperationalError: integer overflow`** past int64; **`TOTAL()` returns a lossy float.** Exact big-int aggregation must be done in Python. (This is the run-12 majority trap.)
- **Rollback-journal, not WAL:** `publish()` holds a SHARED read lock from `read_snapshot()` until `commit()`, so a reader parked mid-render **blocks a concurrent writer's commit** (SHARED blocks EXCLUSIVE). This is why the stale-clobber test needed a *new* hook (`before_publish_swap`) **after** the read-txn releases, not the existing `after_orders_header` (which would deadlock the peer).
- `WITHOUT ROWID` + `ORDER BY … COLLATE BINARY` gives code-point order (SQLite default TEXT collation is already BINARY).

### 6d. Harness gotchas (Windows box, Docker works)
- Prefix docker **mount** commands with `MSYS_NO_PATHCONV=1`; but **do NOT** set it for `docker build <context>` (mangles the context path → "path not found") nor for native-Windows `python`/`cp` on `/c/...` paths (they need `C:\...`).
- Windows working tree has **CRLF** on extensionless entrypoints like `bin/process-orders` (repo index is LF, fine for CI) → hit `/usr/bin/env: python3\r`. **Obsoleted by §10d:** pin `* text=auto eol=lf` in `.gitattributes` from day one and the `sed 's/\r$//'` workaround is unnecessary. Note `*.sh` alone is not enough — extensionless scripts still check out CRLF.
- Building a discriminator variant by string-splicing a method: **splice to the _next_ `def`**, or you silently delete later methods (I once nuked `published_generation`/`mark_published` → false 28/29 failure).
- `gh run rerun` returns **404** (fork lacks actions-write) → rerun only by pushing (empty commit) to `submission`.

---

## 7. Decision framework (HISTORICAL — written at run 12; the "immediate" action below is ~6 runs obsolete)

> Kept for the *shape* of the branching logic and for the difficulty-axis ranking at the end, which is still the best summary of what to try first. The specific instruction to "rerun `182930f`" was resolved long ago; see §9-§11 for what actually happened.

**Immediate (run 12 was infra-voided):** **RERUN** `182930f` (empty commit). This is the correct move for an infra void — the multi-file/overflow change is Docker-verified and defect-free but **unread**. Do not make another task change on top of an unread run; it confounds the signal. Expect a ~30% chance the rerun itself hits another rate-limit void; budget 1–2 reruns.

**Then, conditioned on the first clean `pass@5` read of run 12:**
- **If ≥3 fails with ≥1 anchor → ACCEPTED.** Done.
- **If the overflow trap bit but total < 3** (e.g. 2 fails) → we are close; the trap works on the SQL-`SUM` cohort but the majority summed in Python. Add a *second* majority trap that also survives disclosure (candidates below), or broaden the stale-repair corruption variants to lock in the shortcut cohort as fill.
- **If the overflow trap fired on nobody** (the model reliably sums in Python — the pass2 n=1 diagnosis is a yellow flag) → the exact-integer axis is transcribable too; escalate to a genuinely non-disclosable axis.

**Difficulty axes ranked by how reliably each defeats a frontier model** (evidence + research):
1. **Long-horizon / multi-file debugging of a larger codebase** — a subtle, *discovered* defect graded on a hidden behavioral outcome. Targets the documented Verified→Pro cliff (single-file ~70% → multi-file/real ≤23%). Strongest; biggest build. (Run 12 is a *step* toward this — a coupled third artifact — but still a fully-disclosed repair.)
2. **Self-test blind spots at scale** — requirements easy to implement subtly wrong AND easy for the agent's own tests to miss (inode-aliasing, `SUM` overflow, customer-move aggregates). This is the vein that has actually produced fails here; **stack several independent ones** so P(all correct) drops below the ≥3/5 line.
3. **Out-of-core / resource-bounded execution** — proven to bite (task 3) but calibration is delicate and scale tends to yield **timeouts (uncounted)** unless engineered to yield *wrong output*.

**Do NOT** return to any single-file, fully-specified, exact-match, short-horizon ETL — that shape failed to bite 6× across 2 tasks.

**Candidate second/third majority traps if run 12 comes back close (all survive disclosure, all yield wrong output):**
- Broaden `test_duplicate_run_rebuilds_missing_and_stale_outputs` to defeat **every** staleness shortcut: in-place corruption preserving inode **and size**, mtime-newer-than-DB, single-file-stale-while-other-fresh. Locks in the shortcut cohort as reliable fill.
- A metrics/aggregate that requires **exact ordering of floating edge cases** or **big-int** elsewhere.
- A crash/recovery corner that requires reconciling the **third file** specifically (already partly covered — `customer_totals` now flows through the CAS/crash/stale machinery).

---

## 8. Reusable Docker harness

**The pattern generalizes to any task; the names below are from the ledger case study.** Build one image from `task/environment`, then **mount** `solution/` + `tests/` read-only rather than baking them, so reference and variant checks need no rebuild — only `environment/` changes require `docker build -t <img> task/environment`. Case-study counts (29/29 etc.) were valid at that revision only; the suite later grew to 39.

```bash
# reference full suite (substitute your own repo path, image name and expected count)
export MSYS_NO_PATHCONV=1
ROOT=/c/Users/ADMIN/Desktop/<your-dynamo-repo>/task
docker run --rm -v "$ROOT/solution:/solution:ro" -v "$ROOT/tests:/tests:ro" -v "$ROOT/environment/bin:/envbin:ro" \
  ledger-env bash -c '
    set -e
    cp /solution/ledger_etl/*.py /app/ledger_etl/
    sed "s/\r$//" /envbin/process-orders > /app/bin/process-orders; chmod 0755 /app/bin/process-orders
    pytest -q -p no:cacheprovider /tests/test_outputs.py 2>&1 | tail -20'
```
For a **discriminator variant**: copy `solution/` to scratchpad, edit one method, mount that dir as `/solution`. For the **starter**: omit the `cp` (uses the baked-in broken baseline). **Always** stress new concurrency/repair tests 5× for flake; **always** confirm a wrong variant fails **only** the intended test(s) and via **wrong output**, not a timeout.

**Resources used in that case study:** verifier 600 s · agent 3600 s (hard cap; a configured 7200 was ignored) · build 1800 s · cpus 2 · memory 2048 MB. Trial model observed at the time: `openrouter/openai/gpt-5.4` (`eastus2`) — **verify per run rather than assuming**, and note the pre-seeded `model_tested` label does not track it.

---

## 9. Addendum 2026-07-14 — run 13 (`7ff81a3`): cut labor, keep traps

**What 12b changed in the picture.** `a77495a`'s pass2 was the first read where the blocker was neither infra nor difficulty but **solution volume**: both agents converged on the correct architecture (staged admission, generation CAS, Python-int totals — i.e. the disclosed rules transcribed, as always) and still clocked out, because a wholesale 5-module rewrite + inventing the candidates/`os.replace`/generation-dir scaffolding + ad hoc concurrency harnesses ≈ 65–75 min > 60. Per §3, clock-outs count for nothing — worse than a solve, because pass2 blocks before `trials` even fires.

**The fix (only `environment/ledger_etl/snapshot.py` touched, +21/−5):** starter now renders all three files to `tempfile.mkstemp` candidates and swaps with `os.replace`, hooks at the instruction-defined phases. Nothing graded moved: no consistent read view (fresh conn + `fetchall`), no generation/CAS/lock (stale clobber intact), `if processed:` still gates publish (repair defect intact), `deleted_orders: 0` hardcode, **SQL `SUM`** totals, and all `state_store`/`processor`/`models`/`parser` defects untouched. Container re-verify: oracle **29/29**, starter **18F/11P** — same split, same categories (sigkill-torn test now fails via the repair defect instead of the torn file; fine).

**Why this should *help* the fail rate, not just completion:**
- The starter **hands the agent the SQL `SUM` trap as existing code**. A minimal-diff repairer keeps the aggregation; small self-tests never overflow int64. This is the §1.3 "discovered pitfall" mechanism at its best — the trap is now the *default*, not just the obvious choice.
- Smaller diff → less exposure to the oversized-JSON-blob wedge (§2) and to self-inflicted syntax/typo noise (both 12b deaths were unforced errors in bulk-emitted code).
- The stale-repair blind spot (§4's only proven biter) is untouched.

**Risk:** pre-paying scaffolding anchors the clean design harder → p(solve) up. If pass2 comes back **2/2 solved ("too easy")**, do NOT re-inflate labor; escalate trap density per §7: broaden stale-repair corruption variants (in-place same-inode+same-size, mtime-newer, one-file-stale), and/or a second majority trap.

**Decision tree for run 29288540489:**
- pass2 ≥1 valid fail → `trials` fires → read against the §5 calibration (need ≥3/5 fails + ≥1 anchor). First-ever clean read of the `customer_totals` traps.
- pass2 2/2 solved → too-easy branch above.
- pass2 infra void / wedge → rerun (empty commit), per §2. Budget 1–2 reruns.
- Any in-progress-timeout recurrence → labor is *still* too high; next candidates to pre-pay: starter emits correct-but-unconditional publish on duplicate-only runs (keeps repair trap? NO — that would delete the only proven biter; instead trim the parser/schema surface or pre-create the `stats` table shell without semantics).

**OUTCOME (read 2026-07-14, run 29288540489): pass@5 = 4 solved / 1 anchor → blocked "not hard enough" (need ≥3).**
- **The labor thesis is fully confirmed:** 0 infra, 0 timeouts, `low_timeout` PASS on all 7 trials, pass2 job 42 min (vs 68+ before). Every trial now produces graded output — the read is finally clean. Do not touch labor again.
- **Trap scorecard:** stale-repair blind spot bit **2 of 7** (pass2 hardlink-inode + pass@5 symlink-generation) — still the *only* thing that has ever bitten, now via a third and fourth distinct shortcut variant. **SUM-overflow fired on 0 of 5** even with `SUM` shipped in the starter: all five summed in Python. §7's third branch is now proven — **the exact-integer axis is transcribable**; the disclosed one-liner beats the inherited code. Same for CAS/tombstones/versioning: 5/5 transcribed the whole disclosed surface (all converged on WAL + PK + generations table + fcntl + temp/rename, near-identical designs).
- **Calibration:** clean-read per-trial analytical fail p = 2/5, 1/5, (1/2+1/5) ≈ **0.2–0.4, dominated by the single stale-repair axis**. To clear ≥3/5 needs p ≥ ~0.6 → **one axis cannot get there; independent blind spots must stack** (e.g. 3 independent traps at p≈0.25 → P(≥1 hit) ≈ 0.58 per trial; at 4 → ≈0.68).
- **Next move (§7 axis 2, escalated):** keep the stale-repair family (it works), and add **2–3 genuinely independent self-test blind spots** — non-disclosable implementation pitfalls where the agent's own tests pass. NOT more disclosed rules, NOT bigger N, NOT labor. Candidates must each be verified to (a) bite a *plausible majority/large-cohort* implementation choice, (b) yield **wrong graded output** (not a timeout), (c) be invisible to small self-tests.

**IMPLEMENTED + CONTAINER-VERIFIED (2026-07-14, uncommitted): three traps on independent axes (29 → 32 cases).**
- **Trap A — output-directory hygiene** (publication axis, new): disclosed as "`/app/output` holds exactly the three public files after any successful invocation". Enforced in *every* `assert_outputs` (directory inventory) + a dedicated kill-mid-render test. Bites candidates-rendered-in-output (the starter's own visible pattern — inherited like SUM, but this time the corner is a SIGKILL skipping `finally`, which no small self-test inventories) and lockfile-in-output designs; naive `*.tmp` sweeps race live peers and lose the disjoint-writers test instead. Golden fix: candidates render under `/app/state/publish-tmp` (same fs, `os.replace` stays atomic).
- **Trap B — concurrent identical batches / TOCTOU** (admission axis, new): **zero new disclosure** — pure composition of "exact replay is a no-op" × "concurrent invocations converge". Both invocations park at `ready_to_apply`, then race one 20k-event file; check-then-insert admissions self-collide (PK violation in a branch the agent proved "unreachable" serially, or a SHARED→RESERVED promotion deadlock for read-early deferred txns) → nonzero exit. **Batch size matters: at 600 events the ~10 ms release jitter let the loser start after the winner's commit and V2 escaped (32/32); at 20,000 events V2 fails 5/5.** Also catches double-counted metrics counters.
- **Trap C — crash between metrics and customer-totals swap** (stale-repair-family fill): new disclosed phase `after_metrics_replace`; FAIL_AT there leaves only the third file stale; heal on duplicate-only replay. Bites mark-published-early + per-file-staleness shortcuts.

**Verification matrix (all in `ledger-etl-check` container):** golden **32/32** (suite 89 s ≪ 600 s); starter **21F/11P**, reward 0, smoke/normal-input still passing; V1 (output-dir candidates) fails **only** the 4 interruption-hygiene tests; V2 (check-then-insert + deferred BEGIN) fails **only** `test_concurrent_identical_batches_admit_each_event_once`, 5/5 stress; V3 (CAS `<=` skip-if-equal) fails **only** the duplicate-run repair test; golden concurrency/interruption set (10 tests) × 5 rounds, **0 flake**; instruction 1161 tokens < 1500. All variant failures are wrong graded output, never timeouts. Per-trial fail estimate if each new axis lands ~0.2–0.3 alongside stale-repair's 0.2–0.4: P(≥1 hit) ≈ 0.55–0.7 — at or above the ≥3/5 line for the first time.
---

## 10. Addendum 2026-07-15 — runs 14-read→17: the acceptance (`4815529`)

**Outcome first: ACCEPTED.** Run 29374946300 — `pass2` 1/2, `pass@5` 2 solved / **3 good-valid anchors** (avg@5 0.400), 0 infra, 0 timeouts, `task_specification`/`approach_validity`/`reward_hacking` PASS on all 7 trials, all 8 gates green, PR labeled `accepted`. The scoreboard (§0 rows 14-read→17) and calibration (§5) carry the numbers; this section carries the *why*, because the mechanism that finally worked is the transferable asset for the next task.

### 10a. How the last difficulty ceiling actually fell

Three consecutive reads (14-read, 15, 16) sharpened Wall A into something more precise than "disclosure gets transcribed":

1. **Disclosed mechanisms get transcribed** (§1, unchanged — proved ~10× by now).
2. **Disclosed *properties* get derived.** Run 15 stated only behaviours (bounded staging, TOCTOU recheck, generation floor) and all five agents derived the reference architecture "with no meaningful variation" — the pass@5 analyst explicitly attributed the convergence to *training-data knowledge of these patterns*, not in-context derivation.
3. **Undisclosed consequences on the idiom path get dodged by habit.** Run 16 removed the SUM-overflow warning and the event-ID-set prescription entirely; an agent *flagged the SUM overflow risk in its own reasoning anyway*. The defenses live in the weights. De-disclosure is safe (`task_specification` stayed PASS) but moves p(fail) ~0.
4. **Corollary discovered while building run 17: the stdlib pre-springs traps too.** A lone-surrogate-rejection crux died on the bench because `sqlite3` refuses to bind unencodable text — every SQLite-staged design auto-rejects, so the no-guard mutant passed 37/37. **Mutant-verify a crux bites BEFORE counting it; the stack disarms your traps the same way it disarms its own bugs.**

What survives all four filters is a narrow family: **stdlib betrayal** (the trusted brick itself violates the stated contract — `strptime` accepting unpadded fields against an "exactly `YYYY-MM-DDTHH:MM:SSZ`" spec) and **protocol semantics whose violation leaves every output byte correct**. The winner was the second kind.

### 10b. Anatomy of the winning trap (2 assertion lines)

The instruction has always *defined* `after_orders_replace` as "`orders.csv` replaced". Run 17 added two assertions: after a stale publisher's generation fence makes it *skip* its swap, the marker file must be **absent** (stale-clobber test + crashed-newer-fence test). Reference already correct; a mutant firing the hook on the skip path fails exactly those 2/37.

It killed 3 of 5 trials, via two different implementations (unchecked boolean return ×2; a `while True` retry that re-rendered a *fresh* generation and legitimately republished past a `>` fence — so even its file contents stayed right). The profile that made it lethal:

- **Zero observable damage on every path the agent exercises.** File bytes correct, DB correct, exit codes correct. The only wrong thing in the universe is a marker file's existence in one adversarial interleaving the agent never constructs. Self-testing *cannot* see it — there is no output to diff.
- **It reads as instrumentation, not as a contract.** Agents treat hook emission as logging; `task__bF9mFjF` *wrote the failure scenario in its own step-7 reasoning* ("our instance A would only reach `after_orders_replace` even if it skipped") **and chose not to act on it**. Compare run 16, where an agent acted on an overflow risk *nobody mentioned*: the model triages risks by perceived blast radius, and protocol markers rank below data.
- **It needs no new disclosure.** The phase definition was already on the page; the trap is the precise reading of an existing sentence.

The pass2 companion fail was an **independent second axis** from run 15's additions: simultaneous first-open WAL bootstrap (`PRAGMA journal_mode=WAL` on a brand-new DB races; `busy_timeout` doesn't serialize it; the reference takes a pre-connect `flock`). Same family — a lifecycle window (first boot) that self-tests never race.

**Final arithmetic:** 4 analytical fails / 7 trials ≈ p 0.57 — right at the ≥3/5 line, exactly where §9's stacking math said it had to be, but reached with 2 axes that each bite the *converged* design, instead of 4-5 axes hoping to catch shortcut cohorts.

### 10c. Playbook for the next task (what I'd do first, not last)

1. **Assume the model ships the reference architecture.** Design difficulty for the agent that *finds* the clean design, not the one that misses it. Ask: "what can be subtly wrong in a correct-architecture implementation?"
2. **Hunt protocol/lifecycle semantics, not data semantics.** Contracts whose violation leaves outputs byte-perfect: observability markers gated on actual effect, idempotent-skip paths, first-boot races, crash-window ordering. Wrong *data* gets caught by the agent's own reducer; wrong *ceremony* never is.
3. **Two-sided traps beat one-sided ones.** Pair every reject-case with an accept-case so crude fixes fail from the other direction (unpadded-timestamp ↔ leap-second; lone surrogate ↔ astral scalar ↔ ignored unknown field).
4. **Mutant-or-it-didn't-happen.** For every intended crux, build the one-decision-different variant and demand it fails *exactly* the intended cases and nothing else. This bench-killed one dud crux (sqlite pre-sprung) and certified four real ones in a single session.
5. **Budget the meta-gates:** pass2 needs the trap to bite within n=2 — a p≈0.5 trap passes pass2 only ~75% of the time. Expect to lose one read to variance even when the design is right.
6. **Infra doctrine (updates §2):** Anthropic-429 Stage-2 saturation comes in *windows of hours*. Empirical spacing: 12-min and 22/31-min retry gaps all re-voided; ~49 min cleared; the ~4-h scheduled cloud-routine rerun also cleared. Space ≥45 min, never change content on a void, and use a real commit as the re-fire when one is pending anyway.

### 10d. Harness gotchas earned this round (extends §6d)

- **`.gitattributes` now pins `* text=auto eol=lf` (35a7c05)** — the `sed 's/\r$//'` workaround in §6d/§8 is obsolete; the working tree builds clean directly. (Root cause: only `*.sh` was pinned; extensionless `bin/process-orders` checked out CRLF → `python3\r` shebang → 36/37 "failures" with the only "pass" being the test that *expects* nonzero exit. A broken binary satisfies a rejection test — beware that imposter profile.)
- **git-bash mangles `"$VAR\$M"` in docker mounts** → literal `...$M` path → Docker silently **creates an empty host dir** → `/solution` empty → solve.sh never runs → **the starter gets graded** (26F/11P imposter, looks like a catastrophic mutant). Use forward-slash `C:/...` paths with variables, and guard every harness run with `set -e` on solve.sh + `cmp -s /solution/... /app/...` before pytest.
- **git-bash heredocs eat one backslash level** (observed: `"\ud83d"` reached Python as a real surrogate). Never pattern-match backslash literals through a heredoc — anchor on plain-text markers and filter lines instead.
- `docker run` needs `-i` for heredoc stdin (`python -` silently runs nothing without it).

### 10e. Post-acceptance state (superseded by §11 — a second reviewer reopened the task)

- Accepted head `4815529`: 37 cases; oracle 37/37 reward 1; starter 26F/11P reward 0; mutants: strptime-only 1/37-fail, regex-only 1/37-fail, hook-on-skip 2/37-fail, SQL-SUM 2-fail, list-staging RSS 1-fail — each green elsewhere.
- Suite runtime ~100-140 s ≪ 600 s verifier cap; instruction ~1.2k tokens < 1500 gate.
- Monitors/loops from the watch session are all stopped; nothing pending on the PR.

---

## 11. Addendum 2026-07-16 — second-reviewer rejection and the stale-fence hardening round

**Situation.** A second human reviewer reopened the accepted task: pass@5 read as 2 solved / 3 good-valid fails ("difficulty OK"), but all three fails converged on the *single* stale-generation publication path (unconditional `after_orders_replace` on the skip path, or an equal-generation retry loop). Verdict: harden the same crux so a rerun cannot slip through (their "Situation C: precisely observed blind spot"), with two constraints — solvable by a careful domain expert from instruction+repo alone, and deterministic acceptance of a correct solution.

**Prescribed and implemented (all four levers):**
1. **One terse instruction sentence** (end of the publication paragraph): *"From the moment a publisher observes a strictly newer visible generation it must stand down: no re-rendering, no further replacement, no further publication phase signaled. A retry that observes its own equal generation after a crash proceeds and signals every phase it performs."* Wordsmithing that mattered: "from the moment" makes the mid-set temporal cut explicit (phases already fired stay legitimate); "signals every phase it performs" avoids implying a crashed run's completed files must be re-signaled, and stays compatible with byte-compare-and-skip repair designs.
2. **Two new disclosed phases**: `after_metrics_replace` (metrics replaced, totals not yet) and `after_publish` (all three replaced). NOTE: `after_publish` was *already fired* by both starter and reference but never disclosed — a latent spec gap this round closes. Starter got the one-line `reach("after_metrics_replace")` so the visible hook surface matches the instruction; all starter defects untouched.
3. **Reference redesign forced by race (c)**: the old reference held one flock across all three `os.replace` calls and fired `after_orders_replace` *inside* it — a publisher paused at that phase would have serialized a peer, latently violating the already-disclosed independent-progress sentence (never tested at that pause point). New protocol: per-file brief critical sections; `claim_publication` (floor CAS, idempotent) re-checked before *every* replacement; fenced-out ⇒ discard remaining candidates and return silently; hooks fired *outside* the lock.
4. **Graded races** (37→39 cases): (a) extended stale-skip + crashed-newer tests with `snapshot_identity()` (st_ino + st_mtime_ns per public file) and all-three-marker absence — catches re-render-and-republish whose *bytes* are correct; (b) new `test_crashed_claim_is_resumed_by_equal_generation_retry` — crash after durable claim + orders replace, corrupt orders in place, retry must exit 0, heal all three, and *signal all three phases* (the in-place corruption keeps byte-compare-and-skip designs obligated to replace orders, so the marker demand never false-positives a legit design); (c) new `test_mid_publication_fence_gates_each_file_and_phase` — A parks at `after_orders_replace` (no lock), B publishes fully within a 15 s bound (whole-set-lock designs fail here as graded output, not verifier hang), A resumes, must stand down for metrics+totals with bytes+identity untouched, `after_orders_replace` marker present but `after_metrics_replace`/`after_publish` absent ⇒ hook gating cannot be one global boolean.

**Verification matrix (ledger-env container, 2026-07-16):**
| Run | Result | Notes |
|---|---|---|
| reference | **39/39**, 130 s | deterministic accept |
| starter | **28F/11P** (was 26F) | both new races fail on it |
| m1 claim-once/global-boolean | fails exactly **1**: mid-fence (c) | the reviewer's "cannot be one global boolean" |
| m2 signals-on-skip (run-17 mutant) | fails exactly **3**: the three fencing races | |
| m3 strictly-greater fence | fails exactly **4**: both crash-heals, repair, crashed-newer heal-tail | task__KYkuL6c side 1 |
| m4 re-render-and-republish | fails exactly **3**: fencing races via identity+markers (bytes correct!) | task__KYkuL6c side 2 |
| m5 replaces-but-suppresses-signals-on-equal | fails exactly **1**: resume race (b) | the overcorrection near-miss |
All mutant failures are wrong graded output (assertions), zero timeouts; every mutant green on all other cases.

**Design lessons this round:**
- **A graded race can force a protocol depth the happy path never needs.** Race (c) is only expressible if hooks are reachable without cross-peer locks, which forces per-file fencing in any passing design — the instruction already implied it ("no lock across the slow work of publishing"), the test now makes it load-bearing.
- **mtime_ns + inode is the cheap dual of the marker check**: markers catch silent-wrong ceremony, identity catches correct-bytes republication. Together they close both of task__KYkuL6c's escape hatches.
- **When demanding a signal, make the underlying effect mandatory first** (corrupt the file in place) or a compare-and-skip legitimate design becomes a false positive.
- Instruction now 6,197 chars ≈ 1.3k tokens (< 1500 gate); suite ~130 s (< 600 s).

**Fixture blindness preserved:** example.jsonl and all visible fixtures never exercise publication contention; a wrong answer remains well-formed artifacts plus one stray marker file (or one untouched-file mtime), invisible to self-tests.

**First read of run 18 (run 29527291349 on `2f47b0c`, pass2 read 2026-07-16 ~20:37Z):** static/similarity/validation/ratelimit all PASS with no Stage-2 429 despite the EU-morning window; **pass2 = 0 solved / 1 valid-fail / 1 in-progress-timeout / 0 infra-setup — gate PASSED (1/2), trials will fire.** But the read carries **zero crux signal**: the counted valid fail (`task__BAT3Wbv`) is the §2 **terminal JSON wedge** (six consecutive reasoning-only steps, "No valid JSON found in response", zero code written, graded against the unmodified starter → 28/39 fails, matching the local starter profile exactly); the other trial (`task__FrCUrUQ`) misused SQLite's UPSERT SELECT form, found the crash at step 6, and was mid-fix when the 3600 s cap fired (low_timeout FAIL → counts for nothing). Rubric verdict: `difficulty_crux` FAIL ×2 — "the cruxes are untouched; they remain unassessed difficulty for future trials"; task_specification/approach_validity/reward_hacking clean ×2, so the new instruction sentence and 39-case suite created no spec-gap flags. Whether the fence races bite rests entirely on the pass@5 trials. If those also wedge/timeout, that's the §2 tax — rerun, don't touch content.

---

## 12. Addendum 2026-07-22: first-pass accept, and why (dynamo-6a22900-security)

Task `prvs-record-encoder`, Security / Reverse Engineering. **Accepted on the
second push, first clean pass@5 read.** pass@5 = 0 solved / 4 good-valid-fail /
1 in-progress-timeout, avg@5 0.000, all eight gates green. The only iteration was
a substring false positive: a Dockerfile comment containing the literal
`tests/test.sh` tripped the "does not COPY tests/" static check. One-word reword,
re-push, done. Contrast the prior cycle: ~18 runs across 4 tasks to land one
accept, and that one got reopened.

**What actually made it fast, in order of impact.**

1. **Category, chosen not built.** Security / RE is the model's away turf, where a
   *discovered* crux bites. ETL is home turf and the docs are right that it is
   near-impossible to make hard. The whole difficulty problem was won at claim
   time by picking a category where the crux can live outside the prose.
2. **Two axes designed to bite the converged design, verified by arithmetic
   before a line of code.** A prime-modulus checksum recoverable only by gcd, and
   a latent flags bit recoverable only from the binary. Neither is in any prose.
   The trials confirmed both: five agents exhausted the checksum catalogue and
   none tried gcd recovery; none disassembled the binary, so none found bit0.
3. **Mutant-verify against the real verifier before trusting any axis.** Two
   candidate axes (label normalization, entry sort) died on the bench because
   they failed samples, so the agent's own checks would catch them. Cutting them
   early saved trials. The two survivors were surgical: bit0 failed exactly its 9
   records x 3 tests, wrong-modulus exactly 18 x 2.
4. **The reader-audit (see F19).** The shipped binary was almost a free oracle. A
   per-field audit caught that early and turned it into a fair discovery problem
   instead of a leak.
5. **Hygiene that prevents voided runs.** gitattributes/CRLF pinned before the
   first add, jobs/ ignored, clean-image checks, fairness pre-derived. Zero runs
   lost to infra or self-inflicted breakage this cycle.

**The lesson that generalizes:** the away-category plus the discovered-crux plus
mutant-verify-first recipe works, and it works on the first read when applied with
discipline. The 18-run saga was not the cost of learning to build hard tasks. It
was the cost of building them in the one category where the method cannot win.

**One honest footnote.** The axis-correlation worry (both latent rules in the same
disassembly) never materialized, because no agent disassembled at all. The
difficulty came from a route the model declined to take, not one it took and lost.
Worth remembering: sometimes the crux holds because the model avoids the path that
would crack it, not because the path is hard.

---

## 13. Addendum 2026-07-22: second security task, one-pivot accept (dynamo-825bd62-security)

Task `beacon-frame-encoder`, Security / Reverse Engineering. **Accepted after one
pivot.** First push (v1) blocked at pass2 as too-easy; the rebuild (v2) landed
pass@5 = 0 solved / 5 good-valid-fail / avg@5 0.000, all 8 gates green (static, rubric
PASS, similarity UNIQUE, validation, pass2 2/2 valid-fail, deep_review, adversarial,
ava, gate).

**v1 (too easy) — the known-plaintext trap.** v1 whitened the reading payload with a
keyed xorshift keystream (seed from the record token, full 32-bit state XORed per
reading) plus latent enum codes in an nvram dump. pass2 solved it in ~17 min: the
agent computed keystream = plaintext XOR ciphertext, brute-forced the xorshift
`(a,b,c)` over `[1-31]` (~30k), and read the enum codes straight off the hexdump.
Lesson, sharply: **full known-plaintext over a reversible transform hands the agent
the entire keystream, and any non-cryptographic generator with a small parameter
space is then trivially recovered.** XOR-whitening is the wrong shape for a byte-exact
task; the crux must be **many-to-one** (a reduction) so the secret cannot be read off
the output.

**v2 (accepted) — back to the opaque gcd modulus.** Workhorse swapped to an integrity
trailer = polynomial byte hash of the body mod a secret prime (gcd recovery); payload
became plain sign-magnitude readings whose sign rule is latent (samples all
non-negative, where sign-magnitude and two's complement agree) and disclosed only in a
shipped stripped decoder. Two proven declined routes, mirroring `prvs-record-encoder`.
All 5 pass@5 agents failed on crux 1: the analysis shows them running z3 SAT-based CRC
search, byte-affine modular search, and ARX rolling-hash catalogues, and **none tried
gcd modulus recovery**. One agent solved crux 2 (sign-magnitude) and still lost on
crux 1, confirming the gcd is the workhorse and the sign rule is insurance.

**What generalizes:**
1. **The gcd-secret-prime-modulus crux is the single most reliable RE stump so far.**
   Two tasks, two clean accepts, zero agents taking the gcd route. Catalogue-first
   behavior (checksum-ID tools, z3, named hashes) runs deep; derivation-by-gcd is not
   reached. Prefer a **many-to-one reduction** over any reversible per-value transform,
   so known-plaintext cannot surrender the secret.
2. **A first "too easy" is one pivot, not a saga.** The ETL project burned ~18 runs;
   here one bounce plus one rebuild on the proven mechanism sufficed. When a novel
   mechanism bounces as too-easy, converge on the proven declined-route immediately
   rather than iterating novelty.
3. **Reliability over distinctness, once chosen, is cheap and it works.** The operator
   accepted lower distinctness (v2 rhymes with prvs) for reliability and got a 0/5
   first clean read. The distinctness cost was real; the pass was immediate.
4. **Compile the RE binary in the runtime image itself.** bcnreader was built with
   apt-installed gcc inside the pinned `python:3.13-slim-bookworm`, so glibc matches;
   ship it as environment data with an explicit `bcnreader binary` line in
   `.gitattributes` (an extensionless ELF is otherwise LF-normalized and corrupted).
5. **Gate the binary's oracle surface.** The decoder discloses the sign rule via
   disassembly but prints reading values only in a verbose mode, so a naive dynamic run
   does not round-trip-confirm the encoding. Whether it mattered is unmeasured (crux 1
   dominated), but it is the right instinct per F19.

**Docker footnote.** Local Docker Desktop flapped repeatedly ("daemon is not running")
between a passing `docker info` guard and harbor's own check; several oracle/nop
launches false-started and needed a plain retry. It never touched CI. If harbor
false-starts locally, just re-run; it is the box, not the task.

---

## 14. Stump-strategy field guide (filtered through what has actually worked)

Distilled from a strategies writeup and governed by the two rules that have decided every
read in this file.

**Rule 1 — DISCOVERED beats DERIVABLE.** A crux only stumps a frontier model when it must
be uncovered from data or reverse-engineered; anything derivable from a careful reading of
the prose gets transcribed. That filter picks the patterns below.

**Rule 2 — one crux is fragile; stack at least two INDEPENDENT ones.** This is the
anti-fragility rule and it is not optional. The gate needs >=3 fails of 5. A single trap
that bites ~30% of trials reaches >=3/5 only ~16% of the time by variance alone — a coin
flip you will lose, and the read swings run to run. Two axes that each bite the *converged,
correct* design push the per-trial fail probability into the ~0.55–0.6 band that has
actually cleared the gate; three weaker independent traps at p~0.25 each give P(>=1 hit per
trial) ~0.58, which also clears it. **Independence is the load-bearing word:** axes that
lean on the same skill or the same evidence are correlated — the careful agent beats both,
the careless one fails both — so they do not stack and you are back to one fragile crux.
beacon shows the shape: the gcd trailer carried it (all 5 failed there) and the
sign-magnitude rule was the insurance that would have caught anyone who cracked the gcd
(one agent did solve the sign rule and still failed on the gcd). Never ship a task whose
difficulty rests on a single point.

Kept below are the discovered-crux patterns, each with its concrete anchor, our evidence,
and the fairness line that keeps it acceptable; letters match the rulebook §9 / workflow B2
palette. The through-line: the model stops at the first green result, so each axis plants a
determinate failure it cannot pattern-match, recall, or self-verify past — and you build
more than one of them, on independent routes.

**A — Latent crux (the master pattern).** The deciding case is invisible in the visible
data, so the agent's own diligence deepens the error. *Anchor:* all calibration parts
are steel, so applying the steel gauge-to-thickness table reproduces every sample weight
to the gram; the held-out non-ferrous parts use a different gauge standard and only they
expose it. *Verdict:* the most effective stump in the corpus — proven (accrued-interest
8/8, bytecode-vm-debug); both our accepts are A at core (prvs modulus, beacon gcd + sign
rule). *Condition:* the rule must be real and determinate yet never fire on visible data
(a cache key that breaks only on a repeat, an off-by-one past ten records, a policy
clause the sample omits).

**A-variant — I, stale authority.** The same mechanism for time-scoped data: use the
value authoritative *as of* the reference moment, not the one that looks current now; the
deciding late correction or superseding revision is simply absent from the sample.
*Anchor:* fund end-of-day valuations where a price is corrected after the fact — "use the
latest price" reproduces every in-sample statement and silently rewrites history on the
days a correction landed. *Verdict:* sound but **conditional** — as-of / point-in-time
joins are classic ETL, which §12/F1 mark as home turf and the hardest to make hard;
it bites only as a genuinely latent correction, not as a disclosed as-of rule (which gets
transcribed). Fair because the timestamps and revisions are all present.

**B — Wrong-default lure.** A cheap heuristic is almost equivalent to the correct,
costlier rule; they diverge only where the agent has no reason to look. *Anchor:* "a
ledger row is a rollup if its account path is a prefix of others" (obvious, passes casual
inspection) versus the correct "if its amount equals the sum of its direct children" —
they diverge only on charged-intermediate parents, and every failing agent emitted the
*byte-identical* wrong answer. *Verdict:* proven (experiment-readout 5/5, per-session vs
per-user stats, error bars 5x too small). *Condition:* the correct rule must be
non-obvious enough that the model takes the bait, and the gap must live off-sample.

**C — Misdirection (untried by us; strong candidate).** The environment offers an early,
authoritative, wrong answer, and the agent's eagerness to close does the rest. *Anchor:* a
shipped diagnostic tool that confidently names a service during an outage — but it points
at a downstream symptom, not the upstream cause; the fix is to distrust the tool and trace
the dependency graph to the source. *Verdict:* a reliable winner (F14 ranks C/D/F top); we
have never used a plant tool, so it is fresh territory for the next project. *Condition:*
the plant must be **detectably wrong from agent-visible evidence** — a deliberate,
uncorrectable red herring is a reviewer Reject. Generalizes to misleading code comments,
decoy files/branches that reproduce most of the output, and stale-but-official docs that
contradict the machine-readable source of truth.

**D — Evidence-forced reverse engineering (our proven workhorse).** Recover an
undocumented rule, format, or constant from what can be observed. *Anchor:* rebuild a
crashed metrics service from raw logs alone — sentinel = overflow, ms not s, counters that
reset and must be segmented, rates scaled by the scrape interval; or reverse a custom
binary bit by bit; or recover hidden constants from archived input/output diffs; or, most
elegant, a task where the natural model structurally cannot fit the hidden behaviour (a
smooth fit against a rule with a discontinuous jump). *Verdict:* both our accepts are D
(prvs weighted-sum mod secret prime via gcd; beacon poly-hash mod secret prime via gcd +
sign-magnitude from the shipped binary); legacy-formatter-clone 5/5. The
**gcd-secret-prime-modulus instance is 2-for-2 and the single most reliable crux we have
(§13)** — agents run checksum catalogues, z3, ARX hashes, and decline gcd every time.
*Condition:* discoverable from material the agent can read, with a wide correctness margin
so method differences can't flip it.

**E — Ordering assumption.** The data violates an invariant the agent never consciously
chose. *Anchor:* GPS records whose year field wraps every so often; the sample is
chronological so a running-lower-bound decoder works, but the hidden log jumps backward
several years and that decoder adds a spurious cycle, throwing dates off by decades; the
fix anchors each record independently against a fixed reference. *Verdict:* proven
(gnss-log-decode 8/8, ~20 years off). *Condition:* the broken invariant ("input is
sorted", "records well-formed", "anomalies terminal") must break in data the agent does
not inspect, and its sample-built tests must reinforce the blind spot.

**G — Multi-mechanism accumulation.** Many independent required fixes under an
all-or-nothing bar; seven of eight still scores zero. *Anchor:* an 8-bug binary relinker
(revision handling, symbol binding, alignment, kind-encoding); agents spread by how many
they fix (most 1–3, a strong run 7), and the instructive near-miss fixed seven but wrote a
component's raw kind value instead of its encoded rank — invisible under the rank-zero
sample, caught only by held-out families. *Verdict:* real difficulty through breadth, not
a single insight. *Condition:* the fixes must be genuinely independent (not all derivable
from one realization) and **at least one must hide in a case the sample never exercises**
(G x A). Pairs with the all-or-nothing amplifier.

**Deliberately not built — H and F.** Two patterns are excluded on purpose; do not
re-add them.

*H — entangled rules.* Simple rules whose interactions rewrite each other (a reset
discards approvals made before it; a revocation resurrects a superseded parent and
re-validates its children), so faithful incremental replay lands on a subtly wrong global
state. This is **documented-rule difficulty**: a max-reasoning model derives and solves it
from a careful spec read, and we proved it too-easy twice (§1, §12; F1), including a
bitemporal revision. Bitemporal data, ledger reversals, and dependency resolution are the
same trap — if the interactions are disclosed, they get transcribed.

*F — discovery hop.* A final opaque joint guess with no partial feedback (the auth-token
role/scope/channel triple that returns an identical rejection every time). Excluded as
**reject-prone**: its difficulty comes from removing feedback rather than adding hardness,
so it sits on the knife-edge between fair-hard and pure luck. It fails at the last step
after the real skill was shown, its fairness rests entirely on a reviewer agreeing the
value is discoverable, and it maps straight onto the Reject triggers (coin-flip decides
pass/fail, gotcha not skill). Not worth the blocked-PR risk when A/D/E/B/C give the same
difficulty with robust fairness.

**Stacking, and how to make the stack actually hold (the anti-fragility checklist).** The
strongest tasks combine patterns on independent routes: A hidden inside G (breadth with one
invisible fix), A specialised as I (time-scoped), or D whose recovered constant then gates
an A-style latent branch — exactly beacon (gcd trailer as the D workhorse, latent sign rule
as the A insurance). Combining is necessary but not sufficient; verify the stack before
trusting it:

1. **Mutant-or-it-didn't-happen, per axis.** For each intended crux, build the
   one-decision-different variant and prove it fails *exactly* the intended tests and
   nothing else (F16). The stdlib or the storage layer often pre-springs a trap so the
   buggy variant passes anyway — catch that on the bench, not at pass@5.
2. **Wrong output, never a clock-out.** A harder failure must produce *wrong graded output*,
   not a timeout. In-progress and soft timeouts count for nothing toward the >=3, so raw
   scale (bigger N) is a trap — it yields uncounted timeouts, not fails. Keep the solution
   labor inside the budget (pre-pay boilerplate in the starter) so difficulty lives in the
   traps, not in typing volume.
3. **Check the axes are actually independent.** If cracking axis 1 hands the agent axis 2
   (or both need the same disassembly/gcd/insight), they are correlated and the p's don't
   multiply the way you hoped. Put them on different routes and different evidence.
4. **Two-sided traps.** Pair every reject-case with an accept-case so a crude over-correction
   fails from the *other* direction; when a test demands a signal, make the underlying effect
   mandatory first or a legitimate design becomes a false positive.
5. **Do the arithmetic before building.** Estimate each axis's bite, confirm the combined
   per-trial fail probability lands in the accept band (0–2 solves of 5), and treat a first
   "too easy" as calibration data, not failure.

Amplifiers that sharpen any axis: **silent failure** (wrong output looks normal, no crash or
hint), **no self-check** (grade on held-out cases the friendly sample cannot teach), and
**all-or-nothing** (a single correct artifact). Fairness gut check for every one: an expert
seeing only what the agent sees gets it right AND calls the failure fair.

---

## 15. Addendum 2026-07-23: the scientific-computing project and the qc_gate wall (dynamo-dde7b29)

**Repo:** `dynamo-dde7b29-scientific-computing-and-domain-science`, subcategory Numerical methods,
model_tested Opus-4.8, agent_tested Terminus-2. **Three task attempts in one session; the only one
to clear the new gate was a reverse-engineering task, not a data-analysis one.** This section is
the most important update since the security accepts, because it reorders the whole playbook for
any repo that has the gate.

### 15a. The new pipeline stage: qc_eval -> qc_gate

This repo's pipeline has a stage the security-repo pipeline (§12-§14) did NOT: **`qc_eval` (an LLM
soundness pass, ~44 probes) feeding `qc_gate`**, between `validation` and `pass2`. It is
**blocking and fail-closed**: if `qc_eval` yields no routing (skipped/errored), `qc_gate` BLOCKs by
default ("qc_eval=none, gate=BLOCK; fail-closed"). Observed job order: `review` (static + rubric
eval) · `similarity` · `validation` · `qc_exec` · `qc_eval` · `qc_gate` · `pass2` · `deep_review` ·
`adversarial_review` · `ava_review` · `trials` · `gate`.

**qc_gate is stricter than the rubric eval and overrules it.** On attempt 2 the rubric `review`
returned PASS ("well-designed, fair") while `qc_gate` BLOCKED the same task. A rubric PASS is not a
qc_gate PASS.

### 15b. What qc_gate demands: the output must be UNIQUELY DETERMINED by the visible data

Every block across the three attempts reduced to one principle: **the expected output must be
uniquely determined by what the agent can see; anything the gate can read two ways, or fit with a
rival, is "underdetermined / ambiguous / hidden-knowledge" and BLOCKED.**

- **Attempt 1 - calibration (latent piecewise regime + cross-channel gain bridge; continuous
  prediction).** Bounced twice. Round 1: the second law was disclosed by "3 tightly-clustered
  points" -> underdetermined extrapolation. Round 2 (well-sampled on a regular grid): the gate
  constructed a **rival `Q = 0.3x + sin(pi*x/10)` that vanishes on the grid**, reproduces every
  calibration row, and differs on held-out. **Root cause: predicting a continuous function at new
  points is inherently underdetermined** - you can always add a function that vanishes on finite
  samples (perfect-square turbulent points had the same hole via `sin(pi*sqrt(x))`). The only fix
  (disclose the response form) conceded the crux.
- **Attempt 2 - assay (wrong-default estimator: unbalanced pseudo-replication + zero-sentinel
  dropout).** Rubric PASS; qc_gate BLOCK with a cluster of issues all naming `instruction.md`:
  "Ambiguous Rule", "Missing Definition", "Undocumented Requirement Enforced", "Underdetermined
  Mapping", "Unstated Data-Anomaly Policy." **The gate treats the naive method (pool the reads,
  keep the zeros) as a defensible alternative reading, not an error**, so it demands the deciding
  rules (sample-as-unit; 0 = drop) be stated. But stating them makes a frontier model just follow
  them -> too easy at trials. Dead either way. This is the disclosure paradox, now enforced by an
  automated gate rather than only by the difficulty ceiling.
- **Attempt 3 - record-integrity repair (gcd-secret-prime-modulus RE): CLEARED qc_gate -> pass2.**
  The output (recovered blanked fields) is **objectively unique**: the intact records fix the
  modulus M as `gcd(pack - check)` (a large prime, so the gcd lands on M exactly), and each field
  is < M so its residue is the single valid value. A wrong modulus yields wrong integers, not a
  defensible alternative. The mapping IS determinable from the visible data (via gcd), satisfying
  the gate's own "determinable from visible inputs" bar - while difficulty stays hidden (agents
  catalogue named checksums or search a billions-wide space for M instead of gcd; the §13/F10
  stump).

### 15c. The load-bearing conclusion (reorders the playbook for qc_gate repos)

**In a repo with qc_gate, the discovered-difficulty strategy that works everywhere else is largely
dead for data-analysis shapes.** Both the latent crux (A) and the wrong-default lure (B) - the two
data-analysis workhorses - were blocked as ambiguous/underdetermined, because a data-analysis
answer that depends on a method or interpretation choice is exactly what the gate calls ambiguous.

**What survives qc_gate:** a task whose answer is **OBJECTIVELY UNIQUE** - where a wrong answer is
objectively wrong, not a defensible alternative - recovered via a **deterministic rule the agent
must reverse-engineer.** That is Pattern **D** (evidence-forced RE), and specifically the
**gcd-secret-prime-modulus** family (now 3-for-3 at reaching the difficulty gate: 2 security
accepts + this one clearing qc_gate).

**The one-question test before building anything in a qc_gate repo:** *could two competent,
good-faith experts produce different answers from the same inputs?* If yes (calibration rivals,
assay method-choice) -> qc_gate blocks. If no (there is exactly one correct decode/recovery/scalar)
-> qc_gate passes. Prefer EXACT, uniquely-determined outputs (a decode, a recovered constant, a
hash, an exact scalar field) over any statistic, estimate, ranking, or prediction that rests on a
modeling/aggregation choice. **Reverse-engineering and forensics shapes are naturally unique-answer;
data-analysis shapes are naturally ambiguous. Pick the category accordingly.**

### 15d. Infra and GitHub/Actions gotchas earned this session

- **Anthropic workspace usage-cap void (new flavor of §2/F17).** Mid-session the shared
  project-paid Anthropic key hit a **workspace usage limit** ("API Error: 400 You have reached your
  specified workspace API usage limits. You will regain access on 2026-08-01") - a hard
  monthly-style cap, not a transient 429. It voided `review`/`qc_eval` for ~2 hours (every run:
  `review` FAIL -> `qc_eval` skipped -> `qc_gate` fail-closed) until an admin apparently restored
  it. Tell it apart from a content FAIL by `usage limit` / `no verdict produced` in the job log.
  Spacing reruns does NOT help a monthly cap; escalate to a Dynamo admin.
- **A fork-PR push can fail to fire the synchronize event.** After a clean push, the fork branch
  was at the new SHA but **PR #1's head stayed frozen at the old SHA and no workflow ran** (a side
  effect of `index.lock` collisions during the push). Fix: push a new commit to nudge GitHub to
  reconcile the PR head and fire the event.
- **The pipeline is path-filtered on `task/` and `qc_eval` runs on the incremental push diff.** An
  **empty commit** updates the PR head but triggers no run (no files changed). A commit touching
  only `tests/` (a comment) fired a run but `qc_eval` **skipped** on it (its incremental diff
  carried no agent-facing change) -> `qc_gate` fail-closed "qc_eval=none." **To get a real qc read,
  the triggering push must carry a substantive change to an agent-facing task file**
  (instruction / solution / environment / data), not an empty or tests-only commit.
- Local Docker Desktop kept flapping ("daemon is not running") between a passing `docker info` and
  harbor's own check; a plain retry clears it (never touched CI), per §13's footnote. The
  direct-docker mount harness (§8) was the reliable local check throughout.

### 15e. Status at write time

`dynamo/record-integrity-repair` is **at pass2** - the first of the three attempts to clear
qc_gate. Local matrix: oracle 1.0 (harbor full pipeline + mount harness), mutants (ignore-modulus,
wrong-modulus) 0, nop 0. Whether a single gcd crux is hard enough for pass@5 is the open read; if
too easy, the next lever is a second independent determinate axis (a latent per-field encoding, or
per-channel moduli), NOT a return to any ambiguous data-analysis shape.

---

## 16. Addendum 2026-07-25 — badge-log-forensics (this repo, dynamo-8a66825-security): the ava_review union gate, and the pivot to cryptography

**Repo/task.** `dynamo-8a66825-security`, task `dynamo/badge-log-forensics` (Security / Digital
Forensics). Same proven gcd-secret-prime-modulus DNA as §15's attempt 3. Parse a custom "ACJ1"
binary door-controller journal; the sole door-3 ACCESS_GRANT had its cardholder id zeroed but its
integrity trailer intact; `trailer = int(body,'big') mod M` for a secret ~32-bit prime M; M = gcd
over intact `(body_int − trailer)`; the zeroed id is the unique in-range residue (**640118**).
Second independent axis: a constant undisclosed RTC skew (**20893 s**) recovered by anchoring the
sole boot + sole forced-door records to external UTC times in the case notes (true time
`2025-05-02T22:39:26Z`; the naive raw-ticks reading `2025-05-03T04:27:39Z` is the trap).

### 16a. New gate mechanic: `ava_review` (the AVA ∪ Deep-Review union gate)

The pipeline now ends `… pass2 · deep_review · adversarial_review · ava_review · trials · gate`.
`ava_review` is an LLM **verifier audit** (soundness / ground-truth / golden-conformance) that is
**fail-closed and blocks on _potential_ majors** — low-confidence, unconfirmed findings, not just
confirmed ones. Observed routing counters: `confirmed_major=0 supported_major=0 potential_major=7
gaps=4 → routing=block`. So it can red-check a sound task on speculation alone.

**What it blocked us on (both false positives).** Every other stage was green — static, QC
soundness (44 checks, 1 minor advisory), Dynamo eval PASS, similarity UNIQUE, validation (Docker +
Oracle reward 1.0 + Nop), pass@2 (0/2, legitimate difficulty), adversarial cheat-pass PASS,
deep_review PASS. AVA blocked on two `verifier_coverage` findings against `solution/solve.py`:
1. "brute-force range misses it (empty `found`), tripping the assert — solution fails." **Provably
   false:** the sweep is over the vendor-documented cardholder range `100000..999999` and
   `found == [640118]` (reproduced locally against the shipped `journal.bin`).
2. skew/true-time computation — AVA's own text resolved it to **"Same"** (i.e. no defect).

### 16b. Clearing an adversarial LLM gate (transferable)

You cannot argue with it in comments; you **remove the surface it grabs and re-push** (it re-runs
on push). What was done, none of it touching the graded values:
- **Harden the reference so the speculative reading is impossible to state.** Document that the
  sweep range is the *vendor-documented* value space (so it cannot "miss"), add a round-trip
  re-check of the recovered value, give bare asserts descriptive messages.
- **Tighten the verifier to the instruction's declared types.** Require `cardholder_id` to be a
  genuine JSON **int** (reject str/float/bool) instead of `int(...)` coercion — this also closed the
  one real (non-blocking) QC advisory (type-coercion bypass) and strengthens the acceptance boundary
  the audit inspects.
- Oracle still 1.0; naive-time trap still rejected; instruction/solution/tests re-diffed consistent.
- **Lesson:** budget for an `ava_review` void the way you budget for infra voids (§2) — a clean,
  unique-answer task can still trip it on a *potential* finding. Pre-empt it by making the reference
  self-evidently robust (documented-complete searches, round-trip checks) and the verifier
  type-strict, so the audit has nothing speculative to latch onto. Tell an AVA void apart from a real
  FAIL by the `<!-- AVA-GATE -->` sticky's routing line (`potential_major=N` with `confirmed=0`).
- Status at write time: fix pushed (`bebb1f8`); review re-run in progress; verdict pending.

### 16c. Decision: next task = Security / cryptography

See `NEXT_TASK_PROMPTS.md` §D. **The subcategories actually offered are cryptography,
vulnerability_analysis, security_hardening, digital_forensics — there is no "cryptanalysis" label**
(the initial pick name was wrong). Chose **cryptography, built as a break/recover task**: breaking a
bespoke scheme yields a recovered **key / seed / modulus / plaintext** — an exact scalar with one
correct value → **qc_gate-native** — while keeping the discovered, reverse-engineered difficulty
that survives the disclosure paradox. It is the natural home of the gcd-modulus stump, **now
4-for-4 at reaching the difficulty gate** (`prvs`, `beacon`, `record-integrity-repair`,
`badge-log-forensics`). Two traps: (1) build it as a **break**, never *implement a cipher*
(implementation is disclosed/derivable → too easy, and "is this secure?" is method-choice ambiguity
qc_gate rejects); (2) named textbook attacks (single-byte/repeating XOR, Vigenère, hash
length-extension, textbook RSA) are **memorization-solvable → too easy / not novel** — the crux
must reverse-engineer a *custom, undocumented* construction (RULE 1).

**Why not the other three:** digital_forensics is proven and qc_gate-native but §16 just shipped one
(poor diversity); vulnerability_analysis is unique only if you force a flag/secret output and
exploit-dev tends to **time out** (uncounted at pass@5) plus carries named-vuln novelty risk;
security_hardening is the weakest — many valid hardened states → method-choice ambiguity (qc_gate
risk) and disclosed best-practices → transcribed → "too easy". This is a lateral move within
Security, **NOT** a return to any ambiguous data-analysis / prediction / estimation shape (§15c).

---

## 17. Addendum 2026-07-25 — vault-master-recovery (dynamo-42e68f1-security): the cleanest read yet, and what the insurance axis actually did

**Repo/task.** `dynamo-42e68f1-security`, task `dynamo/vault-master-recovery` (Security / **Cryptography** —
the §16c pivot, executed). Built as a **break/recover** per `NEXT_TASK_PROMPTS.md` §D. A decommissioned
appliance's bespoke key-escrow vault survives; the master key value that unseals it does not. Each sealed
record carries an 8-byte trailer that the shipped firmware reader parses and never uses; it is
`int.from_bytes(body, "big") % M` for a secret **62-bit prime M**. `M = gcd(body - trailer)` over the
records; then `derive_key(M)` (sha256 over a domain-separated label plus M's decimal form) and a
sha256(key || nonce || counter) keystream open the slot. Graded: `master_key`, `active_slot_id`,
`recovered_secret` — exact value + exact JSON type, all-or-nothing.

### 17a. Result: 0 solved / 5 good-valid-fail, avg@5 = 0.000, all 15 checks green

| Stage | Result |
|---|---|
| pass@2 | **0 solved / 2 valid-fail** — 7/7 per-trial criteria PASS x2 |
| pass@5 (`trials`) | **0 solved · 5 good-valid-fail · 0 soft-timeout · 0 task/verifier-issue · 0 in-progress-timeout · 0 infra · avg@5 = 0.000** |
| Everything else | review · similarity · validation · ratelimit · pass2 · deep_review · adversarial_review · ava_review · tier1 · qc_exec · qc_eval · qc_gate · trials · claude-cost-report · gate — **all pass** |

**The best read in the file.** Zero infra loss, zero timeouts, every trial graded. Compare §12 (`prvs`,
4 fails + 1 timeout) and §13 (`beacon`, 5 fails after one pivot): this is the first task to reach
0-solved with **no pivot and no wasted difficulty round** — the two revisions it took were both
packaging, not design (§17c).

### 17b. The load-bearing finding: the insurance axis was solved by everyone; the gcd carried 100% of it

The task shipped two axes. Axis 1 = the gcd modulus. Axis 2 = **pattern C misdirection**, used for the
first time (§14 lists C as "untried by us; strong candidate"): the shipped reader is firmware 1.4.2,
declares `SUPPORTED_FORMAT = 1`, and walks only the slot table, while the vault on disk is format 2 with
an appended journal of re-keys. Trusting it returns each slot's superseded revision-1 value — well-formed,
plausible, silently wrong.

**Agents beat axis 2 and lost on axis 1, uniformly.** The pass@2 analysis is explicit: both agents
"correctly handled the *second* trap (parsed v2 format, found the journal, identified active slot 4)" and
neither ever computed `int.from_bytes(body,"big") - trailer` or called `math.gcd()`. One flagged at step 2
that the trailer is "parsed but never used" and speculated at step 12 that it "might encode master key" —
and still never formed the residue model. pass@5 was the same homogeneous analytical failure across all
five.

**Conclusion, and it revises §14.** A *noticing* axis does not stump a frontier model; a required
**derivation** does. Version skew, unparsed trailing bytes, a stale vendor tool — all of it was seen
through by every agent, while the one step that needed a derivation nobody reached held 5/5. C is fair,
reviewer-safe and passed every fairness probe (`decisive_rule_disclosed` PASS), but on this evidence it is
**insurance that does not bite**, not a second workhorse. Do not count a C-style axis in the arithmetic.

Corollary: **we still have exactly one proven mechanism.** gcd-secret-prime is now **5-for-5** (`prvs`,
`beacon`, `record-integrity-repair`, `badge-log-forensics`, this). Every accept in this file has been
carried by it. That is a reliability asset and a concentration risk at the same time (§17e).

### 17c. Both failed rounds were self-inflicted packaging, and both were already in our own docs

- **Round 1 — static FAIL:** `non-trivial build context has a .dockerignore`. Adding `environment/data/`
  makes the context non-trivial and the check mandatory. **This is rulebook §0.6 and workflow F6, written
  down before the session started.**
- **Round 2 — Dynamo eval FAIL (30/31 PASS):** `difficulty_explanation_quality` — the field explained the
  crux well but never stated **data provenance** (synthetic vs real) or named the **real-world
  practitioner**. Both are required *in that field*, not in `instruction.md` or `[task].description`.
  **This is rulebook §6, also written down.**

Two of three runs burned on checklist items we already had. The fix is process, not knowledge: **run the
rulebook's own static list and the three-essay list as a pre-flight before the first push.** New field
lesson (rulebook §0.18 / workflow F21).

### 17d. Pipeline topology has moved — the qc stage is no longer where §15a put it

Observed job order on this repo, 2026-07-25:

```
review (static + rubric eval) · similarity · validation · ratelimit · pass2 ·
{deep_review, adversarial_review, ava_review} · tier1 · qc_exec · qc_eval · qc_gate · trials · gate
```

- **`qc_exec` / `qc_eval` / `qc_gate` run AFTER `pass2`, not between `validation` and `pass2`** (§15a,
  rulebook §0.17, F20 all state the older position). Position is pipeline-version dependent — **read the
  live job graph, do not assume**.
- **New jobs:** `ratelimit` (explicit provider-void guard, PASS), `tier1`, `claude-cost-report`.
- **§15d's qc_eval-skip fear did not reproduce.** The push carrying the fix touched only `task/task.toml`
  — metadata, not an agent-facing file — and `qc_eval` still ran and routed PASS. Do not manufacture
  agent-facing churn to feed the gate; push the real fix and read the result.
- **`gh pr checks` only lists jobs already created.** Mid-run, absent stages look like "not in this
  pipeline". Use `gh run view <id> --json jobs` for the true graph before concluding a stage is missing.
- **`concurrency: cancel-in-progress: true`** — any push while `trials` is running **cancels it** and
  forfeits the read. Freeze pushes once pass2 is green.

### 17e. What carried, confirmed

- **qc_gate cleared on the first attempt.** The §15c prescription works as stated: three graded scalars,
  each objectively single-valued (a modulus arithmetically refuted by the file if wrong, a header field,
  one record's plaintext). The one-question test remains the design gate.
- **`ava_review` PASS first try** — the §16b pre-emption recipe is confirmed, not just hoped:
  documented-complete search bounds, a round-trip re-check that re-derives every trailer, descriptive
  assert messages, and a type-strict verifier (JSON int with bools rejected). The audit found nothing
  speculative to grab and affirmed no bypass exists (`master.key` absent, 62-bit prime defeats brute
  force, the plaintext magic guards decryption).
- **Mutant-verify-first paid again (F16).** Three variants built before the first push: wrong modulus →
  fails exactly `master_key` + `recovered_secret`; v1-reader-only → exactly `recovered_secret`;
  first-journal-hit → exactly `recovered_secret`. All via wrong graded output, zero timeouts, green
  elsewhere. The two-sided pairing (naive reader vs hasty over-corrector) was built in from the start.
- **Advisory worth carrying forward:** deep_review noted `active_slot_id` is a plain header field the
  shipped reader exposes, so one of three graded fields is free. Not a bypass under all-or-nothing, but it
  means **discriminating power rested entirely on two fields**. When a graded field is free, do not count
  it toward difficulty.

### 17f. Local bar that produced this (unchanged recipe, worth keeping)

Oracle 1.0 and nop 0.0 under both harbor and the §8 mount harness · oracle x5 no flake · three mutants
each failing exactly their intended fields · full-filesystem leak sweep for the master value and the
answer secret (clean) · `.gitattributes` with `* text=auto eol=lf` plus an explicit binary line for the
shipped blob, pinned before the first add · instruction ~430 tokens · suite 0.3 s.

---

## 18. Addendum 2026-07-28: PRVS record encoder (dynamo-cfb3fed-security), the gcd baseline restated

First task of a four-task session. Security / Reverse Engineering. The mechanism that
becomes the workhorse for the whole session: a record trailer that is the payload read
as a big-endian integer, reduced by a secret 62-bit prime, with recovery only by gcd of
the differences between unreduced values and stored trailers.

### 18a. Result

pass@5 0/5 solved, 4 good-valid-fail, 1 in-progress-timeout, avg@5 0.000. Accepted, all
gates green on the run that counted. The single in-progress-timeout did not anchor but
four valid fails carried it comfortably.

### 18b. What the trials confirmed

Every agent ran a named-checksum catalogue (CRC32, CRC64, Adler32, FNV, xxHash, MD5,
SHA family) against the trailer. None matched, because the construction is synthetic.
None then formed the residue model or reached for gcd. The one adversarial trial tried
to make the shipped validator accept a forged blob and failed, because the shipped
reader parses the trailer without ever using it, so it cannot be turned into an oracle
for the graded quantity.

### 18c. The design decisions that carried

- The reader ships as a **parse-only** tool: it reads the trailer and ignores it, so
  there is no executable oracle for the checksum anywhere in the environment.
- The modulus is recovered, never carried: the reference solution runs the gcd at
  runtime rather than embedding the prime.
- Golden lives only in `tests/`, overlaid at verify. The image was swept for the prime
  as ASCII and both byte orders, clean.

This is the template the next three tasks vary.

---

## 19. Addendum 2026-07-28: VM devirtualization (dynamo-36b47e1-security), the too-easy/underdetermined wall, and the pivot that escaped it

Security / Reverse Engineering. The task that taught the wall in its sharpest form,
because it hit the wall from both sides inside one build before escaping.

### 19a. The wall, lived

The original crux was a custom register VM shipped as a stripped decode-only
disassembler plus execution traces, with three underdetermined behaviours the agent had
to recover: a truncating multiply, a signed comparison, and a register-indirect
addressing mode. The addressing mode decided the outcome, twice.

- **Rendered plainly**, the disassembler printed the operand as `[rB + disp]`, so the
  address formula was visible in the listing even though no sample used the mode.
  Result: pass@2 came back **2/2 solved**. Too easy. Both agents recovered all three
  behaviours from the listings and traces in 11 and 23 minutes.
- **Hidden**, the render was collapsed so a mode-1 operand printed identically to a
  direct one, with the mode selector moved to an unused field so no oversized operand
  gave it away. Confirmed with objdump that the decode survived optimization, so the
  information was still physically present for anyone who reversed the binary. Result:
  **qc_gate blocked it as underdetermined**, more than one reading of the mode
  reproduced every sample trace, and the gate does not accept "reverse the binary plus
  convention" as unique determination.
- The gate's own suggested fix, documenting the rule, put it straight back to too easy.

This is the wall stated in the handoff section 3: fair enough to clear qc_gate means
easy enough to solve. There is no rendering of an underdetermined addressing mode that
is both.

### 19b. The escape: pivot the crux to the gcd family

Rather than a fourth attempt at the addressing mode, the crux moved. One VM instruction
became a hash instruction whose result is a Horner fold over the register words with a
non-obvious base, reduced by a secret prime. Recovery is: read the base off a degenerate
program, then gcd the differences. The two other behaviours stayed as uncounted
insurance.

Result: pass@5 **1/5 solved, 4 good-valid-fail, avg@5 0.200**. Accepted. Every failing
agent recovered the base, assumed reduction modulo a power of two, and never attempted
gcd, even one that explicitly proved no constant satisfied the equations modulo 2^32,
which is the correct signal that the modulus is not a power of two.

### 19c. The load-bearing lesson

A determinate-but-declined crux escapes the wall that an underdetermined-but-hidden crux
cannot. The gcd modulus is uniquely fixed by the samples, so qc_gate is satisfied, and
hard only because the recovery technique is one the model does not reach for. That is the
test to apply to any crux at proposal time: not "is it hidden" but "is it determined and
declined".

### 19d. Proposal drift, declared

The shipped crux was not the proposed crux. The proposal named the addressing mode; the
build shipped the hash instruction. Declared plainly in the PR body as responsiveness to
the qc_gate block. Rubric and deep review passed on the shipped state without a drift
flag, confirming that a crux change forced by a gate reads as responsiveness rather than
deviation.

---

## 20. Addendum 2026-07-28: chunk-store forensics (dynamo-cfb3fed... second repo), the field-name disclosure, caught at Phase 9

Security / Digital Forensics. A deduplicating backup appliance whose chunk records carry
a Horner-fold trailer reduced by a secret prime; a ransomware incident corrupted one
recipe slot, and identifying the missing chunk requires the modulus.

### 20a. Result

pass@5 **0/5 solved, 5 good-valid-fail, avg@5 0.000, all 15 checks green**. Tied the
cleanest read in the corpus (vault-master, section 17). Rerun Recommended: NO.

### 20b. The lesson: a graded field's name is agent-visible surface

The task originally graded a field named `integrity_modulus`. During the Phase 9 red
team it was noticed that the name itself tells the solver the trailer is a modular
reduction, which is exactly the residue model no agent has ever formed unprompted.

The field was renamed to grade the missing chunk's own trailer instead, with the word
"modulus" removed from everything the agent can see, one hour before the push. The trial
analysis then confirmed the fix: all five agents ran the checksum catalogue, and none
formed the residue model.

**This is the highest-leverage single edit of the session.** A field named after its
mechanism gives the mechanism away. If a field cannot be named without disclosing the
crux, grade a bare value with no key.

### 20c. The base confounder answered POSSIBLY EASY

The proposal reviewer flagged plain gcd as POSSIBLY EASY, since gcd-of-differences is
known in CTF circles. The Horner-fold base answered it: reading content as a big integer
is that fold with base 2^32, so a naive gcd under the wrong base returns 1, which reads
as "nothing here" and pushes the solver back to catalogues. Benched: every wrong base
returns gcd 1, including bases adjacent to the true one, so there is no gradient to
climb toward the base.

### 20d. What carried

A stripped inspector that parses but never validates the trailer, so no oracle. Golden
in `tests/` only. Type-strict verifier rejecting non-int JSON. Symlink and realpath
guards on the output path. The generator shipped in `solution/` carrying the constants
as literals, with nothing importing it and the reference re-deriving all trailers at
runtime, the same reviewability arrangement that passed on the VM task.

---

## 21. Addendum 2026-07-28: page cache durability (dynamo-656b38e-debugging-and-repair), the repair-category structural finding, and five measurement failures

Debugging and Repair / Concurrency and synchronization debugging. The task that did not
land, and taught more per hour than the three that did. Still open at write time, blocked
at pass@2.

### 21a. The structural finding: write the correct repair first

The deliverable of a repair task is fixed code. **A defect that is hard to find is
almost always easy to fix once found.** Three separate defect designs on this task each
collapsed to a one-line correct repair, a reorder, a guard, a move. That is a property
of the category, not three unlucky picks.

The test that follows, and it costs ten minutes at proposal time: **write the correct fix
before building anything.** If it is a reorder, a guard, or a one-line move, the
difficulty is all in the finding, and finding is a noticing axis, which section 17b says
does not stump. This test would have killed the concept in Phase 3 rather than after four
days in Phase 4.

### 21b. The measurement discipline: prove a metric cannot manufacture failures

Five separate measurement failures in one build, each producing a confident wrong
conclusion before being caught:

1. **Per-seed variant comparison.** Adding a lock changes yield ordering, which changes
   RNG consumption, which re-randomises the schedule. "Seed 2 before and after" are
   different executions. Returned 7/7 "fixed" for a repair that fixed nothing. Only
   distributional comparison over the same seed range is valid.
2. **Per-worker version counters** compared incomparable sequences. 5,319 phantom
   failures.
3. **Call-time high-water mark** gave a constant background independent of correctness.
   All four variants, including a correct one, scored the same.
4. **Stale-read counter**, same shape as 3.
5. **Shutdown flush-all** flushed frames without checking ownership, so a dead tenancy
   clobbered a live durable value. Reported 3 losses on a reference that lost none.

The rule, extended from the prior "prove a metric separates correct from broken": also
**prove the metric cannot manufacture the failure it reports**, by running it against a
known-correct component and requiring exactly zero. Separation was never the weak point;
four of the five were the instrument creating the signal, and separation is blind to
that. Numbers from an unvalidated metric are withdrawn, not reinterpreted.

Corollary: **build correct first, then inject exactly one defect.** Patching a broken
component toward correct produced two defects where one was intended, untangled only by
inverting the order. A known-correct snapshot is also proof the task is solvable, which
is a hard gate.

### 21c. Loud traps funnel, silent traps score

Widening the lock livelocked in 0.1 seconds on essentially every seed. A trap the
solver's own testing catches, deadlock, stall, a reproduction that still reproduces , 
never reaches the verifier and contributes nothing to pass@5. Its only function is to
push a solver off one repair form onto another. **Only silent failures count.** This
imposes a seed-selection rule: shipped seeds are ones every wrong repair passes, held-out
seeds are ones each wrong repair fails.

### 21d. The three measured pass@2 reads

| Commit | Change | pass@2 | Breakdown |
|---|---|---|---|
| 8ab0561 | as designed | 1/2 | 1 solved, 1 valid fail, cleared |
| 0ca5ca6 | verifier hardening | 1/2 | 1 solved, 1 in-progress-timeout, blocked |
| e7e13c4 | log version restored + quiesce sentence | 2/2 | 2 solved, blocked, too easy |

The same 1/2 rate classified as a valid fail one run and an in-progress-timeout the next
is classifier variance at n=2, not a difficulty change. The 3600 s agent budget is a
hard cap, so "raise the timeout" was not an available remedy.

### 21e. The trajectory finding that inverts the design assumption

Reading the trial trajectories: **all four agents derived the mechanism by reading the
source in 2 to 4 minutes.** Localization was never the cost. 48% to 100% of each session
went to building a durability harness before any honest signal, one trial spent 91% of
its hour correctly diagnosing what instrument it needed and ran out of clock before
building it. Three of four failures were on getting the concurrent repair exactly right,
not on finding the defect.

This inverts the premise. The task assumed the defect would be hard to find. It is easy
to find and moderately hard to fix precisely. The log-version restoration (removing an
information-withholding that defended against a residency scan belonging to a previous
defect design, now defending against nothing) was the fix for the wasted-scaffolding
time, and it was correct: it hands over the symptom, not the mechanism, because the cheap
scan is off by one on half the seeds due to per-worker counter collisions.

### 21f. Disclosure of an invariant beats disclosure of a fact

A proposed instruction sentence handed over a machine-checkable residency invariant, and
a six-line scan then returned exactly one candidate from a 120,000-event log. Density is
a statistical defence; an invariant is a structural filter that cuts through any volume.
The fix was to define the target relative to the buffer the solver must identify anyway,
presupposing the hard part rather than describing it.

### 21g. The last untested lever

If resumed: the loss window is two dispatches inside the write-back. Widening the
simulated I/O yield count was measured as roughly free in runtime and moved the loss rate
for the shipped defect, but was never swept against the **near-miss repairs**
(snapshot-and-recheck done slightly wrong). The question is whether a width exists where
the near-miss family fails while the correct reference stays clean. If it does, that is a
one-constant fix with no redesign, no new graded field, and no essay rewrite. This was
the open action when the session ended.

### 21h. Assets that survive regardless of outcome

A deterministic cooperative scheduler with proven byte-identical replay. A livelock
detector, an event-based ceiling structurally cannot see a livelock, since the signature
is millions of dispatches producing almost no events. A validated end-state durability
audit. All three are reusable in any future concurrency task.

---

## 22. Cross-session synthesis (2026-07-28)

Twenty-one tasks recorded, eight of them ending in an accept. The through-line, stated
once:

**The only mechanism that has reliably stumped a frontier model is a required
derivation the model declines to attempt.** Concretely, gcd recovery of a secret prime
modulus, six for six. Everything else, misdirection, version skew, hidden fields,
suspicious code patterns, hard-to-find defects, is a noticing axis, and frontier models
notice.

The corollaries, each earned:

- **Determinate-but-declined, not hidden.** Hidden fails qc_gate as underdetermined.
  Determined-and-declined passes qc_gate and still stumps. (Section 19.)
- **A graded field's name discloses its mechanism.** (Section 20.)
- **In repair tasks, hard-to-find implies easy-to-fix.** Write the correct repair first;
  if it is one line, the task is a trace task. (Section 21a.)
- **A metric can manufacture the failure it reports.** Prove it cannot, against a
  known-correct component, before trusting a number. (Section 21b.)
- **Loud traps funnel, silent traps score.** (Section 21c.)
- **The gcd family is a concentration risk.** Six accepts on one mechanism against an
  explicit offboarding warning on submission similarity. Diversify the surface, and
  hunt a second proven mechanism while the first is still available as a fallback.

The open strategic question: whether any mechanism other than gcd can hold. The
concurrency task was the first attempt at one and did not land, but it produced the
repair-category and measurement-instrument findings, which are transferable. The next
hunt is a category where the model's default toolkit is a catalogue and the answer needs
arithmetic the catalogue does not contain, File and Media Operations, sub-category audio
or image, is the current best candidate.
