# Ohio Community Capacity Fund - certification review FAQ

Maintained by the program office for reviewers working the FY2027 cycle. The directive
(grant_policy.docx) controls where this page and the directive differ.

**An applicant is listed in the master file under a group exemption (GROUP is not 0000). How is it reviewed?**

On its own EIN, the same as any other applicant. A group exemption letter covers exempt
status for a central organization and its subordinates. It does not place a return for
the subordinate in the review corpus, and the corpus contains no group returns. The AFFILIATION
field says what role an EIN plays in its group: codes 6 and 8 mark central organizations, 7
intermediates, and 9 subordinates (definitions in eo-info.pdf). If no return is on file for
the applicant's own EIN, test 3 of the directive applies regardless of group role.

**The extract editions are labeled 2022, 2023, and 2024. Are those fiscal years?**

No. An edition collects the returns IRS processed in that calendar year. A return for a tax
period ending June 2023 can sit in the 2023 or the 2024 edition depending on when it was
processed, and an organization's most recent return is not always in the most recent
edition. The tax period column on the return row (tax_pd on the Form 990 extracts, taxpd on
the 990-EZ extracts) is the fiscal identifier. The edition year is not.

**The master file also carries revenue, income, and asset amounts. What are they?**

Per eo-info.pdf, REVENUE_AMT is the Part I revenue line of the latest return the IRS has
posted, and TAX_PERIOD names that return's period. The master file refreshes monthly.

**The directive says the certification basis is unchanged from FY2026. What was the FY2026 round?**

The FY2026 round ran in September 2025 on the extract editions then available, processing
years 2022 and 2023, with the same tests, thresholds, tiers, and grant amounts. Its
recency line was a tax period ending January 2021 or later. The register as published
(prior_cycle_register.csv) carries each FY2026 applicant's outcome and, where one was
computed, its support share to four decimal places. The FY2026 working papers are not
part of this corpus. The register is the reference point (directive 3b): the basis is
whichever reading reproduces it.

**A return shows contributions larger than total revenue. Is that an error?**

Usually not. Total revenue nets losses against income, so a negative line such as an
investment loss or a loss on sale of assets can pull total revenue below contributions. The
support share is reported as computed, to four decimal places, even above 1.0000. A return
with zero or negative total revenue fails the revenue floor, and no share is computed for it.

**The same return appears in two editions. Which one counts?**

It counts once. Editions occasionally repeat a row when a return is reprocessed. A return
is identified by EIN, tax period, and form type.

**Applications ask for annual revenue and support share. Why collect figures certification does not use?**

Intake triage and workload planning. Applicants estimate in good faith, but definitions
vary (some include in-kind support or pledge commitments) and the figures are not audited.
The pre-screen worksheet uses them.

**Why a January 2022 recency line?**

Certification pays FY2027 funds against demonstrated recent operations. A most recent
return with a tax period ending before January 2022 is more than four fiscal years old at
award. The line is a test on the return's tax period, not on when IRS processed the return.

**What do the standing codes mean?**

STATUS 01 is unconditional exemption and 02 conditional. Code 12 marks trusts described in
section 4947(a)(2), and 25 marks organizations terminating private foundation status.
Definitions are in eo-info.pdf. Only STATUS 01 passes test 2 of the directive.

**Column names differ between the Form 990 and 990-EZ extracts. Where is the mapping?**

In 24eofinextractdoc.xlsx, one sheet per form. Section 6 of the directive fixes the three
fields certification uses on each form. Header spelling and case are as issued by SOI and
vary across editions. Read the files as they are.
