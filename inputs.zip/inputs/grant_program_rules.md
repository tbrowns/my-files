# FY2026 Secondary Success Grant Program
## Program Rules and Certification Requirements. Final, adopted for the FY2026 cycle.

Grants Administration Unit. This document governs eligibility certification for the FY2026
cycle. Where this document is silent, the Program FAQ controls.

---

### 1. Purpose and awards

The Secondary Success Grant supports supervisory unions and supervisory districts with weak
secondary completion outcomes and below-midpoint spending capacity. The program makes exactly
three (3) awards of $750,000 in each cycle. Awards are not divided.

### 2. Applicant units

An applicant unit is a Vermont local education agency of type "Supervisory union" whose
operational status is Open, New, or Reopened in the most recent final (version 1a) Common Core
of Data LEA universe file included in the certification workspace. Component school districts are not
separate applicants. Their data roll up to their supervisory union as provided in Section 4.

### 3. Graduation criterion

3.1 The graduation measure is the four-year adjusted cohort graduation rate (ACGR) as reported
to the U.S. Department of Education under ESSA, at the LEA level, for the three most recent
school years for which LEA-level ACGR files are included in the certification workspace
(the "window").

3.2 The unit's window value is the cohort-weighted combination of its reported annual values.
A reported value that is a range or a bounded value is applied as a closed interval: a value
reported as "a-b" is [a, b], "GEx" is [x, 100], and "LTx" and "LEx" are [0, x]. Weighting
intervals means weighting their endpoints.

3.3 A unit certifies below the benchmark only if the upper endpoint of its weighted interval is
strictly below 80.0. Comparisons are made at one decimal place.

3.4 Reorganized units. For each window year, a unit's value combines the reported values of all
of its constituent reporting identities for that year, weighted by cohort, as evidenced by the
reorganization records in the workspace. A constituent identity that never carried a reportable
ACGR (no secondary cohort) is disregarded. If a constituent identity with an ACGR reporting
history lacks a reportable all-students value for a window year, including a value withheld as
"PS", the unit is ineligible pending data for this cycle. A change in school-building
assignment that does not end a reporting identity is not a reorganization for purposes of this
rule.

### 4. Spending criterion

4.1 The spending measure is per-pupil current expenditure (PPE): the sum of current elementary
and secondary expenditure (TCURELSC) divided by the sum of fall membership (V33) across the
unit's component school districts, from the FY2021 School District Finance Survey (F-33) file
in the workspace. FY2021 is the fiscal year aligned with the final cohort year of the
graduation window. F-33 amounts are whole dollars. See the NCES documentation in the workspace.

4.2 Component membership follows the UNION code assignments in the same final universe file used
in Section 2. A component record carrying an NCES nonreporting code (a negative value, per the
F-33 documentation) in either TCURELSC or V33 is excluded from both sums. A unit whose
remaining components sum to zero membership has no determinable PPE and is ineligible pending
data.

4.3 A unit satisfies the spending criterion if its PPE is strictly below the statewide median
PPE across all applicant units with determinable PPE. The median of an even count is the mean
of the two central values. PPE values are whole dollars.

### 5. Eligibility, ranking, and certification

5.1 A unit is eligible if it certifies below the benchmark (3.3), satisfies the spending
criterion (4.3), and is not ineligible pending data under 3.4 or 4.2.

5.2 Eligible units are ranked by weighted-interval upper endpoint, ascending. Ties break by PPE
ascending, then window cohort total descending, then LEAID ascending.

5.3 The first three ranked units are certified for award. The certification package states the
slate in priority order and accounts for every applicant unit in exactly one class: funded,
eligible but not funded, certifiable but at or above the median, not certifiable, or pending,
with the reason.

### 6. Data authority

The certification workspace is the sole data authority for this cycle. No figure may rest on
materials outside it. Where two workspace sources conflict, the source these rules designate
controls.

---
Scenario document prepared for the FY2026 certification exercise. Program identities and awards
are fictional. Data sources are genuine public files. Recorded as a scenario document in
data_dictionary.json.
