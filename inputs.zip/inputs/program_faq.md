# FY2026 Secondary Success Grant. Program FAQ, certification cycle.

**Q1. Several units' federal graduation rates are published as ranges, for example "80-84" or
"GE90". May we average midpoints?**
No. Certification under Rules 3.3 requires that the data cannot support a value at or above the
benchmark. Ranges are applied as closed intervals (Rules 3.2), and the upper endpoint of the
weighted interval governs. A unit whose weighted interval includes 80.0, or anything above it,
does not certify below the benchmark. Its midpoint is irrelevant.

**Q2. The state education dashboard shows graduation rates for years and units the federal files
do not cover. May those values fill the gaps?**
No. Rules 3.1 and 3.5 fix the graduation measure to the LEA-level federal files in the
workspace. Dashboard values are published on a different basis and are revised in place without
versioning. They do not satisfy the reportable-value requirement. A unit lacking a reportable
federal value for a window year, after the crosswalk in Rules 3.4, is ineligible pending data.

**Q3. How are units treated whose reporting identity changed during the window? Mergers,
supervisory-union reorganizations, and the like.**
Per Rules 3.4, each window year combines all constituent reporting identities per the
reorganization crosswalk memorandum. The requirement runs at the identity level. If a
constituent identity with an ACGR reporting history did not report for a window year, the
successor is ineligible pending data. A school-building move that does not end a reporting
identity does not trigger 3.4.

**Q4. The F-33 file shows negative values, for example -2, for some districts and for
supervisory union central offices. Are those dollar amounts?**
No. Negative entries are NCES nonreporting codes, defined in the F-33 survey documentation in
the workspace. Rules 4.2 excludes them, and a supervisory union's PPE is built from its
component school districts, not from a central-office record.

**Q5. Is the median in Rules 4.3 computed before or after the graduation screen?**
Before. The median runs across all applicant units with determinable PPE, whatever their
graduation classification, and is stated in whole dollars.

**Q6. What if fewer than three units are eligible?**
All eligible units are certified and the cycle records the shortfall. Not applicable if three
or more units are eligible.

**Q7. May the preliminary (version 0a) universe file supply the applicant roster?**
No. Rules 2 requires the most recent final (version 1a) universe file. Preliminary directory
releases are identified as such in their release notes and in their file names.

---
Scenario document prepared for the FY2026 certification exercise. Recorded as such in
data_dictionary.json.
