# FY2026 Secondary Success Grant. Program FAQ, certification cycle.

**Q1. Is the median in Rules 4.3 computed before or after the graduation screen?**
Before. The median runs across all applicant units with determinable PPE, whatever their
graduation classification, and is stated in whole dollars.

**Q2. What if fewer than three units are eligible?**
All eligible units are certified and the cycle records the shortfall. Not applicable if three
or more units are eligible.

**Q3. When are awards disbursed?**
In two payments: sixty percent within thirty days of board approval, the balance on acceptance
of the unit's first-year expenditure report. Disbursement mechanics do not affect eligibility
or certification.

---
Scenario document prepared for the FY2026 certification exercise. Recorded as such in
data_dictionary.json.
