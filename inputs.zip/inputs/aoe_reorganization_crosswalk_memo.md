# Reference memorandum. Vermont school district reorganization, 2016-2024, and federal reporting.

Grants Administration Unit, compiled June 2025. Background for certification and planning work
touching years that span the Act 46 reorganization. Sources: the Vermont Agency of Education
merger-activity page and State Board of Education final order materials, the NCES Common Core
of Data LEA universe files, and the Vermont Education Dashboard.

## 1. Background

Under Act 46 (2015), Vermont school districts merged in waves. Unified districts became
operational on 7/1/2016 (4 districts), 7/1/2017 (8), 7/1/2018 (17), and 7/1/2019 (3 voluntary).
The State Board of Education's final order of November 2018 merged 45 districts in 39 towns
into 11 new union districts and enlarged 3 existing unions, effective 7/1/2019. The SY2018-19
CCD universe records 91 Vermont LEA closures effective 12/07/2018. The SY2019-20 universe
records 19 new LEAs effective 12/18/2019. Supervisory unions themselves were reorganized in
the same period: several supervisory-union offices closed or merged effective with the
7/1/2019 wave, and their member districts and schools were reassigned among the continuing and
newly formed supervisory unions.

Separately, federal ACGR reporting for Vermont moved from district-level identities to
supervisory-union-level identities beginning with SY2017-18. Files for SY2015-16 and SY2016-17
carry rates under district identities, union high school districts and town districts alike.
Files from SY2017-18 forward carry rates under supervisory union and supervisory district
identities.

## 2. Records

The reassignments themselves are matters of record in the workspace files: the per-year CCD
universe files carry each agency's operational status and effective dates, and the state's
own published data carries school-by-school organizational assignments by year. This office
has not maintained a separate consolidated crosswalk; analysts working across the
reorganization should establish continuity from those records.

---
Scenario document prepared by program staff for this exercise, compiled from the public
sources named above. Recorded as a scenario document in data_dictionary.json. Verify against
the Agency of Education's published merger materials before external use.
