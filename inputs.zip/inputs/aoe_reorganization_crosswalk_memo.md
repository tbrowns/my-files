# Reference memorandum. Vermont supervisory-union reorganizations and federal reporting identities, 2016-2024.

Grants Administration Unit, compiled June 2025 for the FY2026 Secondary Success certification
cycle. Sources: the Vermont Agency of Education merger-activity page and State Board of
Education final order materials, the NCES Common Core of Data LEA universe files, and the
Vermont Education Dashboard. This memorandum is the crosswalk referenced by Program Rules 3.4.

## 1. Background

Under Act 46 (2015), Vermont school districts merged in waves. Unified districts became
operational on 7/1/2016 (4 districts), 7/1/2017 (8), 7/1/2018 (17), and 7/1/2019 (3 voluntary).
The State Board of Education's final order of November 2018 merged 45 districts in 39 towns
into 11 new union districts and enlarged 3 existing unions, effective 7/1/2019. The SY2018-19
CCD universe records 91 Vermont LEA closures effective 12/07/2018. The SY2019-20 universe
records 19 new LEAs effective 12/18/2019.

Separately, federal ACGR reporting for Vermont moved from district-level identities to
supervisory-union-level identities beginning with SY2017-18. Files for SY2015-16 and SY2016-17
carry rates under district identities, union high school districts and town districts alike.
Files from SY2017-18 forward carry rates under supervisory union and supervisory district
identities.

## 2. Identity crosswalk: supervisory-union identities ended by reorganization

The table lists each supervisory-union reporting identity that ended during or after SY2017-18
and the successor identity or identities its members joined, effective SY2019-20 unless noted.
State identifiers are as they appear in ST_LEAID in the federal files and in the state
dashboard.

| Ended identity | Successor identity (members joining) |
|---|---|
| SU008 Caledonia North | SU067 Kingdom East (all members) |
| SU018 Essex-Caledonia | SU067 Kingdom East (Concord, Lunenburg); SU009 Caledonia Central (Waterford) |
| SU029 Orange North | SU068 Central Vermont (all members, incl. Williamstown) |
| SU037 Rutland Central | SU066 Greater Rutland County (all members, incl. Proctor, West Rutland) |
| SU038 Rutland Southwest | SU066 Greater Rutland County (all members, incl. Poultney) |
| SU041 Washington Northeast | SU009 Caledonia Central (Cabot, Twinfield) |
| SU043 Washington South | SU068 Central Vermont (Northfield); SU069 Montpelier Roxbury (Roxbury) |
| SU045 Montpelier | SU069 Montpelier Roxbury (all members) |
| SU057 Blue Mountain | SU027 Orange East (Blue Mountain USD #21) |

Corroboration: school-building assignments by year in the Vermont Education Dashboard extract
(supervisoryunionidentifier, by school and year) and the LEA operational-status codes with
effective dates in the SY2018-19 and SY2019-20 CCD universe files.

## 3. Notes relevant to certification

White River Valley (SU030) continued as the same reporting identity across the period but has
no LEA-level federal ACGR record for SY2018-19. Battenkill Valley (SU060) and Washington
Northeast (SU041) do not appear in the SY2023-24 final universe. Lincoln (SU070) and the Stowe
town district first appear as operating LEAs after the FY2021 F-33 collection. District-level
identities appearing only in the SY2015-16 and SY2016-17 ACGR files, the union high school
districts and town districts, are predecessors of the supervisory-union identities above at the
grain described in Section 1. They are provided for history and verification.

---
Scenario document prepared by program staff for this certification exercise, compiled from the
public sources named above. Recorded as a scenario document in data_dictionary.json. Verify
against the Agency of Education's published merger materials before external use.
