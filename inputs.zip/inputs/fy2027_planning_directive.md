# FY2027 Planning Directive. Secondary Success at-risk reserve.

Grants Administration Unit, June 2025. This directive supplements the FY2026 Program Rules for
one purpose: sizing the FY2027 at-risk reserve. Definitions not restated here carry their
Program Rules meanings.

## 1. Purpose and commitment

The finance committee must commit, before the FY2027 budget goes to the board, a reserve of
$250,000 for every applicant unit projected to be at risk in FY2027. The commitment is one
total dollar figure and the named list of units behind it. The reserve is sized on outcome risk
alone. Spending position does not gate it, though per-unit spending is reported for context.

## 2. Population

The planning population is the applicant pool defined in Rules 2, from the same universe file.

## 3. Projection convention

3.1 A unit's projection base is its reportable all-students value, in interval form under Rules
3.2, for each of the four school years SY2017-18 through SY2020-21, combined across constituent
identities under Rules 3.4. A unit lacking any of the four base years is planning-pending and
is excluded from the reserve, with the reason reported.

3.2 The SY2021-22 value is projected one step beyond the base period by least squares fitted
to each endpoint of the interval series against a year index. The projected interval runs from
the smaller to the larger of the two projected endpoints, bounded to the range 0 to 100.

3.3 The FY2027 planning value is the cohort-weighted combination of the SY2019-20 value, the
SY2020-21 value, and the projected SY2021-22 value. The projected year carries the SY2020-21
cohort as its weight.

3.4 A unit is at risk if the upper endpoint of its FY2027 planning value is strictly below
80.0, compared at one decimal place.

## 4. Reporting

The reserve certification accounts for every unit in the planning population in exactly one
class: at risk, not at risk, or pending with the reason. Each unit's FY2021 per-pupil current
expenditure, computed per Rules 4, is reported as information beside its classification.

---
Scenario document prepared for the FY2027 planning exercise. Recorded as a scenario document in
data_dictionary.json.
