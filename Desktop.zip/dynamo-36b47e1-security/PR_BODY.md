## One-sentence problem

The task is done when the agent has recovered the semantics of an undocumented
register virtual machine well enough to compute the exact final state (register file
plus emitted output) of all six held-out challenge programs.

## Success criteria

For each challenge program `c01` through `c06`, the agent writes
`/app/output/<id>.json`:

1. The file exists and is a JSON object with a `regs` map (keys `r0` through `r7`)
   and an `output` list.
2. `regs` holds the final value of all eight registers when the program halts, each
   an unsigned decimal integer, matching the reference exactly.
3. `output` holds the values the program emitted, in emission order, each an unsigned
   decimal integer, matching the reference exactly.

Grading is exact integer equality on every register and every emitted value, for all
six programs. There is no tolerance band: each final state is a deterministic function
of the program and its input.

## Calibration results

- `oracle`: reward 1.0, twice from a clean checkout.
- `nop`: reward 0.0.
- Agent image verified clean: no reference interpreter, solution, or golden states are
  present. The shipped disassembler is a stripped, statically linked binary that only
  decodes.

## How to run

From `task/`:

- `harbor run -p . --agent oracle`  (expect reward 1.0)
- `harbor run -p . --agent nop`     (expect reward 0.0)

## Notes

The difficulty is oracle-free semantic recovery: no interpreter ships, so a wrong
model produces a plausible state and nothing contradicts it. Three instruction
behaviours are underdetermined by the common cases and must be recovered from the
sample traces and the disassembler's decode, then reconciled against every sample.
Each was verified to be discoverable from what ships, and a one-decision mutant per
behaviour fails only the challenge programs that exercise it.
