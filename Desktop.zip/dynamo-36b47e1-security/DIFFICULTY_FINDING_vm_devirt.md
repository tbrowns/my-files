Difficulty finding: VM devirtualization (Security / Reverse Engineering) sits on the capability line

Repo: dynamo-36b47e1-security. PR #4. Stopped 2026-07-23 after the hardened version was
blocked by the soundness gate. Local working note, not part of the submission.

Task. Recover the semantics of an undocumented register VM from a stripped, decode-only
disassembler and execution traces for 24 sample programs, then compute the exact final state
of 6 held-out programs. No interpreter ships, so it is oracle-free. Three behaviours are
underdetermined by the common cases: a multiply that reduces modulo the register width, signed
two's-complement ordered comparisons, and a register-indirect memory addressing mode. The
first two are recoverable only from traces; the addressing mode (call it D2) is the axis that
decided the task, and it is where it broke.

Two readings of D2 were tried.

1) Readable. The disassembler renders the mode explicitly as [rB + disp], so the
   effective-address formula (EA = base + displacement) is visible in the listing even though
   no sample program uses the mode.
   Read: pass@2 came back 2/2 solved. Both trial agents recovered all three cruxes from the
   disassembler output plus the sample traces and solved in roughly 11 to 23 minutes. The
   analysis called the approach "the natural path that falls out of the provided tools."
   Verdict: too easy.

2) Hidden. The disassembler renders the mode-1 operand identically to a direct operand
   ([0x0200]), so neither the listing nor the traces reveal it; recovering the base-plus-
   displacement semantics requires reversing the stripped binary's decode plus standard
   convention. The mode selector was relocated into an unused register field so there was no
   anomalous-operand shortcut, and the mode/base decode was verified present in the compiled
   stripped binary via objdump.
   Read: a new soundness gate (Per-Check QC) judged it underdetermined and unfair, and blocked
   before pass@2 ran. More than one reading of the mode-1 addressing reproduces all 24
   disclosed sample traces and diverges on the graded inputs c02 and c04, and no sample
   exercises the mode, so nothing agent-visible pins it. The gate does not accept "reverse the
   binary plus convention" as unique determination.

Conclusion. The deciding axis has no fair-and-hard rendering. When the mode is visible enough
to be fair, a frontier model transcribes it and the task is too easy. When it is hidden enough
to be hard, it is judged underdetermined and unfair. The gate's own suggested fixes
(disambiguate in instruction.md, or add a sample that pins the formula) both disclose the rule
and return it to too-easy. The other two axes are execution semantics recoverable only from
traces, which the model also transcribes. So this RE shape sits on the model's capability
line: every fair rendering of the crux is transcribed, every hard rendering is underdetermined.
Stopping here rather than running a third round.

Verifier finding worth sharing (not the reason for stopping). The soundness gate also flagged
a symlink hole in the verifier. Because the golden is overlaid at /tests only at verify time,
an agent can create /app/output as a symlink to /tests/golden: it dangles during the agent run
and resolves at verify time, so the verifier reads the reference answers as the agent's output
and scores 1.0 without solving. Fix: resolve realpath in the verifier and reject graded outputs
that are symlinks or escape /app before scoring (tamper independence). This was a real bug, but
it was not why the task was stopped; the difficulty wall above was.
