# Build brief: dynamo-36b47e1-security (VM devirtualization)

Local working doc. Gitignored, never submitted. Companion to
PROPOSAL_APPROVED_vm_devirt.md, which is the locked concept. This is the design
guidance for turning it into a task that bites and is fair.

Second task. The PRVS cycle is submitted and accepted. Carry the lessons, not the
files. Everything below assumes you have read the four build items in the
approved-proposal record; this brief is how to execute them.

---

## 0. The distinctness line, because it is now existential

The platform warned that repeated or near-identical submissions get a contributor
offboarded. This task is safe on mechanism: PRVS reversed a data format and
recovered a checksum constant; this reverses execution semantics of a VM. Keep it
that way. Do not let the build drift toward "recover an encoding" framing. The
instruction, the artifact, and the crux are all about what instructions do, not
how data is laid out. If any part starts to read like a serialization-format
task, stop.

Shared methodology is fine and unavoidable: stripped artifact plus samples plus
held-out, exact-match verifier, no oracle, silent latent crux. That is how good
RE tasks are built, and it is not what the similarity check flags. The check
flags the same task twice. A VM-semantics task is not the same task as a
format-codec task.

---

## 1. The risk that decides this task

Same structural risk as PRVS, one level more subtle. In PRVS the danger was a
shipped tool that could confirm the graded quantity. Here the danger is the same
in a new dress: **anything that lets the agent execute a held-out program is an
oracle, and an oracle kills every latent crux at once.** The moment an agent can
run a held-out program and read its output, the truncating multiply and the
addressing mode stop being silent, because you just execute the edge case and
watch.

So the load-bearing design decision is: no interpreter ships, and the
disassembler decodes but never executes. Guard this like the PRVS trailer. Before
counting any crux, answer one question per crux: if the agent had only what ships,
could they discover this behavior by running something? The answer has to be no.

Two ways an agent could manufacture an oracle you did not intend, and both need
closing at build time:

- **Building an interpreter is fine and expected**; that is the task. It is only
  an oracle if it is correct, and a correct interpreter requires the very
  semantics being tested. An interpreter built on a wrong model of the multiply
  produces wrong held-out states and nothing reveals the error. Good. Leave it.
- **Reconstructing an executor from the disassembler binary.** If the
  disassembler shares code with an executor, or contains dead execution paths, an
  agent could lift them. Ship a disassembler that genuinely only decodes:
  no handler bodies, no dispatch-to-execute, no embedded reference outputs.
  Verify with strings and a skim of the disassembly that no execution logic and
  no golden state is present in the shipped binary.

---

## 2. Fairness is the gate that can sink this one

PRVS was hard to make bite. This one is hard to keep fair. The reviewer flagged
it directly: a latent behavior is only a crux if an expert seeing what the agent
sees can recover it. Two of the three axes need explicit fair-evidence sourcing,
and it is not the same source for each.

- **Truncating multiply.** Fair evidence lives in the traces. This means at least
  one sample program must overflow the multiply and show the truncation in its
  final state, so a reverser who reconciles every trace can recover it. It must
  be subtle, not absent: most samples stay in range, a few overflow. If zero
  samples overflow, the behavior is underdetermined and the task is unfair. Bench
  this: run the reference, confirm at least a couple of samples exercise the
  truncation, and confirm the held-out set leans on it heavily.
- **Register-indirect addressing mode.** Fair evidence lives in the
  disassembler's decode. The decode must expose which operand field is the base
  register and any displacement or scale, so the address formula is inferable
  without executing. If the decode alone underdetermines the formula, add a
  sample program that uses the mode in a way that constrains the address
  arithmetic, without revealing the held-out table-lookup use. This mirrors the
  PRVS varint, where the reader's parse loop was the fair evidence for a rule no
  sample exercised.
- **Third axis (add one).** Whichever you pick, decide its fair-evidence source
  before building it. A signed-versus-unsigned comparison is fair via traces:
  include samples where operands of both signs make the branch direction
  determinable, but keep it subtle. A shift that masks its count is fair via
  traces too: include a sample that shifts by an amount at or above the register
  width so the masking shows, without making it obvious.

The fairness test for each axis: could a competent reverser, seeing only what
ships, arrive at this behavior with certainty rather than a guess? If any axis is
a guess, it is not a difficulty axis, it is a coin flip, and it fails the
unambiguous gate.

---

## 3. The output schema, because a format loss is the worst kind

The reviewer's top spec item. A correct reversal that fails on register naming or
integer encoding is an unfair loss and it pollutes the pass@5 read, because it
looks like a difficulty fail when it is a format fail. Pin it hard, and pin it in
instruction.md where the agent sees it, since a schema is specification, not a
crux hint.

Decide and document, before writing the verifier:

- Which registers are reported, and in what order. Report the full architectural
  register file, named consistently (r0..rN), fixed order.
- Integer encoding: signed or unsigned, and width. State it. The verifier and the
  reference must agree, and the agent must know which. Recommend reporting each
  register as a decimal integer under a stated width and signedness, so there is
  no byte-order ambiguity at all.
- How emitted output is serialized: if the VM can emit values during a run,
  define the exact JSON shape (an ordered list of integers, same encoding).
- Ship a filled example. Take one sample program, run the reference, and include
  its /app/output/<id>.json verbatim in the task materials so the agent has an
  unambiguous target shape. This single example removes the entire class of
  format-mismatch failures.

Compare parsed values in the verifier, not raw bytes: load the agent's JSON,
compare integers to the golden integers. That keeps a correct reversal from
failing on whitespace or key order, exactly the comparison hygiene PRVS used.

---

## 4. The arithmetic, updated for three axes

Gate: at least 3 fails of 5, with at least 1 good valid fail as the anchor. Soft
timeouts fill the count but cannot anchor; infra timeouts count for nothing.

PRVS shipped three axes and landed four good-valid-fails, with an analytical
per-axis rate that put three axes around 0.58 of at least one biting. This task
started at two axes; the reviewer's recommended third is the difference between
sitting at the line and sitting above it. Build three, mutant-verify each, and
expect one may prove weak on the bench.

Also budget for meta-gate variance: pass2 runs n=2, so a p around 0.5 trap clears
it about three quarters of the time. Losing one read to luck is normal and is not
a signal to change the task.

---

## 5. Mutant-or-it-did-not-happen, per axis

For each of the three behaviors, build the one-decision-different reference and
confirm it fails exactly the intended tests and nothing else:

- multiply that does not truncate (full-width product): must fail exactly the
  held-out programs that overflow, and reproduce every sample.
- addressing mode modeled as direct instead of register-indirect: must fail
  exactly the held-out programs that use the mode.
- the third behavior's wrong reading (e.g., unsigned compare where it should be
  signed, or an unmasked shift): must fail exactly the held-out programs that
  exercise it.

If a mutant reproduces every held-out program too, that axis does not bite and
the held-out set does not exercise it enough. Fix the held-out set, not the test.
This is the check that certified the real cruxes and killed a dud on PRVS.

---

## 6. Carried constraints that bite hardest here

- **`tests/` and `solution/` must never appear anywhere in the Dockerfile,
  including comments.** Dynamo static checks are plain-text grep. This exact
  thing cost a review cycle on PRVS. Write "the verifier" in comments, never the
  path.
- **Wrong output, never a clock-out.** A timeout counts for nothing and blocks
  the read. Keep the held-out set small enough that computing states, once the
  semantics are known, is quick. The difficulty is the reversal, not the volume
  of programs. If writing the interpreter plus running eighteen programs starts
  to strain the agent budget, cut the count.
- **Pre-pay boilerplate.** Give the agent the output-writing scaffold, the
  challenge loader, and the paths, so its hour goes to reversing, not plumbing.
- **3600s is the hard agent ceiling** for pass2 and pass@5. Older 900s text is
  stale.
- **Ground truth lives in `tests/`,** overlaid only at verify time. The reference
  interpreter and the golden states never sit in `environment/`.
- **No answer reachable from the image.** Verify with a find, and confirm no
  golden state and no execution logic ships in the disassembler binary. A
  stripped decode-only disassembler is fine; anything that executes is not.
- **No "You have N seconds" closing line** in instruction.md.
- **Humanize everything a reviewer reads, no em dashes:** instruction, the three
  essays, README, PR body, reviewer notes.
- **Do not edit the pre-seeded task.toml fields:** category, subcategory,
  model_tested (Opus-4.8), agent_tested (Terminus-2).

---

## 7. Phase plan

**Phase 4.** Author the reference interpreter and the disassembler (decode-only).
Design the ISA: the common opcodes plus the three underdetermined behaviors.
Generate sample programs and traces such that the two trace-fair cruxes are
exercised subtly and the decode-fair crux is enumerable. Generate the held-out
programs and their inputs, leaning on all three axes. Run the fairness bench from
sections 2 and 3 and record the numbers here. Pin the output schema and produce
the filled example. Get the oracle to 1.0, twice, from a clean checkout. Then
write the numbered success-criteria list.

**Phase 5.** One pytest function per criterion, docstringed, asserting on parsed
JSON from /app/output. Then the three-mutant matrix from section 5.

**Phase 6.** Single Dockerfile, digest-pinned allowlisted base, pip pinned, apt
unpinned, `.dockerignore` present, `mkdir -p` for output parents, no `tests/` or
`solution/` string anywhere in it.

**Phase 7.** instruction.md under 1500 tokens, absolute paths, WHAT not HOW.
Disclose the output schema and what the agent has (held-out bytecode and inputs);
do not disclose the three behaviors. Fill task.toml: non-empty description, the
three essays, task_objective and artifact_type from the taxonomy.

**Phase 8.** Full local validation from a clean checkout, twice.

**Phase 9.** In-chat red team before the PR.

The gate to leave Phase 4 is a pasted oracle reward of 1.0 from a clean checkout,
plus the recorded fairness-bench numbers showing every axis is recoverable from
what ships. Not a belief that it would probably work.

---

## 8. Fairness-bench record (2026-07-22, Phase 4 pre-oracle)

Reference build lives in `task/solution/vm/` (isa/asm/interp/disasm/programs) with
`bench.py` reproducing everything below. ISA: 8 regs r0..r7, 32-bit, word-addressed
memory, 16 opcodes. 16 sample programs (traces are the shipped evidence) and 6
held-out programs (2 per axis, single-axis each for clean mutant isolation). Third
axis chosen and KEPT: signed-vs-unsigned comparison (D3 cleared the distinguishable-
outcome bar, so no switch to the count-masking shift).

Bench result: **11/11 checks passed.**

- **D1 (truncating multiply, evidence = traces).** 3 observable overflow samples
  (bar was >=2). Each refutes a plain multiply (observed != true product).
  `gcd(true - observed)` over the three = **4294967296 = 2**32** exactly; max
  observed result = 2147581952 (0x80018000), which has bit 31 set, so a mod-2**31
  reading is ruled out. Modulus pins **uniquely to 2**32**. Latency preserved:
  only the 3 designated samples wrap, and only via MUL; every other sample stays
  in range so the width is not obvious.
- **D2 (register-indirect mode, evidence = decode).** Samples use mode-1 zero
  times; held-out uses it 3 times. Disassembler renders mode 1 as `[rB + disp]`
  (e.g. `LOAD r3, [r1 + 512]`, parsed base/disp = (r1,512),(r5,512)) and direct as
  a distinct `[0x....]` form. Base and displacement are unambiguous; word-addressed
  + no scale means EA = base + disp follows from standard convention.
- **D3 (signed comparison, evidence = traces).** Both disambiguation samples give
  two clearly distinct observable outcomes: `cmp_signed_negone` signed->[200] vs
  unsigned->[100]; `cmp_signed_boundary` signed->[11] vs unsigned->[22]. Held-out
  under an unsigned model produces wrong-but-finite output (signed_branch
  [2000] vs [1000]; signed_select [7] vs [9]) - no infinite loops, because
  high-bit operands are MOVI-loaded (independent of the truncation choice).
- **Independence preview (design, not the real-verifier matrix).** Each one-decision
  mutant changes exactly its own axis's held-out: no-truncate-MUL -> {mul_overflow_chain,
  mul_overflow_poly}; direct-only-mem -> {table_lookup, store_indirect}; unsigned-
  compare -> {signed_branch, signed_select}. Clean isolation holds in the reference
  harness; Phase 5 re-runs this against the actual pytest verifier.

**One flagged correlation to watch at Pass@5 (not a fairness failure).** D1 and D3
share the fact "registers are 32-bit": recovering the signed comparison logically
reveals the width, which could nudge an agent to truncate MUL. It is a reasoning
link, not an automatic one (an agent can implement signed compare with a 2**32 sign
term yet still forget to mask MUL), and D2 is fully independent of both. Kept D1
overflow evidence and D3 disambiguation on separate programs/registers so the
mutant matrix stays clean; will read whether D1 bites independently in trials.

**Oracle wired and passing (2026-07-22).** Full loop stood up:
environment/data (16 samples + traces, 6 challenge bytecode+inputs, decode-only
disassembler, filled example_output.json), solution/solve.sh + solve.py + vm
modules, tests/test_outputs.py (6 functions: present/registers/output + one
discriminator per axis) with tests/golden/, Dockerfile (ubuntu:24.04 digest-pinned,
pytest pinned), .dockerignore, task.toml (name/description/artifacts/taxonomy/hours).

Harbor results, this box:
  - `harbor run -p . --agent oracle` => Reward **1.0** (build+run 3m45s)
  - `harbor run -p . --agent nop`    => Reward **0.0**
  - clean-image scan: no solve.sh/test.sh/interp.py/programs.py/statefmt.py/golden
    in the agent image; /app ships only challenge+sample bytecode, decode-only
    disasm, empty output/. Agent has no interpreter and no answers.
  - Local oracle bin-load round-trip reproduces all 6 golden exactly.
  - `task/jobs/` (Harbor's solved output) is gitignored + untracked.

Windows/Harbor note: Harbor's daemon probe hits the inactive `default` docker
context and reports "Docker daemon is not running". Fix: export
DOCKER_HOST='npipe:////./pipe/dockerDesktopLinuxEngine' (the desktop-linux engine)
before harbor. Needed for every harbor run on this box, incl. the Phase 8 repeats.

**Disassembler is now a stripped native binary (2026-07-22).** Replaced the
shipped decode-only Python with a C reimplementation of the decode (tools/disasm.c),
compiled and stripped in a multi-stage Dockerfile (gcc:13-bookworm builder ->
`gcc -O2 -static -s` + `strip --strip-all` -> ubuntu:24.04 runtime copies only the
binary; the C source and toolchain never reach the runtime image). PyInstaller was
rejected: it embeds extractable .pyc, so it is not genuinely stripped. Verified:
  1. Stripped binary renders byte-identical listings to the Python reference across
     all 22 programs (challenge + samples), including register-indirect
     `LOAD r3, [r1 + 512]` / `STORE r2, [r1 + 512]`.
  2. `readelf`/`nm`/`strings`: ELF64, statically linked, no symbols, no .symtab/
     .debug (genuinely stripped); targeted grep finds no truncation/signedness/EA
     semantics, no source (.c/.py/#include), no golden, no interpreter. Only the
     mnemonics + listing syntax remain (opcode identity, never crux semantics).
  3. `harbor run -p . --agent oracle` still Reward **1.0**.
  Image sweep: /app ships challenge, samples, example_output.json, the stripped
  `disasm`, empty output/; no .c/.py/interp/golden/solve anywhere in the image.

**Mutant matrix confirmed against the REAL verifier (2026-07-22).** Each one-decision
mutant graded by the shipped tests/test.sh -> pytest -> golden path (mutant outputs
written by solution/vm/mutant_solve.py, which serializes RAW register values with no
width mask so a no-truncate mutant is not silently re-truncated at report time):
  - reference    -> reward 1.0, 0 mismatches, all 6 tests pass.
  - m1_notrunc   -> reward 0.0, breaks exactly {c01,c05}, fails
                    truncating_multiply_edge; indirect + signed discriminators pass.
  - m2_direct    -> reward 0.0, breaks exactly {c02,c04}, fails
                    register_indirect_addressing; multiply + signed pass.
  - m3_unsigned  -> reward 0.0, breaks exactly {c03,c06}, fails signed_comparison;
                    multiply + indirect pass.
  Clean isolation: no axis contaminates another's programs.
  Note: D1 is caught via the REGISTER FILE, not emitted output - the VM's OUT masks
  to 32 bits unconditionally, so a no-truncate mutant still emits truncated values
  but its register file carries the untruncated big int. Robust because both D1
  programs leave the overflow in a reported register (c01 r3/r4, c05 r3/r5). Any
  future D1 program that exposes overflow ONLY through OUT would be silently masked.

**Phase 7 done (2026-07-22).** instruction.md written (schema + what-the-agent-has
disclosed, cruxes and register width withheld, 561 approx tokens, 0 em-dashes);
three graded essays filled; [agent].timeout_sec=3600; taxonomy + 8h set; pre-seeded
untouched. Validated: TOML parses, schema in instruction == example_output.json
shape, example_output.json == s01's recomputed final state.

**Phase 8 done (2026-07-22).** Committed to submission at 2ac3f20 (local, not
pushed). Dropped 3 QA scripts (bench/mutant_solve/disasm.py) from the commit -
gitignored, kept on disk. Fixed the CRLF trap first: repo had core.autocrlf=true
and no .gitattributes, so a clean Windows checkout would have handed the container
a CRLF solve.sh and broken the oracle; added .gitattributes (* text=auto eol=lf,
*.bin binary) + set autocrlf=false. Fresh clone verified LF-clean and .bin
sha256-identical. From the clean checkout: oracle 1.0 x2, nop 0.0 x2, clean-image
scan finds no solve/test/interp/isa/statefmt/programs/gen_artifacts/*.c/golden; /app
ships only challenge, samples, example_output.json, the stripped disasm binary, and
empty output/.

**Phase 9 in-chat red team done (2026-07-22).** Cold re-derive from instruction.md:
spec self-consistent with solve/tests/golden, no crux or register-width leak. Two
fixes applied (working tree, uncommitted since 2ac3f20):
  - F1 (BLOCKING): Dockerfile comment contained the literal "tests/" ("verifier
    overlays tests/ at /tests") - the exact plain-text-grep trap from the prior
    task. Reworded to "the verifier is overlaid at /tests". Dockerfile now clean of
    tests/ and solution/.
  - F2 (over-strict verifier): present-test used set(regs)==set(REG_KEYS), failing a
    correct answer that adds an extra register key. Relaxed to set(REG_KEYS) <=
    set(regs) (subset); value tests still pin r0..r7 exactly. Verified: correct+extra
    passes, missing-r7 rejected.
  Post-fix: oracle 1.0, nop 0.0.
Two flags RESOLVED without code change:
  - F3 (discriminator redundancy): KEEP - proposal promised these 5 test components,
    removing them is proposal drift; verification_explanation frames them as per-crux
    traceability. Non-blocking.
  - F4 (sample count 16 vs proposal "about two dozen"): fairness is fine (bench
    passed, every opcode exercised) and instruction.md accurately says "sixteen";
    optional to pad toward ~22-24 for proposal fidelity + evidence density. OPERATOR
    DECISION pending.
All other rubric criteria / rejection causes / anti-cheat / judgment areas CLEAR.

**F4 resolved by padding + committed (2026-07-23), commit 9d3a39a.** Added 8
common-opcode samples (s17-s24): all in range, direct addressing only, no high-bit
operands, no wrap, no mode-1 -> the three axes stay exactly as latent (still 3 MUL
overflow samples, 2 signed-compare disambiguation samples, 0 mode-1 samples).
Appended (s01-s16 byte-identical, golden unchanged). instruction.md "sixteen"->
"twenty-four". Committed together with the F1/F2 fixes.

Re-verified with 24 samples:
  - Fairness bench: 11/11 (modulus still pins 2**32; width stays latent - only the
    3 designated samples wrap; no sample uses mode-1; D3 samples distinguishable).
  - Mutant matrix vs real verifier: clean isolation - m1_notrunc breaks {c01,c05},
    m2_direct {c02,c04}, m3_unsigned {c03,c06}; reference 1.0.
  - Clean-checkout re-validate (fresh clone of 9d3a39a): oracle 1.0 x2, nop 0.0,
    LF-clean (0 CR bytes), .bin sha256-intact, clean-image scan finds no
    solution/verifier/golden/source; /app ships 24 samples + 6 challenge + the
    stripped disasm ELF.

Note on the clean-clone CRLF scare: a `grep -lU $'\r'` false-positived once, but od
+ tr -cd '\r' | wc -c confirmed 0 CR bytes; .gitattributes eol=lf holds even though
a fresh clone inherits global core.autocrlf=true.

**PR #4 pass@2 read (2026-07-23): TOO EASY.** First read was an infra void
(DaytonaError, 1 solve + 1 crash); rerun (empty commit 323de57) gave a clean read:
2/2 solved, both agents recovered all three cruxes from disasm listings + traces and
solved in ~11-23 min. Not a defect (spec/verifier clean) - genuinely under-hard,
because all three cruxes lived on the readable path. pass2 blocked, pipeline stopped.

**Hardening round (2026-07-23): lever 1 - move D2 off the readable path.** The
register-indirect memory op is now rendered by the disassembler IDENTICALLY to a
direct op, so the listing and traces can't reveal it; recovery requires reversing
the stripped binary's decode. Hex-diff analysis first showed the naive mode bit
(aux[16]) left an anomalous-operand tell (operand read 0x10200 > 0xFFFF) - a
non-reversing shortcut - so the mode selector was relocated into the rs2 field
(bit 17), keeping the operand a normal 16-bit value. Golden-preserving: only
disasm.c render + the mode-bit position changed (isa.py/asm.py decode+encode,
disasm.py render); interp semantics unchanged; only c02.bin + c04.bin re-encoded;
golden byte-identical. Verification:
  (1) oracle 1.0, nop 0.0.
  (2) mode-0 and mode-1 render character-for-character identical (`LOAD r3, [0x0200]`);
      0 `[rN + ..]` renders across all 30 programs; shipped binary == reference decoder.
  (3) objdump of the stripped binary: `shr $0x11; and $0x1` (bit-17 mode), `test; je`
      (mode branch), `shr $0x14; mov %r12d,%edi` (base rs1 passed to the indirect
      render helper). -O2 did not strip the mode/base decode.
  (4) raw-byte anomaly gone: challenge indirect operand(17b) = 0x00200 (was 0x10200).
  (5) fairness: EA = base + disp recoverable with certainty by reversing the binary
      (decode explicitly routes rs1 into a base-register render path) + raw-byte diff
      (challenge sets bit 17, samples don't) + standard convention (scale-free
      base+displacement, word-addressed). Certainty rests on decode-structure +
      convention, not an executed reference - a higher (intended) RE bar than the
      readable version, but not a guess.
  Bench 11/11; mutant matrix clean (m1->c01,c05; m2->c02,c04; m3->c03,c06).
Risk still open (single-axis / discovery-hop): difficulty now rests on this one
hidden axis; bite rate at pass@5 is unknowable until a trial. If it comes back too
easy again, honest-stop.

**Not yet committed:** the hardening (disasm.c, isa.py, asm.py, disasm.py, bench.py,
c02.bin, c04.bin). Next: commit, re-validate from a clean clone, push, let pass@2
re-read. Watch the D1/D3 width-correlation too (section 8).

---

## HANDOFF (2026-07-24): hash-gcd workhorse rebuild

**Why this round.** The register-indirect "hidden addressing mode" hardening was
rejected by the new Per-Check QC soundness gate as underdetermined/unfair (two
readings fit all samples); the fair (readable) version was 2/2-solved too-easy. That
axis is a genuine dead end. TASK_RETROSPECTIVE_v2.md sections 12/13/14-D document the
one proven RE stump not previously applied: the gcd-secret-prime-modulus crux
(accepted 2/2 - prvs, beacon - both 0/5 solved; the model runs checksum catalogues,
z3, ARX hashes and never tries gcd). It escapes the wall because it is DETERMINATE (P
uniquely recoverable from the samples via gcd, so QC-fair) yet HARD (the recovery
route is one the model declines).

**Axis 1 - workhorse (gcd).** New opcode HSH (0x10): acc = (acc*B + value) mod P, a
Horner poly-hash. Touched: isa.py (decode), interp.py (semantics + constants +
`hash_secret_mod` mutant flag), asm.py (encode), disasm.c + disasm.py (render
"HSH rd, rs1"). Grades challenge c01-c03.
  - Secret prime P = 2369687797 (32-bit, off-catalogue: not 1e9+7 / 2^31-1 / FNV /
    Knuth / djb2, not near a power of two). Base B = 1000003, recoverable from the
    sample that folds (1,0), which outputs B directly.
  - Recovery: recover B, compute the unreduced Horner value H_i for wrapping samples,
    then gcd(H_i - observed_i) = P.
  - gcd design gate (gcd_bench.py, gitignored): gcd(H_i - o_i) = 2369687797 = P
    exactly; gcd of the k_i multipliers = 1 (so the gcd is P, not a multiple); max
    observed 2194947904 < P; mod-2^32 and plain (no-reduction) models miss every
    wrapping sample. GATE PASS.

**Axis 2 - coverage (truncating multiply, mod 2^32).** Kept. Grades c04-c05.
Independent evidence (overflow shown in the traces), independent skill.

**Axis 3 - insurance (signed two's-complement comparison).** Kept. Grades c06-c07.
Independent evidence (branch outcomes), independent skill. This is the beacon shape:
gcd workhorse plus a latent-rule insurance on a different route.

**Removed:** the register-indirect addressing crux (QC-unfairness source); memory is
direct-only now. The symlink verifier fix stays.

**Samples: 31 (s01-s31).** s25-s31 are the HSH samples (s25 hash_base [1,0]->B, s26
single, s27 pair/recurrence, s28-s31 wrapping for gcd); s01-s24 unchanged.
**Challenge: 7 (c01-c07):** c01-c03 hash, c04-c05 mul, c06-c07 signed.

**Already validated (all local, this box):**
- Design gate (gcd_bench.py): P uniquely pinned, wrong models diverge. PASS.
- Oracle 1.0, nop 0.0 (harbor, image vm-devirt-hash).
- IN-IMAGE mutant matrix against the REAL verifier (mount solution+tests into the
  built image, mutant_solve.py + pytest): clean isolation - m_hash -> exactly
  c01,c02,c03 + hash_modulus; m_notrunc -> c04,c05 + truncating_multiply_edge;
  m_unsigned -> c06,c07 + signed_comparison; ref 1.0. (So the in-image matrix is DONE.)
- Symlink cheat still rejected (legit passes; /app/output -> /tests/golden fails).
- Clean image: no solve/interp/isa/programs/golden/*.c reachable by the agent.
- Local: reference reproduces all 7 golden.
- Doc consistency: instruction.md (seven / c01-c07), README.md (31 samples, 7
  challenge, hash-gcd approach), task.toml essays (seven, secret-prime Horner hash,
  gcd) all consistent; 0 em-dashes across the three.

**What remains:**
1. Refresh bench.py (gitignored QA) - still references the removed register-indirect
   axis and would error if run; gcd_bench.py + the mutant matrix already cover
   fairness/isolation, so non-blocking.
2. Commit the tracked changes: isa/interp/asm.py, disasm.c, programs/gen_artifacts.py,
   test_outputs.py, task.toml, instruction.md, README.md, .gitignore, plus ~36
   regenerated data+golden files. Gitignored QA (bench/mutant_solve/disasm/gcd_bench.py)
   stay local.
3. Clean-clone re-validation: fresh clone, oracle 1.0 x2, nop 0.0, LF-clean 0 CR,
   .bin sha256-intact, clean-image scan.
4. Push (fast-forward on top of the current head) -> re-triggers the pipeline. Expect
   the QC soundness gate to pass now (P is determinate) and pass@2 to finally read the
   gcd workhorse. The gcd axis is p~1.0 in the corpus (5/5 twice), so it should clear;
   watch for a QC soundness flag on the secret modulus - it should not fire, since P
   is uniquely determined by the samples, which is exactly what QC requires.
