# VM devirtualization

Security / Reverse Engineering. Recover the instruction semantics of an
undocumented register virtual machine from a stripped disassembler and sample
execution traces, then compute the exact final state of seven held-out programs.

## Overview

The agent is handed a stripped, decode-only disassembler, 31 sample programs each
with a full execution trace, and 7 challenge programs with their bytecode and
starting states but no traces and no expected output. There is no interpreter in the
environment. The agent has to recover what every virtual instruction does from the
evidence, build its own interpreter, and produce the final register file and emitted
output of each challenge program. Because nothing runs the challenge programs for it,
a wrong semantic model is never contradicted, which is what makes the task hard and
oracle free.

## Approach

Disassemble the samples and enumerate every opcode the decode defines. Pin each
opcode from the traces by lining up starting states, listings, and final states. The
deciding opcode is a hash fold whose accumulator update is a value times a base plus
the previous accumulator, reduced modulo a secret prime. The base is trivially
recoverable, but the prime is found only by taking the greatest common divisor of the
unreduced Horner value minus the observed result across several wrapping samples, a
route a checksum catalogue or constraint solver does not reach. Two further behaviours
back it up: a multiply that reduces modulo the register width, shown only where a
sample overflows, and signed two's-complement ordered comparisons, shown only where
the signed and unsigned orderings of the operands disagree. With those in hand, build
an interpreter and evaluate it on the seven challenge programs. The reference
interpreter, and the generator that derives the sample traces and the golden states,
live in `task/solution/`.

## Environment

A single Docker image (Ubuntu base, pinned by digest) serves both the agent run and
the verifier. Under `/app` the agent gets the disassembler binary, the sample
programs with traces, the challenge programs with inputs, and one filled output
example. The disassembler is a stripped, statically linked native binary built in a
separate stage; it only decodes, so it cannot be turned into an execution oracle. No
interpreter, golden state, or reference source is present in the image.

## Verification

The agent writes `/app/output/<id>.json` for each challenge program, giving the final
register file (`r0` through `r7`, as unsigned decimals) and the emitted output in
order. The verifier in `task/tests/` compares these to withheld golden states by
exact integer equality on every register and every emitted value; the golden states
are overlaid only at verify time and never reach the agent. The reference solution
scores reward 1.0 and a do-nothing agent scores 0.0. Three discriminator tests
additionally confirm that the programs exercising each recovered behaviour match, so
a failure names the axis it came from.
