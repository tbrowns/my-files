/*
 * Decode-only disassembler for the register VM.
 *
 * Reads a program image (a stream of little-endian 32-bit words) and prints an
 * assembly listing. It decodes instruction fields and every addressing mode the
 * encoding defines; it does not execute (no register file, no memory, no
 * arithmetic, no reference output).
 *
 * Memory operands: the addressing-mode selector is bit 17 (the low bit of the
 * rs2 field) and the base register is rs1. Direct mode prints an absolute address
 * [0x....]; register-indirect mode prints the base register and displacement
 * [rB + disp]. See the two operand renderers below.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

enum {
    OP_HALT = 0x00, OP_MOVI = 0x01, OP_MOV = 0x02, OP_ADD = 0x03, OP_SUB = 0x04,
    OP_MUL = 0x05, OP_AND = 0x06, OP_OR = 0x07, OP_XOR = 0x08, OP_LOAD = 0x09,
    OP_STORE = 0x0A, OP_JMP = 0x0B, OP_BEQ = 0x0C, OP_BLT = 0x0D, OP_BGE = 0x0E,
    OP_OUT = 0x0F, OP_HSH = 0x10
};

static const char *mnem(unsigned op)
{
    switch (op) {
    case OP_HALT:  return "HALT";
    case OP_MOVI:  return "MOVI";
    case OP_MOV:   return "MOV";
    case OP_ADD:   return "ADD";
    case OP_SUB:   return "SUB";
    case OP_MUL:   return "MUL";
    case OP_AND:   return "AND";
    case OP_OR:    return "OR";
    case OP_XOR:   return "XOR";
    case OP_LOAD:  return "LOAD";
    case OP_STORE: return "STORE";
    case OP_JMP:   return "JMP";
    case OP_BEQ:   return "BEQ";
    case OP_BLT:   return "BLT";
    case OP_BGE:   return "BGE";
    case OP_OUT:   return "OUT";
    case OP_HSH:   return "HSH";
    default:       return "??";
    }
}

static int is_alu(unsigned op)
{
    return op == OP_ADD || op == OP_SUB || op == OP_MUL
        || op == OP_AND || op == OP_OR || op == OP_XOR;
}

/*
 * Two separate operand renderers, kept out-of-line so the mode branch and the
 * base-register argument are preserved in the compiled binary. The direct form
 * takes only the operand; the register-indirect form additionally receives the
 * base register (rs1), which this legacy build does not print.
 */
__attribute__((noinline))
static void render_mem_direct(unsigned operand)
{
    printf("[0x%04X]", operand);
}

__attribute__((noinline))
static void render_mem_indirect(unsigned base, unsigned operand)
{
    /* register-indirect: effective address is base register + displacement */
    printf("[r%u + %u]", base, operand);
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: disasm <program.bin>\n");
        return 2;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        fprintf(stderr, "cannot open %s\n", argv[1]);
        return 1;
    }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz < 0) {
        fclose(f);
        return 1;
    }

    long n = sz / 4;
    uint32_t *w = (uint32_t *)malloc((size_t)(n > 0 ? n : 1) * sizeof(uint32_t));
    if (!w) {
        fclose(f);
        return 1;
    }
    for (long i = 0; i < n; i++) {
        unsigned char b[4];
        if (fread(b, 1, 4, f) != 4) {
            n = i;
            break;
        }
        w[i] = (uint32_t)b[0] | ((uint32_t)b[1] << 8)
             | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
    }
    fclose(f);

    long pc = 0;
    while (pc < n) {
        uint32_t word = w[pc];
        unsigned op  = (word >> 26) & 0x3F;
        unsigned rd  = (word >> 23) & 0x7;
        unsigned rs1 = (word >> 20) & 0x7;
        unsigned rs2 = (word >> 17) & 0x7;
        unsigned aux = word & 0x1FFFF;
        long size = 1;

        printf("%04X:  ", (unsigned)pc);

        if (op == OP_HALT) {
            printf("HALT");
        } else if (op == OP_MOVI) {
            uint32_t imm = (pc + 1 < n) ? w[pc + 1] : 0u;
            printf("MOVI r%u, 0x%08X", rd, imm);
            size = 2;
        } else if (op == OP_MOV) {
            printf("MOV r%u, r%u", rd, rs1);
        } else if (op == OP_HSH) {
            printf("HSH r%u, r%u", rd, rs1);
        } else if (is_alu(op)) {
            printf("%s r%u, r%u, r%u", mnem(op), rd, rs1, rs2);
        } else if (op == OP_LOAD || op == OP_STORE) {
            unsigned mode = rs2 & 1u;         /* addressing-mode selector: bit 17 */
            unsigned operand = aux & 0xFFFFu; /* displacement / direct address */
            printf("%s r%u, ", (op == OP_LOAD) ? "LOAD" : "STORE", rd);
            if (mode)
                render_mem_indirect(rs1, operand);
            else
                render_mem_direct(operand);
        } else if (op == OP_JMP) {
            printf("JMP 0x%04X", aux);
        } else if (op == OP_BEQ || op == OP_BLT || op == OP_BGE) {
            printf("%s r%u, r%u, 0x%04X", mnem(op), rs1, rs2, aux);
        } else if (op == OP_OUT) {
            printf("OUT r%u", rs1);
        } else {
            printf("OP%02X", op);
        }
        printf("\n");
        pc += size;
    }

    free(w);
    return 0;
}
