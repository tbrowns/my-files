Recover the instruction set of a small register virtual machine, then use it to compute the exact final state of a set of held-out programs.

Everything is under `/app`.

`/app/disasm` is a disassembler for the VM. Give it a program image, for example `/app/disasm /app/challenge/c01.bin`, and it prints an instruction listing. It only decodes a program; it will not execute one.

`/app/samples/` holds thirty-one worked programs, `s01` through `s31`. Each has three files: `<id>.bin` is the program image, `<id>.input.json` is its starting state, and `<id>.trace.json` is a full execution record: the starting state, the register file after each instruction executes, and the final register file together with everything the program emitted. Use these to work out what each instruction does.

`/app/challenge/` holds seven programs, `c01` through `c07`, each with `<id>.bin` and `<id>.input.json` but no trace. These are the ones you must solve.

In an `<id>.input.json`, `regs` maps a register index to its starting value and `mem` maps a memory address to its starting value; any register or address not listed starts at zero. The machine has eight registers, `r0` through `r7`. Execution is deterministic and ends when the program halts.

No interpreter, and no expected output for the challenge programs, is provided. You have their images and their starting states, which is everything needed to compute their final states once you have recovered the instruction semantics, but nothing in the environment will run a challenge program for you or confirm an answer.

For each challenge program, write `/app/output/<id>.json`, for example `/app/output/c01.json`, in this form:

```
{
  "regs": {"r0": 0, "r1": 0, "r2": 0, "r3": 0, "r4": 0, "r5": 0, "r6": 0, "r7": 0},
  "output": []
}
```

`regs` holds the final value of all eight registers when the program halts, each written as an unsigned decimal integer. `output` is the list of values the program emitted, in the order they were emitted, each an unsigned decimal integer; use an empty list if it emitted nothing. `/app/example_output.json` is this file filled in for sample `s01`.

Grading is exact integer equality on every register and every emitted value, for all seven challenge programs.
