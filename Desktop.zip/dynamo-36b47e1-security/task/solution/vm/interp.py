"""Reference interpreter for the register VM.

Not shipped to the agent. Lives with the reference/verifier only. Executes a
decoded word stream from an initial state to HALT and returns the final register
file, final memory, and emitted output.

The three recovered behaviours are marked. A Semantics object lets the bench and
the later mutant matrix flip exactly one decision at a time; the reference is the
default (all three "correct"). Nothing here is disclosed to the agent.
"""

from dataclasses import dataclass

from isa import (
    HALT, MOVI, MOV, ADD, SUB, MUL, AND, OR, XOR, LOAD, STORE, JMP, BEQ, BLT,
    BGE, OUT, HSH, WORD_MASK, NUM_REGS,
)
from isa import decode_program

MEM_WORDS = 4096
STEP_LIMIT = 100000

# HSH folds a value into a Horner poly-hash accumulator reduced by a secret prime.
# The base is recoverable from a trivial sample; the prime is recoverable only by
# taking the gcd of (unreduced Horner value - observed) across wrapping samples.
HASH_PRIME = 2369687797
HASH_BASE = 1000003


@dataclass(frozen=True)
class Semantics:
    truncate_mul: bool = True     # A2: MUL result is taken mod 2**32
    signed_compare: bool = True   # A3: BLT/BGE compare as two's-complement
    reg_indirect: bool = True     # (memory mode; retained for compatibility)
    hash_secret_mod: bool = True  # A1 (workhorse): HSH reduces mod the secret prime


REFERENCE = Semantics()


def to_signed(x):
    return x - (1 << 32) if (x & 0x80000000) else x


class VMError(Exception):
    pass


def run(words, init_regs=None, init_mem=None, sem=REFERENCE, trace=False):
    """Execute `words`. Returns dict with regs, mem, output, and optional steps."""
    regs = [0] * NUM_REGS
    if init_regs:
        for r, v in init_regs.items():
            regs[r] = v & WORD_MASK
    mem = [0] * MEM_WORDS
    if init_mem:
        for a, v in init_mem.items():
            mem[a] = v & WORD_MASK

    prog = decode_program(words)
    output = []
    steps = []
    wraps = []   # (pc, opname, unbounded, masked) whenever a result exceeds the width
    pc = 0
    n_steps = 0

    while True:
        n_steps += 1
        if n_steps > STEP_LIMIT:
            raise VMError("step limit exceeded (no HALT?)")
        if pc not in prog:
            raise VMError(f"pc {pc} is not an instruction boundary")
        ins = prog[pc]
        op = ins.op
        nxt = pc + ins.size

        if op == HALT:
            if trace:
                steps.append((pc, "HALT", list(regs), list(output)))
            break
        elif op == MOVI:
            regs[ins.rd] = ins.imm & WORD_MASK
        elif op == MOV:
            regs[ins.rd] = regs[ins.rs1]
        elif op == HSH:
            acc = regs[ins.rd] * HASH_BASE + regs[ins.rs1]
            regs[ins.rd] = (acc % HASH_PRIME) if sem.hash_secret_mod else (acc & WORD_MASK)
        elif op == ADD:
            raw = regs[ins.rs1] + regs[ins.rs2]
            masked = raw & WORD_MASK
            if raw != masked:
                wraps.append((pc, "ADD", raw, masked))
            regs[ins.rd] = masked
        elif op == SUB:
            raw = regs[ins.rs1] - regs[ins.rs2]
            masked = raw & WORD_MASK
            if raw != masked:
                wraps.append((pc, "SUB", raw, masked))
            regs[ins.rd] = masked
        elif op == MUL:
            prod = regs[ins.rs1] * regs[ins.rs2]
            masked = prod & WORD_MASK
            if prod != masked:
                wraps.append((pc, "MUL", prod, masked))
            regs[ins.rd] = masked if sem.truncate_mul else prod  # D1
        elif op == AND:
            regs[ins.rd] = regs[ins.rs1] & regs[ins.rs2]
        elif op == OR:
            regs[ins.rd] = regs[ins.rs1] | regs[ins.rs2]
        elif op == XOR:
            regs[ins.rd] = regs[ins.rs1] ^ regs[ins.rs2]
        elif op == LOAD:
            ea = _ea(ins, regs, sem)
            regs[ins.rd] = mem[ea]
        elif op == STORE:
            ea = _ea(ins, regs, sem)
            mem[ea] = regs[ins.rd]
        elif op == JMP:
            nxt = ins.operand
        elif op == BEQ:
            if regs[ins.rs1] == regs[ins.rs2]:
                nxt = ins.operand
        elif op == BLT:
            if _lt(regs[ins.rs1], regs[ins.rs2], sem):   # D3
                nxt = ins.operand
        elif op == BGE:
            if not _lt(regs[ins.rs1], regs[ins.rs2], sem):  # D3
                nxt = ins.operand
        elif op == OUT:
            output.append(regs[ins.rs1] & WORD_MASK)
        else:
            raise VMError(f"unhandled opcode {op}")

        if trace and op != HALT:
            steps.append((pc, op, list(regs), list(output)))
        pc = nxt

    result = {"regs": regs, "mem": mem, "output": output, "wraps": wraps}
    if trace:
        result["steps"] = steps
    return result


def _ea(ins, regs, sem):
    if ins.mode == 1 and sem.reg_indirect:      # D2: register-indirect
        ea = (regs[ins.rs1] + ins.operand) & WORD_MASK
    else:
        ea = ins.operand                        # direct (or mutant: mode bit ignored)
    if ea >= MEM_WORDS:
        raise VMError(f"memory address {ea} out of range")
    return ea


def _lt(a, b, sem):
    if sem.signed_compare:
        return to_signed(a) < to_signed(b)
    return a < b
