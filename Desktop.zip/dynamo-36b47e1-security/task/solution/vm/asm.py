"""Build-only assembler: structured instruction list -> word stream.

Not shipped. Used to author sample and held-out programs. A program is a list of
tuples; labels are ('label', name) markers and branch/jump targets name a label.

Instruction tuples (registers are ints 0..7):
    ('halt',)
    ('movi', rd, imm)                 # two words
    ('mov', rd, rs)
    ('add'|'sub'|'mul'|'and'|'or'|'xor', rd, rs1, rs2)
    ('loadd', rd, addr)               # direct load
    ('loadx', rd, base, disp)         # register-indirect load  (mode 1)
    ('stored', src, addr)             # direct store
    ('storex', src, base, disp)       # register-indirect store (mode 1)
    ('jmp', label)
    ('beq'|'blt'|'bge', rs1, rs2, label)
    ('out', rs)
    ('label', name)
"""

from isa import (
    HALT, MOVI, MOV, ADD, SUB, MUL, AND, OR, XOR, LOAD, STORE, JMP, BEQ, BLT,
    BGE, OUT, HSH, WORD_MASK,
)

_ALU = {"add": ADD, "sub": SUB, "mul": MUL, "and": AND, "or": OR, "xor": XOR}
_BR = {"beq": BEQ, "blt": BLT, "bge": BGE}


def _word(op, rd=0, rs1=0, rs2=0, aux=0):
    return ((op & 0x3F) << 26) | ((rd & 0x7) << 23) | ((rs1 & 0x7) << 20) \
        | ((rs2 & 0x7) << 17) | (aux & 0x1FFFF)


def _size(instr):
    return 2 if instr[0] == "movi" else (0 if instr[0] == "label" else 1)


def assemble(program):
    """Return (words, labels) where labels maps name -> word index."""
    # first pass: label -> word index
    labels = {}
    pc = 0
    for instr in program:
        if instr[0] == "label":
            labels[instr[1]] = pc
        else:
            pc += _size(instr)

    def tgt(name):
        if name not in labels:
            raise KeyError(f"undefined label {name!r}")
        return labels[name]

    words = []
    for instr in program:
        kind = instr[0]
        if kind == "label":
            continue
        if kind == "halt":
            words.append(_word(HALT))
        elif kind == "movi":
            _, rd, imm = instr
            words.append(_word(MOVI, rd=rd))
            words.append(imm & WORD_MASK)
        elif kind == "mov":
            _, rd, rs = instr
            words.append(_word(MOV, rd=rd, rs1=rs))
        elif kind == "hsh":
            _, rd, rs = instr
            words.append(_word(HSH, rd=rd, rs1=rs))
        elif kind in _ALU:
            _, rd, rs1, rs2 = instr
            words.append(_word(_ALU[kind], rd=rd, rs1=rs1, rs2=rs2))
        elif kind == "loadd":
            _, rd, addr = instr
            words.append(_word(LOAD, rd=rd, aux=(addr & 0xFFFF)))
        elif kind == "loadx":
            _, rd, base, disp = instr
            words.append(_word(LOAD, rd=rd, rs1=base, rs2=1, aux=(disp & 0xFFFF)))
        elif kind == "stored":
            _, src, addr = instr
            words.append(_word(STORE, rd=src, aux=(addr & 0xFFFF)))
        elif kind == "storex":
            _, src, base, disp = instr
            words.append(_word(STORE, rd=src, rs1=base, rs2=1, aux=(disp & 0xFFFF)))
        elif kind == "jmp":
            _, name = instr
            words.append(_word(JMP, aux=tgt(name)))
        elif kind in _BR:
            _, rs1, rs2, name = instr
            words.append(_word(_BR[kind], rs1=rs1, rs2=rs2, aux=tgt(name)))
        elif kind == "out":
            _, rs = instr
            words.append(_word(OUT, rs1=rs))
        else:
            raise ValueError(f"bad instruction {instr!r}")
    return words, labels
