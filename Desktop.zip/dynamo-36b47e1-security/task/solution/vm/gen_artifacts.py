"""Build-only generator. Produces the agent-facing environment data and the
withheld golden. Run from task/solution/vm/:

    python gen_artifacts.py

Writes:
  ../../environment/data/samples/        s01..s16 : bytecode + input + trace (evidence)
  ../../environment/data/challenge/      c01..c06 : bytecode + input (states withheld)
  ../../environment/data/example_output.json   filled schema example (one sample)
  ../../tests/golden/                     c01..c06 : golden graded state (never shipped)

The shipped disassembler is a compiled, stripped native binary built from
../../environment/tools/disasm.c by the environment Dockerfile (multi-stage); it
is not emitted here. Public ids are opaque so filenames never telegraph which axis
a program exercises.
"""

import json
import os
import shutil
import struct

from asm import assemble
from interp import run, REFERENCE
from isa import NUM_REGS, WORD_MASK
from statefmt import run_program, state_dict
import programs as P

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "environment", "data"))
GOLDEN = os.path.normpath(os.path.join(HERE, "..", "..", "tests", "golden"))

# internal name -> opaque public id (fixed, interleaved so specials aren't grouped)
SAMPLE_IDS = {
    "arith_basic": "s01", "mul_ovf_boundary": "s02", "bitwise_basic": "s03",
    "cmp_signed_negone": "s04", "mem_direct": "s05", "mul_small": "s06",
    "loop_sum": "s07", "mul_ovf_lowbits": "s08", "branch_beq": "s09",
    "mem_direct_table": "s10", "cmp_signed_boundary": "s11", "sub_inrange": "s12",
    "mul_ovf_highbit": "s13", "mov_chain": "s14", "mixed_arith": "s15",
    "branch_blt_small": "s16",
    # common-opcode padding (no new crux evidence)
    "add_accumulate": "s17", "sub_chain": "s18", "mul_accumulate": "s19",
    "bitwise_combine": "s20", "mem_multi": "s21", "loop_countdown": "s22",
    "compare_small_blt": "s23", "mov_arith_mix": "s24",
    # HSH samples (base recovery, recurrence, and wrapping samples for gcd)
    "hash_base": "s25", "hash_single": "s26", "hash_pair": "s27",
    "hash_wrap1": "s28", "hash_wrap2": "s29", "hash_wrap3": "s30", "hash_wrap4": "s31",
}
CHALLENGE_IDS = {
    "hash_challenge_1": "c01", "hash_challenge_2": "c02", "hash_challenge_3": "c03",
    "mul_overflow_chain": "c04", "mul_overflow_poly": "c05",
    "signed_branch": "c06", "signed_select": "c07",
}


def write_bin(path, words):
    with open(path, "wb") as f:
        for w in words:
            f.write(struct.pack("<I", w & WORD_MASK))


def write_json(path, obj):
    with open(path, "w", newline="\n") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def input_obj(init_regs, init_mem):
    return {
        "regs": {str(k): (v & WORD_MASK) for k, v in sorted(init_regs.items())},
        "mem": {str(k): (v & WORD_MASK) for k, v in sorted(init_mem.items())},
    }


def trace_obj(words, init_regs, init_mem):
    res = run(words, init_regs, init_mem, REFERENCE, trace=True)
    steps = []
    for pc, op, regs, out in res["steps"]:
        steps.append({
            "pc": pc,
            "regs": [r & WORD_MASK for r in regs],
            "output": [v & WORD_MASK for v in out],
        })
    return {
        "init": input_obj(init_regs, init_mem),
        "steps": steps,
        "final": state_dict(res["regs"], res["output"]),
    }


def reset_dir(path):
    if os.path.isdir(path):
        shutil.rmtree(path)
    os.makedirs(path, exist_ok=True)


def main():
    reset_dir(os.path.join(DATA, "samples"))
    reset_dir(os.path.join(DATA, "challenge"))
    reset_dir(GOLDEN)
    # the disassembler now ships as a compiled binary from tools/disasm.c; drop any
    # previously shipped Python source so it never reaches the image
    stale = os.path.join(DATA, "disasm")
    if os.path.isdir(stale):
        shutil.rmtree(stale)

    # samples: bytecode + input + trace
    for name, pub in SAMPLE_IDS.items():
        prog, ir, im = P.SAMPLES[name]
        words, _ = assemble(prog)
        write_bin(os.path.join(DATA, "samples", f"{pub}.bin"), words)
        write_json(os.path.join(DATA, "samples", f"{pub}.input.json"), input_obj(ir, im))
        write_json(os.path.join(DATA, "samples", f"{pub}.trace.json"), trace_obj(words, ir, im))

    # challenge: bytecode + input only; golden withheld into tests/
    for name, pub in CHALLENGE_IDS.items():
        _, prog, ir, im = P.HELDOUT[name]
        words, _ = assemble(prog)
        write_bin(os.path.join(DATA, "challenge", f"{pub}.bin"), words)
        write_json(os.path.join(DATA, "challenge", f"{pub}.input.json"), input_obj(ir, im))
        write_json(os.path.join(GOLDEN, f"{pub}.json"), run_program(words, ir, im))

    # filled schema example: one sample's graded state, shown to the agent
    ex_name = "arith_basic"
    prog, ir, im = P.SAMPLES[ex_name]
    words, _ = assemble(prog)
    write_json(os.path.join(DATA, "example_output.json"), run_program(words, ir, im))

    print("wrote:")
    print("  ", os.path.join(DATA, "samples"), f"({len(SAMPLE_IDS)} programs)")
    print("  ", os.path.join(DATA, "challenge"), f"({len(CHALLENGE_IDS)} programs)")
    print("  ", GOLDEN, f"({len(CHALLENGE_IDS)} golden states)")


if __name__ == "__main__":
    main()
