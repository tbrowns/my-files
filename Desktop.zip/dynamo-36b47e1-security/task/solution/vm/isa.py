"""Instruction encoding and decode for the register VM.

This module is decode-only: it defines the encoding, extracts fields, and turns a
word stream into structured instructions. It holds no execution semantics and no
handler bodies. The reference interpreter (interp.py) and the shipped disassembler
(disasm.py) both decode through here so encode and decode never drift.

Instruction word is 32 bits:

    [31:26] opcode (6b)
    [25:23] rd     (3b)
    [22:20] rs1    (3b)
    [19:17] rs2    (3b)
    [16:0]  aux    (17b)

MOVI is two words: the opcode word plus a following 32-bit immediate word.
For LOAD/STORE, aux[16] is the addressing-mode selector and aux[15:0] is the
operand (a direct word address in mode 0, or a displacement in mode 1 with rs1 as
the base register). For branches/JMP, aux is the absolute target word index.
Registers are r0..r7 and are 32 bits wide; that width is not stamped in any name
here, it is a property of the machine the reader recovers.
"""

REG_BITS = 3
NUM_REGS = 8
WORD_MASK = 0xFFFFFFFF

# opcodes
HALT = 0x00
MOVI = 0x01
MOV = 0x02
ADD = 0x03
SUB = 0x04
MUL = 0x05
AND = 0x06
OR = 0x07
XOR = 0x08
LOAD = 0x09
STORE = 0x0A
JMP = 0x0B
BEQ = 0x0C
BLT = 0x0D
BGE = 0x0E
OUT = 0x0F
HSH = 0x10

MNEMONIC = {
    HALT: "HALT", MOVI: "MOVI", MOV: "MOV", ADD: "ADD", SUB: "SUB", MUL: "MUL",
    AND: "AND", OR: "OR", XOR: "XOR", LOAD: "LOAD", STORE: "STORE", JMP: "JMP",
    BEQ: "BEQ", BLT: "BLT", BGE: "BGE", OUT: "OUT", HSH: "HSH",
}

# opcodes that carry a two-operand ALU form rd, rs1, rs2
ALU = {ADD, SUB, MUL, AND, OR, XOR}
# opcodes that use the aux field as an addressing mode + operand
MEM = {LOAD, STORE}
# opcodes that use aux as a branch/jump target word index
CTRL = {JMP, BEQ, BLT, BGE}


class Instr:
    """A decoded instruction, positioned at word index `pc`."""

    __slots__ = ("pc", "op", "rd", "rs1", "rs2", "mode", "operand", "imm", "size")

    def __init__(self, pc, op, rd=0, rs1=0, rs2=0, mode=0, operand=0, imm=0, size=1):
        self.pc = pc
        self.op = op
        self.rd = rd
        self.rs1 = rs1
        self.rs2 = rs2
        self.mode = mode      # LOAD/STORE only: 0 direct, 1 register-indirect
        self.operand = operand  # LOAD/STORE: direct address or displacement
        self.imm = imm        # MOVI only
        self.size = size      # words consumed (2 for MOVI, else 1)

    def __repr__(self):
        return f"Instr(pc={self.pc}, {MNEMONIC.get(self.op, self.op)})"


def _fields(word):
    op = (word >> 26) & 0x3F
    rd = (word >> 23) & 0x7
    rs1 = (word >> 20) & 0x7
    rs2 = (word >> 17) & 0x7
    aux = word & 0x1FFFF
    return op, rd, rs1, rs2, aux


def decode_at(words, pc):
    """Decode a single instruction starting at word index `pc`. Returns an Instr."""
    word = words[pc]
    op, rd, rs1, rs2, aux = _fields(word)
    if op == MOVI:
        imm = words[pc + 1] & WORD_MASK
        return Instr(pc, op, rd=rd, imm=imm, size=2)
    if op in MEM:
        mode = rs2 & 1              # addressing-mode selector lives in the rs2 field (bit 17)
        operand = aux & 0xFFFF      # displacement / direct address, always 16-bit
        return Instr(pc, op, rd=rd, rs1=rs1, mode=mode, operand=operand, size=1)
    if op in CTRL:
        return Instr(pc, op, rs1=rs1, rs2=rs2, operand=aux, size=1)
    if op in ALU:
        return Instr(pc, op, rd=rd, rs1=rs1, rs2=rs2, size=1)
    if op == MOV:
        return Instr(pc, op, rd=rd, rs1=rs1, size=1)
    if op == HSH:
        return Instr(pc, op, rd=rd, rs1=rs1, size=1)
    if op == OUT:
        return Instr(pc, op, rs1=rs1, size=1)
    if op == HALT:
        return Instr(pc, op, size=1)
    raise ValueError(f"unknown opcode 0x{op:02X} at word {pc}")


def decode_program(words):
    """Decode a whole word stream into {pc: Instr}. MOVI consumes two words."""
    out = {}
    pc = 0
    n = len(words)
    while pc < n:
        instr = decode_at(words, pc)
        out[pc] = instr
        pc += instr.size
    return out
