"""Design gate for the gcd-secret-prime-modulus workhorse axis.

Confirms the secret prime P is uniquely recoverable from sample hash traces via
gcd (fair / determinate), and that the plausible wrong models diverge (bites).
Run: python gcd_bench.py
"""

from functools import reduce
from math import gcd

from asm import assemble
from interp import run, REFERENCE, Semantics, HASH_PRIME, HASH_BASE


def hash_prog(vals):
    prog = [("movi", 0, 0)]  # r0 = accumulator
    for v in vals:
        prog += [("movi", 1, v), ("hsh", 0, 1)]
    prog += [("out", 0), ("halt",)]
    return prog


def observed(vals, sem=REFERENCE):
    words, _ = assemble(hash_prog(vals))
    return run(words, {}, {}, sem)["output"][0]


def horner_unmodded(vals):
    h = 0
    for v in vals:
        h = h * HASH_BASE + v
    return h


print("=" * 70)
print("gcd design gate  (secret prime P, base B)")
print("=" * 70)

# 1) base B is recoverable from a trivial sample HSH([1, 0])
b_obs = observed([1, 0])
print(f"\n[B] HSH([1,0]) = {b_obs}   == HASH_BASE({HASH_BASE}): {b_obs == HASH_BASE}")

# 2) diverse wrapping samples -> gcd pins P uniquely
seqs = [
    [1000, 2000, 3000, 4000],
    [12345, 67890, 11111],
    [999999, 888888, 777777],
    [500000, 4, 123456, 7],
    [2000000, 1999999, 1888],
    [314159, 265358, 979323, 846],
]
print("\n[P] wrapping samples (H = unreduced Horner value, o = observed mod P):")
diffs, maxobs = [], 0
for s in seqs:
    o = observed(s)
    H = horner_unmodded(s)
    d = H - o
    k = d // HASH_PRIME
    diffs.append(d)
    maxobs = max(maxobs, o)
    print(f"    len {len(s)}: o={o:<11d} H-o={d:<20d} = {k} * P  ({d % HASH_PRIME == 0})")

G = reduce(gcd, diffs)
ks = [d // HASH_PRIME for d in diffs]
gcd_k = reduce(gcd, ks)
unique = (G == HASH_PRIME) and (maxobs < HASH_PRIME)
print(f"\n    gcd(H_i - o_i)      = {G}")
print(f"    == HASH_PRIME({HASH_PRIME}): {G == HASH_PRIME}")
print(f"    gcd of the k_i      = {gcd_k}  (must be 1 so gcd equals P, not a multiple)")
print(f"    max observed        = {maxobs}  < P: {maxobs < HASH_PRIME}")
print(f"    ==> P UNIQUELY PINNED (prime, gcd=P, all o<P): {unique}")

# 3) crux bites: the plausible wrong models diverge on these samples
print("\n[bite] wrong models vs reference on the wrapping samples:")
wrong_mod = Semantics(hash_secret_mod=False)  # mod 2**32
allmiss_mod = allmiss_plain = True
for s in seqs[:3]:
    ref = observed(s)
    w32 = observed(s, wrong_mod)
    plain = horner_unmodded(s)
    allmiss_mod = allmiss_mod and (w32 != ref)
    allmiss_plain = allmiss_plain and (plain != ref)
    print(f"    ref={ref:<11d} mod2^32={w32:<11d}(miss={w32 != ref})  plain={plain}(miss={plain != ref})")
print(f"    mod-2^32 model misses all: {allmiss_mod}")
print(f"    plain (no reduction) model misses all: {allmiss_plain}")

print("\n" + "=" * 70)
print(f"DESIGN GATE: {'PASS' if (b_obs == HASH_BASE and unique and allmiss_mod and allmiss_plain) else 'FAIL'}")
print("=" * 70)
