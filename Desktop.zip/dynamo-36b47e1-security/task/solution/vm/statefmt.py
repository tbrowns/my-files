"""Shared serializer so the golden generator and the oracle produce byte-identical
JSON. Registers are reported as unsigned decimals under fixed keys r0..r7; emitted
output is an ordered list of the same. The register bit-width is deliberately not
part of this format (a correct reversal already recovered it); the format only
fixes naming, ordering, base, and reporting signedness (unsigned).
"""

from interp import run, REFERENCE
from isa import NUM_REGS, WORD_MASK


def run_program(words, init_regs=None, init_mem=None):
    """Run the reference machine and return the graded state dict."""
    res = run(words, init_regs, init_mem, REFERENCE)
    return state_dict(res["regs"], res["output"])


def state_dict(regs, output):
    return {
        "regs": {f"r{i}": (regs[i] & WORD_MASK) for i in range(NUM_REGS)},
        "output": [v & WORD_MASK for v in output],
    }
