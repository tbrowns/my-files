"""Decode-only disassembler. This is the tool shipped to the agent (later compiled
and stripped for the environment image). It decodes a word stream and renders a
textual listing. It never executes: it has no register file, no memory, and no
handler bodies. It decodes every addressing mode the encoding defines, including
the register-indirect mode, so a listing of any program reveals which mode each
memory instruction uses and, for register-indirect, its base register and
displacement.
"""

from isa import (
    MNEMONIC, MOVI, MOV, ALU, MEM, CTRL, HALT, OUT, LOAD, STORE, HSH,
)
from isa import decode_program


def render(ins):
    """Render one decoded instruction to an assembly line."""
    m = MNEMONIC.get(ins.op, f"OP{ins.op:02X}")
    if ins.op == HALT:
        return "HALT"
    if ins.op == MOVI:
        return f"MOVI r{ins.rd}, 0x{ins.imm:08X}"
    if ins.op == MOV:
        return f"MOV r{ins.rd}, r{ins.rs1}"
    if ins.op == HSH:
        return f"HSH r{ins.rd}, r{ins.rs1}"
    if ins.op in ALU:
        return f"{m} r{ins.rd}, r{ins.rs1}, r{ins.rs2}"
    if ins.op in MEM:
        operand = _mem_operand(ins)
        if ins.op == LOAD:
            return f"LOAD r{ins.rd}, {operand}"
        return f"STORE r{ins.rd}, {operand}"      # rd field holds the source reg
    if ins.op in CTRL:
        if ins.op == 0x0B:  # JMP
            return f"JMP 0x{ins.operand:04X}"
        return f"{m} r{ins.rs1}, r{ins.rs2}, 0x{ins.operand:04X}"
    if ins.op == OUT:
        return f"OUT r{ins.rs1}"
    return m


def _mem_operand(ins):
    if ins.mode == 1:
        # register-indirect: effective address is base register plus displacement
        return f"[r{ins.rs1} + {ins.operand}]"
    # direct: operand is an absolute word address
    return f"[0x{ins.operand:04X}]"


def disassemble(words):
    """Return a listing: list of (pc, text) for the whole word stream."""
    prog = decode_program(words)
    return [(pc, render(prog[pc])) for pc in sorted(prog)]


def format_listing(words):
    lines = []
    for pc, text in disassemble(words):
        lines.append(f"{pc:04X}:  {text}")
    return "\n".join(lines)
