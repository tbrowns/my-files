"""Sample and held-out programs.

Build conditions honoured here:
  - Samples never use the register-indirect addressing mode (mode 1). Only the
    held-out programs do.
  - The only samples that observably exceed the register width are the three
    designated MUL-overflow samples; every other sample stays in range, so the
    width stays latent (recoverable only by reconciling those three).
  - High-bit operands used to disambiguate the signed comparison are loaded
    directly with MOVI, never produced by arithmetic, so that axis is independent
    of whether the reader truncates arithmetic.
  - Held-out programs each lean on exactly one axis so the later one-decision
    mutant matrix isolates cleanly (2 programs per axis).

Each program is (instructions, init_regs, init_mem). Registers are ints 0..7.
"""

# register aliases for readability
r0, r1, r2, r3, r4, r5, r6, r7 = range(8)


# ----------------------------------------------------------------------------
# SAMPLES  (traces shipped to the agent as the fair evidence)
# ----------------------------------------------------------------------------

SAMPLES = {}


def _s(name, prog, init_regs=None, init_mem=None):
    SAMPLES[name] = (prog, init_regs or {}, init_mem or {})


_s("arith_basic", [
    ("movi", r1, 3), ("movi", r2, 4),
    ("add", r3, r1, r2), ("sub", r4, r2, r1), ("mul", r5, r1, r2),
    ("out", r3), ("out", r4), ("out", r5), ("halt",),
])

_s("bitwise_basic", [
    ("movi", r1, 0xF0), ("movi", r2, 0x0F),
    ("and", r3, r1, r2), ("or", r4, r1, r2), ("xor", r5, r1, r2),
    ("out", r3), ("out", r4), ("out", r5), ("halt",),
])

_s("mov_chain", [
    ("movi", r1, 12345), ("mov", r2, r1), ("mov", r3, r2),
    ("out", r3), ("halt",),
])

_s("mem_direct", [
    ("movi", r1, 42), ("stored", r1, 0x100),
    ("loadd", r2, 0x100), ("out", r2), ("halt",),
])

_s("mem_direct_table", [
    ("loadd", r1, 0x040), ("loadd", r2, 0x041), ("loadd", r3, 0x042),
    ("add", r4, r1, r2), ("add", r4, r4, r3),
    ("out", r4), ("halt",),
], init_mem={0x040: 5, 0x041: 6, 0x042: 7})

_s("branch_beq", [
    ("movi", r1, 5), ("movi", r2, 5),
    ("beq", r1, r2, "eq"),
    ("movi", r0, 0), ("out", r0), ("halt",),
    ("label", "eq"), ("movi", r0, 1), ("out", r0), ("halt",),
])

_s("branch_blt_small", [
    ("movi", r1, 3), ("movi", r2, 8),
    ("blt", r1, r2, "less"),
    ("movi", r0, 0), ("out", r0), ("halt",),
    ("label", "less"), ("movi", r0, 1), ("out", r0), ("halt",),
])

_s("loop_sum", [
    ("movi", r0, 0), ("movi", r1, 1), ("movi", r2, 6), ("movi", r3, 1),
    ("label", "loop"),
    ("bge", r1, r2, "end"),
    ("add", r0, r0, r1), ("add", r1, r1, r3), ("jmp", "loop"),
    ("label", "end"), ("out", r0), ("halt",),
])

_s("sub_inrange", [
    ("movi", r1, 900), ("movi", r2, 250),
    ("sub", r3, r1, r2), ("out", r3), ("halt",),
])

_s("mul_small", [
    ("movi", r1, 1000), ("movi", r2, 2000),
    ("mul", r3, r1, r2), ("out", r3), ("halt",),
])

_s("mixed_arith", [
    ("movi", r1, 7), ("movi", r2, 11), ("movi", r3, 2),
    ("mul", r4, r1, r2), ("add", r4, r4, r3), ("sub", r5, r4, r1),
    ("out", r4), ("out", r5), ("halt",),
])

# --- the three MUL-overflow samples (the fair evidence for D1) ---
_s("mul_ovf_boundary", [
    ("movi", r1, 0x10000), ("movi", r2, 0x10000),   # 65536 * 65536 = 2**32
    ("mul", r3, r1, r2), ("out", r3), ("halt",),
])

_s("mul_ovf_lowbits", [
    ("movi", r1, 0x12345), ("movi", r2, 0x10000),   # true 0x1_2345_0000
    ("mul", r3, r1, r2), ("out", r3), ("halt",),
])

_s("mul_ovf_highbit", [
    ("movi", r1, 0x10001), ("movi", r2, 0x18000),   # true 0x1_8001_8000, low word high bit set
    ("mul", r3, r1, r2), ("out", r3), ("halt",),
])

# --- the two signed-comparison disambiguation samples (fair evidence for D3) ---
_s("cmp_signed_negone", [
    ("movi", r1, 0xFFFFFFFF), ("movi", r2, 0x00000001),
    ("blt", r1, r2, "taken"),
    ("movi", r0, 100), ("out", r0), ("halt",),
    ("label", "taken"), ("movi", r0, 200), ("out", r0), ("halt",),
])

_s("cmp_signed_boundary", [
    ("movi", r1, 0x80000000), ("movi", r2, 0x7FFFFFFF),
    ("bge", r1, r2, "ge"),
    ("movi", r0, 11), ("out", r0), ("halt",),
    ("label", "ge"), ("movi", r0, 22), ("out", r0), ("halt",),
])

# --- additional common-opcode samples: no new crux evidence, everything in range
# (no MUL overflow, no register-indirect mode, no high-bit operands), so the three
# axes stay exactly as latent as before and the register width stays hidden. ---
_s("add_accumulate", [
    ("movi", r1, 10), ("movi", r2, 20), ("movi", r3, 30),
    ("add", r4, r1, r2), ("add", r4, r4, r3), ("out", r4), ("halt",),
])

_s("sub_chain", [
    ("movi", r1, 500), ("movi", r2, 100), ("movi", r3, 50),
    ("sub", r4, r1, r2), ("sub", r4, r4, r3), ("out", r4), ("halt",),
])

_s("mul_accumulate", [
    ("movi", r1, 3), ("movi", r2, 5), ("movi", r3, 7),
    ("mul", r4, r1, r2), ("mul", r4, r4, r3), ("out", r4), ("halt",),
])

_s("bitwise_combine", [
    ("movi", r1, 0xAA), ("movi", r2, 0x55), ("movi", r3, 0xF0),
    ("and", r4, r1, r3), ("or", r5, r4, r2), ("xor", r6, r5, r1),
    ("out", r4), ("out", r5), ("out", r6), ("halt",),
])

_s("mem_multi", [
    ("movi", r1, 11), ("movi", r2, 22),
    ("stored", r1, 0x080), ("stored", r2, 0x081),
    ("loadd", r3, 0x080), ("loadd", r4, 0x081),
    ("add", r5, r3, r4), ("out", r5), ("halt",),
])

_s("loop_countdown", [
    ("movi", r0, 0), ("movi", r1, 5), ("movi", r2, 0), ("movi", r3, 1),
    ("label", "loop"),
    ("beq", r1, r2, "end"),
    ("add", r0, r0, r1), ("sub", r1, r1, r3), ("jmp", "loop"),
    ("label", "end"), ("out", r0), ("halt",),
])

_s("compare_small_blt", [
    ("movi", r1, 7), ("movi", r2, 20), ("movi", r3, 20),
    ("blt", r1, r2, "less"),
    ("movi", r0, 111), ("out", r0), ("halt",),
    ("label", "less"),
    ("bge", r2, r3, "ge"),
    ("movi", r0, 222), ("out", r0), ("halt",),
    ("label", "ge"), ("movi", r0, 333), ("out", r0), ("halt",),
])

_s("mov_arith_mix", [
    ("movi", r1, 8), ("mov", r2, r1),
    ("add", r3, r1, r2), ("mul", r4, r3, r2), ("sub", r5, r4, r1),
    ("out", r3), ("out", r4), ("out", r5), ("halt",),
])

# --- HSH samples: fold values into a Horner accumulator (r0). The base is
# recoverable from hash_base; the secret modulus is recoverable only by gcd over
# the wrapping samples. Every non-modular / wrong-modulus model diverges on the
# wrapping ones. ---
_s("hash_base", [        # HSH([1, 0]) == base
    ("movi", r0, 0), ("movi", r1, 1), ("hsh", r0, r1),
    ("movi", r1, 0), ("hsh", r0, r1), ("out", r0), ("halt",),
])
_s("hash_single", [      # HSH([5]) == 5 (a single fold from zero)
    ("movi", r0, 0), ("movi", r1, 5), ("hsh", r0, r1), ("out", r0), ("halt",),
])
_s("hash_pair", [        # HSH([3, 7]) == 3*base + 7 (no wrap: confirms the recurrence)
    ("movi", r0, 0), ("movi", r1, 3), ("hsh", r0, r1),
    ("movi", r1, 7), ("hsh", r0, r1), ("out", r0), ("halt",),
])
_s("hash_wrap1", [
    ("movi", r0, 0),
    ("movi", r1, 1000), ("hsh", r0, r1), ("movi", r1, 2000), ("hsh", r0, r1),
    ("movi", r1, 3000), ("hsh", r0, r1), ("movi", r1, 4000), ("hsh", r0, r1),
    ("out", r0), ("halt",),
])
_s("hash_wrap2", [
    ("movi", r0, 0),
    ("movi", r1, 12345), ("hsh", r0, r1), ("movi", r1, 67890), ("hsh", r0, r1),
    ("movi", r1, 11111), ("hsh", r0, r1), ("out", r0), ("halt",),
])
_s("hash_wrap3", [
    ("movi", r0, 0),
    ("movi", r1, 999999), ("hsh", r0, r1), ("movi", r1, 888888), ("hsh", r0, r1),
    ("movi", r1, 777777), ("hsh", r0, r1), ("out", r0), ("halt",),
])
_s("hash_wrap4", [
    ("movi", r0, 0),
    ("movi", r1, 2000000), ("hsh", r0, r1), ("movi", r1, 1999999), ("hsh", r0, r1),
    ("movi", r1, 1888), ("hsh", r0, r1), ("out", r0), ("halt",),
])


# ----------------------------------------------------------------------------
# HELD-OUT  (bytecode + inputs shipped; final states withheld and graded)
# ----------------------------------------------------------------------------

HELDOUT = {}


def _h(name, axis, prog, init_regs=None, init_mem=None):
    HELDOUT[name] = (axis, prog, init_regs or {}, init_mem or {})


# A1 (workhorse): fold a sequence into the Horner hash. The correct output requires
# the secret modulus; any model that does not recover it (mod 2**32, plain, or a
# wrong prime) emits a different value. Uses only MOVI + HSH, so only the modulus
# axis bites these programs.
_h("hash_challenge_1", "A1", [
    ("movi", r0, 0),
    ("movi", r1, 1234567), ("hsh", r0, r1), ("movi", r1, 2345678), ("hsh", r0, r1),
    ("movi", r1, 3456789), ("hsh", r0, r1), ("movi", r1, 4567890), ("hsh", r0, r1),
    ("out", r0), ("halt",),
])

_h("hash_challenge_2", "A1", [
    ("movi", r0, 0),
    ("movi", r1, 999999999), ("hsh", r0, r1), ("movi", r1, 888888888), ("hsh", r0, r1),
    ("movi", r1, 777777777), ("hsh", r0, r1), ("out", r0), ("halt",),
])

_h("hash_challenge_3", "A1", [
    ("movi", r0, 0),
    ("movi", r1, 0xDEADBEEF), ("hsh", r0, r1), ("movi", r1, 0x12345678), ("hsh", r0, r1),
    ("movi", r1, 0x9ABCDEF0), ("hsh", r0, r1), ("out", r0), ("halt",),
])

# A2 (coverage): routine MUL overflow. A non-truncating model emits >32-bit values.
_h("mul_overflow_chain", "A2", [
    ("movi", r1, 0x1ABCD), ("movi", r2, 0x1F000),
    ("mul", r3, r1, r2), ("out", r3),
    ("mul", r4, r3, r2), ("out", r4), ("halt",),
])

_h("mul_overflow_poly", "A2", [
    ("movi", r1, 0xC0000), ("movi", r2, 0x0B000),
    ("mul", r3, r1, r2), ("out", r3),
    ("add", r4, r3, r1), ("mul", r5, r4, r4), ("out", r5), ("halt",),
])

# A3 (insurance): signed comparison of a high-bit operand. An unsigned model takes
# the other branch and emits a different value.
_h("signed_branch", "A3", [
    ("movi", r1, 0xFFFFFFFB), ("movi", r0, 0),    # bits of -5, and 0
    ("blt", r1, r0, "neg"),
    ("movi", r3, 1000), ("out", r3), ("halt",),
    ("label", "neg"), ("movi", r3, 2000), ("out", r3), ("halt",),
])

_h("signed_select", "A3", [
    ("movi", r1, 0x90000000), ("movi", r2, 0x10000000),
    ("bge", r1, r2, "big"),
    ("movi", r3, 7), ("out", r3), ("halt",),
    ("label", "big"), ("movi", r3, 9), ("out", r3), ("halt",),
])
