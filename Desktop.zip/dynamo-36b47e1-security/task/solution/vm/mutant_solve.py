"""Build-only: write challenge outputs under a chosen one-decision-different
semantics, to drive the real verifier for the mutant matrix. Not shipped.

Usage:  python3 mutant_solve.py {ref|m1_notrunc|m2_direct|m3_unsigned}

Serialization here reports the raw register/output values with NO width mask. That
is deliberate: a faithful mutant agent that (for example) does not truncate the
multiply also does not know the width, so it would report the full untruncated
integer. Masking at serialization would silently re-truncate and hide the mutation.
The reference variant's values are already in range, so raw == the shipped schema.
"""

import glob
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from interp import run, Semantics, REFERENCE  # noqa: E402

VARIANTS = {
    "ref": REFERENCE,
    "m_hash": Semantics(hash_secret_mod=False),   # wrong modulus (mod 2**32)
    "m_notrunc": Semantics(truncate_mul=False),
    "m_unsigned": Semantics(signed_compare=False),
}

CHALLENGE_DIR = "/app/challenge"
OUTPUT_DIR = "/app/output"


def load_words(path):
    with open(path, "rb") as f:
        raw = f.read()
    return list(struct.unpack("<%dI" % (len(raw) // 4), raw))


def load_input(path):
    if not os.path.exists(path):
        return {}, {}
    with open(path) as f:
        obj = json.load(f)
    regs = {int(k): int(v) for k, v in obj.get("regs", {}).items()}
    mem = {int(k): int(v) for k, v in obj.get("mem", {}).items()}
    return regs, mem


def main():
    variant = sys.argv[1]
    sem = VARIANTS[variant]
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    n = 0
    for bin_path in sorted(glob.glob(os.path.join(CHALLENGE_DIR, "*.bin"))):
        cid = os.path.splitext(os.path.basename(bin_path))[0]
        words = load_words(bin_path)
        regs, mem = load_input(os.path.join(CHALLENGE_DIR, f"{cid}.input.json"))
        res = run(words, regs, mem, sem)
        state = {
            "regs": {f"r{i}": res["regs"][i] for i in range(8)},  # raw, no mask
            "output": list(res["output"]),
        }
        with open(os.path.join(OUTPUT_DIR, f"{cid}.json"), "w", newline="\n") as f:
            json.dump(state, f, indent=2)
            f.write("\n")
        n += 1
    print(f"variant={variant}: wrote {n} outputs")


if __name__ == "__main__":
    main()
