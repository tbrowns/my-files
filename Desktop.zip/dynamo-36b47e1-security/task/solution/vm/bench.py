"""Fairness bench. Confirms each axis is recoverable from what ships, under the
stated build conditions. Does NOT wire the oracle or grade anything; it only
measures recoverability and independence and prints the numbers.

Run:  python bench.py   (from task/solution/vm/)
"""

import math
import re

from asm import assemble
from isa import decode_program, MEM
from interp import run, Semantics, REFERENCE, VMError
from disasm import disassemble, render
import programs as P

TWO32 = 1 << 32
TWO31 = 1 << 31

OVERFLOW_SAMPLES = ["mul_ovf_boundary", "mul_ovf_lowbits", "mul_ovf_highbit"]
D3_SAMPLES = ["cmp_signed_negone", "cmp_signed_boundary"]


def asm_sample(name):
    prog, ir, im = P.SAMPLES[name]
    words, _ = assemble(prog)
    return words, ir, im


def asm_heldout(name):
    axis, prog, ir, im = P.HELDOUT[name]
    words, _ = assemble(prog)
    return words, ir, im, axis


def mode1_count(words):
    prog = decode_program(words)
    return sum(1 for i in prog.values() if i.op in MEM and i.mode == 1)


results = {"checks": [], "numbers": {}}


def check(label, ok, detail=""):
    results["checks"].append((label, ok, detail))
    tag = "PASS" if ok else "FAIL"
    line = f"[{tag}] {label}"
    if detail:
        line += f"\n        {detail}"
    print(line)
    return ok


print("=" * 72)
print("FAIRNESS BENCH  (register-VM devirtualization)")
print("=" * 72)

# --- sanity: reference runs every sample and held-out without error ----------
print("\n-- sanity --")
sane = True
for name in P.SAMPLES:
    words, ir, im = asm_sample(name)
    try:
        run(words, ir, im, REFERENCE)
    except VMError as e:
        sane = False
        print(f"    sample {name} errored: {e}")
for name in P.HELDOUT:
    words, ir, im, _ = asm_heldout(name)
    try:
        run(words, ir, im, REFERENCE)
    except VMError as e:
        sane = False
        print(f"    held-out {name} errored: {e}")
check(f"reference runs all {len(P.SAMPLES)} samples + {len(P.HELDOUT)} held-out clean", sane)

# ============================================================================
# D1 : truncating multiply, recovered from sample traces
# ============================================================================
print("\n-- D1: truncating multiply (evidence: sample traces) --")

ovf = []  # (name, true_product, observed_result)
for name in OVERFLOW_SAMPLES:
    words, ir, im = asm_sample(name)
    res = run(words, ir, im, REFERENCE)
    mul_wraps = [w for w in res["wraps"] if w[1] == "MUL"]
    if len(mul_wraps) != 1:
        check(f"{name} has exactly one MUL overflow", False,
              f"found {len(mul_wraps)} MUL wraps")
        continue
    _, _, prod, masked = mul_wraps[0]
    observed = res["output"][0]  # OUT r3 emits the truncated product
    ovf.append((name, prod, observed))
    print(f"    {name}: true={prod} (0x{prod:X})  observed={observed} (0x{observed:X})"
          f"  plain-multiply-wrong={prod != observed}")

n_obs = len(ovf)
check("at least 2 observable overflow samples", n_obs >= 2, f"have {n_obs}")

# every overflow sample refutes a plain (non-truncating) multiply
all_refute = all(prod != observed for _, prod, observed in ovf)
check("each overflow sample refutes plain multiply", all_refute)

# modulus recovery: M | gcd(P_i - observed_i) and M > max(observed_i)
diffs = [prod - observed for _, prod, observed in ovf]
G = 0
for d in diffs:
    G = math.gcd(G, d)
mx = max(observed for _, _, observed in ovf)
modulus_pinned = (G == TWO32 and TWO31 <= mx < TWO32)
check("modulus pins uniquely to 2**32", modulus_pinned,
      f"gcd(P-observed)={G} (0x{G:X}); max observed={mx} (0x{mx:X}); "
      f"high-bit set in an observed result = {mx >= TWO31}")
results["numbers"]["D1_observable_overflow_samples"] = n_obs
results["numbers"]["D1_gcd_of_diffs"] = G
results["numbers"]["D1_max_observed_result"] = mx
results["numbers"]["D1_modulus"] = G if modulus_pinned else None

# width stays latent: only the designated overflow samples ever wrap observably
wrapping_samples = {}
for name in P.SAMPLES:
    words, ir, im = asm_sample(name)
    res = run(words, ir, im, REFERENCE)
    if res["wraps"]:
        wrapping_samples[name] = [w[1] for w in res["wraps"]]
only_designated = set(wrapping_samples) == set(OVERFLOW_SAMPLES)
all_mul = all(all(op == "MUL" for op in ops) for ops in wrapping_samples.values())
check("width stays latent: only the 3 designated samples wrap, and only via MUL",
      only_designated and all_mul,
      f"wrapping samples = {dict(wrapping_samples)}")
results["numbers"]["D1_wrapping_samples"] = sorted(wrapping_samples)

# ============================================================================
# D2 : register-indirect addressing, recovered from the disassembler's decode
# ============================================================================
print("\n-- D2: register-indirect mode (evidence: disassembler decode) --")

sample_mode1 = sum(mode1_count(asm_sample(n)[0]) for n in P.SAMPLES)
heldout_mode1 = sum(mode1_count(asm_heldout(n)[0]) for n in P.HELDOUT)
check("no sample uses mode 1; held-out does", sample_mode1 == 0 and heldout_mode1 > 0,
      f"sample mode-1 instrs = {sample_mode1}; held-out mode-1 instrs = {heldout_mode1}")
results["numbers"]["D2_sample_mode1"] = sample_mode1
results["numbers"]["D2_heldout_mode1"] = heldout_mode1

# the mode is visible in the listing: register-indirect renders as base + displacement,
# distinct from a direct absolute address, so an expert can read the effective-address
# formula off the disassembly.
d_words, _ = assemble([("loadd", 3, 0x0200), ("halt",)])
i_words, _ = assemble([("loadx", 3, 1, 0x0200), ("halt",)])
d_line = disassemble(d_words)[0][1]
i_line = disassemble(i_words)[0][1]
print(f"    direct   LOAD r3,[0x0200] renders: {d_line!r}")
print(f"    indirect LOAD r3,[r1+512] renders: {i_line!r}")
check("mode-1 renders base register + displacement, distinct from direct",
      i_line == "LOAD r3, [r1 + 512]" and d_line == "LOAD r3, [0x0200]",
      f"direct={d_line!r}, indirect={i_line!r}")

# ============================================================================
# D3 : signed comparison, recovered from sample traces
# ============================================================================
print("\n-- D3: signed comparison (evidence: sample traces) --")
UNSIGNED = Semantics(signed_compare=False)

d3_distinguishable = True
d3_rows = []
for name in D3_SAMPLES:
    words, ir, im = asm_sample(name)
    ref = run(words, ir, im, REFERENCE)
    uns = run(words, ir, im, UNSIGNED)
    differ = bool(ref["output"] != uns["output"] and ref["output"] and uns["output"])
    d3_distinguishable = d3_distinguishable and differ
    d3_rows.append((name, ref["output"], uns["output"], differ))
    print(f"    sample {name:20s}  signed->{ref['output']}  unsigned->{uns['output']}"
          f"  distinguishable={differ}")

check("each D3 disambiguation sample yields two clearly distinct observable outcomes",
      d3_distinguishable)
results["numbers"]["D3_sample_outcomes"] = [
    {"sample": n, "signed": s, "unsigned": u} for n, s, u, _ in d3_rows
]

# same on the graded held-out D3 programs
d3_heldout_ok = True
for name in ["signed_branch", "signed_select"]:
    words, ir, im, _ = asm_heldout(name)
    ref = run(words, ir, im, REFERENCE)
    uns = run(words, ir, im, UNSIGNED)
    differ = ref["output"] != uns["output"]
    d3_heldout_ok = d3_heldout_ok and differ
    print(f"    heldout {name:20s}  signed->{ref['output']}  unsigned->{uns['output']}"
          f"  wrong-model-differs={differ}")
check("held-out D3 programs produce wrong-but-finite output under an unsigned model",
      d3_heldout_ok)

# ============================================================================
# independence preview: which held-out each one-decision mutant changes
# (full mutant matrix vs the real verifier is Phase 5; this is a design preview)
# ============================================================================
print("\n-- independence preview (mutant vs reference on held-out) --")
MUTANTS = {
    "no-truncate-MUL": Semantics(truncate_mul=False),
    "direct-only-mem": Semantics(reg_indirect=False),
    "unsigned-compare": Semantics(signed_compare=False),
}
ref_out = {}
for name in P.HELDOUT:
    words, ir, im, _ = asm_heldout(name)
    ref_out[name] = run(words, ir, im, REFERENCE)

isolation = {}
for mname, sem in MUTANTS.items():
    changed = []
    for name in P.HELDOUT:
        words, ir, im, _ = asm_heldout(name)
        try:
            res = run(words, ir, im, sem)
            diff = (res["output"] != ref_out[name]["output"]
                    or res["regs"] != ref_out[name]["regs"])
        except VMError:
            diff = True
        if diff:
            changed.append(name)
    isolation[mname] = changed
    print(f"    {mname:18s} changes: {changed}")

expected = {
    "no-truncate-MUL": ["mul_overflow_chain", "mul_overflow_poly"],
    "direct-only-mem": ["table_lookup", "store_indirect"],
    "unsigned-compare": ["signed_branch", "signed_select"],
}
clean = all(sorted(isolation[k]) == sorted(v) for k, v in expected.items())
check("each mutant changes exactly its own axis's held-out (clean isolation)", clean)
results["numbers"]["independence"] = isolation

# ----------------------------------------------------------------------------
print("\n" + "=" * 72)
n_pass = sum(1 for _, ok, _ in results["checks"] if ok)
n_total = len(results["checks"])
print(f"BENCH RESULT: {n_pass}/{n_total} checks passed")
print("=" * 72)
import json
print(json.dumps(results["numbers"], indent=2))
