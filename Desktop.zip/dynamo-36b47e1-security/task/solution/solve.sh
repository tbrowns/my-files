#!/bin/bash
# Reference (Oracle) solution. Harbor mounts solution/ at /solution and runs this.
# It evaluates every challenge program with the reference interpreter and writes
# the graded state to /app/output/<id>.json.
set -euo pipefail

python3 /solution/solve.py
