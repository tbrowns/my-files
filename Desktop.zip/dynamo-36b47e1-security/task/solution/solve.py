"""Reference (oracle) solver.

The intended solution recovers the VM semantics and evaluates each challenge
program. This reference shortcuts that by evaluating with the known-correct
interpreter: for every program under /app/challenge, run it from its initial
state and write the final register file and emitted output to
/app/output/<id>.json in the reported schema (registers r0..r7 as unsigned
decimals, output an ordered list of unsigned decimals).
"""

import glob
import json
import os
import struct
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "vm"))

from statefmt import run_program  # noqa: E402

CHALLENGE_DIR = "/app/challenge"
OUTPUT_DIR = "/app/output"


def load_words(path):
    with open(path, "rb") as f:
        raw = f.read()
    return list(struct.unpack("<%dI" % (len(raw) // 4), raw))


def load_input(path):
    if not os.path.exists(path):
        return {}, {}
    with open(path) as f:
        obj = json.load(f)
    regs = {int(k): int(v) for k, v in obj.get("regs", {}).items()}
    mem = {int(k): int(v) for k, v in obj.get("mem", {}).items()}
    return regs, mem


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    for bin_path in sorted(glob.glob(os.path.join(CHALLENGE_DIR, "*.bin"))):
        cid = os.path.splitext(os.path.basename(bin_path))[0]
        words = load_words(bin_path)
        regs, mem = load_input(os.path.join(CHALLENGE_DIR, f"{cid}.input.json"))
        state = run_program(words, regs, mem)
        with open(os.path.join(OUTPUT_DIR, f"{cid}.json"), "w", newline="\n") as f:
            json.dump(state, f, indent=2)
            f.write("\n")
        print(f"wrote {cid}.json")


if __name__ == "__main__":
    main()
