"""Verifier: grade the agent's recovered final states against the withheld golden.

Each challenge program has a deterministic final state (register file + emitted
output). The agent writes /app/output/<id>.json; these tests compare parsed
integers to the golden states, exactly. Golden lives under /tests/golden and is
never present during the agent run.
"""

import json
import os

OUTPUT_DIR = "/app/output"
GOLDEN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "golden")

CHALLENGE_IDS = ["c01", "c02", "c03", "c04", "c05", "c06", "c07"]
REG_KEYS = [f"r{i}" for i in range(8)]

# which programs exercise which recovered behaviour (for discriminator coverage)
HASH_MODULUS = ["c01", "c02", "c03"]  # secret-prime Horner hash (workhorse)
MULTIPLY_EDGE = ["c04", "c05"]        # truncating multiply
SIGNED_COMPARISON = ["c06", "c07"]    # signed ordered comparison


def _load(path):
    with open(path) as f:
        return json.load(f)


def _golden(cid):
    return _load(os.path.join(GOLDEN_DIR, f"{cid}.json"))


def _agent_path(cid):
    """Return the graded output path, rejecting symlink / path-escape tampering.

    The golden lives under /tests, which is overlaid only at verify time. A
    submission could point its output (or the whole /app/output directory) at the
    reference files to score without solving. Require a real regular file that
    resolves to inside /app/output.
    """
    assert not os.path.islink(OUTPUT_DIR), "output directory must not be a symlink"
    path = os.path.join(OUTPUT_DIR, f"{cid}.json")
    assert os.path.exists(path), f"missing output for {cid}"
    assert not os.path.islink(path), f"{cid}: output must not be a symlink"
    assert os.path.realpath(path) == os.path.join(OUTPUT_DIR, f"{cid}.json"), \
        f"{cid}: output must be a real file inside {OUTPUT_DIR}"
    return path


def _agent(cid):
    return _load(_agent_path(cid))


def _norm_regs(regs):
    return {k: int(regs[k]) for k in REG_KEYS}


def _norm_output(output):
    return [int(v) for v in output]


def test_all_challenge_outputs_present():
    """Every challenge id has a well-formed output file with r0..r7 and an output list."""
    for cid in CHALLENGE_IDS:
        obj = _load(_agent_path(cid))
        assert set(REG_KEYS) <= set(obj.get("regs", {})), f"{cid}: regs must include r0..r7"
        assert isinstance(obj.get("output"), list), f"{cid}: output must be a list"


def test_register_files_match_golden():
    """Every challenge program's final register file equals the golden, value by value."""
    for cid in CHALLENGE_IDS:
        assert _norm_regs(_agent(cid)["regs"]) == _norm_regs(_golden(cid)["regs"]), \
            f"{cid}: register file mismatch"


def test_emitted_outputs_match_golden():
    """Every challenge program's emitted output equals the golden, in order."""
    for cid in CHALLENGE_IDS:
        assert _norm_output(_agent(cid)["output"]) == _norm_output(_golden(cid)["output"]), \
            f"{cid}: emitted output mismatch"


def test_truncating_multiply_edge():
    """Programs whose multiply overflows the register width match golden (truncated result)."""
    for cid in MULTIPLY_EDGE:
        a, g = _agent(cid), _golden(cid)
        assert _norm_regs(a["regs"]) == _norm_regs(g["regs"]), f"{cid}: multiply-edge registers"
        assert _norm_output(a["output"]) == _norm_output(g["output"]), f"{cid}: multiply-edge output"


def test_hash_modulus():
    """Programs computing the Horner hash match golden (correct secret-prime modulus)."""
    for cid in HASH_MODULUS:
        a, g = _agent(cid), _golden(cid)
        assert _norm_regs(a["regs"]) == _norm_regs(g["regs"]), f"{cid}: hash-modulus registers"
        assert _norm_output(a["output"]) == _norm_output(g["output"]), f"{cid}: hash-modulus output"


def test_signed_comparison():
    """Programs branching on a signed ordered comparison match golden (correct branch taken)."""
    for cid in SIGNED_COMPARISON:
        a, g = _agent(cid), _golden(cid)
        assert _norm_regs(a["regs"]) == _norm_regs(g["regs"]), f"{cid}: signed-comparison registers"
        assert _norm_output(a["output"]) == _norm_output(g["output"]), f"{cid}: signed-comparison output"
