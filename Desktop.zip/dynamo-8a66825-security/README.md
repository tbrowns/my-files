# dynamo/badge-log-forensics

Security / Digital Forensics task (Harbor "TB2" format). The whole task lives in
[`task/`](task/).

## Overview

A door-access controller was pulled from an intrusion at "Building 7" and its
on-flash binary event journal was imaged. During the incident the tamperer zeroed
the cardholder-id field on the single server-room (door 3) access grant. The agent
is given three evidence files under `/app/evidence/` — the imaged journal
(`journal.bin`), a vendor field-service reference for the record format
(`controller_reference.txt`), and the examiner's case notes (`case_notes.txt`) —
and must write `/app/findings.json` with two exact facts about that event:

- `cardholder_id` — the original (now-zeroed) cardholder number, and
- `access_time_utc` — the true wall-clock time of the grant in UTC.

Both are single, objectively-determined scalars, graded by exact equality,
all-or-nothing. Nothing in the instruction reveals *how* either is recovered.

## Approach (reference solution)

Two independent obstacles stand between the analyst and the answer; neither is
stated anywhere in the inputs, and each is discovered from a different artifact
with a different skill.

1. **Integrity-key recovery (recovers `cardholder_id`).** Each record carries a
   4-byte integrity trailer that matches no standard CRC or named checksum: it is
   the record's 24 body bytes read as one big-endian integer, reduced modulo a
   secret ~32-bit prime `M` baked into firmware. For every intact record,
   `int(body) − trailer` is a multiple of `M`, so `M = gcd` over those differences
   (the modulus is prime, so the gcd lands on it exactly). The tamperer could not
   recompute the trailer, so the zeroed id is still pinned by the surviving
   trailer — recovered by brute-forcing the disclosed six-digit id range against
   it (exactly one value matches). Catalogue-first instincts (CRC/hash tools) all
   fail here; the modulus-by-gcd route is the crux.

2. **Latent RTC skew (recovers `access_time_utc`).** The controller's clock is
   hand-set at commissioning and never disciplined, so it runs at a constant
   unknown offset from true UTC, with no timezone field. Reading the timestamp as
   UTC is silently wrong. The offset is fixed by anchoring the two events that
   occur exactly once in the journal — the boot and the door-3 forced-open alarm —
   to the externally-observed UTC times in the case notes, confirming the offset
   is constant, then subtracting it from the grant's timestamp.

`task/solution/solve.py` performs both derivations from the shipped artifacts
alone (no hardcoded answers).

## Environment

A single container image (`task/environment/Dockerfile`) built for both the agent
and the verifier, `FROM` the pre-approved `python:3.13-slim-bookworm` digest. The
three evidence files (`task/environment/data/`) are copied to `/app/evidence/`;
the verifier dependency (`pytest`, pinned) is baked at build time. The journal is
synthetic but models a real access-control device journal format and a real
forensic gotcha (unsynchronized embedded RTCs). Ground truth and the secret
modulus/skew live only with the verifier — never in the agent's environment.

## Verification

`task/tests/test.sh` runs `task/tests/test_outputs.py` against the agent's
`/app/findings.json` (the only requested output) and writes `1`/`0` to
`/logs/verifier/reward.txt`. Three atomic tests: the file is a JSON object with
both keys; `cardholder_id` equals the recovered value exactly; and
`access_time_utc` parses to the exact UTC instant after skew correction (a `Z` or
`+00:00` spelling is equivalent, but any wrong instant — including the naive
device time — fails). There are no tolerance bands or fuzzy matching: each field
is uniquely determined by the shipped evidence and checked for exact equality.
