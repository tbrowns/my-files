A door controller was pulled from an intrusion at Building 7 and its on-flash
event journal was imaged. The evidence is in `/app/evidence/`:

- `/app/evidence/journal.bin` — the imaged event journal.
- `/app/evidence/controller_reference.txt` — vendor field-service reference for
  the journal format.
- `/app/evidence/case_notes.txt` — the examiner's working notes for the case.

A single credential was presented at door 3 (the server room) and access was
granted — the only such grant in the journal. After the fact, the cardholder
number stored on that one record was zeroed. Recover the truth about that event:
the original cardholder number, and the actual wall-clock time (UTC) the access
was granted.

Write your answer to `/app/findings.json` as a single JSON object with these
two keys:

- `cardholder_id` — integer, the original cardholder number on the door-3 grant.
- `access_time_utc` — string, the true time of that grant in UTC, formatted
  `YYYY-MM-DDTHH:MM:SSZ` (e.g. `2025-04-18T03:12:07Z`).

Both values are graded exactly.
