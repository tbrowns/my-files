#!/usr/bin/env python3
"""Reference solution for badge-log-forensics.

Recovers, from /app/evidence/ alone:
  * the secret integrity modulus M, by gcd over the intact records
    (each trailer = int(body_bytes, 'big') mod M);
  * the zeroed cardholder id on the sole door-3 access grant, by brute force
    against that record's surviving trailer;
  * the controller's constant RTC skew, by anchoring two journal records
    (the sole boot and the sole forced-door event) to the externally-observed
    UTC times in the case notes, and hence the grant's true UTC time.
"""
import json, re, struct
from math import gcd
from datetime import datetime, timezone

EV_GRANT, EV_FORCED, EV_BOOT = 1, 3, 4
EVID = "/app/evidence"

# ---- parse the journal -------------------------------------------------------
blob = open(f"{EVID}/journal.bin", "rb").read()
magic, version, rec_size, rec_count, device_id = struct.unpack("<4sHHII", blob[:16])
assert magic == b"ACJ1"
recs = []
for i in range(rec_count):
    raw = blob[16 + i*rec_size : 16 + (i+1)*rec_size]
    body = raw[:24]
    seq, ticks, etype, door, reader, result, card, cred, site = struct.unpack("<IIBBBBIII", body)
    trailer = struct.unpack("<I", raw[24:28])[0]
    recs.append(dict(i=i, raw=raw, body=body, seq=seq, ticks=ticks, etype=etype,
                     door=door, reader=reader, result=result, card=card,
                     cred=cred, trailer=trailer))

# ---- the tampered target: the sole granted access at door 3 ------------------
target = next(r for r in recs if r["etype"] == EV_GRANT and r["door"] == 3)

# ---- recover M by gcd over every other (intact) record -----------------------
M = 0
for r in recs:
    if r is target:
        continue
    M = gcd(M, int.from_bytes(r["body"], "big") - r["trailer"])
assert M > 2**31 and all(
    int.from_bytes(r["body"], "big") % M == r["trailer"] for r in recs if r is not target)

# ---- brute-force the zeroed cardholder id against the surviving trailer -------
# controller_reference.txt pins cardholder_id to 100000..999999, so the original
# id is guaranteed to lie in the swept range and the sweep cannot miss it; the
# prime modulus makes the match that reproduces the surviving trailer unique.
head, tail, tr = target["raw"][:12], target["raw"][16:24], target["trailer"]
def body_with(x):
    return head + struct.pack("<I", x) + tail
found = [x for x in range(100000, 1000000)
         if int.from_bytes(body_with(x), "big") % M == tr]
assert len(found) == 1, f"expected exactly one in-range cardholder id, got {found}"
cardholder_id = found[0]
assert int.from_bytes(body_with(cardholder_id), "big") % M == tr  # round-trip check

# ---- recover the constant RTC skew from the two external anchors -------------
notes = open(f"{EVID}/case_notes.txt").read()
def note_time(keyword):
    for line in notes.splitlines():
        if keyword in line.lower():
            m = re.search(r"(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}) UTC", line)
            if m:
                dt = datetime.strptime(m.group(1)+" "+m.group(2), "%Y-%m-%d %H:%M:%S")
                return int(dt.replace(tzinfo=timezone.utc).timestamp())
    raise RuntimeError(keyword)

boot_rec   = next(r for r in recs if r["etype"] == EV_BOOT)
forced_rec = next(r for r in recs if r["etype"] == EV_FORCED)
skew = boot_rec["ticks"] - note_time("boot")
assert skew == forced_rec["ticks"] - note_time("forced")   # constant offset

true_unix = target["ticks"] - skew
access_time_utc = datetime.fromtimestamp(true_unix, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

json.dump({"cardholder_id": cardholder_id, "access_time_utc": access_time_utc},
          open("/app/findings.json", "w"))
print("M =", M, "skew =", skew, "->", cardholder_id, access_time_utc)
