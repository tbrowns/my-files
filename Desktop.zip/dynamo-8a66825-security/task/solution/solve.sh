#!/bin/bash
# Reference (Oracle) solution. Harbor mounts solution/ at /solution/ and runs this.
set -euo pipefail
python3 /solution/solve.py
