"""Verifier for badge-log-forensics.

Grades /app/findings.json against the two forensic facts the instruction asks
for. Both are uniquely determined by the shipped evidence:

  * cardholder_id (640118): the sole door-3 ACCESS_GRANT had its cardholder id
    zeroed but its integrity trailer intact. Every intact record satisfies
    trailer == int(body_bytes, 'big') mod M for a secret ~32-bit prime M;
    M = gcd over the intact records' (int(body) - trailer), and the wiped id is
    the unique value in 100000..999999 whose reconstructed body reproduces the
    surviving trailer.
  * access_time_utc (2025-05-02T22:39:26Z): the controller RTC runs at a constant
    unknown offset from UTC. Anchoring the sole boot record and the sole
    forced-door record to the external UTC times in case_notes.txt fixes that
    offset (20893 s); the grant's true UTC time is its ticks minus the offset.
    (A naive reading of ticks as UTC yields 2025-05-03T04:27:39Z, which is wrong.)
"""
import json
from datetime import datetime, timezone

FINDINGS = "/app/findings.json"
EXPECTED_CARDHOLDER_ID = 640118
EXPECTED_ACCESS_TIME = "2025-05-02T22:39:26Z"


def _load():
    with open(FINDINGS) as f:
        return json.load(f)


def _to_utc_instant(s):
    """Parse an RFC3339 timestamp string to an exact unix second (a tz-naive
    value is read as UTC, since the field is defined as UTC)."""
    s = str(s).strip()
    if s.endswith(("Z", "z")):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.astimezone(timezone.utc).timestamp())


def test_findings_is_json_object_with_required_keys():
    """findings.json exists, parses as a JSON object, and has the two required keys."""
    data = _load()
    assert isinstance(data, dict)
    assert "cardholder_id" in data and "access_time_utc" in data


def test_cardholder_id_recovered():
    """The zeroed cardholder id on the door-3 grant is recovered exactly (integrity-modulus recovery)."""
    data = _load()
    cid = data["cardholder_id"]
    # instruction.md defines cardholder_id as a JSON integer; reject strings,
    # floats, and booleans so no coerced or near-miss value slips through.
    assert isinstance(cid, int) and not isinstance(cid, bool)
    assert cid == EXPECTED_CARDHOLDER_ID


def test_access_time_utc_is_true_wall_clock():
    """The grant's reported time equals the true UTC instant after RTC-skew correction (not raw device time)."""
    data = _load()
    assert _to_utc_instant(data["access_time_utc"]) == _to_utc_instant(EXPECTED_ACCESS_TIME)
