"""Verifier for the FG-220 escrow-vault recovery task.

Ground truth (verifier-side only; never present in the environment image):

  master_key        the 62-bit prime the appliance sealed every record under.
                    Recoverable from /app/vault/keyvault.kvlt as the gcd of
                    (record body as a big-endian integer - record trailer) over
                    the file's records, and confirmed by the fact that it
                    reproduces all twelve trailers exactly.
  active_slot_id    the active-slot field of the vault header.
  recovered_secret  the secret in the highest-revision record of that slot,
                    which lives in the record journal appended after the slot
                    table -- not in the slot table itself, whose copy is the
                    superseded revision 1 value.

Every check is exact equality on a value the agent wrote; nothing here inspects
the agent's source or method.
"""

import json
import os

import pytest

FINDINGS_PATH = "/app/output/findings.json"

EXPECTED_MASTER_KEY = 3465461797281629617
EXPECTED_ACTIVE_SLOT_ID = 4
EXPECTED_SECRET = "Z8MR-4HQC-6PWT-9DKN-3VBJ"

REQUIRED_KEYS = {"master_key", "active_slot_id", "recovered_secret"}


@pytest.fixture(scope="module")
def findings():
    """Parse /app/output/findings.json once for every check below."""
    assert os.path.isfile(FINDINGS_PATH), f"{FINDINGS_PATH} was not created"
    with open(FINDINGS_PATH, "r", encoding="utf-8") as fh:
        raw = fh.read()
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:  # pragma: no cover - diagnostic path
        pytest.fail(f"{FINDINGS_PATH} is not valid JSON: {exc}")


def test_findings_is_a_json_object_with_the_three_required_keys(findings):
    """findings.json is a single JSON object carrying exactly the three declared keys."""
    assert isinstance(findings, dict), (
        f"{FINDINGS_PATH} must hold a single JSON object, got {type(findings).__name__}"
    )
    assert set(findings) == REQUIRED_KEYS, (
        f"{FINDINGS_PATH} must have exactly the keys {sorted(REQUIRED_KEYS)}, "
        f"got {sorted(findings)}"
    )


def test_master_key_is_the_recovered_vault_master(findings):
    """master_key is the exact integer vaultlib.derive_key() expects for this vault.

    This is the recovered secret modulus every record trailer was reduced under;
    only one value reproduces the trailers, so any other answer is wrong.
    """
    value = findings["master_key"]
    assert isinstance(value, int) and not isinstance(value, bool), (
        f"master_key must be a JSON integer, got {type(value).__name__}"
    )
    assert value == EXPECTED_MASTER_KEY, f"master_key {value} does not unseal this vault"


def test_active_slot_id_is_the_vaults_active_slot(findings):
    """active_slot_id is the exact id of the slot the vault header marks active."""
    value = findings["active_slot_id"]
    assert isinstance(value, int) and not isinstance(value, bool), (
        f"active_slot_id must be a JSON integer, got {type(value).__name__}"
    )
    assert value == EXPECTED_ACTIVE_SLOT_ID, (
        f"active_slot_id {value} is not the vault's active slot"
    )


def test_recovered_secret_is_the_live_value_of_the_active_slot(findings):
    """recovered_secret is the active slot's plaintext secret in the vault's final state.

    Exact string equality: the secret must be the one held by that slot's
    highest-revision record, verbatim and untrimmed.
    """
    value = findings["recovered_secret"]
    assert isinstance(value, str), (
        f"recovered_secret must be a JSON string, got {type(value).__name__}"
    )
    assert value == EXPECTED_SECRET, (
        "recovered_secret is not the value the active slot holds in the vault's "
        f"final state (got {value!r})"
    )
