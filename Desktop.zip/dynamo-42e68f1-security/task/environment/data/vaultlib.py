"""kvlt -- key-escrow vault reader.

Aperion FG-220 gateway firmware, image 1.4.2 (build 20250311).
Shipped read-only helper: the appliance seals slot values with the provisioning
service; this library only opens them again.

Typical use on the appliance:

    import vaultlib
    v = vaultlib.open_vault("/var/lib/kvlt/keyvault.kvlt")
    for rec in v.records:
        print(rec.slot_id, vaultlib.unseal(rec, vaultlib.load_master()))
"""

from __future__ import annotations

import hashlib
import os
import struct
import sys
from dataclasses import dataclass

MAGIC = b"KVLT"

#: Highest vault format this firmware image knows how to read.
SUPPORTED_FORMAT = 1

#: Where the provisioning service drops the master key value on a live unit.
MASTER_KEY_PATH = "/app/vault/master.key"

#: Domain separator for the slot-key derivation.
KDF_LABEL = b"KVLT/kdf/v1|"

# magic, format_version, header_len, vault_id, slot_count, active_slot_id,
# table_off, table_len
_HEADER = struct.Struct(">4sHH8sHHII")

# magic, slot_id, revision, flags, nonce, value_len, reserved
_RECORD = struct.Struct(">2sHHH8sHH")

_TRAILER = struct.Struct(">Q")


@dataclass
class Record:
    """One sealed slot value as it sits on disk."""

    slot_id: int
    revision: int
    flags: int
    nonce: bytes
    value: bytes  # sealed bytes, not readable without the master key
    trailer: int  # written by the provisioning service; not used by this reader
    offset: int


@dataclass
class Vault:
    """A parsed vault file."""

    vault_id: str
    format_version: int
    slot_count: int
    active_slot_id: int
    records: list


def load_master(path: str = MASTER_KEY_PATH) -> int:
    """Read the vault master key value the provisioning service left on disk."""
    with open(path, "r", encoding="ascii") as fh:
        return int(fh.read().strip())


def derive_key(master: int) -> bytes:
    """Derive the 32-byte slot key from the vault master key value."""
    return hashlib.sha256(KDF_LABEL + str(master).encode("ascii")).digest()


def keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    """Expand (key, nonce) into `length` keystream bytes."""
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hashlib.sha256(key + nonce + struct.pack(">I", counter)).digest()
        counter += 1
    return bytes(out[:length])


def unseal(record: Record, master: int) -> dict:
    """Open one sealed record. Returns its label and its secret value."""
    key = derive_key(master)
    plain = bytes(
        a ^ b for a, b in zip(record.value, keystream(key, record.nonce, len(record.value)))
    )
    if plain[:3] != b"KS1":
        raise ValueError("slot value did not open: wrong master key?")
    label_len = plain[3]
    label = plain[4 : 4 + label_len].decode("ascii")
    pos = 4 + label_len
    secret_len = plain[pos]
    secret = plain[pos + 1 : pos + 1 + secret_len].decode("ascii")
    return {"label": label, "secret": secret}


def parse_records(blob: bytes, offset: int, count: int) -> list:
    """Parse `count` consecutive sealed records starting at `offset`."""
    records = []
    pos = offset
    for _ in range(count):
        magic, slot_id, revision, flags, nonce, value_len, _res = _RECORD.unpack_from(blob, pos)
        if magic != b"KR":
            raise ValueError(f"bad record magic at offset {pos}")
        start = pos + _RECORD.size
        value = blob[start : start + value_len]
        (trailer,) = _TRAILER.unpack_from(blob, start + value_len)
        records.append(
            Record(
                slot_id=slot_id,
                revision=revision,
                flags=flags,
                nonce=nonce,
                value=value,
                trailer=trailer,
                offset=pos,
            )
        )
        pos = start + value_len + _TRAILER.size
    return records


def open_vault(path: str) -> Vault:
    """Open a vault file and parse its slot table."""
    with open(path, "rb") as fh:
        blob = fh.read()

    magic, fmt, header_len, vault_id, slot_count, active, table_off, _table_len = (
        _HEADER.unpack_from(blob, 0)
    )
    if magic != MAGIC:
        raise ValueError("not a kvlt vault")
    if fmt > SUPPORTED_FORMAT:
        print(
            f"kvlt: warning: vault format v{fmt} is newer than this reader "
            f"(v{SUPPORTED_FORMAT}); opening the slot table in compatibility mode",
            file=sys.stderr,
        )
    if header_len < _HEADER.size:
        raise ValueError("short vault header")

    return Vault(
        vault_id=vault_id.rstrip(b"\x00").decode("ascii"),
        format_version=fmt,
        slot_count=slot_count,
        active_slot_id=active,
        records=parse_records(blob, table_off, slot_count),
    )


def main(argv: list) -> int:
    if len(argv) != 2:
        print("usage: vaultlib.py <keyvault.kvlt>", file=sys.stderr)
        return 2
    vault = open_vault(argv[1])
    print(f"vault {vault.vault_id} format v{vault.format_version}")
    print(f"slots {vault.slot_count} active slot {vault.active_slot_id}")
    master = load_master() if os.path.exists(MASTER_KEY_PATH) else None
    for rec in vault.records:
        line = f"  slot {rec.slot_id} rev {rec.revision} flags 0x{rec.flags:04x}"
        if master is not None:
            opened = unseal(rec, master)
            line += f" {opened['label']} {opened['secret']}"
        print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
