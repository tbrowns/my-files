#!/usr/bin/env python3
"""Reference solution: break the FG-220 escrow vault and read the live slot secret.

Route, in the order an analyst finds it:

1.  The firmware reader in /app/vault/vaultlib.py is build 1.4.2 and declares
    SUPPORTED_FORMAT = 1, but the vault header says format 2 and the reader says
    so on stderr when it opens the file.  The v1 header stops after
    (table_off, table_len); the v2 header carries two more fields, and the bytes
    after the slot table are a run of further "KR" records -- the in-place
    re-keying the decommissioning note mentions.  So the slot table holds each
    slot's *original* sealed value and the trailing journal holds its later
    revisions; the live value of a slot is its highest-revision record anywhere
    in the file.

2.  Every record carries an 8-byte trailer that the reader parses but never
    uses.  It is the record body reduced modulo the vault master key:

        trailer = int.from_bytes(body, "big") % master

    so master divides (int(body) - trailer) for every intact record.  The master
    is prime, so the gcd of those differences over the records lands on the
    master exactly -- no search over the 2**61..2**62 range is needed, and none
    would be feasible.  The recovered value is confirmed by re-deriving every
    trailer from it, and by unsealing a record (the plaintext carries a "KS1"
    magic, so a wrong key is rejected rather than silently accepted).

3.  vaultlib.derive_key() + vaultlib.unseal() then open the live record of the
    slot the header marks active.
"""

from __future__ import annotations

import json
import math
import os
import struct
import sys

sys.path.insert(0, "/app/vault")
import vaultlib  # noqa: E402  (the shipped firmware reader)

VAULT_PATH = "/app/vault/keyvault.kvlt"
OUTPUT_PATH = "/app/output/findings.json"

# The v2 header: the v1 struct in vaultlib plus (journal_off, journal_count).
_HEADER_V2 = struct.Struct(">4sHH8sHHIIIH")


def parse_all_records(blob: bytes) -> tuple:
    """Return (header fields, every sealed record in the file: table + journal)."""
    (
        magic,
        fmt,
        _header_len,
        _vault_id,
        slot_count,
        active_slot_id,
        table_off,
        _table_len,
        journal_off,
        journal_count,
    ) = _HEADER_V2.unpack_from(blob, 0)
    if magic != vaultlib.MAGIC:
        raise ValueError(f"{VAULT_PATH}: not a kvlt vault")
    if fmt != 2:
        raise ValueError(f"{VAULT_PATH}: unexpected vault format v{fmt}")

    records = vaultlib.parse_records(blob, table_off, slot_count)
    records += vaultlib.parse_records(blob, journal_off, journal_count)

    # Every byte of the file must be accounted for, or there is more evidence
    # to read before trusting the recovery below.
    end = records[-1].offset + vaultlib._RECORD.size + len(records[-1].value) + 8
    if end != len(blob):
        raise ValueError(f"{VAULT_PATH}: {len(blob) - end} unparsed trailing bytes")
    return active_slot_id, records


def record_body(blob: bytes, record) -> bytes:
    """The bytes the trailer is computed over: the whole record minus the trailer."""
    return blob[record.offset : record.offset + vaultlib._RECORD.size + len(record.value)]


def recover_master(blob: bytes, records: list) -> int:
    """Recover the vault master key as the gcd of (body - trailer) over all records."""
    master = 0
    for record in records:
        body = int.from_bytes(record_body(blob, record), "big")
        if body <= record.trailer:
            raise ValueError("record body is smaller than its trailer")
        master = math.gcd(master, body - record.trailer)

    if master.bit_length() < 32:
        raise ValueError(
            f"gcd collapsed to a {master.bit_length()}-bit value ({master}); "
            "the records are not all sealed under one modulus"
        )

    # Round-trip: the recovered value must reproduce every trailer in the file.
    for record in records:
        body = int.from_bytes(record_body(blob, record), "big")
        if body % master != record.trailer:
            raise ValueError(
                f"recovered master {master} does not reproduce the trailer of "
                f"slot {record.slot_id} rev {record.revision}"
            )
    return master


def live_record(records: list, slot_id: int):
    """The record in force for a slot: its highest revision anywhere in the file."""
    candidates = [r for r in records if r.slot_id == slot_id]
    if not candidates:
        raise ValueError(f"no records for slot {slot_id}")
    top = max(r.revision for r in candidates)
    winners = [r for r in candidates if r.revision == top]
    if len(winners) != 1:
        raise ValueError(f"slot {slot_id} has {len(winners)} records at revision {top}")
    return winners[0]


def main() -> int:
    with open(VAULT_PATH, "rb") as fh:
        blob = fh.read()

    active_slot_id, records = parse_all_records(blob)
    master = recover_master(blob, records)
    opened = vaultlib.unseal(live_record(records, active_slot_id), master)

    findings = {
        "master_key": master,
        "active_slot_id": active_slot_id,
        "recovered_secret": opened["secret"],
    }
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(findings, fh, indent=2, sort_keys=True)
        fh.write("\n")
    print(json.dumps(findings, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
