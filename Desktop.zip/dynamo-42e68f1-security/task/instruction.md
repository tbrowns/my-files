An Aperion FG-220 field gateway was decommissioned and wiped. Its key-escrow vault
file survived the wipe; the master key value that unseals it did not.

Everything recovered from the unit is in `/app/vault/`:

- `/app/vault/keyvault.kvlt` — the escrow vault written by the appliance.
- `/app/vault/vaultlib.py` — the vault reader from the gateway's firmware image.
- `/app/vault/DECOMMISSION.txt` — the decommissioning note left by the operator.

`vaultlib.derive_key()` turns the vault master key — a single positive integer —
into the key that unseals stored slot values. That integer is what was lost. It is
not on this machine, it is not published anywhere, and its range is far too large
to search. It is, however, recoverable from `/app/vault/keyvault.kvlt` itself.

Recover it, then read out the secret held by the vault's active slot as of the
vault's final state — the value the customer would have been using when the unit
was pulled.

Write your findings to `/app/output/findings.json`: one JSON object, exactly these
three keys.

```json
{
  "master_key": 0,
  "active_slot_id": 0,
  "recovered_secret": ""
}
```

`master_key` — JSON integer. The vault master key value, i.e. the integer that
`vaultlib.derive_key()` expects.

`active_slot_id` — JSON integer. The id of the vault's active slot.

`recovered_secret` — JSON string. The plaintext secret that slot holds in the
vault's final state, exactly as stored: no surrounding whitespace, no added
quoting, no re-encoding, no truncation.

Use whatever tools and languages you like; only the contents of
`/app/output/findings.json` are graded. Every field is checked for an exact value
and an exact JSON type, and grading is all-or-nothing: three correct fields pass,
anything else fails.
