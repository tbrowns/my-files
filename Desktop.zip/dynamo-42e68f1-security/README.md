# vault-master-recovery

Break a decommissioned network appliance's bespoke key-escrow vault: recover the
lost master key value from the sealed records themselves, then read out the
secret its active slot held when the unit was pulled.

**Category:** Security / Cryptography · **Harbor task:** `dynamo/vault-master-recovery`

## Overview

An Aperion FG-220 field gateway was decommissioned and wiped. The key-escrow
vault file survived; the master key value that unseals it was destroyed with the
boot volume. Three artifacts are recovered from the unit, in `/app/vault/`:

| Artifact | What it is |
|---|---|
| `keyvault.kvlt` | The escrow vault written by the appliance — a 913-byte file in a proprietary "KVLT" format. |
| `vaultlib.py` | The vault reader from the gateway's firmware image (build 1.4.2). |
| `DECOMMISSION.txt` | The decommissioning note left by the operator. |

The agent writes `/app/output/findings.json` with three fields — `master_key`,
`active_slot_id`, `recovered_secret` — each graded for an exact value and an
exact JSON type, all-or-nothing.

Every graded field is objectively single-valued and recoverable from the shipped
artifacts alone: the master key is the unique modulus that reproduces all twelve
record trailers, the active slot id is a vault header field, and the secret is
the plaintext of one specific record.

## The break

The vault is protected by a homebrew construction, so no catalogued attack
applies. Two independent obstacles sit between the agent and the answer.

**Recovering the master key.** Each sealed record carries an 8-byte trailer that
the firmware reader parses but never uses. It is the record body, read as a
big-endian integer, reduced modulo the vault master key. Nothing states that, and
the master is a 62-bit prime, so searching its range is infeasible and every
checksum-identification reflex — CRC catalogues, named MACs, SAT or byte-affine
recovery, power-of-two lifting — comes back empty. The route that works is
noticing that the master divides `body − trailer` for every intact record and
taking the gcd across records, which lands on the prime exactly. The recovered
value is then confirmed by re-deriving all twelve trailers from it.

**Reading the live value.** The shipped reader is firmware 1.4.2, declares
`SUPPORTED_FORMAT = 1`, and walks only the slot table. The vault on disk is
format 2 and appends a journal of re-keyed records after that table. The reader
warns about the version on stderr and otherwise succeeds, so trusting it unseals
each slot's superseded revision-1 value and yields a well-formed, plausible,
wrong secret. The evidence is all present and visible — the version mismatch, the
warning, 433 unparsed trailing bytes, six further record magics, and a
decommissioning note that mentions repeated in-place re-keying against a reader
that reports revision 1 everywhere.

The two are independent: recovering the modulus does not reveal the journal, and
finding the journal does not help with the modulus. The gcd taken over the slot
table alone still recovers the master exactly.

## Environment

A single image, built from `task/environment/Dockerfile` and shared by the agent
and the verifier. It starts from the pre-approved, digest-pinned
`python:3.13-slim-bookworm`, bakes in the verifier's `pytest` and
`pytest-json-ctrf` at pinned versions so verification installs nothing, copies
`environment/data/` to `/app/vault`, and pre-creates `/app/output`. The task needs
nothing beyond the Python standard library. The master key value and the expected
outputs appear nowhere in the image.

## Verification

`task/tests/test.sh` runs `task/tests/test_outputs.py` and writes `1`/`0` to
`/logs/verifier/reward.txt`. The verifier reads only
`/app/output/findings.json` and compares each declared field for exact value and
exact JSON type — `master_key` and `active_slot_id` must be JSON integers with
booleans rejected, `recovered_secret` an exact JSON string. Nothing inspects the
agent's source or method, so any route that arrives at the right values passes.
Ground truth lives only in `task/tests/`, which Harbor overlays at verify time.

Locally: `harbor run -p task --agent oracle` scores 1.000 and
`harbor run -p task --agent nop` scores 0.000. Three one-decision-different
variants of the reference isolate the two obstacles, each failing via wrong
graded output rather than a crash or a timeout: a wrong or unrecovered modulus
fails exactly `master_key` and `recovered_secret`; reading only the slot table
fails exactly `recovered_secret`; and taking the first journal hit for the active
slot instead of its highest revision also fails exactly `recovered_secret`.
