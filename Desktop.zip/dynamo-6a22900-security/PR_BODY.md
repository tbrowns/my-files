## One sentence problem

The task is done when all 18 held-out provisioning records have been encoded to
`/app/output/<id>.bin` exactly as the vendor's writer would have produced them, byte
for byte.

## Success criteria

Mirroring `task/instruction.md`:

1. One encoded file per record in `/app/data/records.json`, written to
   `/app/output/<id>.bin` using that record's own `id` field.
2. Nothing else left in `/app/output`.
3. Every file byte for byte identical to what the vendor's writer produces. The
   encoding is a deterministic function of the record, so exactly one output is
   correct for each one.

The verifier splits criterion 3 into named pieces so that a failure says which rule
broke rather than reporting an opaque mismatch: magic and version, the content
derived flags byte, varint values, varint minimality, entry content and canonical
ordering, and the checksum trailer. Nothing is graded beyond criterion 3.

## Calibration results

On the final tree:

| Command | Result |
|---|---|
| `harbor run -p . --agent oracle` | reward 1.0, three consecutive runs |
| `harbor run -p . --agent nop` | reward 0.0, three consecutive runs |

The verifier is 8 test functions parametrized per record, 127 cases, running in 1 to
4 seconds against a 300 second cap. A whole trial takes about a minute.

Clean image confirmed on a fresh build. `find / \( -name solve.sh -o -name test.sh
\)` returns nothing, and a widened search for `solve.*`, `test_outputs.py`,
`refcodec.py`, `records_golden.json`, `golden` and `reward.txt` is also empty. No
blob carrying the format magic exists anywhere in the image outside the 24 samples
and the reader itself, so no golden encoding of a held-out record is reachable.

Discriminator evidence, from mutant encoders run against the real verifier inside
the real image:

| Mutant | Samples reproduced | Cases failed of 127 |
|---|---|---|
| reference | 24/24 | 0 |
| flags bit0 never set | 24/24 | 27 |
| wrong modulus, Adler prime 65521 | 0/24 | 36 |
| one byte varints | 24/24 | 72 |
| non minimal varints | 0/24 | 54 |
| no NFC normalization | 16/24 | 68 |
| no entry sort | 0/24 | 72 |

The two that carry the task are surgical. The flags mutant reproduces every sample
and fails exactly the nine records that carry the crux, times three test functions.
The wrong modulus mutant fails exactly the 18 records times two, and nothing else.

The instruction is 921 characters, roughly 230 tokens against the 1500 limit.

## How to run

```bash
cd task
harbor run -p . --agent oracle   # expect reward 1.0
harbor run -p . --agent nop      # expect reward 0.0
```

## Notes and open questions

Three rules decide an attempt, and they are not equally hard.

The prime modulus in the trailer is recoverable from the samples by gcd. Every
sample constrains it, so a wrong modulus reproduces none of the 24 and the solver
finds out at once. The difficulty there is recovery effort rather than silence, and
I am not relying on it to carry the task.

The multi byte varint rule is exercised by no sample and lives in the validator's
parse loop, but it is also enforced by framing, so a one byte assumption produces a
blob the validator rejects outright. I have treated it as a diligence check rather
than a difficulty axis.

The flags bit is the quiet one. It is clear in all 24 samples, the validator reads
it without ever checking it against the values, and nine held-out records need it
set.

On the fairness of that bit, since it is the thing I would question first: the rule
is in the shipped binary, which is agent visible and which the task is about
reading. The parse takes the low flags bit, selects a four byte or two byte stride
for its value column, and stores through a truncating 16 bit write on the narrow
path. Signedness is the one thing that store does not reveal, and the samples settle
it, because all 24 carry negative values with the bit clear, which an unsigned
column cannot hold. I also checked whether the ambiguity ever decides an output, and
it does not: zero of the 18 held-out records change classification under the
unsigned reading. The trap is two sided as well, since setting the bit
unconditionally fails the samples and never setting it fails the held-out set.

binutils and file are baked into the image rather than left to the open internet,
because that fairness argument depends on the disassembly path being open and I did
not want it resting on a network fetch.

One open question I cannot settle locally. Both latent rules sit a few instructions
apart in the same parse function, so a solver who disassembles for one may well see
the other. My difficulty estimate assumes more independence between them than I have
evidence for. There is a decorrelating path, since the varint is also reachable by
trial and error against the validator's own errors and that route never touches the
flags branch, but the size of that effect is something to read off the trials rather
than guess at. I have not added a speculative third axis to compensate for it.
