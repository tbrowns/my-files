# Reviewer notes

Local working doc, gitignored. Paste into the platform's reviewer notes field at
submission.

---

Things worth knowing before you read this one, including the place I would push
hardest if I were reviewing it.

## Where the deciding evidence lives

Three rules decide whether an attempt lands, and they are not equally hard.

The prime modulus in the trailer is recoverable from the samples by gcd. Every
sample constrains it, so a wrong modulus reproduces none of the 24 and the solver
finds out at once. The difficulty here is recovery effort, not silence. I am not
counting on it to carry the task.

The multi byte varint rule is exercised by no sample. It lives in the validator's
parse loop. It is also enforced by framing, so a solver who assumes a one byte count
produces a blob the validator rejects outright. That makes it a diligence check
rather than a blind spot, and I have treated it as one.

The flags bit is the rule that is genuinely quiet. It is clear in all 24 samples, so
the samples cannot teach it, and the validator reads it without ever checking it
against the values, so round tripping never complains. Nine of the 18 held-out
records need it set.

## On the fairness of the flags bit

This is the item most likely to draw a hard look, so here is the argument rather
than leaving it to be reconstructed.

The rule is not undisclosed. It is in the shipped binary, which is agent visible and
which the whole task is about reading. The parse takes the low flags bit, selects a
four byte or two byte stride for its value column, and stores through a truncating
16 bit write on the narrow path. Reading that, you conclude the format promises
values fit in 16 bits when the bit is clear, which forces the writer to set the bit
when one does not.

Signedness is the one thing the store does not reveal, since truncation looks
identical either way. The samples settle it. All 24 carry negative values with the
bit clear, which is impossible for an unsigned column. I also checked whether the
ambiguity ever decides an output, and it does not: zero of the 18 held-out records
change classification under the unsigned reading, because every affected record also
carries a value outside the unsigned 16 bit range too.

The trap is two sided without my having to engineer a pair for it. Setting the bit
unconditionally fails the samples, since all 24 have it clear. Never setting it
fails the held-out records. Guessing in either direction loses.

binutils and file are baked into the image rather than left to the open internet,
because the fairness of all this rests on the disassembly path being open and I did
not want it depending on a network fetch.

## Failure modes I expect

A solver who never disassembles will still meet the varint rule, because the
validator errors on a one byte count, and will most likely fix it by trial and
error. That path never touches the flags branch. So I expect the flags bit to be
where most genuine failures land.

A solver who does disassemble is likely to see both rules, since they sit a few
instructions apart in the same function. That correlation is the main uncertainty in
my own difficulty estimate. I have not tried to engineer around it, because the
honest way to measure it is the trials rather than another bench run.

Wrong output is quiet everywhere it matters. A wrong flags bit, a wrong modulus and
a wrong varint all produce a well formed blob, and the vendor's validator accepts
the first two without comment.

## Construction notes

The data is synthetic, from a seeded generator, so the format and the checksum are
both novel and no part of the answer is searchable.

Sample blob sizes are load bearing. They run 761 to 2122 bytes so that the unreduced
weighted sum comfortably exceeds the modulus. Shrink them and no reduction ever
happens, the trailer degenerates into a plain weighted sum, and the modulus stops
being recoverable at all. That one is easy to get wrong and worth checking if you
rebuild the corpus.

The raw gcd across the samples lands on the modulus exactly. The gcd of the
quotients is 1, so no spurious factor survives and there is no stripping rule for a
solver to guess at.

The weighting and covered range hypothesis space is unique. I enumerated 45 cells,
nine start offsets by five weightings, and ran the recovery on every one. Exactly two
are consistent across all samples, and those two are the same function written two
ways, both recovering the same modulus. Every other cell gcds to 1.

No record in either set has duplicate canonical labels, so the sort is a total order
and there is no unstated tie break.

## Verifier notes

Ground truth lives only in tests/. The verifier rebuilds the canonical encoding from
the golden record definitions and never trusts a value read back from the agent's
output, including the trailer, which it recomputes over a byte range it constructs
itself.

The instruction states one criterion for the encoded files, byte equality with the
vendor's output. Six of the encoding tests are decompositions of that criterion
rather than extra requirements, kept separate so a failure names the rule that
broke. Nothing is graded beyond byte equality.

One thing to know when reading a trial log: a varint framing break shows up as
failures across several tests, including the flags test, because the parse gives up
before the flags can be read. The message still says the record is not well formed
and why, so it stays diagnostic, but the spread of failing test names is wider than
the actual defect.

Mutant matrix, run against the real verifier inside the real image. The flags mutant
reproduces all 24 samples and fails exactly 27 of 127 cases, which is the nine
affected records times three functions. The wrong modulus mutant fails exactly 36,
the 18 records times two. The reference passes 127. Mutants are built by patching
functions on the imported reference module rather than by splicing its source, so
nothing can be silently lost in the process.
