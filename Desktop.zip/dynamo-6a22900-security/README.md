# Provisioning record encoder

The agent gets an undocumented binary format, 24 worked examples and a stripped
validator, and has to rebuild the vendor's writer accurately enough to match it byte
for byte on 18 records it has never seen.

This is ordinary interoperability work. Somebody needs to emit blobs a locked down
device will accept, the vendor will not release a spec, and the format does not
yield to guessing.

## What is in the box

`/app/data/samples` holds 24 records twice over: `<id>.json` in plain form and
`<id>.bin` as the vendor's writer produced it. `/app/data/records.json` holds 18
more in plain form only. `/app/data/provverify` is the vendor's own validator,
shipped stripped, and it is an older release than the writer that made the samples.

Output goes to `/app/output/<id>.bin`, one file per record and nothing else.

## The format

Magic, a version byte, a flags byte, an entry count, then per entry a uint32 id, a
length prefixed label and an int32 value, then a four byte trailer. Entries are
emitted sorted by canonical label bytes, and labels are NFC normalized before they
are written. The count and the label lengths are unsigned LEB128.

Three parts of that cannot be read off the samples alone.

The trailer is a position weighted byte sum reduced by a prime modulus. It is not
CRC-32, Adler-32, Fletcher or FNV, so running a checksum catalogue returns nothing.
The modulus has to be recovered rather than recognised. For each sample the
unreduced weighted sum minus the stored value is a multiple of it, so a gcd across
the samples gives it up. It is prime by design, which rules out the 2-adic lifting
that cracks a mod-2^k hash.

Every count and label length in the samples happens to fit in a single byte, so the
samples argue for a fixed one byte field. Twelve of the 18 held-out records need the
continuation form. The only evidence for the real rule is the validator's parse
loop.

One flags bit is clear in all 24 samples. The validator picks a 16 bit or a 32 bit
value column from that bit and trusts it without checking, which is what tells you
the bit means the values fit in int16. Nine held-out records carry values that do
not. The samples cannot teach this one, and nothing in the environment complains
when it is wrong.

## Environment

One image, used for the agent and the verifier both, on the pinned
`python:3.13-slim-bookworm` digest. binutils, file and xxd are installed because the
slim base ships none of them and reading the binary is the intended path, so it
should not depend on the network being up. pytest and the ctrf plugin are pinned and
baked. Only `environment/data` is copied in, so neither the solution nor the tests
are reachable from the image.

## Verification

`tests/` is overlaid at verify time only. It holds the golden encodings, the golden
record definitions and a private copy of the codec. The verifier rebuilds the
canonical encoding from the record definitions and compares parsed fields against
it. It never trusts a value read back out of the agent's own output, and it
recomputes the trailer over the byte range it constructs itself rather than over
whatever bytes the agent wrote.

Eight test functions, parametrized per record, 127 cases. One checks that the output
directory holds exactly the expected files. One asserts byte equality with the
golden encoding, which is the criterion the instruction states. The other six break
that criterion into named pieces, covering magic and version, flags derivation,
varint values, varint minimality, entry content and ordering, and the trailer, so a
failure says which rule broke instead of reporting an opaque mismatch.

There are no tolerances. The encoding is a deterministic function of the record, so
exactly one output is correct and there is no legitimate variation to absorb.

## Calibration

Oracle 1.000 and nop 0.000, both repeated. The reference solution recovers the
modulus at run time by the search described above rather than carrying it as a
constant, and it self checks against all 24 samples before writing anything.

```bash
harbor run -p task --agent oracle
harbor run -p task --agent nop
```
