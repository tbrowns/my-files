`/app/data/samples` holds 24 provisioning records from a device vendor. Each record
appears twice: `<id>.json` is the record in plain form, and `<id>.bin` is that same
record as produced by the vendor's writer. The encoding is undocumented.

`/app/data/records.json` holds 18 more records in the same plain form, with no
encodings.

Encode each of those 18 records the way the vendor's writer would, and write each
one to `/app/output/<id>.bin`, taking `<id>` from the record's `id` field. Leave
nothing else in `/app/output`.

The encoding is a deterministic function of the record, so exactly one output is
correct for each one, and your files must match the vendor's byte for byte.

`/app/data/provverify` is the vendor's own record validation tool, shipped as a
stripped binary. It is an older release than the writer that produced the samples,
so it accepts more than the writer emits and does not know every field.
