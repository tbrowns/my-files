"""Reference encoder for the PRVS provisioning record format.

Nothing about the format is hardcoded that can be derived instead. The modulus
in particular is recovered at run time from the shipped sample pairs, by the same
route a solver takes: fix the weighting and the covered range by search, then
take the gcd of (unreduced weighted sum - stored trailer) across the samples.

Everything else here is the format itself, read off the samples and the reader:

    magic     4  'PRVS'
    version   1
    flags     1  bit0 any value outside int16, bit1 any non-ascii label
    count     unsigned LEB128, minimal length
    entry x count, ordered by canonical label bytes:
        id        4  uint32 little endian
        labellen  unsigned LEB128, byte length of the canonical label
        label     labellen bytes, UTF-8, NFC
        value     4  int32 little endian, two's complement
    trailer   4  uint32 little endian, weighted byte sum mod P
"""

import json
import os
import sys
import unicodedata
from functools import reduce
from math import gcd

DATA = "/app/data"
OUT = "/app/output"

MAGIC = b"PRVS"
VERSION = 3
INT16_MIN, INT16_MAX = -32768, 32767


# --------------------------------------------------------------------------
# format primitives

def uleb128(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def canon_label(s):
    return unicodedata.normalize("NFC", s).encode("utf-8")


def derive_flags(entries):
    f = 0
    if any(e["value"] > INT16_MAX or e["value"] < INT16_MIN for e in entries):
        f |= 0x01
    if any(not canon_label(e["label"]).isascii() for e in entries):
        f |= 0x02
    return f


def encode_body(record):
    entries = sorted(record["entries"], key=lambda e: canon_label(e["label"]))
    out = bytearray()
    out += MAGIC
    out.append(VERSION)
    out.append(derive_flags(entries))
    out += uleb128(len(entries))
    for e in entries:
        lb = canon_label(e["label"])
        out += int(e["id"]).to_bytes(4, "little")
        out += uleb128(len(lb))
        out += lb
        out += int(e["value"]).to_bytes(4, "little", signed=True)
    return bytes(out)


# --------------------------------------------------------------------------
# modulus recovery

def is_prime(n):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


WEIGHTINGS = {
    "const1":     lambda i, off: 1,
    "idx0_range": lambda i, off: i,
    "idx1_range": lambda i, off: i + 1,
    "idx0_file":  lambda i, off: i + off,
    "idx1_file":  lambda i, off: i + off + 1,
}


def weighted(blob, start, wfn):
    return sum(wfn(i, start) * b for i, b in enumerate(blob[start:-4]))


def stored_trailer(blob):
    return int.from_bytes(blob[-4:], "little")


def recover_modulus(blobs):
    """Search the weighting x covered-range grid; the true cell is the one whose
    gcd of differences is a large prime that reproduces every sample."""
    for start in range(0, 9):
        for name, wfn in WEIGHTINGS.items():
            diffs = [abs(weighted(b, start, wfn) - stored_trailer(b)) for b in blobs]
            g = reduce(gcd, diffs)
            if g <= 0xFFFF or not is_prime(g):
                continue
            if all(weighted(b, start, wfn) % g == stored_trailer(b) for b in blobs):
                return g, start, name
    raise SystemExit("modulus recovery failed")


# --------------------------------------------------------------------------

def main():
    sample_dir = os.path.join(DATA, "samples")
    sample_ids = sorted(f[:-5] for f in os.listdir(sample_dir) if f.endswith(".json"))

    samples = []
    blobs = []
    for sid in sample_ids:
        with open(os.path.join(sample_dir, sid + ".json"), encoding="utf-8") as f:
            samples.append(json.load(f))
        with open(os.path.join(sample_dir, sid + ".bin"), "rb") as f:
            blobs.append(f.read())

    modulus, start, wname = recover_modulus(blobs)
    print(f"recovered modulus {modulus} (start={start}, weighting={wname})")

    def checksum(body):
        return sum((i + 1) * b for i, b in enumerate(body)) % modulus

    def encode(record):
        body = encode_body(record)
        return body + checksum(body).to_bytes(4, "little")

    # Self-check against every sample before touching the held-out set. If the
    # recovered format cannot reproduce the samples it is wrong, and encoding
    # anything else is pointless.
    for rec, blob in zip(samples, blobs):
        got = encode(rec)
        if got != blob:
            sys.exit(f"sample {rec['id']} does not round-trip; format is wrong")
    print(f"reproduced all {len(samples)} samples exactly")

    with open(os.path.join(DATA, "records.json"), encoding="utf-8") as f:
        records = json.load(f)

    os.makedirs(OUT, exist_ok=True)
    for rec in records:
        with open(os.path.join(OUT, f"{rec['id']}.bin"), "wb") as f:
            f.write(encode(rec))
    print(f"wrote {len(records)} records to {OUT}")


if __name__ == "__main__":
    main()
