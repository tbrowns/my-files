"""Canonical PRVS codec, verify-time only.

This file is ground truth. It lives in tests/, which Harbor overlays at /tests
only when the verifier runs, so it is never present during the agent's run.

The verifier reconstructs the canonical encoding from the golden record and
compares parsed fields against it. It never trusts bytes read back out of the
agent's output for anything it grades, and in particular it recomputes the
trailer over the canonical byte range rather than over whatever the agent wrote.
"""

import unicodedata

MAGIC = b"PRVS"
VERSION = 3
MODULUS = 13744691
INT16_MIN, INT16_MAX = -32768, 32767


def uleb128(n):
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def read_uleb128(buf, pos):
    """Returns (value, new_pos, n_bytes). Raises on truncation or over-long."""
    result = 0
    shift = 0
    start = pos
    while True:
        if pos >= len(buf):
            raise ValueError(f"truncated varint at offset {start}")
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not b & 0x80:
            break
        shift += 7
        if shift > 63:
            raise ValueError(f"over-long varint at offset {start}")
    return result, pos, pos - start


def canon_label(s):
    return unicodedata.normalize("NFC", s).encode("utf-8")


def derive_flags(entries):
    f = 0
    if any(e["value"] > INT16_MAX or e["value"] < INT16_MIN for e in entries):
        f |= 0x01
    if any(not canon_label(e["label"]).isascii() for e in entries):
        f |= 0x02
    return f


def canonical_entries(record):
    return sorted(record["entries"], key=lambda e: canon_label(e["label"]))


def encode_body(record):
    entries = canonical_entries(record)
    out = bytearray()
    out += MAGIC
    out.append(VERSION)
    out.append(derive_flags(entries))
    out += uleb128(len(entries))
    for e in entries:
        lb = canon_label(e["label"])
        out += int(e["id"]).to_bytes(4, "little")
        out += uleb128(len(lb))
        out += lb
        out += int(e["value"]).to_bytes(4, "little", signed=True)
    return bytes(out)


def checksum(body):
    return sum((i + 1) * b for i, b in enumerate(body)) % MODULUS


def encode(record):
    body = encode_body(record)
    return body + checksum(body).to_bytes(4, "little")


def parse(blob):
    """Structural parse of an agent blob. Records the byte width of every varint
    so minimality can be graded separately from the value it encodes."""
    if len(blob) < 12:
        raise ValueError("blob too short to be a record")
    if blob[:4] != MAGIC:
        raise ValueError(f"bad magic {blob[:4]!r}")
    version = blob[4]
    flags = blob[5]
    count, pos, count_w = read_uleb128(blob, 6)

    entries = []
    for i in range(count):
        if pos + 4 > len(blob):
            raise ValueError(f"entry {i} id runs past end of blob")
        eid = int.from_bytes(blob[pos:pos + 4], "little")
        pos += 4
        llen, pos, llen_w = read_uleb128(blob, pos)
        if pos + llen > len(blob):
            raise ValueError(f"entry {i} label runs past end of blob")
        label = blob[pos:pos + llen]
        pos += llen
        if pos + 4 > len(blob):
            raise ValueError(f"entry {i} value runs past end of blob")
        value = int.from_bytes(blob[pos:pos + 4], "little", signed=True)
        pos += 4
        entries.append({"id": eid, "label": label, "value": value,
                        "labellen_width": llen_w})

    if pos + 4 != len(blob):
        raise ValueError(
            f"blob is {len(blob)} bytes but the record plus a 4 byte trailer "
            f"accounts for {pos + 4}")
    trailer = int.from_bytes(blob[pos:pos + 4], "little")
    return {"version": version, "flags": flags, "count": count,
            "count_width": count_w, "entries": entries, "trailer": trailer,
            "body_len": pos}
