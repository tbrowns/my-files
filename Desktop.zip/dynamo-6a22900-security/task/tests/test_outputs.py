"""Verifier for the PRVS provisioning record task.

One test function per success criterion from the instruction, parametrized over
the records so a failure names the record it happened on. Every expectation is
derived from the golden record definitions in tests/ by refcodec, never read back
out of the agent's own output, and never matched against source text.
"""

import json
import pathlib

import pytest

import refcodec

OUTPUT_DIR = pathlib.Path("/app/output")
HERE = pathlib.Path(__file__).parent

with open(HERE / "records_golden.json", encoding="utf-8") as _f:
    RECORDS = json.load(_f)

RECORDS_BY_ID = {r["id"]: r for r in RECORDS}
IDS = [r["id"] for r in RECORDS]


def read_blob(rid):
    path = OUTPUT_DIR / f"{rid}.bin"
    if not path.is_file():
        pytest.fail(f"missing output file {path}")
    return path.read_bytes()


def parsed(rid):
    try:
        return refcodec.parse(read_blob(rid))
    except ValueError as exc:
        pytest.fail(f"{rid}.bin is not a well-formed record: {exc}")


def test_output_directory_holds_exactly_the_expected_files():
    """One encoded file per record id in the input, named <id>.bin, and nothing extra."""
    assert OUTPUT_DIR.is_dir(), f"{OUTPUT_DIR} does not exist"
    # Every entry counts, directories included: the instruction says to leave
    # nothing else here, so a stray scratch directory is as much a violation as
    # a stray file.
    produced = {p.name for p in OUTPUT_DIR.iterdir()}
    expected = {f"{rid}.bin" for rid in IDS}
    assert produced >= expected, f"missing outputs: {sorted(expected - produced)}"
    assert produced <= expected, f"unexpected extra files: {sorted(produced - expected)}"


@pytest.mark.parametrize("rid", IDS)
def test_header_magic_and_version(rid):
    """Every blob opens with the format's magic and the version the samples carry."""
    blob = read_blob(rid)
    assert blob[:4] == refcodec.MAGIC, f"{rid}: wrong magic {blob[:4]!r}"
    assert blob[4] == refcodec.VERSION, f"{rid}: wrong version byte {blob[4]}"


@pytest.mark.parametrize("rid", IDS)
def test_flags_byte_is_derived_from_record_content(rid):
    """The flags byte is computed from the entries, not copied: bit0 marks a value
    outside the 16 bit range, bit1 marks a non-ascii canonical label."""
    want = refcodec.derive_flags(refcodec.canonical_entries(RECORDS_BY_ID[rid]))
    got = parsed(rid)["flags"]
    assert got == want, (
        f"{rid}: flags byte is 0x{got:02x}, expected 0x{want:02x} "
        f"(bit0 wide value, bit1 non-ascii label)")


@pytest.mark.parametrize("rid", IDS)
def test_varint_fields_hold_the_right_values(rid):
    """The entry count and every label length are correct as decoded values."""
    want_entries = refcodec.canonical_entries(RECORDS_BY_ID[rid])
    got = parsed(rid)
    assert got["count"] == len(want_entries), (
        f"{rid}: entry count is {got['count']}, expected {len(want_entries)}")
    for i, (g, w) in enumerate(zip(got["entries"], want_entries)):
        want_len = len(refcodec.canon_label(w["label"]))
        assert len(g["label"]) == want_len, (
            f"{rid} entry {i}: label length {len(g['label'])}, expected {want_len}")


@pytest.mark.parametrize("rid", IDS)
def test_varints_are_minimally_encoded(rid):
    """Multi-byte varints use the shortest form, so the canonical encoding is unique."""
    got = parsed(rid)
    want_w = len(refcodec.uleb128(got["count"]))
    assert got["count_width"] == want_w, (
        f"{rid}: entry count varint uses {got['count_width']} bytes, "
        f"minimal form for {got['count']} is {want_w}")
    for i, g in enumerate(got["entries"]):
        want_lw = len(refcodec.uleb128(len(g["label"])))
        assert g["labellen_width"] == want_lw, (
            f"{rid} entry {i}: label length varint uses {g['labellen_width']} "
            f"bytes, minimal form for {len(g['label'])} is {want_lw}")


@pytest.mark.parametrize("rid", IDS)
def test_entries_match_the_record_in_canonical_order(rid):
    """Entry ids, canonical label bytes and values all match, in the writer's order."""
    want_entries = refcodec.canonical_entries(RECORDS_BY_ID[rid])
    got = parsed(rid)
    assert len(got["entries"]) == len(want_entries), f"{rid}: wrong entry count"
    for i, (g, w) in enumerate(zip(got["entries"], want_entries)):
        assert g["id"] == w["id"], (
            f"{rid} entry {i}: id {g['id']}, expected {w['id']} "
            f"(entries may be out of canonical order)")
        assert g["label"] == refcodec.canon_label(w["label"]), (
            f"{rid} entry {i}: label bytes {g['label']!r}, "
            f"expected {refcodec.canon_label(w['label'])!r}")
        assert g["value"] == w["value"], (
            f"{rid} entry {i}: value {g['value']}, expected {w['value']}")


@pytest.mark.parametrize("rid", IDS)
def test_checksum_trailer_matches_the_canonical_recomputation(rid):
    """The trailer is the format's integrity value, recomputed here over the
    canonical byte range built from the golden record rather than trusted from
    the agent's own bytes."""
    want = refcodec.checksum(refcodec.encode_body(RECORDS_BY_ID[rid]))
    got = parsed(rid)["trailer"]
    assert got == want, f"{rid}: trailer is {got}, expected {want}"


@pytest.mark.parametrize("rid", IDS)
def test_encoding_is_byte_exact(rid):
    """Taken together the rules above define one canonical encoding per record,
    so a correct solution reproduces the vendor's bytes exactly."""
    want = (HERE / "golden" / f"{rid}.bin").read_bytes()
    got = read_blob(rid)
    assert got == want, (
        f"{rid}: encoding differs from the vendor's writer "
        f"({len(got)} bytes produced, {len(want)} expected)")
