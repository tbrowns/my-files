# Build brief: dynamo-6a22900-security

Local working doc. Gitignored, never part of the submission.
Companion to PROPOSAL_APPROVED.md. That file is the locked concept. This one is
the design guidance for turning it into a task that actually bites.

Written against the cross-task lessons in TASK_RETROSPECTIVE.md. The prior cycle
burned roughly 18 runs across 4 tasks learning things that apply directly here,
and the expensive ones are the ones a fresh session forgets first.

---

## 1. Where we are

Proposal PASSED. Phase 2 (ideation) is behind us, the concept is locked, and
Phase 3 is closed. Next is Phase 4: build the environment, author the reference
codec, get the oracle to 1.0, then write the numbered success-criteria list.

Repo is still at scaffold. `instruction.md` is the placeholder, `task.toml` is
unfilled, `description` is empty (a blocking static-check failure until it is
filled). `.gitignore` now covers `jobs/` and the local working docs.

Pre-seeded and untouchable: category Security, subcategory Reverse Engineering,
`model_tested`, `agent_tested`.

---

## 2. The risk that decides this task

The retrospective's most expensive single lesson was that the stack disarms your
traps the same way it disarms its own bugs. A lone-surrogate-rejection crux died
on the bench because `sqlite3` refuses to bind unencodable text, so every design
auto-rejected and the no-guard mutant passed every case. The rule that came out
of it: mutant-verify a crux bites before counting it.

The reverse-engineering version of that lesson is sharper, because in RE we
*ship the tooling ourselves*. **Anything in the box that can validate the
agent's output disarms the crux it validates.** The stripped reader is the
evidence source and it is also, if we are careless, a free oracle.

Work this per field before writing a line of code. For every field in the
format, answer one question: if the agent encodes a held-out record, runs it
back through the shipped reader, and compares, does the reader reveal the error?

- Framing fields (magic, version, varint counts, label lengths) mostly say yes.
  A truncated count walks the parser off the end of the buffer and the reader
  errors. That is the reader catching your trap for the agent.
- Value-level conventions (ordering, normalization, derived flag bits, unit or
  epoch choices) mostly say no. The reader parses them and does not judge them.
- The checksum trailer says no by construction, because the reader ignores it.
  That is why axis 1 is the strong one.

This has a direct consequence for the varint axis in the approved proposal. As
written, a solver that assumes one-byte counts produces a blob whose framing
breaks, and the reader will tell them so. **The varint axis is currently a
partial oracle, not a blind spot.** Two ways to fix it, and the second is
better:

1. Narrow the reader's validation surface so it reports structural validity
   without echoing parsed values. Workable, slightly artificial.
2. **Ship the reader as a version-skewed tool.** It is the vendor's older
   release: it accepts a superset of what the current writer emits, and it
   predates the trailer entirely. Round-tripping then answers "this parses",
   never "this is what the vendor's writer would have produced". Detectable
   from agent-visible evidence, since the version byte in the samples is ahead
   of the reader, which keeps it on the right side of the misdirection fairness
   line. It is also just what RE work actually looks like. Version skew is the
   normal state of the world, not a contrivance.

Option 2 converts the oracle problem into a fair discovery problem and it buys
room for a third axis. Recommend it.

---

## 3. Assume the gcd axis gets solved by some trials

The reviewer found the approach, including the gcd step, without being told it.
Retrospective section 10a: disclosed mechanisms get transcribed, disclosed
properties get derived, and undisclosed consequences on the idiom path get
dodged by trained habit. Run 16 proved the third one hard: the SUM-overflow
warning was removed entirely and an agent flagged the risk in its own reasoning
anyway. The defenses live in the weights.

Modulus recovery by gcd of differences is a catalogued technique. It is the
standard move for recovering LCG parameters and it is well represented in
training data. The prime modulus still defeats the 2-adic shortcut, and that is
worth having, but plan for a meaningful fraction of trials to walk the gcd path
cleanly.

Do not build this task on one axis. That is not pessimism, it is the arithmetic
in section 4.

---

## 4. The arithmetic

Gate: at least 3 fails of 5, with at least 1 good valid fail as an anchor. Soft
timeouts can fill the count but cannot anchor. Infra timeouts count for nothing.

Measured on the prior task, a single well-built axis gives a per-trial
analytical fail rate around 0.2 to 0.4. Clearing 3 of 5 wants roughly 0.6. One
axis does not get there. The acceptance that finally landed came from two
independent axes stacking to about 0.57.

Rough targets:

| Independent axes | Per-axis p | P(at least one bites) |
|---|---|---|
| 2 | 0.30 | 0.51 |
| 3 | 0.25 | 0.58 |
| 4 | 0.25 | 0.68 |

Aim for three that survive the section 2 audit, and accept that the third may
die on the bench. Also budget for variance at the meta-gate: pass2 only runs
n=2, so a p≈0.5 trap clears it about 75% of the time. Losing one read to luck is
normal and is not a signal to change the task.

---

## 5. Candidate axes, filtered through section 2

Axis 1, the prime-modulus trailer, is locked and strong. It survives
round-tripping because the reader never looks at it.

For the others, the profile to hunt is the same one that won last time:
**a wrong answer that leaves every byte the agent can check looking correct.**
In RE that means value-level conventions, not framing.

Worth benching:

- **Canonical ordering of entries.** The writer sorts by a byte-wise comparison
  over the raw label bytes. Samples are homogeneous on the deciding axis, so
  case-insensitive or locale-ish ordering reproduces every sample and diverges
  on the held-out set. Fair only if the ordering rule is recoverable from the
  binary or from some sample that distinguishes it. Decide which, and write it
  down, before this counts as an axis.
- **A derived field the agent will copy instead of compute.** A flags bit or a
  count that the writer derives from the record content rather than from the
  input record. Copying reproduces every sample and breaks where the derivation
  and the input disagree. Invisible to the reader.
- **Text normalization or encoding convention on labels.** The reader accepts
  any bytes, so a wrong choice round-trips clean. Check first whether Python's
  own defaults pre-spring this, exactly as `sqlite3` pre-sprang the surrogate
  crux last cycle.
- **Varint minimality**, if the reader is version-skewed and lenient about it.
  Then a non-minimal encoding parses fine and is still not what the writer
  emits.

For each one, write the two-sided pair: a case that punishes the wrong rule and
a case that punishes the crude overcorrection. One-sided traps get patched by
accident.

---

## 6. The four review items as build decisions

**Varint canonicality.** Minimal-length LEB128 is normative for the canonical
encoder. Two separate verifier concerns, keep them separate: an explicit test
that every varint in the agent's blob is minimally encoded, and a trailer
comparison computed over the canonical byte range the verifier reconstructs from
the golden record. A non-minimal encoding then fails the minimality test by
name, rather than failing the checksum for a reason nobody can read off the
output. Note the tension: stating minimality in `instruction.md` discloses the
varint mechanism and kills that axis, so this belongs in the environment and the
verifier, with the instruction saying only that the output must match what the
vendor's writer produces.

**Hypothesis-space uniqueness.** This is a bench task, not a sentence. Enumerate
the weighting and covered-range grid the solver would search, run the gcd
recovery on every cell across all samples, and record which cells yield a prime
consistent with every sample. The answer must be exactly one. Keep the output of
that run in this file. If a spurious cell also produces a plausible prime, the
discriminator is not unique and the sample set needs adjusting.

**Spurious gcd factors.** Do not document a stripping rule the solver has to
guess at. Engineer the sample set so the raw gcd across the samples equals the
modulus exactly, then verify it at build time and record the result. That
removes the ambiguity instead of papering over it. With roughly two dozen
samples a surviving common factor is unlikely, but unlikely is not verified.

**Reader architecture.** State it: x86-64 ELF, stripped, and say whether it is
dynamically or statically linked. Confirm the base image actually carries usable
disassembly tooling, or that the agent can install it, before assuming the
disassembly path is open. That assumption is load-bearing for fairness, since
the varint rule lives in the parse loop.

---

## 6b. Bench results, 2026-07-21 (scratchpad, format not yet frozen)

Format v3 as benched: magic `PRVS`, version byte, derived flags byte, ULEB128
count, entries sorted by canonical label bytes, per entry a uint32 LE id, a
ULEB128 label length, NFC UTF-8 label bytes, and an int32 LE value, then a
4-byte trailer. Trailer is a 1-based position-weighted byte sum over everything
preceding it, reduced by P.

**P = 13744691.** Prime confirmed by Miller-Rabin. 24 samples, blobs 717 to 2291
bytes, which is sized so the unreduced weighted sum actually exceeds P and the
modulus is recoverable at all. That sizing is load-bearing: at a few hundred
bytes per blob the sum never wraps, the trailer degenerates to a plain weighted
sum, and the modulus becomes unrecoverable.

**[Criterion C] Spurious factors: clean.** k_i = floor(S_i/P) spans 1 to 13 with
11 distinct values, and gcd(k_i) = 1. The raw gcd across the samples lands on P
exactly, so no stripping rule has to be documented or guessed at.

**[Criterion 4] Uniqueness: holds.** Grid of 9 start offsets by 5 weightings, 45
cells. Exactly 2 cells are consistent across all 24 samples, and they are the
same function written two ways (1-based index counted from range start versus
from file start, identical when the range starts at offset 0). Both recover
13744691. Every other cell gives gcd 1. The discriminator is provably unique.

**Mutant matrix.** The first column is the one that decides whether an axis is
real, because a mutant that fails a sample is caught by the agent's own
validation:

| Mutant | Samples reproduced | Held-out wrong | Blind to samples? |
|---|---|---|---|
| M0 reference | 24/24 | 0/18 | n/a |
| M1 one-byte counts and lengths | 24/24 | 12/18 | yes |
| M2 flags bit0 never set | 24/24 | 9/18 | yes |
| M3 no NFC normalization | 18/24 | 18/18 | no, caught |
| M4 wrong modulus | 0/24 | 18/18 | no, caught |
| M5 no entry sort | 0/24 | 18/18 | no, caught |

M1 and M2 overlap on only 3 of 18 held-out records, so they are substantially
independent.

**What this measures, and what it does not.** Sample-blindness is necessary, not
sufficient. Cross it with the section 2 reader audit:

- M4, the modulus, is caught by the samples by construction. That is fine and it
  is the point, the samples are how the modulus gets recovered. Axis 1's
  difficulty is recovery effort, not latency, and criterion 4 uniqueness caps it
  there permanently.
- M1, the varint, is sample-blind but reader-loud. A one-byte count with the
  high bit set desynchronizes any correct LEB128 parser. It is a diligence test.
- **M2, flags bit0, is the only mutant blind to both the samples and the
  reader.** Fixed-width field, no framing effect, and a validator-style reader
  does not cross-check the bit against content. This is the real second axis.
- M3 and M5 are discoverable, honest RE work that adds labor and legitimacy but
  cannot produce a failure.

**Open fairness dependency.** M2 is only fair if bit0's meaning is recoverable.
Nothing in the samples reveals it, since bit0 is clear in all 24. The evidence
has to be the reader binary: the reader must load the flags byte and branch on
bit0 visibly, for a purpose that does not amount to validating it. Designing that
branch is the next build step and it gates the axis. Until it exists, M2 is an
uncorrectable trap and a reject trigger.

## 6c. Reader audit, 2026-07-21 (section 2, run against the real binary)

`provverify 2.4.1`, built from `reader.c` in the scratchpad. **x86-64 ELF,
dynamically linked, stripped, 14448 bytes**, which answers review item
[Criterion A]. The source never goes near `environment/`; only the binary ships.

It is a **validator, not a dumper**. It reports structure and errors and never
echoes a parsed value. That one choice is what keeps the convention-level axes
blind, per the section 2 finding that the reader is an oracle for framing and
blind to convention.

| Audit assertion | Result |
|---|---|
| 1. Reader accepts every genuine blob | **42/42 accepted**, so it is usable evidence |
| 2. M1 one-byte counts is LOUD where it is wrong | **12 errored, 6 silent**, and the 6 silent ones are exactly the records M1 encodes correctly. 100% revealed where wrong |
| 3. M2 wrong flags bit0 is SILENT | **0 errored, 18/18 accepted.** No leak |
| 4. M3 no-NFC is reader-silent | 18/18 accepted, so the samples are what catch it, as benched |

**Assertion 3 is the one that mattered and it holds.** bit0 is a genuine blind
spot: reader-silent and sample-silent, with a fair discovery path in the
disassembly. The axis is real.

**Evidence sites survive stripping.** The bit0 branch reads, in the stripped
binary, as `and $0x1,%eax` followed by two stores that differ in both operand
width and addressing scale:

    mov %eax,(%r8,%rdi,4)     wide path,   4-byte stride, 32-bit register
    mov %ax,(%r8,%rdi,2)      narrow path, 2-byte stride, 16-bit register

That is a clean, complete inference for a reverse engineer: bit0 selects a
32-bit versus 16-bit value column, so a clear bit0 is the format promising the
values fit in 16 bits. It pins the int16 threshold exactly, without a word of
prose. The varint loop survives as `and $0x7f` twice plus `cmp $0x80`.

The version-skew story is legible in the surviving strings: the tool announces
itself as v2 reading a v3 record, and reports the trailer as unconsumed trailing
bytes it does not recognize. That tells the agent the reader is not the spec and
points at the trailer as a v3 addition, without explaining it.

**One wrinkle worth knowing.** An M1 blob usually fails with `label is not
well-formed UTF-8` rather than a varint error, because the framing desync makes
the parser read label bytes from the wrong offset. It reveals the error, which
is all assertion 2 needs, but the message is not diagnostic. That is realistic RE
experience and not a planted lie, since the agent can see the count field and the
byte layout for itself.

**Finding that changes the Dockerfile.** `python:3.13-slim-bookworm` ships almost
no binary tooling. Checked: `objdump`, `readelf`, `nm`, `gdb`, `strings`, `xxd`
and `file` are all ABSENT; only `od` is present. The fairness of both axes rests
on the disassembly path being open, so **binutils and file must be baked into the
image** via apt, unpinned per the apt rule. Leaving it to `allow_internet` would
make the fairness argument depend on a network fetch, which is not acceptable for
a load-bearing path.

## 6d. Phase 4 gate, 2026-07-21: PASSED

**Oracle 1.000, twice. Nop 0.000.** Real `harbor run -p . --agent oracle`, not a
docker stand-in. Runtimes 2m31s and 57s against a 300s verifier cap.

Harness note: harbor could not see the Docker daemon because it resolves the
`default` context while Docker Desktop listens on `desktop-linux`. Fix is
`DOCKER_HOST='npipe:////./pipe/dockerDesktopLinuxEngine'` in front of the command.
Worth carrying, it reads as "Docker daemon is not running" when Docker is fine.

**Clean image confirmed.** `find` for solve.sh, solve.py, test.sh, test_outputs.py,
refcodec.py and records_golden.json returns nothing. `/app` holds only `data` and a
pre-created `output`. `objdump` resolves at `/usr/bin/objdump`, so the disassembly
path is open without the network as section 6c required.

**Anti-cheat spot check.** The modulus 13744691 appears nowhere in the image, not
as decimal text and not as 4-byte little or big endian in any file under `/app`.
The reader contains no multiply instructions at all, which is consistent with it
having no checksum logic to leak.

**Reference solution genuinely computes.** `solution/solve.py` recovers the modulus
at run time by searching the weighting x range grid and taking the gcd of
differences, exactly the intended solver path, rather than carrying P as a
constant. It then self-checks against all 24 samples before writing anything. The
constant only exists in `tests/refcodec.py`, which is verify-time only.

**Verifier shape.** Seven tests, one per criterion, each with a docstring: outputs
exist and no extras, magic and version, flags derived from content (the bit0
discriminator), varint values, varint minimality (separate so a non-minimal
encoding fails by name), entry content in canonical order, trailer recomputed over
the canonical range (the modulus discriminator), and byte equality with the golden.

**Also fixed this session.** No `.gitattributes` existed, which is the CRLF trap
from section 10d of the retrospective. Added with `* text=auto eol=lf` plus
explicit `binary` for `*.bin` and the reader, and set `core.autocrlf false`.
Confirmed `jobs/` is ignored and untracked after two harbor runs, and that none of
the local working docs would be committed.

## 6e. Mutant matrix against the real verifier, 2026-07-21: PASSED

Run inside the real environment image with `solution/` and `tests/` mounted, so
this is the shipped verifier grading real output, not a bench approximation.
Mutants are built by patching functions on the imported reference module, never by
splicing source, so no method can be silently lost (section 6d of the
retrospective). The sample self-check is bypassed so each mutant actually writes
output, since a wrong agent ships anyway.

Tests were parametrized per record first, 127 cases total. Without that every
mutant failed nearly every test function and the matrix said nothing.

| Mutant | Samples | Failing test functions | Cases |
|---|---|---|---|
| reference | 24/24 | none | 0 of 127 |
| onebyte_varint | 24/24 | varint values, minimality, flags, entries, checksum, byte-exact | 72 |
| **flags_bit0_never_set** | **24/24** | **flags, checksum, byte-exact** | **27** |
| no_nfc | 16/24 | varint values, entries, checksum, byte-exact | 68 |
| no_sort | 0/24 | varint values, entries, checksum, byte-exact | 72 |
| **wrong_modulus** (Adler prime) | 0/24 | **checksum, byte-exact** | 36 |
| nonminimal_varint | 0/24 | **minimality**, checksum, byte-exact | 54 |

**The two real axes are surgical.** `flags_bit0_never_set` fails 27 cases, which
is exactly 9 records times 3 functions, and those 9 are exactly the held-out
records carrying an out-of-int16 value. It reproduces all 24 samples, so nothing
the agent can check locally catches it. `wrong_modulus` fails 36, exactly 18
records times 2 functions, and nothing else.

**Every mutant also fails checksum and byte-exact.** That is structural, since any
change to the body moves the trailer. Byte equality is the criterion the
instruction actually states, so this is correct rather than redundant.

**The [Criterion 2/1] review item is satisfied twice over.** A non-minimal varint
fails `test_varints_are_minimally_encoded` by name rather than surfacing only as a
confusing checksum mismatch. It also fails 24/24 samples, so an agent would catch
it before shipping.

**Confirms the axis analysis from 6b and 6c.** `wrong_modulus` reproduces 0 of 24
samples, so a solver using the Adler prime knows immediately. Axis 1's difficulty
is recovery effort, never silent failure, exactly as reported. Only bit0 is silent
end to end: blind to the samples, blind to the reader, and surgical in the
verifier.

**One diagnostic wrinkle.** `onebyte_varint` fails the flags test too, because the
framing desync makes the parse fail before flags can be read. The failure message
still says `not a well-formed record: <reason>`, so it is diagnostic even though
the test name is about flags. Acceptable, worth knowing when reading a trial log.

**Oracle re-confirmed at 1.000** after the parametrization change, via real
`harbor run`.

## 6f. Red team pass, 2026-07-21: gate re-run green

Four flags applied, three carried. Full write-up was in session; the durable parts:

**Applied.** (1) `.gitattributes` had `data/provverify binary`, which is anchored
to the repo root by the slash and matched nothing, leaving the reader on
`text=auto`. Now `provverify binary`, confirmed `binary: set`. (2) The output
directory test only counted regular files, so a stray subdirectory passed while
the instruction says leave nothing else. Now counts every directory entry, and
verified to fail on both a stray file and a stray directory while the other 126
cases stay green. (3) `verification_explanation` now says plainly that six of the
seven encoding tests are diagnostic decompositions of the single stated
byte-equality criterion, not additional requirements, so a reviewer does not read
them as grading unstated behavior. (4) `task/jobs/` cleared; harbor writes golden
output there and it should not sit in the tree even ignored.

**Carried, not fixed.**

- **Axis correlation is the live risk.** The bench measured independence over
  records (overlap 3 of 18), not over solvers. Both the varint rule and the bit0
  rule live in the same disassembly, a few instructions apart in the same parse
  function, so an agent that disassembles for one likely sees the other. Partial
  decorrelation exists because the varint is also reachable by trial and error
  against the reader's errors, a path that never reads the flags branch. The
  p ≈ 0.5 estimate assumes more independence than there is evidence for. Only
  trials settle this. Do not add a speculative third axis first.
- **bit0 has one evidence source, the binary.** That is what an RE task is, and
  the binary is agent-visible, but if bit0 produces most pass@5 failures a
  reviewer will scrutinise it against the "undisclosed verifier-enforced
  requirement" reject trigger. State the fairness argument in the reviewer notes
  rather than leaving it to be reconstructed.
- README replacement, PR body and reviewer notes remain Phase 10.

**Cold re-derive found one ambiguity and closed it.** A solver reading the
reader's narrow column as unsigned would classify bit0 differently, and the
truncating store does not show signedness. It is forced anyway: all 24 samples
carry negative values with bit0 clear, impossible under an unsigned column. It
also never decides an output, 0 of 18 held-out records diverge under the wrong
reading. Separately confirmed zero duplicate canonical labels in either set, so
the sort is a total order with no unstated tie-break.

**Gate after fixes:** mutant matrix bit-identical to the pre-fix run, reference
127/127, oracle 1.000, nop 0.000, both via real `harbor run`.

---

## 7. Carried constraints that bite hardest here

- **Wrong output, never a clock-out.** A timeout counts for nothing and is
  strictly worse than a solve, because it blocks the read. Keep the encoding
  work small. The difficulty is the reversal, not the volume. If the held-out
  set is large enough that writing the encoder becomes the bottleneck, cut it.
- **Labor is a budget item.** Last cycle a 5-module rewrite stopped fitting the
  3600s cap and produced two uncounted in-progress timeouts. Pre-pay the
  boilerplate the agent should not be spending its hour on: file I/O, output
  paths, a records loader. Difficulty lives in the traps, not in typing.
- **3600s is the hard ceiling** for both pass2 and pass@5. Older 900s text is
  stale.
- **Mutant or it did not happen.** For every intended crux, build the
  one-decision-different encoder and confirm it fails exactly the intended tests
  and nothing else. This killed one dud crux and certified four real ones in a
  single session last cycle.
- **Ground truth lives in `tests/`,** overlaid only at verify time. The golden
  blobs and the record definitions must never sit in `environment/`.
- **No answer reachable from the image.** Verify with the find command, and be
  careful that the reference codec is not shipped in any form. A stripped
  reader is fine. An encoder is not.
- **No "You have N seconds" closing line.** The live deep review fails it.
- **Humanize everything a reviewer reads,** no em dashes: the instruction, the
  three essays, the README, the PR body, the reviewer notes.

---

## 8. Phase plan

**Phase 4.** Design `environment/data/`: the sample pairs, the held-out records,
the stripped reader. Author the reference codec and `solution/solve.sh`. Run the
hypothesis-uniqueness bench from section 6 and record the numbers here. Get the
oracle to 1.0, twice, from a clean checkout. Then write the numbered
success-criteria list, which drives everything downstream.

**Phase 5.** One pytest function per criterion, each with a docstring, asserting
on observable `/app` artifacts. Then the mutant matrix: one variant per axis,
each failing exactly its own cases.

**Phase 6.** Single Dockerfile, digest-pinned allowlisted base, pip pinned, apt
not pinned, `.dockerignore` present, `mkdir -p` for every output parent.

**Phase 7.** `instruction.md` under 1500 tokens, absolute paths, WHAT not HOW,
no format disclosure that would kill an axis. Fill `task.toml`, including a
non-empty `description` and the three essays carried from the approved proposal.

**Phase 8.** Full local validation from a clean checkout, twice.

**Phase 9.** In-chat red team before the PR goes up.

The gate to move off Phase 4 is a pasted oracle reward of 1.0, not a belief that
it would probably work.
