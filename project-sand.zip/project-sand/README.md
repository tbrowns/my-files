# Project Sand — working folder

Authoring eval tasks for Project Sand: a small web app with planted defects, a
reference patch, a Playwright verifier, and a user-voiced instruction with
before/after screenshots.

## Where things are

| Path | What |
|---|---|
| `project-instruction.txt` | the platform's own rules, verbatim. The source of truth |
| `docs/LIFECYCLE.md` | folder stages, when a task moves, what to do when review returns |
| `docs/DIFFICULTY.md` | how to build a task that survives difficulty calibration |
| `docs/REJECTIONS.md` | every rejection, why, and the standing checks C1–C13 |
| `docs/PLATFORM-MECHANICS.md` | hard-won platform facts that are not in the rules |
| `docs/QUEUE-TASKS.md` | claiming, reworking, and **submitting** a queue task (the two-rule submission: images via tool, human-written instruction) |
| `imports/` | tasks whose app we wrote. **Preferred route** |
| `queue/` | tasks claimed from the platform queue |
| `template/` | the pristine import template, unpacked |
| `tooling/` | verifiers, screenshot harnesses, defect planters, packagers |

Both `imports/` and `queue/` carry the same three stages:

```
1-drafting/          building, returned for edits, or failed calibration
2-awaiting-review/   calibration passed, human review pending
3-approved/          approved
```

A task moves out of `1-drafting/` only when **difficulty calibration has
actually passed** — not merely when it was submitted.

## Current status

| Task | Route | Stage | Note |
|---|---|---|---|
| `tidewater` | import | dead | too-easy at calibration; canonical substrate (seat geometry). Packaging fix (R4) done but not worth resubmitting |
| `meadowlark` | import | **released** | too easy at calibration (R5) — canonical substrate (calendar/DST). Unsalvageable; triggered the difficulty-method rewrite |
| `greenroom` | import | uploaded | studio booking + turnaround buffers. Bespoke interval twist — the live test of whether it clears the bar. `greenroom.zip` |

The `meadowlark` failure (R5) is the first **measured** Sand calibration verdict.
It proved the old difficulty approach wrong and drove a full rewrite:
`docs/DIFFICULTY.md` is now the seven-gate screen (G1–G7), the conjunction
mechanism, the canonical-substrate ban, and a **calibration-faithful probe**
(full running app, iterate, grade blind). Evidence: `docs/forensics/`. The old
playbook is preserved at `docs/archive-DIFFICULTY-v1.md`.

## The one-paragraph history

Two attempts on a claimed queue template were rejected as *too similar* despite
using entirely different bug families — the corpus dedup keys on the **app
shell**, not the bug. Switching to Task Import, where we supply the app, cleared
Originality first time and passed every mechanical gate including the Docker
build. It then failed **difficulty calibration**: frontier models solved it too
consistently. That is the current problem, and `docs/DIFFICULTY.md` is the
answer being built for it. Full detail in `docs/REJECTIONS.md`.

## Before submitting anything

Work the checklist at the end of `docs/LIFECYCLE.md`, and confirm standing checks
C1–C13 in `docs/REJECTIONS.md`. When a verdict comes back negative, the rule is:
record it, turn it into a standing check, then **re-audit every task still in
`1-drafting/`** before submitting any of them.
