#!/usr/bin/env python3
"""Toggle the reefdesk backend between the broken base and the fix.

The whole task is one domain-logic module. Planting writes the broken desk.js
(the base the solver receives); --fix writes the correct desk.js. The packager
diffs the two into solution/patches/source_patch.diff.

    python tooling/plant-reefdesk.py          # plant broken (base)
    python tooling/plant-reefdesk.py --fix    # apply the fix
"""
import io
import os
import sys

FIX = '--fix' in sys.argv

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)  # tooling/ sits directly under the repo root
PKG = os.path.join(REPO, 'imports', '1-drafting', 'reefdesk', 'pkg')

REFS = os.path.join(REPO, 'imports', '1-drafting', 'reefdesk', 'refs')
DESK = os.path.join(PKG, 'environment', 'app', 'backend', 'desk.js')
BROKEN = os.path.join(REFS, 'desk-broken.js')
FIXED = os.path.join(REFS, 'desk-fixed.js')

src = FIXED if FIX else BROKEN
if not os.path.exists(src):
    sys.exit('planter: missing source %s' % src)

content = io.open(src, encoding='utf-8').read()
io.open(DESK, 'w', encoding='utf-8', newline='').write(content)
print(('applied fix' if FIX else 'planted broken') + ' -> environment/app/backend/desk.js')
