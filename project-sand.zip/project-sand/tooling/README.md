# Tooling

Reusable across tasks. Paths inside most scripts are relative to the project
root, so run them from there: `node tooling/<script>.js`.

## Verifiers — the local `nop=0` / `oracle=1` gate

| Script | For |
|---|---|
| `verify-import.js` | full-stack import tasks. Boots the real Express backend and the real react-scripts dev server — the same two processes `launch.sh` starts — then runs the real spec against broken and fixed |
| `verify.js` | static single-page queue tasks. Serves `base-repo/` and `fixed-repo/` and runs the spec against each |

Both print a per-test table with a `<-- WRONG` marker on any row that is not
`F2P: fail→pass` or `P2P: pass→pass`.

**Two traps, both learned the hard way:**

- Never launch the app with a **synchronous** child process. `execFileSync`
  blocks Node's event loop, so a static server in the same process never answers
  and *every* test fails on `goto`. Use `spawn` and await it.
- `npm start` under a shell spawns a grandchild that `child.kill()` misses. Free
  the ports by listener before and after every boot, or the next run dies on
  `EADDRINUSE`.

## Screenshot harnesses

`capture-import.js`, `capture.js`, `cap225.js` — drive both builds through an
**identical scripted scenario** and capture one shot each, so the pair differs
only where the defects are. Seed `Math.random` and zero out animation and
transition durations first.

Clip in **document coordinates** with `fullPage: true`. A viewport clip silently
truncates when the page ends below the region you asked for.

## Probes

`probe-water.js`, `probe-title.js`, `probe225.js`, `ov.js`, `dbg225.js` —
measure real geometry and real behaviour before designing a defect around them.

Written after two wrong assumptions that a probe caught: buttons that "obviously
overlapped" were held 10px apart by flex (only the text overflowed), and a
`grep -P` that reported no em-dash was actually erroring on the locale. **Measure
before you assert.**

## Defect planters

`plant-import.py`, `plant.py`, `plant225.py` — idempotent, exact-anchor
scripts that toggle a task between broken and fixed (`--fix` reverses).

The pattern is worth keeping: exact-string anchors that **assert** on a miss, so
a drifted file fails loudly instead of silently half-patching. Re-running reports
`= already planted` rather than double-applying. The verifiers call these to flip
between builds.

`plant225.py` also holds the full defect definitions for the abandoned botanical
task — see `docs/REJECTIONS.md` R2.

## Package re-application

`reapply.py` — re-applies authored changes onto a freshly downloaded queue
workspace. Needed because a lapsed claim hands back the *accepted base*, not your
edits. Derives both repos from whatever base the fresh workspace ships, so it
survives any number of re-claims.

## Packaging an import

Inline in the session rather than a script; the essentials:

```python
zi = zipfile.ZipInfo(rel)
zi.date_time = (2024, 1, 1, 0, 0, 0)
zi.create_system = 3                      # Unix — without this the mode bits are ignored
zi.external_attr = (stat.S_IFREG | (0o755 if is_script else 0o644)) << 16
```

Skip `node_modules`, `build`, `__pycache__`, `test-results`. Ship `.git` —
`HEAD` must equal `base_commit`.
