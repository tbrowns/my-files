#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Package an import task for upload, doing every fiddly step in the right order.

    python tooling/package-import.py imports/1-drafting/tidewater-seats/pkg \
        --planter tooling/plant-import.py

What it does, and why each step exists:

  1. Plant the defects, so the committed base is the BROKEN app the solver gets.
  2. Recreate environment/app/.git from scratch, with LF enforced. A CRLF blob
     makes `git apply` fail inside the Linux container.
  3. Commit -> base_commit.
  4. Apply the fix, diff it into solution/patches/source_patch.diff, restore.
     The tree must end clean, with HEAD == base_commit.
  5. Rewrite task.toml's base_commit and the F2P/P2P counts, read from the spec
     rather than trusted from whatever was there before.
  6. Zip with Unix file modes, INCLUDING environment/app/.git so the importer can
     resolve base_commit. Python's zipfile silently drops mode bits unless
     ZipInfo.create_system = 3, which is how a package ends up with -rw---- on
     launch.sh.

Everything is checked and reported; nothing is assumed.
"""
import argparse
import io
import os
import re
import stat
import subprocess
import sys
import zipfile

EXEC_NAMES = {'launch.sh', 'solve.sh', 'test.sh', 'run_script.sh', 'seed_fixtures.js'}
# environment/app/.git MUST travel in the upload: the importer resolves
# base_commit and `git apply`s the reference patch against it. It strips the
# repo only AFTER intake (the returned package carries no .git). Ship it; the
# first upload that omitted it was rejected "not imported" (docs/PLATFORM-MECHANICS.md).
SKIP_DIRS = {'node_modules', 'build', 'dist', '__pycache__', 'test-results', 'playwright-report'}
EPOCH = 1577836800  # 2020-01-01T00:00:00Z


def run(cmd, cwd=None, check=True):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, shell=False)
    if check and r.returncode != 0:
        sys.exit('FAILED: %s\n%s%s' % (' '.join(cmd), r.stdout, r.stderr))
    return r.stdout.strip()


def planter(script, task_root, fix):
    cmd = [sys.executable, os.path.abspath(script)] + (['--fix'] if fix else [])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit('planter failed:\n%s%s' % (r.stdout, r.stderr))
    return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ''


def count_tests(tests_dir):
    """F2P/P2P counts read from the spec, not trusted from task.toml."""
    f2p = p2p = 0
    titles = []
    for fn in os.listdir(tests_dir):
        if not fn.endswith('.spec.js'):
            continue
        src = io.open(os.path.join(tests_dir, fn), encoding='utf-8').read()
        for m in re.finditer(r"^test\(\s*(['\"])(.+?)\1", src, re.M):
            title = m.group(2)
            titles.append(title)
            if '[F2P]' in title:
                f2p += 1
            elif '[P2P]' in title:
                p2p += 1
    dupes = {t for t in titles if titles.count(t) > 1}
    return f2p, p2p, dupes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('task_root')
    ap.add_argument('--planter', required=True)
    ap.add_argument('--out', default=None)
    ap.add_argument('--skip-package', action='store_true')
    ap.add_argument('--keep-git', action='store_true',
                    help='leave environment/app/.git in place (default: remove after zipping)')
    a = ap.parse_args()

    root = os.path.abspath(a.task_root)
    app = os.path.join(root, 'environment', 'app')
    tests = os.path.join(root, 'tests')
    patch = os.path.join(root, 'solution', 'patches', 'source_patch.diff')
    toml_path = os.path.join(root, 'task.toml')
    for p in (app, tests, toml_path):
        if not os.path.exists(p):
            sys.exit('missing: ' + p)

    print('1. planting defects (the base must be the broken app)')
    print('   ', planter(a.planter, root, fix=False))

    print('2. recreating the app git repo with LF enforced')
    run(['git', 'init', '-q'], cwd=app) if not os.path.isdir(os.path.join(app, '.git')) else None
    if os.path.isdir(os.path.join(app, '.git')):
        import shutil
        shutil.rmtree(os.path.join(app, '.git'), ignore_errors=True)
    io.open(os.path.join(app, '.gitattributes'), 'w', encoding='utf-8', newline='').write('* -text\n')
    if not os.path.exists(os.path.join(app, '.gitignore')):
        io.open(os.path.join(app, '.gitignore'), 'w', encoding='utf-8', newline='').write('node_modules/\nbuild/\n')
    run(['git', 'init', '-q'], cwd=app)
    run(['git', 'config', 'core.autocrlf', 'false'], cwd=app)
    run(['git', 'config', 'user.email', 'tb.obande@gmail.com'], cwd=app)
    run(['git', 'config', 'user.name', 'tbrowns'], cwd=app)

    print('3. committing the broken state as base_commit')
    run(['git', 'add', '-A'], cwd=app)
    run(['git', 'commit', '-q', '-m', 'base'], cwd=app)
    base = run(['git', 'rev-parse', 'HEAD'], cwd=app)
    print('    base_commit =', base)

    print('4. generating the reference patch')
    print('   ', planter(a.planter, root, fix=True))
    # Capture the diff RAW -- do NOT strip. A hunk whose trailing context is a
    # blank line ends the diff with a " " line; stripping it drops that context
    # and the final hunk's line count no longer matches its header ("corrupt
    # patch"). git's own trailing newline is all we need.
    dr = subprocess.run(['git', 'diff'], cwd=app, capture_output=True, text=True)
    if dr.returncode != 0:
        sys.exit('    git diff failed:\n' + dr.stderr)
    diff = dr.stdout
    if not diff.strip():
        sys.exit('    the fix produced an EMPTY diff - the planter did nothing')
    if not diff.endswith('\n'):
        diff += '\n'
    io.open(patch, 'w', encoding='utf-8', newline='').write(diff)
    run(['git', 'checkout', '--', '.'], cwd=app)
    dirty = run(['git', 'status', '--porcelain'], cwd=app)
    if dirty:
        sys.exit('    tree is not clean after restore:\n' + dirty)
    check = subprocess.run(['git', 'apply', '--check', '--ignore-whitespace', patch],
                           cwd=app, capture_output=True, text=True)
    if check.returncode != 0:
        sys.exit('    patch does NOT apply at base_commit:\n' + check.stderr)
    print('    patch applies at base, %d files, %d hunks'
          % (diff.count('diff --git '), diff.count('\n@@ ')))

    print('5. rewriting task.toml')
    f2p, p2p, dupes = count_tests(tests)
    if dupes:
        sys.exit('    duplicate test titles: %s' % ', '.join(sorted(dupes)))
    if f2p < 6 or p2p < 2:
        print('    WARNING: below the floor (need >=6 F2P, >=2 P2P)')
    t = io.open(toml_path, encoding='utf-8').read()
    t = re.sub(r'base_commit\s*=\s*"[^"]*"', 'base_commit = "%s"' % base, t)
    t = re.sub(r'fail_to_pass_count\s*=\s*\d+', 'fail_to_pass_count = %d' % f2p, t)
    t = re.sub(r'pass_to_pass_count\s*=\s*\d+', 'pass_to_pass_count = %d' % p2p, t)
    io.open(toml_path, 'w', encoding='utf-8', newline='').write(t)
    print('    F2P = %d, P2P = %d' % (f2p, p2p))

    if a.skip_package:
        print('\ndone (packaging skipped)')
        return

    out = a.out or os.path.join(os.path.dirname(root), os.path.basename(root) + '.zip')
    print('6. zipping with Unix modes ->', out)
    n = 0
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
            for fn in sorted(filenames):
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, root).replace(os.sep, '/')
                zi = zipfile.ZipInfo(rel)
                zi.date_time = (2024, 1, 1, 0, 0, 0)
                zi.compress_type = zipfile.ZIP_DEFLATED
                zi.create_system = 3  # Unix, else the mode bits below are ignored
                mode = 0o755 if fn in EXEC_NAMES else 0o644
                zi.external_attr = (stat.S_IFREG | mode) << 16
                with open(full, 'rb') as fh:
                    z.writestr(zi, fh.read())
                n += 1
    print('    %d files, %.0f KB' % (n, os.path.getsize(out) / 1024))

    # The zip carries the .git it needs; leaving it on disk makes the OUTER repo
    # add environment/app as a gitlink (source untracked). Remove it -- a repackage
    # recreates it. (Keep it only with --keep-git if you want to re-inspect base.)
    if not a.keep_git:
        import shutil as _sh
        _sh.rmtree(os.path.join(app, '.git'), ignore_errors=True)
        print('    removed environment/app/.git (repackage recreates it)')
    print('\ndone. HEAD == base_commit, tree clean, patch verified.')


if __name__ == '__main__':
    main()
