// Captures the matched broken/target pair: same party size, same viewport, same
// scripted interaction, one shot per build.
const { chromium } = require('playwright');
const { spawn, spawnSync } = require('child_process');
const http = require('http');
const path = require('path');

const APP = path.resolve('import-task/environment/app');
const BE = 5000, FE = 3000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function freePorts() {
  spawnSync('powershell', ['-NoProfile', '-Command',
    `Get-NetTCPConnection -LocalPort ${FE},${BE} -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }`],
    { stdio: 'ignore' });
}

function get(url) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => { res.resume(); resolve(res.statusCode); });
    req.on('error', () => resolve(0));
    req.setTimeout(2000, () => { req.destroy(); resolve(0); });
  });
}
async function waitUp(url, secs, label) {
  for (let i = 0; i < secs; i++) {
    const c = await get(url);
    if (c && c < 500) return;
    await sleep(1000);
  }
  throw new Error(label + ' never came up');
}

function plant(fix) {
  const r = spawnSync('python', ['plant-import.py', ...(fix ? ['--fix'] : [])], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error(r.stderr || r.stdout);
}

async function shoot(label, fix, out) {
  freePorts(); await sleep(1500);
  plant(fix);
  const be = spawn(process.execPath, ['server.js'],
    { cwd: path.join(APP, 'backend'), env: { ...process.env, PORT: String(BE) }, stdio: 'ignore' });
  const fe = spawn('npm.cmd', ['start'],
    { cwd: path.join(APP, 'frontend'), env: { ...process.env, BROWSER: 'none', CI: 'false', PORT: String(FE), DANGEROUSLY_DISABLE_HOST_CHECK: 'true' }, stdio: 'ignore', shell: true });
  try {
    await waitUp(`http://127.0.0.1:${BE}/api/health`, 40, 'backend');
    await waitUp(`http://127.0.0.1:${FE}`, 180, 'frontend');
    const browser = await chromium.launch();
    const ctx = await browser.newContext({ viewport: { width: 1180, height: 1000 }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    await page.goto(`http://127.0.0.1:${FE}`, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-seat="C1"]', { timeout: 30000 });
    await page.selectOption('#partySize', '4');
    await page.click('#findBtn');
    await page.waitForSelector('#pickRow, #pickError', { timeout: 20000 });
    await sleep(400);
    const state = await page.evaluate(() => ({
      row: document.getElementById('pickRow') ? document.getElementById('pickRow').textContent : null,
      seats: document.getElementById('pickSeats') ? document.getElementById('pickSeats').textContent : null,
      total: document.getElementById('pickTotal') ? document.getElementById('pickTotal').textContent : null,
      gangway: (() => {
        const a = document.querySelector('[data-seat="C7"]').getBoundingClientRect();
        const b = document.querySelector('[data-seat="C8"]').getBoundingClientRect();
        return Math.round(b.left - a.right);
      })(),
    }));
    await page.screenshot({ path: out, fullPage: true });
    console.log(label.padEnd(7), JSON.stringify(state));
    await ctx.close(); await browser.close();
  } finally {
    try { fe.kill(); } catch (e) { void e; }
    try { be.kill(); } catch (e) { void e; }
    freePorts(); await sleep(2500);
  }
}

(async () => {
  await shoot('BROKEN', false, 'import-task/environment/problem_assets/broken.png');
  await shoot('TARGET', true, 'import-task/environment/problem_assets/target.png');
})();
