// Local nop/oracle for the Tidewater import task.
//   broken app -> every [F2P] must FAIL, every [P2P] must PASS   (nop,    reward 0)
//   fixed app  -> everything must PASS                            (oracle, reward 1)
//
// Boots the real backend and the real react-scripts dev server, the same two
// processes launch.sh starts in the container, then runs the real spec.
const { spawn, spawnSync } = require('child_process');
const http = require('http');
const path = require('path');

const APP = path.resolve('imports/1-drafting/tidewater/pkg/environment/app');
const TESTS = path.resolve('imports/1-drafting/tidewater/pkg/tests');
const BACKEND_PORT = 5000;
const FRONTEND_PORT = 3000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function get(url) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => { res.resume(); resolve(res.statusCode); });
    req.on('error', () => resolve(0));
    req.setTimeout(2000, () => { req.destroy(); resolve(0); });
  });
}

async function waitUp(url, seconds, label) {
  for (let i = 0; i < seconds; i++) {
    const code = await get(url);
    if (code && code < 500) return true;
    await sleep(1000);
  }
  throw new Error(`${label} never came up at ${url}`);
}

function plant(fix) {
  const r = spawnSync('python', ['tooling/plant-tidewater.py', ...(fix ? ['--fix'] : [])], { encoding: 'utf8' });
  if (r.status !== 0) throw new Error('plant-tidewater.py failed: ' + (r.stderr || r.stdout));
  return r.stdout.trim().split('\n').filter((l) => l.trim()).pop();
}

async function runVariant(label, fix) {
  console.log(`\n--- ${label} ---`);
  console.log('   ', plant(fix));

  const be = spawn(process.execPath, ['server.js'], {
    cwd: path.join(APP, 'backend'),
    env: { ...process.env, PORT: String(BACKEND_PORT) },
    stdio: 'ignore',
  });
  const fe = spawn(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['start'], {
    cwd: path.join(APP, 'frontend'),
    env: { ...process.env, BROWSER: 'none', CI: 'false', PORT: String(FRONTEND_PORT), DANGEROUSLY_DISABLE_HOST_CHECK: 'true' },
    stdio: 'ignore',
    shell: process.platform === 'win32',
  });

  let results = {};
  try {
    await waitUp(`http://127.0.0.1:${BACKEND_PORT}/api/health`, 40, 'backend');
    console.log('    backend up');
    await waitUp(`http://127.0.0.1:${FRONTEND_PORT}`, 420, 'frontend');
    console.log('    frontend up, running spec...');

    const json = await new Promise((resolve) => {
      const cp = spawn(process.execPath,
        [path.resolve('node_modules/@playwright/test/cli.js'), 'test', '--reporter=json', '--workers=1'],
        {
          cwd: TESTS,
          env: {
            ...process.env,
            FRONTEND_URL: `http://127.0.0.1:${FRONTEND_PORT}`,
            BACKEND_URL: `http://127.0.0.1:${BACKEND_PORT}`,
            ARTIFACTS_DIR: path.resolve('.import-artifacts', label),
          },
          stdio: ['ignore', 'pipe', 'pipe'],
        });
      let buf = '';
      cp.stdout.on('data', (d) => { buf += d; });
      cp.stderr.on('data', () => {});
      cp.on('close', () => resolve(buf));
    });

    const report = JSON.parse(json);
    const walk = (s) => {
      (s.specs || []).forEach((sp) => {
        results[sp.title] = sp.tests.every((t) => t.results.at(-1).status === 'passed');
      });
      (s.suites || []).forEach(walk);
    };
    (report.suites || []).forEach(walk);
  } finally {
    try { fe.kill(); } catch (e) { void e; }
    try { be.kill(); } catch (e) { void e; }
    if (process.platform === 'win32') {
      spawnSync('powershell', ['-NoProfile', '-Command',
        `Get-NetTCPConnection -LocalPort ${FRONTEND_PORT},${BACKEND_PORT} -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }`],
        { stdio: 'ignore' });
    }
    await sleep(2000);
  }
  return results;
}

(async () => {
  const broken = await runVariant('broken', false);
  const fixed = await runVariant('fixed', true);

  const titles = Object.keys(broken).length ? Object.keys(broken) : Object.keys(fixed);
  console.log('\n' + 'TEST'.padEnd(66) + 'broken  fixed');
  console.log('-'.repeat(82));
  let ok = true;
  let f2p = 0, p2p = 0;
  for (const t of titles) {
    const b = broken[t], f = fixed[t];
    const isF2P = t.includes('[F2P]');
    if (isF2P) f2p++; else p2p++;
    const want = isF2P ? (b === false && f === true) : (b === true && f === true);
    if (!want) ok = false;
    console.log(t.slice(0, 64).padEnd(66) + String(b ? 'PASS' : 'FAIL').padEnd(8) + (f ? 'PASS' : 'FAIL') + (want ? '' : '   <-- WRONG'));
  }
  console.log('-'.repeat(82));
  console.log(`F2P: ${f2p}   P2P: ${p2p}   nop(broken)=${ok ? 0 : '?'}   oracle(fixed)=${Object.values(fixed).every(Boolean) ? 1 : 0}`);
  console.log(ok ? '\nALL GOOD: every F2P red on broken + green on fixed, every P2P green on both.'
                 : '\nPROBLEM: see rows marked WRONG.');
})();
