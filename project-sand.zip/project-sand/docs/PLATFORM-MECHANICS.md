# Platform mechanics

Things about Project Sand that cost time to learn and are not in
`project-instruction.txt`. Every entry here was observed directly.

---

## The claim timer pauses during Verification Check

Observed 2026-09-06 on `task_0696`: 50:57 before a verification run, 63:50
after. The docs say only *"A new claim runs for 60 min"*, which reads as a hard
budget and conflicts with the same document's *"budget 1 hour or more per task"*.

**Apply:** do not rush authoring or skip hardening to beat the clock. Verification
time is free. Expiry is still real — it closes the working snapshot and discards
unfinished edits.

---

## Two upload lanes, and mixing them fails

For queue tasks the workspace can be edited in the browser **or** downloaded as
a `.tar`, edited locally, and uploaded back. These do not compose.

- **Instruction images never travel in the archive.** Uploading a `.tar` whose
  `instruction-images/*.png` differ from what the platform holds is rejected:
  *"instruction images change through the image and screenshot tools, not archive
  uploads."* Ship the images byte-identical to the download and upload new ones
  through the screenshot tool afterwards.
- **The browser editor rewrites your markup.** `<img src="..." width="900" />`
  became `![alt](...)`. Do not diff against your local copy and conclude the
  images were dropped.

---

## The archive must match the platform's own tar format

This is what produced *"Archive was downloaded from a previous claim — re-download
the workspace and re-apply your changes"*, and the `workingSnapshotId` was
**correct** the whole time. The real differences:

| | platform export | naive `tar -cf` |
|---|---|---|
| directory entries | none | one per directory |
| file mtimes | uniform `2020-01-01 00:00 UTC` | real times on edited files |

Passing directories to `tar` emits `drwxr-xr-x` members and stamps edited files
with the current time; the platform reads that as a stale archive.

**Recipe that works:**

```bash
tar -tf <downloaded>.tar | grep -v '/$' > filelist.txt
cd <workspace> && tar -cf ../out.tar \
  --owner=0 --group=0 --numeric-owner \
  --no-recursion --mtime='@1577836800' --format=gnu -T ../filelist.txt
```

---

## Zip file modes on Windows

Import packages need Unix modes (`755` on the five shell scripts). Python's
`zipfile` silently drops them unless you set `ZipInfo.create_system = 3` — the
default is MS-DOS and the mode bits are ignored. Symptom: `unzip -Z` shows
`-rw----`. Working packer is in `tooling/`.

---

## The import template is full-stack React + Express

Not a static page. `launch.sh` boots `app/backend/server.js` on **:5000** and
`npm start` (react-scripts) on **:3000**; the Dockerfile installs both
`package.json`s. `find_app` requires a `package.json` or a `backend/` directory.

Consequences:

- The reference solution is a **git patch**, applied with `git apply` inside the
  app dir. It does **not** need a repo — see *What the platform does to your
  package*: `.git/` is stripped on upload and `base_commit` is discarded. Ship
  the app as plain files.
- Add `.gitattributes` with `* -text` and `core.autocrlf=false`. Windows CRLF
  conversion otherwise corrupts the patch when applied in the container.
- F2P tests are tagged **by defect**: the parser matches `\[(D\d+)\]`, so titles
  read `[F2P][D1] …`. P2P stays `[P2P]`.
- `node_modules` must not ship; the Dockerfile installs it.

---

## The base image cannot be pulled

`app-base:latest` in the template is a placeholder; the platform substitutes a
digest-pinned image from a private registry that refuses anonymous pulls. So the
real container **cannot be built locally**.

Two ways to verify, and they cover different things:

1. **Native** — boot the backend and the dev server and run the spec against
   them. Proves the app and the spec. Skips `launch.sh`, `run_script.sh`,
   `parser.py` and the reward file entirely.
2. **Local harness** (`tooling/local-harness/`) — a stand-in base image so the
   real chain `test.sh -> run_script.sh -> lib/boot.sh -> launch.sh -> parser.py`
   runs end to end. Not identical to the platform image, but it catches a broken
   script, a bad parser, a `launch.sh` that never comes up, and a reward file
   that never gets written.

The Docker layer passed first time for `tidewater-seats`, so build risk is lower
than it looks — but the harness scripts had never been executed before.

---

## Import pipeline stages, in order

Observed on the import history page:

```
Intake → Originality → Structure → Build → Change → Writing →
Verification review → Package → Baseline test run → Solution test run →
Difficulty calibration → Human review → Final processing
```

**Difficulty calibration sits after every mechanical check.** A package can be
perfectly built, verified and original and still be returned. Budget for a
rework cycle rather than treating a green build as done.

---

## Local verification, and how it lies

`app-base` is unavailable, so local runs differ from the container in one way
that matters: **outbound network is unresolvable**, so `waitUntil: 'networkidle'`
stalls the full 30s on any page requesting a webfont or CDN asset.

Two failures traced to this and nothing else:

1. Parallel Playwright workers timing out on boot — the tests were fine; running
   serially passed.
2. Two tests exceeding the 60s limit because they each reloaded four times.

**Apply:** before believing a local failure, check whether it is a timeout rather
than an assertion. Prefer one page load per test and click through state.

---

## Queue templates ship broken

Two of two claimed templates described defects the app did not have, and both
shipped reference "fixes" that were dishonest (a hardcoded literal; a racing
inline script). See `REJECTIONS.md` R1 and R2.

**Apply:** drive the app and confirm the symptom before writing a single line.
Read the shipped patch early — if it is a hack, the whole task needs rebuilding,
not editing.

---

## What the platform does to your package (measured)

Compared byte-for-byte against a returned package (`sandwich-…-returned.tar.gz`)
on 2026-09-06. Of everything uploaded, **exactly two files come back changed**,
and one whole directory is dropped.

### `.git/` is stripped from the RETURN — but the UPLOAD must carry it

The returned package contains no `environment/app/.git/`. That was the whole
484KB → 267KB size difference. The earlier reading of this — *"stop shipping
`.git`"* — was **wrong, and it cost an upload cycle** (2026-09-06).

What actually happens: the importer **reads `environment/app/.git` during intake**
to resolve `base_commit` and `git apply` the reference patch, **then strips the
repo** before storing the task. So it is absent from what comes back but required
in what goes in.

Proof, both directions, same task:
- The **original** upload shipped a full `environment/app/.git/` (HEAD ==
  `base_commit`) and cleared every mechanical stage (structure, build, both test
  runs), failing only later at difficulty.
- The **repackaged** upload that omitted `.git` (following the bad note above) was
  rejected at the door: *"The package was not imported. Compare it with the task
  template and try again."* — before any pipeline stage ran.

**Ship `environment/app/.git`, with a clean tree at `base_commit` (the broken
state).** The size saving is not worth a rejection, and the "leak surface" is
moot — the platform discards the repo anyway.

### `problem_assets/` must be `broken.png` + `target.png`

The template ships exactly `environment/problem_assets/broken.png` and
`target.png`, and its `instruction.md` references both. The original used those
two names and passed structure; the repackage that renamed them
(`broken-plan.png` / `broken-bill.png`, no `target.png`) was part of the same
"not imported" rejection. **Use the two canonical names**; a task with a
before-only story still ships a `target.png` (the corrected view). Custom names
and a missing `target.png` do not import.

### `task.toml` — almost everything is discarded

```diff
-name = "tbrowns/tidewater-seats-across-the-gangway"
-description = "…"   -authors = […]   -keywords = […]
+name = "sand/sandwich-<uuid>"

-category / task_family / source_repo / base_commit / skipped_meta_files
+source_type = "sandwich"
+stack = "nextjs"
+docker_image = "sand-pending-build:import"

 fail_to_pass_count = 8      ← kept
 pass_to_pass_count = 3      ← kept
```

**Only the F2P/P2P counts survive.** Do not spend effort on the description,
keywords, authors or category — they are thrown away. Do get the counts right;
they are the only metadata the platform carries forward.

Note the platform labelled a create-react-app project `stack = "nextjs"`. It
built and ran correctly regardless, so the label looks coarse rather than
load-bearing — but it is a mismatch worth remembering if anything downstream
branches on it.

### `environment/Dockerfile` — rewritten, base image substituted

```diff
-FROM app-base:latest
+FROM us-docker.pkg.dev/afterquery-compute/compute-images/sand-app-base@sha256:dc40aeb1d0c0…
```

All comments stripped and whitespace collapsed. The placeholder base is replaced
with a digest-pinned image, so **Dockerfile comments and formatting are wasted
effort**, and the unpullable `app-base:latest` is not a problem — the platform
substitutes it.

That registry is private: an anonymous pull fails with *"Unauthenticated
requests do not have permission artifactregistry.repositories.downloadArtifacts"*.
The real base image cannot be obtained. `tooling/local-harness/` builds a
stand-in so the harness chain can still be exercised locally.

### Everything else is untouched

`instruction.md`, `launch.sh`, `solution/**`, `tests/**`, `problem_assets/**` and
every application file came back byte-identical. The platform does not edit your
content.

---

## Docker Desktop will not start

Symptom: the UI processes and the WSL `docker-desktop` distro are running, but
`docker info` fails.

Cause seen here: the privileged helper service **`com.docker.service` was
Stopped** (StartType Manual). Starting it needs elevation:

```powershell
Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-Command','Start-Service com.docker.service'
```

The engine came up ~10s later. Check the service before reinstalling anything.
