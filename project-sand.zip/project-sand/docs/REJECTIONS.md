# Rejection ledger

Every task that was rejected, abandoned or expired, what it was, and why it
failed. The working trees are deleted; this file is what survives them.

**Rule: when a rejection reason arrives, add it here, then check every
unsubmitted task against it before submitting anything else.** The standing
checks distilled from these entries live at the bottom.

---

## R1 — `task_0696-vibe-games-...-zig-zag` — REJECTED TWICE, "too similar"

**Source:** platform queue (claimed, not imported)
**Verdict:** *"Your task is too similar to a task already in our corpus. Change
it substantially, for example a different bug or a different scenario, then
submit again."* — returned twice, on two completely different bug families.
**Outcome:** released. Working tree deleted 2026-09-06.

### What the app was

`Emberdrift`, a 2D zig-zag canyon flyer. Vanilla JS on a canvas, one 1,312-line
`js/game.js`, one HTML file, one stylesheet. Player holds to climb at 45°,
releases to glide down, threads a spike-lined channel, collects stars and coins.

### What shipped in the template

A HUD task, and it was invalid as shipped:

- `instruction.md` claimed the star tally "advertises fewer stars than the canyon
  actually hands you". **False.** The canyon genuinely held only two stars and
  the tally honestly read `0/2`. HUD and world agreed. The screenshot proved it.
- The reference fix replaced a derived total (`L.stars.length`) with a literal
  `'/3'`, so an agent could satisfy two of the four F2P tests by typing three
  characters.
- 4 F2P + 3 P2P — below the 6 + 2 floor, so Submit was blocked anyway.

### Attempt 1 — HUD readouts

Root cause found: `runSpan = Math.max(segEnd, 1)` — a *span* computed as an
absolute coordinate rather than a difference. One line produced all three
advertised symptoms.

Reworked to three causes in two files:

| | site | defect |
|---|---|---|
| D1 | `genLevel` | run span as a coordinate, so the third star falls out of bounds |
| D2 | `startLevel` + update loop | progress measured from the wrong origin, clamped only above |
| D3 | `styles.css` | fill re-centred with `top:50%` and never given a height |

8 F2P + 4 P2P, `nop=0`/`oracle=1` verified locally. **Rejected: too similar.**

A measured property worth keeping: the star bug **self-healed by canyon 8** —
`leadIn` shrinks with difficulty until the third star lands back in bounds. Base
gave 2 stars on canyons 1–5 and 3 from canyon 8. Cross-canyon inconsistency made
a good test that a label hardcode could not satisfy.

### Attempt 2 — save/resume

Deliberately disjoint from attempt 1: different subsystem (`localStorage`
persistence), different screen (title, not HUD), different primitive (saved
progress), different test style (seed-and-read, no flying).

| | site | defect |
|---|---|---|
| D1 | `btnContinue` handler | resumes `best - 1`, a canyon behind its own label |
| D2 | `refreshBest` | enable threshold `best > 2`, so a player one canyon in gets a dead button |
| D3 | `.menu-btn` CSS | pinned `width: 96px`, so `CONTINUE · L12` bursts its pill into SETTINGS |

6 F2P + 4 P2P, `nop=0`/`oracle=1` on the first run. **Rejected: too similar.**

### Diagnosis

Two submissions sharing **nothing but the app**: different families, screens,
subsystems, and test styles. Both rejected identically.

> **The corpus dedup keys on the application shell, not on the bug.**

Sand's own wording reads differently in hindsight: *"Ship a new UI shell, not a
noun-swap of something already approved or in review."* The shell is the unit of
comparison. `task_0696` was already represented in the corpus and nothing built
on it could clear originality.

### What it cost, and what it bought

Two full authoring cycles and a claim expiry. It bought the decision to abandon
the queue for **Task Import**, where you supply the app and cannot collide with
the corpus — which then passed the Originality check first time.

---

## R2 — `task_0225-vibe-web-...-botanical-conservatory` — EXPIRED, unfinished

**Source:** platform queue
**Verdict:** none — the claim expired while work was paused to fix Tidewater,
and it cannot be reclaimed until Tidewater is resolved.
**Outcome:** working tree deleted 2026-09-06. Never submitted.

### What the app was

`Botanica`, a botanical conservatory browser. Modular ES modules —
`js/ui/{detail-panel,doctor,light,plant-grid,quiz,water}.js` — and split CSS.
~3,700 lines per repo. Considerably better engineered than R1's app.

### What shipped in the template — invalid in both directions

**The defect did not exist.** The instruction said the Light Simulator's dome
"never updates to reflect the option you just chose". Probed live: it updates on
every click — `Low Light` → `Medium / Indirect Light` → `Bright Indirect Light`
→ `Direct Sunlight`. The real difference is a wording mismatch between each
button's `<span>` and `LIGHT_DATA[level].label`.

**The reference fix was a hack.** An inline `<script>` appended to `index.html`
adding a document-level click listener that force-writes the label on
`setTimeout(0)` and `setTimeout(400)`. It never touches `light.js`, races the
real handler, and makes the labels *less* informative (`Direct Sun` replacing
`Direct Sunlight`). This is exactly the "hardcode around the tests" that Sand
forbids.

### What was built instead — the Watering Station

Chosen because the shipped task never touches it, and because the app's own data
already contains a trap:

```
tropical  { dry: 5,  average: 7,  humid: 10 }   monotonic
fern      { dry: 3,  average: 5,  humid: 7  }   monotonic
flowering { dry: 5,  average: 7,  humid: 9  }   monotonic
succulent { dry: 14, average: 10, humid: 14 }   NOT monotonic
```

Succulents want leaving alone longest at *both* humidity extremes. Any code that
assumes "drier air ⇒ water more often" is correct for three plant types and
wrong only for succulents.

| | site | defect |
|---|---|---|
| D1 | `js/ui/water.js` | intervals sorted and indexed by climate rank — swaps succulent dry/average |
| D2 | `js/ui/water.js` | range printed high-to-low: `Every 13–10 days` |
| D3 | `styles/tools.css` | `margin-bottom: -30px` so the volume overlaps the frequency line |

Defect definitions preserved verbatim in `tooling/plant225.py`.

### Why it was never proven

The verifier stayed flaky. Two runs disagreed with each other:

```
run 1   [P2P] dose scales with pot size        FAIL / FAIL
        [P2P] tropical keeps its intervals     PASS / FAIL
run 2   [P2P] dose scales with pot size        PASS / FAIL
        [P2P] tropical keeps its intervals     FAIL / PASS
        [F2P][D2] range runs low to high       FAIL / FAIL
```

Root cause of the first round: two tests reloaded the page four times each, and
`waitUntil: 'networkidle'` stalls ~30s per load locally, blowing the 60s test
timeout. Refactored to one load per test — results changed but still disagreed
between runs. **`nop=0`/`oracle=1` was never achieved.** Do not treat this task
as verified.

### Transferable lessons

1. **Probe the app before trusting the instruction.** Two of two queue templates
   described defects the app did not have. Checklist item 1 exists for this.
2. **Read the shipped reference patch early.** R1's hardcoded a literal; R2's
   was a racing inline script. Both would have failed review as dishonest.
3. **Never reload inside a test loop.** Click through state instead — faster,
   less brittle, and it proves the UI updates live.

---

## R3 — `tidewater-seats` — FAILED difficulty calibration

**Source:** own import
**Verdict:** *"Frontier models completed your task too consistently, so it is
currently too easy to enter review. Rework it to be substantially more
challenging, for example stricter success criteria, a more demanding scenario,
or more required steps, then resubmit."*
**Outcome:** returned for edits; **being reworked**, not abandoned. Lives at
`imports/1-drafting/tidewater-seats/`.

Everything else passed: Intake, Originality, Structure, Build, Change, Writing,
Verification review, Package, Baseline test run, Solution test run. Only
Difficulty calibration failed, and Human review was never reached.

Two results worth recording separately from the failure:

- **Originality passed.** This is the direct refutation of R1 — an app you wrote
  yourself cannot collide with the corpus.
- **Build passed.** `app-base:latest` is not a public image, so the Docker layer
  could never be tested locally. It worked first time.

### Diagnosis (measured, see `DIFFICULTY.md` §9)

All three defects fail both design filters:

| Defect | Reflex reachability | Self-test opacity |
|---|---|---|
| D1 adjacency | FAIL — the instruction restates the fix, and `seatPosition()` sits **four lines above** the defective predicate, exported and unused | FAIL — driving the app shows the split at once |
| D2 pricing | FAIL — the correct expression `TIER_PRICE[block.tier]` is on the line **immediately above** the broken one | FAIL — £192 for four £34 seats is visibly wrong |
| D3 layout | FAIL — the instruction describes the fix | FAIL — `target.png` adjudicates it for free |

The whole reference patch is **four changed lines, three of them single-token
edits, every one adjacent to the correct idiom.**

Three structural holes beyond the filters:

- **No counter-half.** Nothing grades that a party of six which *does* fit on one
  side is still offered, so "refuse everything above four" passes D1.
- **Internal-consistency hole.** Both D2 tests assert
  `total === pricePerSeat x count`, which passes while reporting a premium
  `pricePerSeat` for a standard row — exactly the reported bug.
- **Anti-attractor.** The base app already contains the *correct* model
  (`AISLE_WIDTH`, `seatPosition`), unused by the defective predicate. The nearest
  prior art teaches the right answer.

The coordinate-vs-index substrate is sound (`DIFFICULTY.md` §6 catalogue #1) and
is being kept. Rework record: `imports/1-drafting/tidewater-seats/REWORK.md`.

---

## R4 — `tidewater-v2` — "not imported" (structural, self-inflicted)

**Source:** own import, resubmit attempt
**Verdict:** *"The package was not imported. Compare it with the task template and
try again."* — shown at upload, **before any pipeline stage ran**.
**Outcome:** fixed the same day (2026-09-06). Not a platform judgement — a
packaging regression against `sand-task-template.zip`.

The repackage diverged from the template (and from our own original, which had
cleared every mechanical stage) in exactly two ways, **both introduced by our own
tooling and notes**:

1. **No `environment/app/.git`.** `package-import.py` excluded it and
   `PLATFORM-MECHANICS.md` said to — a wrong inference from the *returned*
   package, which has no `.git` because the platform strips it *after* intake. The
   importer needs it *during* intake to resolve `base_commit` and apply the patch.
2. **Wrong `problem_assets` names.** Shipped `broken-plan.png` + `broken-bill.png`,
   no `target.png`; the template mandates `broken.png` + `target.png`.

The trap: **the local verifier passed** (`nop=0`, `oracle=1`) on a package that
could not import. Mechanical local checks do not exercise the importer's
base-commit resolution or its structure allowlist. Hence C11 — diff the tree
against the template before every resubmit. Corrected `package-import.py` (ships
`.git`), `PLATFORM-MECHANICS.md` (both notes), and instruction/assets.

---

## R5 — `meadowlark` — failed difficulty calibration, "too consistently" (canonical substrate)

**Source:** own import
**Verdict:** *"Frontier models completed your task too consistently, so it is
currently too easy to enter review."* — passed **every** mechanical stage
(Originality, Structure, Build, Change, Writing, Verification review, Package,
both test runs); failed only **Difficulty calibration**.
**Outcome:** unsalvageable as-is — **released** (2026-09-06). This is the first
measured Sand calibration verdict, and it triggered a full forensic rewrite of the
difficulty method (`docs/DIFFICULTY.md`, `docs/forensics/`).

The value: it proved my whole difficulty approach was wrong, and why.

1. **Canonical substrate.** meadowlark's defect lived in recurring-calendar / DST /
   month-end math — one of the most documented domains in any training corpus, with
   effectively one canonical semantics. A frontier agent reconstructs the fix **from
   its weights**, so hardening `recurrence.js` changes nothing. Re-domain, don't harden.
2. **My F1/F2/F3 were scoped to the FILE, not the model's weights.** "No adjacent
   correct idiom in `recurrence.js`" is worthless when the answer is common knowledge.
3. **The old probe over-rated difficulty.** A one-shot "fix this module" probe denies
   the agent everything calibration grants (the full running app, a browser, the
   screenshots, iteration). 2/2 solvers failing my probe meant nothing; a frontier
   agent *with the app* solved it near-totally. Replaced by the calibration-faithful
   probe in `DIFFICULTY.md §6`.
4. **The real stump mechanism is conjunction, not concealment.** Approved gold tasks
   were solved 0–2 of 5 by facing **one behaviour into ~30 independent anti-reflex
   promises** under self-test opacity — not by hiding one deep misconception behind
   ~10 tests that all fall the moment the solver "gets" it (which is a single coin flip).

Full evidence: `docs/forensics/`. greenroom (bespoke interval twist) is the one
salvageable case and is the live test of whether bespoke-but-single-misconception
clears the bar.

---

## Standing checks

Derived from the above. Run these against **every** unsubmitted task before
submitting, and re-run them all whenever a new rejection lands.

| # | Check | From |
|---|-------|------|
| C1 | The instruction describes a defect the app **actually has** — verified by driving the app, not by reading code | R1, R2 |
| C2 | The reference patch fixes the **cause**, never forces the observable — no literals substituted for derived values, no listeners layered over the real handler | R1, R2 |
| C3 | ≥6 F2P and ≥2 P2P, tags exact, no duplicate titles | R1 |
| C4 | `nop=0` and `oracle=1` proven locally, **twice**, with matching results | R2 |
| C5 | No test reloads the page more than once; no test depends on animation, clocks or network settling | R2 |
| C6 | Queue templates are corpus-tainted at the **shell** level — prefer Import; a queue task needs a genuinely new app, not a new bug | R1 |
| C7 | Difficulty is measured, not asserted — state the reflex path and where it breaks before submitting | R3 |
| C8 | Screenshots come from the same scripted scenario on both builds, and differ only where the defects are | R1 |
| C9 | The upload **ships `environment/app/.git`** with a clean tree at `base_commit` (the broken state); the importer needs it to resolve base and apply the patch, and strips it only afterward — omitting it fails "not imported" | R4 |
| C10 | `problem_assets/` uses exactly the template names **`broken.png` + `target.png`** (a before-only story still ships a corrected `target.png`); custom names or a missing `target.png` fail "not imported" | R4 |
| C11 | Before any resubmit, diff the package tree against `sand-task-template.zip` — the two divergences above passed the local verifier and still would not import | R4 |
| C12 | **Canonical-substrate gate.** If the load-bearing defect is a memorised bug class (dates/DST/recurrence, interval boundaries, pagination, tokens, N+1, float money, dedup, rate-limit, auth, CORS, semver, apportionment) — REJECT and re-domain. Reflex-reachability is a property of the model's **weights**, not your file (`DIFFICULTY.md` G4/§5) | R5 |
| C13 | Difficulty is **conjunction on a bespoke computation** — ~30 independent anti-reflex promises on one behaviour under self-test opacity — not one deep misconception behind a handful of tests, and not layout/config. Probe it the **calibration-faithful** way (full running app, browser, iterate; grade blind) before building (`DIFFICULTY.md` §4/§6/G7) | R5 |
| C14 | **Distinct shell per task.** Every import task ships a genuinely different app shell — do NOT clone a prior task's scaffolding (`launch.sh`, `Dockerfile`, `tests/` harness, build config, `package.json`, `index.html`). Corpus dedup keys on the shell (R1), so cloned tasks read as "too similar" **to each other**, not just to the corpus. meadowlark + greenroom were both cloned from tidewater's skeleton → greenroom apparently failed Originality on shell-similarity. A new task = a new app built its own way, not a reskin | R1, greenroom |
