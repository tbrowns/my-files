# Retired tasks - what we tried, and why not to redo it

reefdesk is the only live task. Everything below was deleted to shrink the repo.
The source of every task except task_0128 is recoverable from git history
(`git log --oneline`, then `git show <sha>:<path>` or `git checkout <sha> -- <path>`);
this ledger is the "do not redo" record. Deeper detail lives in the other docs
and in auto-memory (MEMORY.md).

## Import tasks

- **tidewater** (theatre box office: seats-across-a-gangway, block pricing, floor
  plan). The FIRST import task and the origin of the import anatomy + the shared
  infra (Dockerfile, launch.sh, tests/{behavior.spec.js, parser.py,
  run_script.sh, playwright.config.js, seed_fixtures.js, test.sh}, solution/solve.sh).
  It cleared every mechanical stage and failed only at Difficulty. Its infra now
  lives in **reefdesk**, the living reference - copy from there for the next import
  task. Lessons in PLATFORM-MECHANICS.md (ship environment/app/.git; assets must be
  broken.png + target.png). Do not rebuild it.

- **tidewater-v3** - a later tidewater re-cut. Superseded by the above.

- **meadowlark** (standing appointments). Failed ORIGINALITY (cloned tidewater's
  app shell) and then DIFFICULTY (canonical/derivable substrate, solved too
  consistently). Lessons: C14 distinct shell per task (REJECTIONS.md R5) and the
  difficulty law (DIFFICULTY.md). Never reuse a cloned app shell; never build a
  canonical substrate.

- **greenroom** (turnaround diary). Failed ORIGINALITY the same way (cloned
  tidewater). Same C14 lesson.

## Queue tasks

- **task_0104** (piezocrack, a 2D lattice fracture + piezo-charge physics sim).
  Reworked into a valid deterministic task, submitted, and failed DIFFICULTY twice
  as TOO EASY - even after hardening (anisotropy + field superposition). Root
  cause: **physics/geometry/math is DERIVABLE from a frontier model's weights**, so
  a solver reconstructs it from first principles no matter how it is dressed up. An
  agentic probe showed solvers deriving the exact model independently. Do NOT
  author physics/calendar/geometry/interval difficulty tasks. See
  [[sand-disclosure-kills-difficulty]] and DIFFICULTY.md.

- **task_0128** (infographic / lorem-style generator). Downloaded, never worked on
  (only "game" category was on offer and it needed a redesign). Nothing learned;
  not worth picking up.

## The one durable conclusion (why reefdesk is the shape that works)

Frontier difficulty needs arbitrary CONTINGENT business rules that must be READ,
not derived; an UNDER-specified instruction so the solver has to infer; and the
graded difficulty concentrated in subtle DETERMINATE edges/interactions the
instruction leaves unstated. Disclosed rules get transcribed (8/8 solved);
derivable ones get derived (physics). The narrow in-band zone is determinate-but-
overlooked edges. reefdesk (Tidepool Support Desk) is the one substrate that
probed near the band. Full detail: DIFFICULTY.md, [[sand-disclosure-kills-difficulty]],
[[sand-reefdesk-status]].
