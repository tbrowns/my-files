# Task lifecycle and folder rules

Two sources of tasks, kept apart because they behave differently:

- **`imports/`** — apps written here and uploaded as a package. Cannot collide
  with the corpus. The preferred route (see `REJECTIONS.md` R1).
- **`queue/`** — templates claimed from the platform queue. Corpus-tainted at the
  shell level, time-boxed by a claim, and shipped broken often enough that every
  one needs verifying before it is trusted.

Each side carries the same three stages.

---

## The three stages

```
1-drafting/          being built, OR returned for edits, OR failed calibration
2-awaiting-review/   submitted AND passed difficulty calibration, human review pending
3-approved/          approved
```

**A task moves `1 → 2` only when difficulty calibration has actually passed.**
Not when it is submitted. Submission alone changes nothing on disk, because a
submitted task that fails calibration comes straight back — and the whole point
of the split is that stage 1 means "not yet proven hard enough".

The operator says when a task is submitted and when a verdict lands. Movement is
never inferred from a build passing.

### Moving a task

```bash
mv imports/1-drafting/<task>  imports/2-awaiting-review/<task>   # calibration passed
mv imports/2-awaiting-review/<task>  imports/3-approved/<task>   # approved
mv imports/2-awaiting-review/<task>  imports/1-drafting/<task>   # returned for edits
```

Then update the table in `../README.md` in the same breath, and append to
`REJECTIONS.md` if a verdict was negative.

---

## When a review comes back with changes

This is the rule that makes the structure worth having.

1. Append the verdict to `REJECTIONS.md` — verbatim wording, what the task was,
   why it failed.
2. Turn it into a **standing check** at the bottom of that file.
3. **Run the new check against every task still in `1-drafting/`**, and fix them
   before submitting any of them.
4. Note in each task's own `REWORK.md` that it was audited against the new check
   and what changed.

The failure mode this prevents: submitting three tasks in sequence and
collecting the same rejection three times. R1 cost two cycles to that exact
mistake before the pattern was recognised.

---

## What lives inside a task folder

```
<task-name>/
├── task.toml                  metadata, base_commit, F2P/P2P counts
├── instruction.md             the solver's only prompt
├── launch.sh
├── environment/
│   ├── Dockerfile
│   ├── app/                   the application (a git repo, HEAD == base_commit)
│   └── problem_assets/        broken.png, target.png
├── solution/
│   ├── solve.sh
│   └── patches/source_patch.diff
├── tests/                     the verifier
├── REWORK.md                  design record: defects, why each is hard, verdicts
└── <task>.zip                 the packaged artefact actually uploaded
```

`REWORK.md` is the task's own memory: what was planted and where, the reflex path
a solver takes and where it breaks, calibration verdicts, and what changed
between submissions. Written while building, not afterwards.

---

## Abandoned tasks

Deleted, not archived. The working trees are large and regenerable; what matters
is why they failed, and that goes in `REJECTIONS.md` with enough detail to be
useful without the tree — including the actual defect code where it carries the
lesson.

---

## Before any submission

- [ ] Standing checks C1–C8 in `REJECTIONS.md` all pass
- [ ] `nop=0` and `oracle=1` locally, run twice with matching results
- [ ] ≥6 F2P, ≥2 P2P, tags exact, no duplicate titles
- [ ] Screenshots from the same scripted scenario on both builds
- [ ] `HEAD == base_commit`, tree clean, patch applies at base
- [ ] Reflex path written down in `REWORK.md` and shown to break

---

## Version control

This folder is a git repo. One repo tracks everything: docs, tooling, both task
routes, and the template.

**The app inside a task is NOT its own repo while you are authoring it.** The
import format requires `environment/app/` to be a git repo with
`HEAD == base_commit`, but keeping one there makes it a nested repo — git records
only a gitlink, and the app's source ends up untracked by this repo. A clone
would not contain it.

So the app's repo is created **at package time** and not before:

```bash
cd <task>/environment/app
rm -rf .git
printf '* -text\n' > .gitattributes          # LF, or git apply breaks in the container
git init -q && git config core.autocrlf false
python ../../../tooling/plant-import.py       # ensure the BROKEN state is the base
git add -A && git commit -q -m "<app name>"
git rev-parse HEAD                            # -> task.toml base_commit

python ../../../tooling/plant-import.py --fix # apply the real fix
git diff > ../../solution/patches/source_patch.diff
git checkout -- .                             # back to base; tree must be clean
```

Toggling between broken and fixed during authoring uses the planter scripts, not
git, so nothing depends on the inner repo existing.

`.gitignore` excludes `node_modules/`, build and test output, and packaged
archives — all regenerable. It also excludes any inner `environment/app/.git/`
that survives a package run.

**Commit at every meaningful step**: a defect planted, a verifier passing, a
verdict recorded. The rejection ledger is only as good as the history under it.
