# Queue tasks — claiming, reworking, and submitting

How the platform's **queue** route works (the "Needs your fix" / claimed-task lane),
distinct from Import. Written from reworking `task_0104` end to end and getting it
submitted on 2026-09-07. Import mechanics live in `PLATFORM-MECHANICS.md`;
difficulty rules (which apply to queue tasks too) live in `DIFFICULTY.md`.

## What a claimed queue task is

Claiming a task downloads a **workspace tar**, `task_XXXX-<slug>-workspace.tar`, laid
out as:

```
.sand-workspace.json          # { version, taskId, workingSnapshotId }
base-repo/                    # the BROKEN app the solver receives
fixed-repo/                   # the CORRECT app (the reference)
instruction-images/           # broken.png + target.png
instruction.md
reference/tests/              # the spec + boot.sh + run_script.sh + parser.py + playwright.config.js
```

- The apps are **static vanilla-JS sites** (category `game`/`vibe`): `index.html`
  loads `js/main.js` as an ES module. Served with `python -m http.server` (see
  `reference/tests/lib/boot.sh`). Not React.
- The **base vs fixed diff is the reference solution.** Keep it to the one intended
  defect; everything else identical.
- `.sand-workspace.json` carries the `taskId` and a `workingSnapshotId`. Each fresh
  claim of the same task gets a **new** `workingSnapshotId` — update it on re-claim.

## "Needs redesign" means the shipped task is broken

These templates routinely ship **invalid**: `task_0104`'s instruction, base, and
fixed disagreed and all four F2P failed on *both* builds. So reworking is authoring
a coherent task on the given app, not patching the shipped one:
- Keep the **app** (it is the platform's shell, so originality is the platform's
  problem — you do not risk the R1 "too similar" shell trap by keeping it).
- Write **one coherent defect** (base vs fixed = one clean diff).
- Write **correct tests** (>=6 F2P fail-on-base/pass-on-fixed, >=2 P2P green on both)
  and an **honest, human-voiced instruction**.

## Making a vibe sim gradeable (determinism)

Sim apps step on `requestAnimationFrame` and use `Math.random`, so a wall-clock wait
gives machine-dependent values — which is exactly why `task_0104`'s shipped tests
failed on both builds. Fixes that worked:
- **Seed `Math.random`** with a small LCG, and add a `window.__crush(cfg)` hook that
  re-seeds, re-inits, sets params, steps a **fixed count**, and returns `window.S`
  telemetry. Tests read reproducible state via `page.evaluate`, not the animation loop.
- Put the hook in `js/main.js` of **both** repos (identical — not part of the defect).
- Grade off `window.S` (or read-back DOM), never off a timed screenshot.
- Tests use `waitUntil: 'domcontentloaded'`, **never `networkidle`** — the app loads
  Google Fonts, and `networkidle` stalls ~30s per navigation locally.
- Browser V8 reproduces a Node headless run of the physics module **to 13 digits**,
  so iterate on a fast Node harness (`import` the module, override `Math.random`,
  step, read `S`); reserve the browser for the final check.
- `@playwright/test` is **pathologically slow** here (minutes). Verify with the
  `playwright` package directly instead (`chromium.launch`, drive, assert).

## Submission mechanics — the two hard-won rules

**1. Instruction images do NOT go in the archive.** They "change through the image
and screenshot tools, not archive uploads." An archive whose `instruction-images/*.png`
**differ** from the platform's originals is rejected. So:
- Ship the **original, byte-identical** `broken.png`/`target.png` in the archive
  (restore them from the fresh claim tar), so the archive is accepted.
- Set the **new** screenshots through the platform's **screenshot/image tool**
  separately. Capture them yourself for upload (or drive the app to the state the
  tool captures: pick the material, Apply/crush, capture — base for broken, fixed
  for target).
- Same rule as Import (`PLATFORM-MECHANICS.md`), now confirmed for the queue.

**2. `instruction.md` must be a specific, human-written user request.** An
AI-template with `## What you see` / `## What correct looks like` headers is rejected
("Rewrite instruction.md as a specific, human-written user request"). Write it as a
real user's bug report — first person, specific, plain. Run the **`humanizer`** skill
(ASCII-clean, no em-dashes, no "caveat"). Keep the two `<img>` tags out of a pasted
user request; add them only if the instruction field wants inline image markdown.

## The order that worked

1. Rework the workspace: one coherent defect in `base-repo` (fixed-repo correct),
   deterministic tests, humanized `instruction.md`.
2. Verify locally: `nop=0` / `oracle=1`.
3. Package the archive with the **original** instruction images and the humanized
   instruction. Exclude scratch dirs (`.pw`, `test-results`, `screenshots-for-tool`).
4. Upload the archive.
5. Set the **new** screenshots via the screenshot tool.
6. Make sure `instruction.md` reads as a human user request (checked on the archive).
7. Submit **before the claim timer expires**.

## The claim timer

Counts down during authoring; pauses only during platform **verification**. A long
first-time rebuild can expire the claim (it did once). If it expires, re-download
(re-claim) — you get a **new `workingSnapshotId`**; if the rework is already
committed, re-applying is a snapshot-id swap plus a repackage, not a rebuild. Do the
authoring, then submit promptly.

## The queue pipeline (measured 2026-09-07)

A submitted queue task runs the **same automated pipeline as Import**, in order:
Intake checks -> Originality check -> Structure check -> Build -> Change check ->
Writing check -> Verification review -> Package check -> Baseline test run ->
Solution test run -> **Difficulty calibration** -> Human review -> Final processing.

So the queue **does gate on difficulty** — the earlier hope that it might not is
wrong. Two things confirmed on `task_0104`'s run:
- **Originality passed.** Keeping the platform's app shell and reworking only the
  defect/tests/instruction clears Originality. This is the whole reason keeping the
  given app matters: originality is the platform's, not ours (contrast R1, where a
  *queue reskin of an existing app* was rejected "too similar").
- Difficulty calibration is in the pipeline, so a reworked queue task must still
  clear the `DIFFICULTY.md` bar (conjunction on a bespoke, non-canonical computation).

## Status

`task_0104` (piezocrack, physics/vibe): reworked into a material-scales-the-field
defect (base hardcodes the PZT-5A coefficient; fixed uses the selected material's
`d33`), `nop=0`/`oracle=1`, 6 F2P + 4 P2P, humanized instruction. **Submitted
2026-09-07; cleared Intake + Originality + Structure, reached Build.** Difficulty
calibration still upstream — verdict pending. If it returns "too easy", the substrate
is real (bespoke piezoelectric-fracture dynamics), so harden in place: a subtler
coupling error and a real conjunction across strain -> charge -> field -> breakdown,
graded on the same deterministic `window.__crush` harness.
