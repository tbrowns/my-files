# Difficulty playbook

How to author a Project Sand task that survives automated difficulty calibration.

Calibration runs your task against a state-of-the-art agent **10 times** and returns it if the agent completed it too consistently. It sits *after* every mechanical check — Intake, Originality, Structure, Build, Change, Writing, Verification review, Package, Baseline test run, Solution test run — so a package can be perfectly built, verified and original and still come back. It can return a task **three times**, each with a fresh window; after that the task goes back to the queue and **cannot be reclaimed**.

That cap is the reason this document exists in the shape it does. On Gold, a rejection at a deterministic stage was cheap and effectively part of the design process. In Sand, an easiness return spends one of three lives. **Front-load the hardening; you cannot iterate your way through calibration.**

---

## 1. The thesis, in one paragraph

Sand requires you to state the expected behaviour precisely — *"Ambiguity is not difficulty… If you can't state the expected behavior precisely, the task isn't ready"* — and it hands the agent a before screenshot, usually a target screenshot, the whole app, a browser, and the ability to write its own tests. Under those conditions, almost every trap dissolves. **The only difficulty that survives is a derivation step between a stated invariant and the code that computes it, where the wrong derivation produces plausible, well-formed output on every scenario the agent will actually try.** Everything below is machinery for finding that shape, proving it is live before you build, and grading it without flaking.

---

## 2. Scope of the evidence, and what does not transfer

This playbook is distilled from a ten-task authoring record on a different platform ("Gold": Django/DRF, pytest, held-out test selections, six approvals and four rejections with measured solve rates), cross-checked against Sand's own rules and against the three Sand outcomes recorded in `REJECTIONS.md`.

**Sand data is thin and I will not pad it.** One calibration verdict exists (R3, `tidewater-seats`, "too consistently"), with no per-trial numbers. Two other rejections were originality and expiry, not difficulty. Every mechanism claim below about *why* something is easy or hard is inference from Gold plus structure, not a Sand measurement.

### Transfers cleanly

| Gold finding | Sand form |
|---|---|
| Reflex reachability (F1) as the primary screen | unchanged — Sand's "Ambiguity is not difficulty" forces the same full statement that dissolved Gold's traps |
| Self-test opacity (F2) | **stronger** in Sand — the agent has Playwright and the seed data, so its self-check is better than Gold's |
| Modal-reading soundness (F3) | unchanged — one half-stated clause zeroed every Gold task-12 solver at 83/84 |
| One rule, several call sites | unchanged — API + second surface + page |
| Counter-halves for every constraint | maps onto P2P tests |
| Paired absence/presence in one test | unchanged |
| Determinism as a gate | **harder** in Sand — Playwright flake killed R2 outright |
| Legitimacy over rate | unchanged |

### Does NOT transfer — do not import these

- **Patch line-count floors.** Gold required ≥459 added solution lines over ≥4 files and ≥596 test lines. Sand has no such floor and says the opposite: *"A small patch can still be a hard task."* Gold's own numbers refute the floor anyway — approved solutions ran 493–674 lines while the too-easy task 10 shipped 521.
- **Gold's "pair the defect with a feature to reach the floor."** Actively harmful here. Sand: *"One problem, several angles. Don't bolt on unrelated requirements just to inflate difficulty."*
- **Gold's f2p counts (42–92 ids).** Sand's floor is 6 F2P / 2 P2P. A well-faceted single behaviour lands around 8–14 F2P and 4–8 P2P. Do not chase sixty.
- **The repository gate and base-commit selection.** You write the app.
- **"Prefer a subsystem whose existing tests are already red."** Gold's task 3 got real difficulty from a suite with ~27 pre-existing failures, because solvers defended the baseline they measured. In Sand the app is yours, so a red suite is your own defect and shipping one is dishonest.
- **The 100–300 instruction word band**, JUnit id bucketing, and every Django/DRF-specific trap (serializer read-only stripping, `get_object_or_404`, signal registration).
- **Gold's approved 0–2 of 5 band.** Different platform, different grader, different trial count. Sand's band is unmeasured in this repository.

### New in Sand, with no Gold counterpart

**The target screenshot is an oracle.** `environment/problem_assets/target.png` sits inside the container at a path the instruction names, and the agent can render its own build with Playwright and compare. Gold had no image channel at all. This single fact invalidates the most tempting difficulty family in a web-app eval — see §5.

---

## 3. The three filters

Run all three before writing app code. Each is a paragraph in `REWORK.md`, not a feeling.

### F1 — Reflex reachability

> Given the instruction you intend to publish, write down the implementation a competent agent produces from one read of the repo. Is the wrong shape still on that path?

This is the diagnosis for every Gold too-easy verdict. Task 10 (4/5), task 6 (7/8), task 8 (5/5), task 11 (6/6 on probe) all failed here: the instruction's own fairness-mandated observables made the reflex shape impossible to write, so the trap died before the draw.

Three failure shapes:

- **F1a — unreachable observable.** The contract names a value the reflex shape cannot compute at all, so the agent abandons it before writing a line. Gold task 10: `clients` was a three-way union across multi-valued relations, computable by exactly one code shape; all four captured solvers adopted that shape before writing anything.
- **F1b — the observable IS the fix.** The contract restates the correction. Gold task 6: *"each get ten a minute per client, on separate allowances"* has one implementation. Gold task 11: six of six probe solvers produced the four-state field, and **every one found the boolean prior art, named it, and killed it on the single sentence stating the four states.**
- **F1c — the row shields the rollup.** Stating a per-row field forces the solver to row level, and the summary becomes a reduction over rows that are already correct.

**The generalisation, recorded verbatim in the Gold record:** *"A stated observable is a procedure in disguise when only one code shape can compute it."* Disclosure can kill a trap structurally without the instruction ever describing a method.

### F2 — Self-test opacity

> What does the agent see on its first self-run against the wrong implementation?

Gold measured solvers writing 30–75 of their own tests, running them green, and failing anyway. Task 7's three released transcripts each wrote 48–75 tests; all three declared them green; two were wrong. Task 2's four solvers wrote suites of 37, 30 and 34 and declared the work done.

The mechanism: **a self-test written by the solver checks the reading the solver already holds.** Green self-tests are evidence of internal consistency, never of correctness.

**The calibration refinement that matters most, and the one most often got wrong:** *"A count of objects the solver seeded is not opaque."* F2 filters on **derivability**, not on whether the wrong value happens to look tidy. A band edge, an apportionment remainder, a local-calendar-day assignment, a weighted mean — opaque. "How many rows did I just insert" — not opaque, because the fixture's own setup is the oracle.

Fails F2 immediately: a crash, a 500, an empty list, a NaN, a missing element, a blank page, or any value the agent's own seed data determines.

### F3 — Modal-reading soundness

> For every graded assertion, is the behaviour you grade the reading a competent solver reaches *first*?

This is the too-hard direction, and it is the same filter seen from the other side. Gold task 12 scored 0 of 5 and 0 of 8. Job-directory data showed six trials each scoring **83 of 84**, all failing the same single test, caused by one instruction clause that stated one half of an asymmetry. A five-word fix took every measured solver to 84/84.

F2 and F3 pull against each other, and reconcile as one rule:

> **Opacity is earned by statement.** A contract may be hidden from the solver's own tests only if the instruction states it in the reading you will grade.

**Mechanical check:** a table in `REWORK.md`, one row per F2P test — `[title | the sentence that decides it | the cheapest reading of that sentence | does the cheapest reading pass?]`. Empty sentence cells are ungraded surprise. Failing cheapest-reading cells are unsound contracts.

---

## 4. The laws

### L1–L3 · Screen before you build
Apply F1, F2 and F3 to every intended trap, in writing, before any app code exists. A trap that fails F1 is worth nothing under calibration however elegant the code is.

### L4 · State the invariant; withhold the derivation

Difficulty survives full disclosure **only** when a derivation step remains between the sentence and the code.

- Gold task 7 stated 29 exact response keys and both trap invariants outright — *"the counts add up to total_leads, so 0 and scores past 100 count too"*, *"whole numbers summing to exactly 100; on a tie the earlier row takes the extra point"* — and solved **1 of 5**. The R1 rewrite that forced full disclosure **did not move the result**.
- Gold task 8 stated an even-count median rounded half-up and a nearest-rank quartile, tie directions included, and solved **4 of 5** then **5 of 5**. All four transcripts copied the rules straight into their own smoke tests.

Numerical is not the same as derived. The discriminator is outcome vs. method.

**Carry the caveat.** Task 8 R3 deliberately transplanted task 7's exact shape (a value-weighted largest-remainder behind a stated invariant) and went 4/5 → **5/5, worse**. A surviving derivation step is *necessary, not sufficient* — "a filter to apply, never a guarantee to lean on."

**Test:** can more than one code shape satisfy your sentence? If exactly one can, you wrote a procedure in disguise.

### L5 · Describe the shape of the failure, never the magnitude of the constant

Gold task 2's instruction said *"thirty hours from Thursday morning"* while the code held `timedelta(hours=24)`. All four recovered solvers matched the phrase against the literal on first read. *"A worked example that names the magnitude of the bound is naming the bound."*

This is the **only** surviving form of the concealment rule. Gold measured 8 of 8 solvers naming the defect immediately across two tasks; the standing rule became *"stop hiding the defect — spend the instruction's words on breadth, not concealment."*

**Check:** grep every number in your prose against the app source. Any match is a search key.

### L6 · Screenshot the case the reflex gets right; grade the cases it gets wrong

See §5. Sand-specific and load-bearing.

### L7 · One rule, several call sites; the symptom names one

Gold's most reliable structural lever.

- Task 2: one overlap predicate behind create, update, calendar and availability. *"Fixing `perform_create` does nothing for `perform_update`."* One test required both halves corrected simultaneously, and the design sequence explicitly ran the F2P set against a create-only reference and a clamp-only reference to confirm each failed from its own direction.
- Task 3: solver T1 fixed the reported path and reasoned the other *"is acceptable"* to leave silent.
- Task 5: mutant m1 — *"the callback half fixed and the read left as it was"* — is called **"the commonest partial answer available"** and fails 12 of 42 ids.

In Sand the natural triple is: the API that answers the user's question, a second API that reports the same state, and the page that draws it.

### L8 · Every constraint gets a graded counter-half

The reflex fix for a constraint over-applies. Gold task 2: re-running the create-time conflict check on update finds the booking as *its own* conflict and breaks a pinned pre-existing test. Gold task 4: the one-second fix for a catch-all route eating a fixed path is to delete the catch-all — so nine P2P ids grade that every agent page still works, and mutant m9 is *"slug route deleted outright"*, described as **"the one that matters most."**

Gold task 2's clamp trap is the cheapest technique in the whole record: *for every constraint you add, add the case that must still be allowed.*

Sand's P2P floor of 2 is a floor, not a target. Counter-halves are where the anti-shortcut work lives.

### L9 · Every absence assertion pairs with a presence in the same test body

Rediscovered four independent times in Gold. An assertion that nothing happened is satisfied by an implementation that does nothing at all.

Gold task 4's version is the one that matters most for Sand: *"while the slug pattern shadowed this path, **every** request to it was answered with a 404, so an assertion that some caller is turned away held perfectly well against the broken routing."* A shadowed route is indistinguishable from an absent one by status code alone.

And the sibling rule, which Gold says *"has cost three tasks"*: **when a test asserts a 4xx, make sure the request could not have been refused for any other reason.** Send a body valid in every respect except the one under test.

### L10 · Never assert an invariant between two fields of the same response

Measured directly in `tidewater-seats`. Both D2 tests assert `total === pricePerSeat × count`. An implementation reporting `pricePerSeat: 48` and `total: 192` for a standard row satisfies both — while being wrong in exactly the way the user complained about. Nothing pins row C to 34, and `/api/house` exposes `tier` but no price, so no external anchor exists anywhere in the suite.

**Fix:** anchor to a second endpoint, or assert a set of cases whose correct values differ (standard 136, premium 192, rear 88 in one test), so no single constant satisfies them all.

**Check:** for each assertion, name the single wrong value that would make both sides agree. If one exists, the test grades nothing.

### L11 · Grade derived state by reading it back, never by recomputing it

Gold task 4's rating had to be *"right the moment approval changes, rather than the next time somebody reads the profile."* It is graded by reading the stored row directly, and by a test that never issues a profile GET at all. The framework reflex — compute on read — produces a correct-looking response over a stale store, and three of nine mutants target that one decision.

Strong in Sand, because React naturally recomputes on render, so the read-time reflex is the default and is invisible on the demo path.

### L12 · Every F2P test must be red at base for its own reason

Sand says it: *"A collapsed or half-finished fix should leave most of your fail_to_pass tests red."* Gold sharpens it: **red-at-base proves nothing, because at base everything is red for one reason.**

Gold task 9's version is the sharpest instance in the record. Ten negative date-format cases had to be split across two parameter lists, because one value placed against the wrong end of a range would have been refused as a *reversed range* — answering 400 for the wrong reason and passing against the very implementation it existed to catch.

**Three builds, not two:** base, reference, and the **collapsed fix** — the smallest edit that makes the loudest symptom go away. Name, in `REWORK.md`, which F2P tests survive the collapsed fix. Any that do not are grading the symptom.

### L13 · One mutant per graded decision; a decision with no mutant is unsound

Gold task 12 shipped 25 mutants with zero survivors and still failed — its own mutant file named the hole in writing: *"no mutant models a blank is treated as unrecognised."* A sweep that looks clean because it never modelled the contract that mattered.

Task 5's battery shows why this is not optional: **six variants each fail exactly one id of forty-two.** A solution right about everything else and wrong about a single peripheral rule scores zero.

Two operating rules from the record:

- A mutant models **the reflex**, not a broken program — the idiomatic thing an agent would actually ship.
- *"A surviving equivalent mutant is a badly chosen mutant, not a task hole"* (task 7's m1 first shipped as a change with no behavioural effect and was replaced).

Cheapest ordering, which reached full coverage on the first pass in Gold task 5: **group the F2P tests by the decision each grades, and let the groups name the mutants.**

### L14 · Determinism is a gate

Sand's R2 died here — two runs disagreed, `nop=0`/`oracle=1` was never achieved, and the root cause was `waitUntil: 'networkidle'` stalling ~30s per load because outbound DNS is unresolvable locally.

Gold measured the other half: pinning tests by pass count rather than by structure produced a **26–76% flake rate over 200 replicas**, and two *different* members of one flaky trio flipped on two different tasks. A flaky graded test takes a correct solution to reward 0 on a coin toss, silently.

Rules: one page load per test, click through state. `domcontentloaded`, never `networkidle`. Assert relations, not pixels. No animation, no clock, no unspecified tie-break. Fixed seed data. **Three runs a side, requiring identical result sets — not identical counts.**

### L15 · Width from facets of one behaviour, never from bolted-on features

Conjunction under binary grading is real: Gold's approved tasks each carried ~30 promises where one peripheral rule takes reward to zero. But it is **not sufficient and it is non-monotone**. Task 6 carried 54 f2p ids under the same binary grading and every one of 8 trials passed all 54. Task 8 had the *most* contracts (67) and went 5/5. Task 12's 0/5 was diagnosed as **not** width.

> *"Width did not cause the failure. It set how many chances there were for one contract to be unsound."*

Sand constrains it further: one problem, several angles. Facets must be independently decidable **and** each must diverge from the reflex answer. A facet the reflex gets right adds ids and no difficulty.

### L16 · The reference patch fixes the cause; no test is satisfiable by a hardcode

Both Sand queue templates shipped dishonest fixes: R1 substituted the literal `'/3'` for a derived total, so an agent could satisfy two of four F2P tests by typing three characters; R2 layered an inline click listener over the real handler on `setTimeout`. Both are the hardcode-around-the-tests Sand forbids.

**Check:** name the smallest literal that satisfies each test. And confirm `source_patch.diff` touches nothing the grader trusts — no `tests/`, no `playwright.config.js`, no `seed_fixtures.js`, no package scripts. Gold's parallel: the reference touching only one app means *"the only route to reward is the report code."*

### L17 · Probe the instruction with independent solvers before building

Gold calls this **"the one finding that outranks the rest."**

Task 11's six-solver probe settled the design for a fraction of a build cost — 6 of 6 produced the four-state field, 6 of 6 produced the refusal, and **every one found the wrong prior art, named it, and killed it on one declarative sentence.** The task was parked without ever spending a calibration draw. Task 10's probe *"would have failed in one line, ten minutes, before any code."*

Sand makes this cheaper and more necessary: you already have the app, and the easiness check has three lives.

**Protocol:** three fresh sessions. Draft instruction + broken app only. No tests, no patch, no `REWORK.md`. Ask each for the diff it would write. **Require at least two of three to produce the wrong shape.** Paste the results into `REWORK.md` — it is the evidence for standing check C7.

### L18 · Calibration is a sample; legitimacy is what is judged

Gold task 3 solved **0 of 5** and was **approved**, because the run audit found zero fails on failure legitimacy and task specification. Task 12 scored the same rate and was rejected, because the failures were caused by the author's own half-stated clause. Identical rates, opposite verdicts, decided on legitimacy.

For Sand: do not import Gold's band. When a return lands — log it verbatim, turn it into a standing check, re-audit everything in `1-drafting/`, then **rebuild the mechanism**. Rewording spends a life on a trap you already know is reachable.

And the meta-law Gold asserts about itself, confirmed twice: **pre-register the falsifier before the draw, or the result teaches you nothing.** Task 9 predicted 1-or-2 of 5, hit 1 of 5, and then honestly recorded that the *mechanism* it predicted did not occur.

---

## 5. Screenshot discipline — Sand only

There is no Gold counterpart to this and it is the most under-appreciated hazard in the format.

`environment/problem_assets/target.png` ships inside the container. The instruction references it by path. The agent can open it, and it can screenshot its own build with Playwright. **The target screenshot is a visual oracle**, and any promise it adjudicates fails F2 before you have written a single test.

Concretely, in `tidewater-seats`: the entire D3 defect is `.row-seats { gap: 0 }` → `gap: 5px` and `.aisle { width: 0 }` → `width: 26px`. Both are settled by looking at the picture.

**Rules:**

1. Choose a demo scenario in which the reflex implementation and the correct one **look the same**. Show a party of four in a row with no boundary in it; grade the party that straddles.
2. Audit it: list every graded assertion an agent could settle by diffing its build against `target.png`. For the load-bearing traps, that list must be empty.
3. The target screenshot is **optional**. If no safe frame exists, ship `broken.png` alone and let prose carry the reviewer. The reviewer convenience is not worth the oracle.
4. Both screenshots from the same scripted scenario, viewport and state, differing only where the defects are (standing check C8).

**The corollary that has to be said plainly:** Sand's own guidance says *"Front-end depth. Layout, spacing, and professional presentation issues are genuinely difficult for agents."* Ship the layout work — the target build must be the most professional version of the app you could ship, and reviewers check that. But **score it zero for calibration**. It is fair-review content, not difficulty.

---

## 6. Trap catalogue for React + Express

Generative material. Each entry names the invariant to state, the reflex it defeats, and why it survives F2.

| # | Family | State this invariant | The reflex it defeats | Why it is opaque |
|---|---|---|---|---|
| 1 | **Coordinate vs. index across a discontinuity** | "seats offered together are genuine neighbours on the floor" | arithmetic on the identifier (`b - a === 1`) rather than on the position | correct for every row without a boundary in the offered block |
| 2 | **Integer apportionment** | "the line items add up to the total shown" | per-line `Math.round(x/total*100)` | three equal shares give 33+33+33=99 only on some fixtures; the naive result often sums correctly by luck |
| 3 | **Half-open intervals** | "both ends of the range are included, and nothing is listed twice" | `BETWEEN`, `<=` upper bounds, closed slicing | plausible non-empty output for multi-day ranges; fails only on the single-day case and the exact boundary instant |
| 4 | **Local calendar day vs. stored instant** | "a booking is listed under the day it happens on here" | `new Date(iso).toISOString().slice(0,10)` | wrong for only a few hours out of 24; a self-test written with `Date.now()` at midday is green |
| 5 | **Derived state at write time** | "the seats-left badge is right the moment a hold is placed" | recompute on read / `useMemo` on render | the API response looks correct everywhere except after the mutation that should have invalidated the store |
| 6 | **Two write paths converging** | "however a hold is placed, the rule applies" | fix the path the complaint names | the named path works; the other one is silent, and nothing crashes |
| 7 | **A guard that must not over-fire** | "when a party can't be seated that way the house says so" — plus the party that legitimately fits | re-run the create check on update, catching the record as its own conflict | breaks a case the agent never thought to re-run |
| 8 | **Ordering under ties** | the sort key **and** the tie direction, both stated | insertion order, or the model's own default ordering | agrees with the correct answer on any fixture without a tie |
| 9 | **Optimistic UI reconciliation** | "what the page shows after the server answers is what the server said" | keep the optimistic local value | the demo path agrees, because the server returns what was guessed |
| 10 | **Route/middleware shadowing** | the fixed path answers, **and** the parameterised one keeps working | a documented knob — weak alone | worth one promise; never the spine |

Entry 10 carries Gold's standing caution. Registration and call **order** were Gold's most reliable lever across tasks 2, 3, 4 and 5 — *"nothing computes a wrong answer; `AgentProfileView` is correct, it simply never runs."* But task 6 had the same lever in its purest form and it did not bite, because **the wrong site could still produce the observable**: the solver hand-rolled the check inside the view body and passed everything.

> The discriminator is not "is there a lifecycle fact" but **"is there an input the wrong site cannot answer."**

And the line between the strong version and the weak one: **a documented setting is config-shaped and the model has seen it a thousand times; an undocumented call order is not.**

---

## 7. The measurement protocol

Run in this order. Steps 1–2 happen before any app code exists.

1. **Write the reflex path.** The exact function and expression a competent agent produces from the instruction plus one read of the repo. If you cannot write it, you do not know whether your trap is live.
2. **Three-solver probe (L17).** Draft instruction + broken app only. Require ≥2 of 3 wrong. Fix the mechanism now, not after a return.
3. **Build base and reference.** `nop=0`, `oracle=1`, run twice with matching results (C4).
4. **Build the collapsed fix (L12).** Most F2P must stay red. Record which do not.
5. **Mutant ladder (L13).** One variant per graded decision, each the idiomatic-wrong version. Read the table both ways: every F2P title killed by at least one mutant; every mutant modelling something an agent would ship.
6. **Determinism (L14).** Three runs a side, identical result sets.
7. **Contract table (F3).** Every F2P title → the sentence that decides it → the cheapest reading → does it pass?
8. **Screenshot oracle audit (L6).** The list of assertions settleable from `target.png` must be empty for load-bearing traps.
9. **Standing checks C1–C8** in `REJECTIONS.md`.

Gold's warning about batteries, earned twice: **an instrument nobody has falsified is not a measurement.** Task 10 passed a fan-out mutant check, a 24-mutant sweep and an end-to-end reward-1 run, and still calibrated 4 of 5 — because every item measured *gradability*, and none could fail on account of an unreachable trap. Steps 1–2 exist because **the design check has to run before the build; running the verification battery afterwards is running it too late.**

---

## 8. Fake difficulty

Things that look like difficulty, cost real hours, and buy nothing under calibration.

1. **A CSS or layout defect as the load-bearing trap.** The target screenshot adjudicates it for free. Ship the layout work for professionalism; score it zero. (§5)
2. **More defects.** Three independent one-line bugs is one-line difficulty three times. Sand rejects bolt-ons.
3. **A bigger patch or more files.** Gold's approved solutions ran 493–674 lines; the too-easy one shipped 521. Sand has no line floor and says a small patch can still be a hard task.
4. **A vague instruction.** Sand rejects it as unfair, and it does not even work — task 7 disclosed *more* than the 7-of-8 task 6 and solved 1 of 5.
5. **Hiding where the defect is.** 8 of 8 Gold solvers named the defect in their first pass. Only the narrow form survives: never name the magnitude of the constant.
6. **Obscure, minified or deeply nested code.** Labour, not difficulty. Gold's failure mode was never not-finishing — every recovered transcript finished, self-tested green, and submitted a confident summary.
7. **Framework configuration and documented knobs.** CORS, proxy, ports, env vars. Nine Gold rounds on exactly this shape produced 7 of 8.
8. **More F2P tests over the same decision.** The two too-easy Gold extremes carried the two highest redundancy ratios (4.15 and 1.97 ids per contract, against 1.06–1.48 for the approved).
9. **Brittle assertions.** Exact pixels, exact copy, exact DOM nesting. Brittle is not hard; it fails correct implementations and fails the determinism gate.
10. **Guessing an invisible convention.** Sand rejects it explicitly, and it produces task 12's failure: everybody dies on the author's defect, at 0/5 and 0/8.
11. **A rare library API.** Agents search faster than you do. A lookup, timed.
12. **A long instruction of transcription clauses.** Task 8 stated the median and quartile rules in full and all four transcripts copied them into their own smoke tests. Numerical ≠ derived.
13. **A framework-reflex trap as the spine.** Gold task 3's flagship trap was called *"the single best trap in the task"* and **caught zero of four solvers**. One promise, never the plan.
14. **Planting wrong prior art to be copied.** Pre-registered and tested twice on Gold, then **retired as a design driver**: task 9's sat in files the solution never opens and nobody read it; task 10's was read deliberately and *declined*. Available in Sand since you write the app — but never a substitute for F1.
15. **A defect the agent cannot reach.** Not hard, unfair. It comes back on failure legitimacy.
16. **Inheriting a broken test suite.** Gold's task 3 got real difficulty this way; in Sand the app is yours, so a red suite is your own defect.

---

## 9. Worked diagnosis: `tidewater-seats` (R3)

The task passed Intake, Originality, Structure, Build, Change, Writing, Verification review, Package, Baseline test run and Solution test run — and failed only difficulty calibration. Here is why, measured from the artefacts.

**The entire reference patch is four changed lines, three of them single-token edits, and every one sits adjacent to the correct idiom.**

```js
// backend/house.js — seatPosition() is defined FOUR LINES ABOVE this function
- return right - left === 1;
+ return seatPosition(right) - seatPosition(left) === 1;

// the correct expression is on the line IMMEDIATELY ABOVE
  pricePerSeat: TIER_PRICE[block.tier],
- total: TIER_PRICE.premium * size,
+ total: TIER_PRICE[block.tier] * size,
```

```css
- .row-seats { gap: 0; }        + gap: 5px;
- .aisle { width: 0; }          + width: 26px;
```

| Defect | F1 | F2 | Verdict |
|---|---|---|---|
| D1 adjacency | **FAIL (F1b)** — the instruction says *"seats offered as together should be genuine neighbours on one side of the gangway"*; that is the fix restated, and `seatPosition` is exported, named, and unused by `areNeighbours` | **FAIL** — driving the app shows the split immediately | dead |
| D2 pricing | **FAIL (F1b)** — *"Charge each row at its own rate"* with `TIER_PRICE[block.tier]` on the line above | **FAIL** — £192 for four £34 seats is visibly wrong | dead |
| D3 layout | **FAIL** — *"the gangway shown as a real break in the row and the seats spaced apart"* | **FAIL** — settled by `target.png` | dead |

Three additional structural findings:

- **No counter-half (L8).** Nothing grades that a party of six which *does* fit entirely on one side is still offered. A solver could refuse everything above four and pass D1.
- **Internal-consistency hole (L10).** Both D2 tests assert `total === pricePerSeat × count`. Reporting `pricePerSeat: 48` and `total: 192` for a standard row passes both while being exactly the bug the user reported.
- **An anti-attractor, not an attractor.** The base repo already contains the *correct* model — `AISLE_WIDTH = 1` and `seatPosition()` — unused by the defective predicate. The nearest prior art teaches the right answer. Gold saw this on task 8, where the nearest prior art also taught the correct idiom and the task went 5/5.

**The rework, in the terms of this document:** the coordinate/index distinction (catalogue #1) is a genuinely good substrate and worth keeping. What has to change is that the invariant must be stated as an outcome that several code shapes could satisfy; the correct helper must not sit four lines from the defect; the discriminating cases must be off the demo path and out of `target.png`; the price must be anchored across tiers so no single constant satisfies it; and the refusal rule must acquire the counter-half that stops "refuse everything" from passing.

---

## 10. Honesty limits

Read these before quoting anything above as settled.

1. **Sand's calibration band is unmeasured here.** One verdict, no per-trial numbers. Gold's 0–2 of 5 was a different platform with a different grader and a different trial count. Do not import the number.
2. **A solve rate is measured; a solve mechanism is inferred.** Gold hit this limit three times (tasks 7, 9, 10): released transcripts elide tool outputs and produced source, so *"which held-out assertion actually failed is not recoverable."* The two exceptions were transcript recovery (task 2) and per-id job-directory data (task 12) — and task 12 is precisely where the diagnosis **inverted**, from "conjunction width" to a single instruction defect. If Sand exposes per-trial data, read it; it is the cheapest available upgrade to any claim about *why*.
3. **The three filters score traps, not tasks.** Score every trap separately, take the maximum, and a task passes if **any** trap passes both F1 and F2. All three of Gold's in-band tasks carried one shielded trap alongside one live one.
4. **Neither F1 nor F2 models conjunction**, and width is non-monotone against outcome. A promise count belongs *beside* the filters, never inside them.
5. **The substrate gate and the ceiling test are separate gates the filters do not encode.** A candidate can pass F1 and F2 and still be a low-ceiling substrate — Gold's only PASS/PASS attractor in a 31-item catalogue was killed by the ceiling test, not by the filters.
6. **Gold's own record contains four flat contradictions** that were never resolved there, and I am not resolving them here: the 700–1,800 line target that no approved task ever reached; the "two calibration rounds average the noise" claim that four of six approvals did not receive; the premise that concealment protects difficulty, refuted twice; and "framework wiring is the weakest lever" against "registration and ordering is the one lever that has never failed." On the last one, the reconciliation offered in §6 — documented knob vs. undocumented call order — is a reading, not a finding.
7. **The Gold record's own verdict on its repository, after twelve tasks:** *"the strongest evidence in the project that this repository is exhausted for difficulty under full statement."* A re-scout ran 31 candidate traps through the two filters and shortlisted **zero**. Expect the same arc in Sand: the substrate, not the craft, is what runs out. When it does, write a new app rather than a new bug — which is what the Import route is for.