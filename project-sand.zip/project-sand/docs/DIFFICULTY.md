# Project Sand — Difficulty Method

A decisive playbook for authoring a Sand task that survives difficulty calibration. This replaces the prior draft and folds in the meadowlark/greenroom forensics as first-class law.

Calibration runs your task against a state-of-the-art agent **~10 times** and returns it if the agent completed it **too consistently**. It sits *after* every mechanical check (Intake → Originality → Structure → Build → Change → Writing → Verification review → Package → Baseline run → Solution run), so a perfectly built, verified, original package can still come back. A return spends **one of three lives**; after the third the task cannot be reclaimed. The claim timer **pauses during Verification Check**, so hardening time is effectively free — there is no excuse to rush the screen.

**Front-load the hardening. You cannot iterate your way through calibration.**

---

## 1. Thesis

Sand forces you to state the expected behaviour precisely ("Ambiguity is not difficulty… if you can't state the expected behavior precisely, the task isn't ready") and it hands the agent the **whole running app, a browser, the before/target screenshots, the seed data, and the right to write its own tests**. Under those conditions almost every trap dissolves.

The only difficulty that survives is a **derivation step between a stated invariant and the code that computes it, where the wrong derivation produces plausible, well-formed output on every scenario the agent will actually try** — and the reliable way to make that survive *ten* draws is to **face one behaviour into ~30 independent promises**, each diverging from the reflex, so that every solver misses a different subset and none can tell which of its readings is wrong.

Two things kill this before it starts, and they are the new law of this rewrite:

- **Reflex reachability is a property of the model's WEIGHTS, not of your file.** Proving no correct idiom sits adjacent in the source is worthless if the domain is canonical.
- **The source must not leak the answer** — not in a comment, not in a field name, not in a screenshot the agent can diff.

---

## 2. The band you are aiming at

- **Target interior: 1–3 of 10** completed (~10–30%).
- **Easiness ceiling: <4/10.** At or above ~4/10 it reads as "too consistently" and returns.
- **0/10 is acceptable only if the failures are dispersed** — each solver misses a *different* facet. A 0/10 where everyone misses the *same* clause is a broken instruction (illegitimate), and it returns on failure-legitimacy.

This number is **inferred, not measured** — Sand's band is uncalibrated here. It is mapped from gold's approved 0–2/5 onto Sand's 10-run calibration and biased to the safe interior. **Judge legitimacy and dispersion first, the raw count second.** Never soften a task because a draw came back scary, and never resubmit a passing or mid-pipeline task — that spends a good sample to buy a re-roll against a stochastic gate.

---

## 3. The Screen — seven gates, all before any app code

Score every gate **per trap**, take the maximum, and pass the task if **any one trap** clears G1 **and** G2. Then the whole task must clear G3–G7.

### G1 — Reflex reachability, scoped to weights
Write the implementation a 2026 frontier agent produces from your published instruction plus one read of the app. **PASS only if the wrong shape lies on that path AND the correct shape is not retrievable from the model's parametric priors.** The three ways a trap dies here:
- **G1a unreachable observable** — the contract names a value the reflex shape cannot compute at all, so the agent abandons the reflex before writing a line.
- **G1b the observable IS the fix** — the sentence restates the correction; only one code shape satisfies it.
- **G1c the row shields the rollup** — a stated per-row field forces the solver to row level and the summary becomes a reduction over already-correct rows.

*Generalisation: a stated observable is a procedure in disguise when only one code shape can compute it.*

**The meadowlark correction (do not skip):** G1 is about the training distribution, not your file. meadowlark proved no correct idiom sat adjacent in `recurrence.js` and still went too-easy, because recurring-calendar/DST math has one canonical, documented semantics the model already carries. Scoping reflex-reachability to adjacent code is the exact error that shipped it.

### G2 — Self-test opacity on derivability
What does the agent see on its **first self-run against the wrong implementation**? It must be plausible, well-formed output on every scenario it will actually seed. **Fails immediately:** a crash, a 500, an empty list, a NaN, a missing element, a blank page, a rate over 100%, or any value the agent's own fixtures determine. Opacity filters on **derivability, not tidiness**: a band edge, an apportionment remainder, a local-calendar-day assignment, a weighted mean — opaque. "How many rows did I just insert" — transparent, because the fixture's own setUp is the oracle.

### G3 — Modal-reading soundness (the too-hard guard)
Every graded assertion must grade the reading a competent solver reaches **first**. One half-stated clause zeroed every gold task-12 solver at 83/84. **Opacity is earned only by statement:** a contract may hide from the solver's own tests only if the instruction states it in the exact reading you grade. Build the table — one row per F2P: `[title | the sentence that decides it | the cheapest reading of that sentence | does the cheapest reading pass?]`. Empty sentence cells are ungraded surprises; failing-cheapest-reading cells are unsound contracts.

### G4 — Canonical-substrate gate
If the load-bearing defect coincides with a heavily-documented bug class, **reject and re-domain — do not harden.** The repair is reachable from weights regardless of local code. The banned list (non-exhaustive): naive date / RRULE / DST wall-clock math, interval off-by-one and half-open boundaries, keyset/offset/cursor pagination, HMAC-signed tokens, N+1 and missing `distinct`, float money, dedup/union counts, rate-limiting, auth/session/JWT, CORS, semver, apportionment behind a stated rule. Evidence: DRF throttling 7/8, keyset pagination 6/6 unprompted, meadowlark's whole D1–D5 checklist. See §5.

### G5 — Spec-leak gate
Nothing in the shipped source may name or point at the fix:
- no **unused field named for the invariant** (greenroom's `turnaround`);
- no **comment stating the rule** in prose;
- no **correct-but-unused helper** sitting near the defect (tidewater's `seatPosition`, four lines up);
- no **numeric magnitude in the prose** that greps to a source literal (gold task 2's "thirty hours" beside `timedelta(hours=24)`);
- no **wrong prior art you are banking on being copied** — retired as a design driver; it sat unread on gold task 9.

Compute standing values rather than storing them under revealing names. Redact descriptive prose that states the footprint. Grep every number in your instruction against the source and remove every match.

### G6 — Screenshot-oracle gate (Sand-only)
`broken.png` and `target.png` ship in the container and the agent can diff its own Playwright render against them. **Any load-bearing promise the picture can adjudicate fails G2 before you write a test.** Choose a demo scenario where the reflex build and the correct build **look identical**; grade the case that straddles the discontinuity, off the demo path and out of the frame. Ship the layout work for professionalism (reviewers check it), but **score every pixel/spacing promise zero for difficulty**. If no safe frame exists, ship `broken.png` alone (a `target.png` is optional).

### G7 — The empirical screen
G1–G6 on paper is a hypothesis. The **calibration-faithful probe (§6)** is the measurement, run before any app code. Require **≥2 of 3 fresh solvers to produce the wrong shape** from instruction + broken app alone. Convergence on the correct shape means fix the mechanism now — not after a draw.

---

## 4. What actually makes a Sand task hard

Only these mechanisms have held a frontier agent below the band. Everything else is fake difficulty (§7).

1. **Conjunction under binary grading.** ~30 independent promises on **one** behaviour, all F2P must pass together, each solver fails a *different* subset, and the app gives no signal about which reading is wrong. This is the one reliable stump. It is **non-monotone and necessary-not-sufficient**: the promises must be facets of a single behaviour, each independently decidable, and each must **diverge from the reflex** — a facet the reflex gets right adds ids and no difficulty (task 6 carried 54 ids and passed 8/8).
2. **A live derivation step** between a stated invariant and the code, whose wrong derivation still produces plausible output everywhere the agent looks (task 7, 1/5, held under full disclosure). **Necessary, not sufficient** — task 8 R3 transplanted the exact shape and got *easier*. Test: can more than one code shape satisfy your sentence? If exactly one can, you wrote a procedure in disguise.
3. **Self-test opacity on derivability** — the amplifier that turns breadth into a coin toss. Solvers wrote 30–75 of their own tests, went green, and submitted confident wrong answers, because a self-test encodes the same reading that produced the code. Prize the promises the solver would **never think to test** and can only check against its own reading of the spec.
4. **Lifecycle / call-position correctness** — which of two convergent write paths, before-vs-after validation, write-time vs read-time recompute, inside-vs-outside a transaction. Gold's most reliable structural lever — but it bites **only when the wrong site cannot produce the observable** (task 6's purest lifecycle lever caught nobody, because a hand-rolled wrong site still answered). The discriminator is *"is there an input the wrong site cannot answer,"* not *"is there a lifecycle fact."*
5. **Populated counter-halves.** Every `only / never / nobody-else / really-changed` qualifier and every absence assertion carries a positive case in the **same test body**, so the promise is red-at-base for *behaviour*, not shape. Without it, an assertion that nothing happened is satisfied by an implementation that does nothing, a refuse-everything guard passes a refusal test, and a shadowed route is indistinguishable from an absent one by status code alone. Sibling rule (cost three gold tasks): when a test asserts a 4xx, send a body valid in every respect except the one under test.

---

## 5. The canonical-substrate verdict

**Never place load-bearing difficulty on a canonical, memorised substrate.** A 2026 frontier agent reconstructs the one canonical semantics from its weights by reflex, so the full statement Sand's fairness rule *requires* turns the task into transcription. This is unanimous and cross-platform (task 6 7/8; keyset pagination 6/6 unprompted; meadowlark's D1–D5). The reflex is reachable from **priors**, not adjacent code — the scoping error that killed meadowlark.

The **only** canonical-adjacent survivor is a genuinely **bespoke twist** no well-known library implements (greenroom's per-room turnaround-as-footprint) **and** that the instruction cannot state without handing over the shape — and even then it is **one promise among ~30, never the spine**, and it dies the instant a comment or a self-describing field name leaks it (G5).

Put load-bearing difficulty only in a **bespoke domain computation** with a derivation step that survives full disclosure.

---

## 6. The calibration-faithful probe

The old one-shot "fix this module" probe **over-rated difficulty** by denying the agent everything calibration grants. Difficulty that exists only under snippet-isolation dissolves the moment the agent can drive the real app.

**Environment (match calibration exactly):** the full base/broken app booted; the instruction as you will publish it; `broken.png`/`target.png` at their paths; browser automation; the agent free to write/run its own tests and iterate to a self-declared done. Withhold only the held-out suite and the reference patch — grade blind.

**Solvers:** ≥3 fresh independent sessions; prefer 5 for a rate reading. Each runs to its own completion, not a fixed edit count.

**Two questions, two bars:**
1. **SHAPE** (pre-build, on instruction + broken app only): ask for the diff each would write. Require **≥2 of 3 wrong**. Convergence on the correct shape ⇒ reflex-reachable (G1/G4); fix or re-domain now.
2. **RATE** (dress rehearsal, once base + reference + held-out suite exist): let each solver iterate to done against the real app, grade its final state blind. **Pass bar: ≤1 of 3 (≤2 of 5) completes the full contract.** ≥2/3 (≥3/5) ⇒ too easy, rebuild.

**Dispersion gate:** failing solvers must miss **different** facets. All failing on one clause = illegitimate (task 12); fix the clause and re-probe, never ship as "hard."

**Discipline:** pre-register the predicted rate **and** the mechanism you expect to fail solvers before you look — a right rate with the wrong mechanism (task 9) is not a confirmation. Run the whole probe before spending a life; the claim timer pauses during verification, so this is free.

---

## 7. Fake difficulty — the kill list

1. A CSS/layout defect as the load-bearing trap — `target.png` adjudicates it free.
2. More defects. Three one-line bugs is one-line difficulty three times; Sand rejects bolt-ons.
3. A bigger patch or more files. No line floor; "a small patch can still be a hard task."
4. A vague instruction — unfair *and* ineffective (task 7 disclosed more than the 7/8 task 6 and solved 1/5).
5. Hiding where the defect is. Only the narrow form survives: never name the magnitude of a constant.
6. Obscure/minified/nested code — labour, not difficulty. Solvers always finished.
7. Framework config and documented knobs (CORS, proxy, ports, env, rate-limit, pagination) — canonical; nine rounds produced 7/8.
8. More F2P tests over the same decision — the two too-easy gold extremes had the highest redundancy ratios.
9. Brittle assertions (exact pixels, copy, DOM nesting) — fails correct solutions and the determinism gate.
10. Guessing an invisible convention — task 12's 0/5-and-0/8 failure.
11. A rare library API — a lookup, timed.
12. A long instruction of transcription clauses — numerical ≠ derived.
13. A framework-reflex trap as the spine — task 3's flagship caught 0/4. One promise, never the plan.
14. Planting wrong prior art to be copied — retired as a design driver.
15. A defect the agent cannot reach — unfair; returns on failure-legitimacy.
16. Inheriting a broken test suite — in Sand the app is yours, so a red suite is your own defect.

---

## 8. Grading that holds

- **L: one rule, several call sites; the symptom names one.** In Sand the natural triple: the API that answers the user's question, a second API reporting the same state, and the page that draws it. Require both write paths corrected in one test.
- **Every F2P must be red at base for its own reason.** Build **three** references — base, reference, and the *collapsed fix* (the smallest edit that silences the loudest symptom). Any F2P that survives the collapsed fix is grading the symptom; cut or re-anchor it.
- **One mutant per graded decision;** a decision with no mutant is unsound. A mutant models **the reflex** an agent would ship, not a broken program. Group F2P by the decision each grades and let the groups name the mutants.
- **Never assert an invariant between two fields of the same response** (tidewater's `total === pricePerSeat × count` passed the exact bug). Anchor to a second endpoint or assert a set of cases whose correct values differ, so no single constant satisfies them.
- **Grade derived state by reading it back, never by recomputing it** — React recomputes on render, so the read-time reflex is invisible on the demo path.
- **Determinism is a gate.** One page load per test, click through state; `domcontentloaded`, never `networkidle` (outbound DNS is unresolvable locally and stalls 30 s); assert relations not pixels; fixed seed; no clock, no animation, no unspecified tie-break. **Three runs a side, identical result sets — not identical counts.**
- **No test satisfiable by a hardcode.** Name the smallest literal that satisfies each test. Confirm `source_patch.diff` touches nothing the grader trusts — no `tests/`, no `playwright.config.js`, no `seed_fixtures.js`, no package scripts.

---

## 9. Feasibility and when to re-domain

Passable tasks are **rare**, and the binding constraint is **substrate, not craft**. Gold judged its repository "exhausted for difficulty under full statement" after twelve tasks, and a re-scout ran 31 candidate traps through the two filters and shortlisted **zero**. The productive families — bucketing, apportionment, stated procedures, local-calendar/half-open, fan-out, state transitions, pagination — are consumed, and G4 disqualifies most of them retroactively as never safe.

Sand's advantage: **you author the app**, so each new app is a fresh substrate — *write a new app, not a new bug*. But the exhaustion arc recurs per app, and every canonical domain is pre-burned across all apps at once, so re-domaining does not reset the canonical ban.

**Operating expectation:** high candidate mortality (most ideas die at G1 or G4), most of the work in screening and probing before any build, and a standing bias toward **re-domaining (a new app) over re-hardening (a new bug on a spent substrate)**. The 3–5 solver probe is the cheap instrument that kills doomed ideas before they cost a build or a life.

---

## 10. Pre-submit checklist

1. Reflex path written down; wrong shape on it; correct shape **not** in the model's priors (G1, G4).
2. First self-run against the wrong impl is plausible and non-derivable (G2).
3. Contract table complete; every graded reading is the cheapest one (G3).
4. Source leaks nothing — no naming field, comment, adjacent helper, matching magnitude, or copied prior art (G5).
5. Demo scenario hides the discriminating case from `target.png` (G6).
6. Three-to-five-solver probe: ≥2/3 wrong on shape, ≤1/3 (≤2/5) complete on rate, failures dispersed (G7, §6).
7. Three references built; collapsed fix leaves most F2P red (§8).
8. One mutant per decision, each the reflex; every F2P killed by at least one (§8).
9. Determinism: three runs a side, identical result sets (§8).
10. `nop=0`, `oracle=1`; no test satisfiable by a hardcode; patch touches only app code (§8).
11. Difficulty is conjunction on a bespoke computation — not layout, not config, not a canonical footgun (§4, §5, §7).