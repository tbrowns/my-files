const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');

const FRONTEND = process.env.FRONTEND_URL || 'http://localhost:3000';
const BACKEND = process.env.BACKEND_URL || 'http://localhost:5000';
const ARTIFACTS = process.env.ARTIFACTS_DIR || '/logs/artifacts';
try { fs.mkdirSync(ARTIFACTS, { recursive: true }); } catch (e) { void e; }

async function snap(page, name) {
  try { if (page && !page.isClosed()) await page.screenshot({ path: path.join(ARTIFACTS, name), fullPage: true }); }
  catch (e) { void e; }
}

// Every test starts from the same seed. The desk keeps its tickets in memory,
// so the harness resets it between checks through a dev-only hook.
test.beforeEach(async ({ request }) => {
  await request.post(`${BACKEND}/api/_test/reset`, { failOnStatusCode: false });
});

const H = {
  get: async (request, p, headers = {}) => {
    const r = await request.get(`${BACKEND}${p}`, { headers, failOnStatusCode: false });
    return { status: r.status(), body: await r.json().catch(() => ({})) };
  },
  post: async (request, p, data = {}, headers = {}) => {
    const r = await request.post(`${BACKEND}${p}`, { data, headers, failOnStatusCode: false });
    return { status: r.status(), body: await r.json().catch(() => ({})) };
  },
};
const asAgent = (id) => ({ 'X-Actor-Id': id, 'X-Actor-Role': 'agent' });
const asAdmin = () => ({ 'X-Actor-Id': 'a_admin', 'X-Actor-Role': 'admin' });
const asRequester = (id) => ({ 'X-Actor-Id': id, 'X-Actor-Role': 'requester' });

// ===========================================================================
//  [P2P] what the desk already gets right (green on both builds)
// ===========================================================================

test('[P2P] the desk answers', async ({ request }) => {
  const r = await H.get(request, '/api/health');
  expect(r.status).toBe(200);
  expect(r.body.ok).toBe(true);
});

test('[P2P] a single ticket reads back with its fields', async ({ request }) => {
  const r = await H.get(request, '/api/tickets/t_502');
  expect(r.status).toBe(200);
  expect(r.body.ticket.subject).toBe('Invoice double-charged');
  expect(r.body.ticket.status).toBe('in_progress');
  expect(r.body.ticket.priority).toBe('high');
});

test('[P2P] the queue lists the open work', async ({ request }) => {
  const r = await H.get(request, '/api/tickets');
  expect(r.status).toBe(200);
  const ids = r.body.tickets.map((t) => t.id);
  expect(ids).toContain('t_501');
  expect(ids).toContain('t_502');
  expect(ids).toContain('t_506');
});

test('[P2P] a public comment is appended to a ticket', async ({ request }) => {
  const before = (await H.get(request, '/api/tickets/t_502')).body.ticket.publicComments;
  const r = await H.post(request, '/api/tickets/t_502/comments', { body: 'Following up' }, asAgent('a_rez'));
  expect([200, 201]).toContain(r.status);
  const after = (await H.get(request, '/api/tickets/t_502')).body.ticket.publicComments;
  expect(after).toBe(before + 1);
});

// Assigning a RESOLVED ticket reassigns its owner but must not resurrect it to
// in_progress. True on both the base build (which never advances status) and a
// correct fix; a fix that advances status unconditionally regresses it.
test('[P2P] assigning a resolved ticket does not reopen it', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_503/assign', { assignee: 'a_rez' });
  expect(r.body.ticket.assignee).toBe('a_rez');
  expect(r.body.ticket.status).toBe('resolved');
  expect(r.body.ticket.resolution).not.toBeNull();
});

// ===========================================================================
//  [F2P][D1] the working queue
// ===========================================================================

test('[F2P][D1] closed tickets are hidden from the default queue', async ({ request }) => {
  const ids = (await H.get(request, '/api/tickets')).body.tickets.map((t) => t.id);
  expect(ids).not.toContain('t_505');
});

test('[F2P][D1] the queue is ordered most pressing first', async ({ request }) => {
  const ids = (await H.get(request, '/api/tickets')).body.tickets.map((t) => t.id);
  // urgent t_501 must sort ahead of the older but lower-priority high t_506
  expect(ids.indexOf('t_501')).toBeGreaterThanOrEqual(0);
  expect(ids.indexOf('t_506')).toBeGreaterThanOrEqual(0);
  expect(ids.indexOf('t_501')).toBeLessThan(ids.indexOf('t_506'));
});

test('[F2P][D1] an unknown status filter is a bad request', async ({ request }) => {
  const r = await H.get(request, '/api/tickets?status=frozen');
  expect(r.status).toBe(400);
});

test('[F2P][D1] a merged ticket is dropped from the queue even when closed are included', async ({ request }) => {
  await H.post(request, '/api/tickets/t_504/merge', { into: 't_502' });
  const ids = (await H.get(request, '/api/tickets?includeClosed=true')).body.tickets.map((t) => t.id);
  expect(ids).not.toContain('t_504');
  expect(ids).toContain('t_505');
});

// ===========================================================================
//  [F2P][D2] priority and the response clock
// ===========================================================================

test('[F2P][D2] a created ticket answers 201', async ({ request }) => {
  const r = await H.post(request, '/api/tickets', { subject: 'Login loops', requester: 'r_new', category: 'bug' });
  expect(r.status).toBe(201);
});

test('[F2P][D2] the category fixes the priority, not the caller', async ({ request }) => {
  const r = await H.post(request, '/api/tickets', { subject: 'Site down', requester: 'r_new', category: 'outage', priority: 'low' });
  expect(r.body.ticket.priority).toBe('urgent');
});

test('[F2P][D2] the breach clock is the priority', async ({ request }) => {
  // t_501 is urgent and 3h old; its 2h promise has blown, so it is breaching
  const t = (await H.get(request, '/api/tickets/t_501')).body.ticket;
  expect(t.breaching).toBe(true);
});

// ===========================================================================
//  [F2P][D3] assignment
// ===========================================================================

test('[F2P][D3] assigning an open ticket starts the work', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_504/assign', { assignee: 'a_rez' });
  expect(r.body.ticket.status).toBe('in_progress');
});

test('[F2P][D3] re-assigning to the same agent changes nothing and pings nobody', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_502/assign', { assignee: 'a_rez' });
  expect(r.body.changed).toBe(false);
  const notes = (await H.get(request, '/api/notifications')).body.notifications;
  expect(notes.length).toBe(0);
});

test('[F2P][D3] an admin cannot be an assignee', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_504/assign', { assignee: 'a_admin' });
  expect(r.status).toBe(400);
});

test('[F2P][D3] a closed ticket cannot be assigned', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_505/assign', { assignee: 'a_rez' });
  expect(r.status).toBe(409);
});

// ===========================================================================
//  [F2P][D4] comments
// ===========================================================================

test('[F2P][D4] a public reply reopens a resolved ticket and clears its resolution', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_503/comments', { body: 'still broken', public: true }, asRequester('r_fen'));
  expect(r.body.ticket.status).toBe('open');
  expect(r.body.ticket.resolution).toBeNull();
});

test('[F2P][D4] a private note does not reopen a resolved ticket', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_503/comments', { body: 'internal note', public: false }, asAgent('a_lin'));
  expect(r.body.ticket.status).toBe('resolved');
});

test('[F2P][D4] a requester cannot comment on a ticket that is not theirs', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_502/comments', { body: 'me too' }, asRequester('r_fen'));
  expect(r.status).toBe(403);
});

// ===========================================================================
//  [F2P][D5] resolving
// ===========================================================================

test('[F2P][D5] only the assignee or an admin may resolve', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_501/resolve', { resolution: 'done' }, asAgent('a_lin'));
  expect(r.status).toBe(403);
});

test('[F2P][D5] resolving requires a resolution note', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_502/resolve', {}, asAgent('a_rez'));
  expect(r.status).toBe(400);
});

test('[F2P][D5] a closed ticket cannot be resolved', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_505/resolve', { resolution: 'x' }, asAdmin());
  expect(r.status).toBe(409);
});

test('[F2P][D5] an already-resolved ticket cannot be resolved again', async ({ request }) => {
  const first = await H.post(request, '/api/tickets/t_502/resolve', { resolution: 'fixed' }, asAgent('a_rez'));
  expect(first.status).toBe(200);
  const n1 = (await H.get(request, '/api/notifications')).body.notifications.length;
  const again = await H.post(request, '/api/tickets/t_502/resolve', { resolution: 'again' }, asAgent('a_rez'));
  expect(again.status).toBe(409);
  const n2 = (await H.get(request, '/api/notifications')).body.notifications.length;
  expect(n2).toBe(n1);
});

// ===========================================================================
//  [F2P][D6] reopening
// ===========================================================================

test('[F2P][D6] reopen returns a ticket to open and clears the resolution', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_503/reopen', {}, asAdmin());
  expect(r.body.ticket.status).toBe('open');
  expect(r.body.ticket.resolution).toBeNull();
});

test('[F2P][D6] a requester cannot reopen a ticket that is not theirs', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_503/reopen', {}, asRequester('r_gwen'));
  expect(r.status).toBe(403);
});

test('[F2P][D6] reopening an unassigned ticket pings nobody', async ({ request }) => {
  await H.post(request, '/api/tickets/t_501/resolve', { resolution: 'transient outage' }, asAdmin());
  const r = await H.post(request, '/api/tickets/t_501/reopen', {}, asAdmin());
  expect(r.body.ticket.status).toBe('open');
  const notes = (await H.get(request, '/api/notifications')).body.notifications;
  // the ticket had no assignee, so there is nobody to tell -- no empty-recipient note
  expect(notes.some((n) => !n.to)).toBe(false);
});

// ===========================================================================
//  [F2P][D7] escalation
// ===========================================================================

test('[F2P][D7] escalating hands the ticket to the team lead and pings them', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_501/escalate', {});
  expect(r.body.ticket.assignee).toBe('a_mara');
  const notes = (await H.get(request, '/api/notifications')).body.notifications;
  expect(notes.some((n) => n.to === 'a_mara')).toBe(true);
});

test('[F2P][D7] escalating an open ticket also starts the work', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_504/escalate', {});
  expect(r.body.ticket.status).toBe('in_progress');
});

// ===========================================================================
//  [F2P][D8] merging
// ===========================================================================

test('[F2P][D8] a ticket cannot be merged into a closed ticket', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_502/merge', { into: 't_505' });
  expect(r.status).toBe(409);
});

test('[F2P][D8] a ticket cannot be merged into itself', async ({ request }) => {
  const r = await H.post(request, '/api/tickets/t_502/merge', { into: 't_502' });
  expect(r.status).toBe(400);
});

test('[F2P][D8] a merged ticket is gone for good', async ({ request }) => {
  await H.post(request, '/api/tickets/t_504/merge', { into: 't_502' });
  const re = await H.post(request, '/api/tickets/t_504/merge', { into: 't_503' });
  expect(re.status).toBe(404);
  const act = await H.post(request, '/api/tickets/t_504/comments', { body: 'x' }, asAgent('a_rez'));
  expect(act.status).toBe(404);
});

// ===========================================================================
//  [F2P][D1] / [P2P] the page draws the queue
// ===========================================================================

test('[P2P] the queue page renders the open tickets', async ({ page }) => {
  try {
    await page.goto(FRONTEND, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-ticket="t_501"]', { timeout: 20000 });
    await expect(page.locator('[data-ticket="t_502"]')).toHaveCount(1);
  } finally {
    await snap(page, 'queue.png');
  }
});

test('[F2P][D1] the page does not show closed tickets in the default queue', async ({ page }) => {
  try {
    await page.goto(FRONTEND, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('[data-ticket="t_501"]', { timeout: 20000 });
    await expect(page.locator('[data-ticket="t_505"]')).toHaveCount(0);
  } finally {
    await snap(page, 'queue_no_closed.png');
  }
});
