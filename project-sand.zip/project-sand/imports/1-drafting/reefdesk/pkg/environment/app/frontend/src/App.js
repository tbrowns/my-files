import React, { useEffect, useState, useCallback } from 'react';

const PRIORITY_LABEL = { urgent: 'Urgent', high: 'High', normal: 'Normal', low: 'Low' };
const STATUS_LABEL = { open: 'Open', in_progress: 'In progress', resolved: 'Resolved', closed: 'Closed' };

function Badge({ kind, value }) {
  const label = kind === 'priority' ? (PRIORITY_LABEL[value] || value) : (STATUS_LABEL[value] || value);
  return <span className={`badge badge-${kind} ${kind}-${value}`}>{label}</span>;
}

export default function App() {
  const [tickets, setTickets] = useState([]);
  const [includeClosed, setIncludeClosed] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    const q = includeClosed ? '?includeClosed=true' : '';
    fetch(`/api/tickets${q}`)
      .then((r) => r.json())
      .then((d) => { setTickets(d.tickets || []); setError(null); })
      .catch((e) => setError(String(e)))
      .finally(() => setLoading(false));
  }, [includeClosed]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="mark" aria-hidden="true">◐</span>
          <div>
            <h1>Tidepool Support Desk</h1>
            <p className="sub">Live queue — most pressing first</p>
          </div>
        </div>
        <label className="toggle">
          <input type="checkbox" checked={includeClosed} onChange={(e) => setIncludeClosed(e.target.checked)} />
          Show closed
        </label>
      </header>

      {error && <div className="notice error">Could not load the queue: {error}</div>}

      <main data-queue className="queue">
        <div className="queue-head">
          <span className="col-priority">Priority</span>
          <span className="col-subject">Ticket</span>
          <span className="col-status">Status</span>
          <span className="col-assignee">Owner</span>
          <span className="col-sla">SLA</span>
        </div>
        {loading && tickets.length === 0 ? (
          <div className="empty">Loading…</div>
        ) : tickets.length === 0 ? (
          <div className="empty">Nothing in the queue.</div>
        ) : (
          tickets.map((t) => (
            <div className="row" data-ticket={t.id} data-priority={t.priority} data-status={t.status} key={t.id}>
              <span className="col-priority"><Badge kind="priority" value={t.priority} /></span>
              <span className="col-subject">
                <span className="subject">{t.subject}</span>
                <span className="meta">#{t.id.replace('t_', '')} · {t.category}{t.breaching ? ' · ' : ''}{t.breaching && <span className="breach">breaching</span>}</span>
              </span>
              <span className="col-status"><Badge kind="status" value={t.status} /></span>
              <span className="col-assignee">{t.assignee ? t.assignee.replace('a_', '') : <span className="muted">unassigned</span>}</span>
              <span className="col-sla">{t.slaHours}h</span>
            </div>
          ))
        )}
      </main>
    </div>
  );
}
