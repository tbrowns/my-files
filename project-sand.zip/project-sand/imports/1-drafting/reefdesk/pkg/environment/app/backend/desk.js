// ===========================================================================
//  Tidepool Support Desk -- the ticket desk
// ===========================================================================
// A support ticket moving through its life: open, in progress, resolved,
// closed, with reopen, escalation and merge. The endpoints all work; the desk
// just handles a lot of the policy the naive way.

// A new ticket's priority. Right now we take whatever the caller sends, or
// fall back to normal.
const DEFAULT_PRIORITY = 'normal';

// How long before a ticket is "breaching" -- one day, across the board.
const SLA_HOURS_FLAT = 24;

// Escalation ladder. Escalating lifts a ticket one rung.
const PRIORITY_LADDER = ['low', 'normal', 'high', 'urgent'];
const PRIORITY_RANK = { urgent: 0, high: 1, normal: 2, low: 3 };

// --- the people ----------------------------------------------------------
const AGENTS = [
  { id: 'a_rez', name: 'Rez Okafor', role: 'agent', team: 'frontline' },
  { id: 'a_lin', name: 'Lin Sato', role: 'agent', team: 'frontline' },
  { id: 'a_mara', name: 'Mara Voss', role: 'lead', team: 'frontline' },
  { id: 'a_admin', name: 'Desk Admin', role: 'admin', team: 'ops' },
];
const LEAD_OF = { frontline: 'a_mara' };
const agentById = (id) => AGENTS.find((x) => x.id === id) || null;

// --- today's tickets (fixed seed; times are ISO on a fixed clock) ---------
const NOW = Date.parse('2026-04-14T12:00:00Z');
let seq = 100;

function seed() {
  return [
    { id: 't_501', subject: 'Checkout is down for everyone', category: 'outage', requester: 'r_dana',
      assignee: null, status: 'open', createdAt: '2026-04-14T09:00:00Z', resolution: null,
      priority: 'urgent', comments: [], mergedInto: null, escalated: false },
    { id: 't_502', subject: 'Invoice double-charged', category: 'billing', requester: 'r_elias',
      assignee: 'a_rez', status: 'in_progress', createdAt: '2026-04-14T07:30:00Z', resolution: null,
      priority: 'high', comments: [{ id: 'c1', author: 'a_rez', body: 'Looking into it', public: true, at: '2026-04-14T08:00:00Z' }],
      mergedInto: null, escalated: false },
    { id: 't_503', subject: 'Cannot change my email', category: 'account', requester: 'r_fen',
      assignee: 'a_lin', status: 'resolved', createdAt: '2026-04-13T15:00:00Z',
      resolution: 'Sent reset link; confirmed working', priority: 'normal', comments: [], mergedInto: null, escalated: false },
    { id: 't_504', subject: 'How do I export my data?', category: 'howto', requester: 'r_gwen',
      assignee: null, status: 'open', createdAt: '2026-04-14T11:30:00Z', resolution: null,
      priority: 'low', comments: [], mergedInto: null, escalated: false },
    { id: 't_505', subject: 'Feature idea: dark mode', category: 'feedback', requester: 'r_hoda',
      assignee: 'a_lin', status: 'closed', createdAt: '2026-04-10T10:00:00Z',
      resolution: 'Logged to roadmap', priority: 'low', comments: [], mergedInto: null, escalated: false },
    { id: 't_506', subject: 'API returns 500 on bulk import', category: 'bug', requester: 'r_ivo',
      assignee: 'a_lin', status: 'in_progress', createdAt: '2026-04-13T06:00:00Z', resolution: null,
      priority: 'high', comments: [], mergedInto: null, escalated: false },
  ];
}

let TICKETS = seed();
const reset = () => { TICKETS = seed(); seq = 100; };
const ticketById = (id) => TICKETS.find((t) => t.id === id) || null;

// --- derived reads --------------------------------------------------------

// A ticket is breaching once it has been open longer than the SLA and isn't
// finished yet.
function isBreaching(t) {
  if (t.status === 'resolved' || t.status === 'closed') return false;
  const due = Date.parse(t.createdAt) + SLA_HOURS_FLAT * 3600 * 1000;
  return NOW > due;
}

function view(t) {
  return {
    id: t.id, subject: t.subject, category: t.category, requester: t.requester,
    assignee: t.assignee, status: t.status, priority: t.priority,
    createdAt: t.createdAt, resolution: t.resolution, escalated: t.escalated,
    mergedInto: t.mergedInto, breaching: isBreaching(t),
    publicComments: t.comments.filter((c) => c.public).length,
    slaHours: SLA_HOURS_FLAT,
  };
}

// --- the queue (GET /api/tickets) ----------------------------------------
function listTickets({ status, includeClosed }) {
  let out = TICKETS.slice();
  if (status !== undefined) out = out.filter((t) => t.status === status);
  out = out.sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt));
  return { code: 200, tickets: out.map(view) };
}

// --- notifications (recorded, so we can show who was told what) -----------
let NOTES = [];
const notify = (to, event, ticket) => { NOTES.push({ to, event, ticket }); };
const notesReset = () => { NOTES = []; };

// --- create (POST /api/tickets) ------------------------------------------
function createTicket(body) {
  const b = body || {};
  if (!b.subject || !b.requester || !b.category) return { code: 400, error: 'subject, requester and category are required' };
  const t = {
    id: 't_' + (++seq), subject: String(b.subject), category: b.category, requester: String(b.requester),
    assignee: null, status: 'open', createdAt: '2026-04-14T12:00:00Z', resolution: null,
    priority: b.priority || DEFAULT_PRIORITY, comments: [], mergedInto: null, escalated: false,
  };
  TICKETS.push(t);
  return { code: 200, ticket: view(t) };
}

// --- assign (POST /api/tickets/:id/assign) -------------------------------
function assign(id, body) {
  const t = ticketById(id);
  if (!t) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  const agent = agentById(b.assignee);
  if (!agent) return { code: 400, error: 'no such agent' };
  t.assignee = agent.id;
  notify(agent.id, 'assigned', t.id);
  return { code: 200, ticket: view(t), changed: true };
}

// --- comment (POST /api/tickets/:id/comments) ----------------------------
function comment(id, body, actor) {
  const t = ticketById(id);
  if (!t) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  if (!b.body) return { code: 400, error: 'a comment body is required' };
  const isPublic = b.public !== false;
  const who = actor || {};
  const c = { id: 'c_' + (++seq), author: who.id || 'system', body: String(b.body), public: isPublic, at: '2026-04-14T12:00:00Z' };
  t.comments.push(c);
  if (t.status === 'resolved') t.status = 'open';
  notify(t.requester, 'public_comment', t.id);
  return { code: 201, ticket: view(t), comment: { id: c.id, public: c.public } };
}

// --- resolve (POST /api/tickets/:id/resolve) -----------------------------
function resolve(id, body, actor) {
  const t = ticketById(id);
  if (!t) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  t.status = 'resolved';
  t.resolution = b.resolution ? String(b.resolution) : null;
  notify(t.requester, 'resolved', t.id);
  return { code: 200, ticket: view(t) };
}

// --- reopen (POST /api/tickets/:id/reopen) -------------------------------
function reopen(id, actor) {
  const t = ticketById(id);
  if (!t) return { code: 404, error: 'no such ticket' };
  if (t.status !== 'resolved') return { code: 409, error: 'only a resolved ticket can be reopened' };
  t.status = 'in_progress';
  notify(t.assignee, 'reopened', t.id);
  return { code: 200, ticket: view(t) };
}

// --- escalate (POST /api/tickets/:id/escalate) ---------------------------
function escalate(id) {
  const t = ticketById(id);
  if (!t) return { code: 404, error: 'no such ticket' };
  const rung = PRIORITY_LADDER.indexOf(t.priority);
  t.priority = PRIORITY_LADDER[Math.min(rung + 1, PRIORITY_LADDER.length - 1)];
  t.escalated = true;
  return { code: 200, ticket: view(t) };
}

// --- merge (POST /api/tickets/:id/merge) ---------------------------------
function merge(id, body) {
  const t = ticketById(id);
  if (!t) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  const into = ticketById(b.into);
  if (!into) return { code: 400, error: 'no such target ticket' };
  for (const c of t.comments) into.comments.push(c);
  t.status = 'closed';
  t.mergedInto = into.id;
  return { code: 200, ticket: view(t), into: view(into) };
}

module.exports = {
  PRIORITY_LADDER, AGENTS, agentById,
  NOW, reset, notesReset, ticketById, view, isBreaching,
  listTickets, createTicket, assign, comment, resolve, reopen, escalate, merge,
  _notes: () => NOTES, TICKETS: () => TICKETS,
};
