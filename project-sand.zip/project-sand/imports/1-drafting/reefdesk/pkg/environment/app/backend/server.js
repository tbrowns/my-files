const express = require('express');
const cors = require('cors');
const desk = require('./desk');

const app = express();
app.use(cors());
app.use(express.json());

// The acting user rides on request headers; the desk decides what they may do.
function actorOf(req) {
  const id = req.header('X-Actor-Id');
  const role = req.header('X-Actor-Role');
  return { id: id || null, role: role || null };
}

function send(res, result) {
  const { code, ...rest } = result;
  return res.status(code || 200).json(rest);
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'tidepool-support-desk' }));

app.get('/api/tickets', (req, res) => {
  const status = req.query.status === undefined ? undefined : String(req.query.status);
  const includeClosed = req.query.includeClosed === 'true' || req.query.includeClosed === '1';
  send(res, desk.listTickets({ status, includeClosed }));
});

app.get('/api/tickets/:id', (req, res) => {
  const t = desk.ticketById(req.params.id);
  if (!t) return res.status(404).json({ error: 'no such ticket' });
  return res.json({ ticket: desk.view(t) });
});

app.post('/api/tickets', (req, res) => send(res, desk.createTicket(req.body)));

app.post('/api/tickets/:id/assign', (req, res) => send(res, desk.assign(req.params.id, req.body)));

app.post('/api/tickets/:id/comments', (req, res) => send(res, desk.comment(req.params.id, req.body, actorOf(req))));

app.post('/api/tickets/:id/resolve', (req, res) => send(res, desk.resolve(req.params.id, req.body, actorOf(req))));

app.post('/api/tickets/:id/reopen', (req, res) => send(res, desk.reopen(req.params.id, actorOf(req))));

app.post('/api/tickets/:id/escalate', (req, res) => send(res, desk.escalate(req.params.id)));

app.post('/api/tickets/:id/merge', (req, res) => send(res, desk.merge(req.params.id, req.body)));

app.get('/api/notifications', (req, res) => res.json({ notifications: desk._notes() }));

// test harness hook: reset the desk to its seed between checks
app.post('/api/_test/reset', (req, res) => { desk.reset(); desk.notesReset(); res.json({ ok: true }); });

app.get('/', (req, res) => res.json({ service: 'tidepool-support-desk' }));

const PORT = process.env.PORT || 5000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`support desk api on :${PORT}`));
}
module.exports = app;
