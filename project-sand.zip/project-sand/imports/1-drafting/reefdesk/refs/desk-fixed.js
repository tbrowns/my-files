// ===========================================================================
//  Tidepool Support Desk -- the ticket desk and the rules it runs on
// ===========================================================================
// One behaviour: a support ticket moving through its life (open -> in progress
// -> resolved -> closed, with reopen and escalation). The rules below are the
// desk's own policy. They are not derivable from anything; they are what this
// desk decided, and every one of them decides an answer the API must return.

// --- the desk's fixed policy tables --------------------------------------

// A ticket's category fixes its starting priority. (Desk policy, not a guess.)
const CATEGORY_PRIORITY = {
  outage: 'urgent',
  billing: 'high',
  bug: 'high',
  account: 'normal',
  howto: 'low',
  feedback: 'low',
};

// Priority fixes the response-time promise, in hours.
const SLA_HOURS = { urgent: 2, high: 8, normal: 24, low: 72 };

// The escalation ladder. Escalating lifts a ticket one rung; urgent is the top.
const PRIORITY_LADDER = ['low', 'normal', 'high', 'urgent'];

// Sort order for the queue: most pressing first, then oldest first.
const PRIORITY_RANK = { urgent: 0, high: 1, normal: 2, low: 3 };

// The only status moves the desk allows. Anything else is refused.
const ALLOWED = {
  open: ['in_progress', 'resolved'],
  in_progress: ['resolved', 'open'],
  resolved: ['open', 'closed'],
  closed: [],
};

// --- the people ----------------------------------------------------------
const AGENTS = [
  { id: 'a_rez', name: 'Rez Okafor', role: 'agent', team: 'frontline' },
  { id: 'a_lin', name: 'Lin Sato', role: 'agent', team: 'frontline' },
  { id: 'a_mara', name: 'Mara Voss', role: 'lead', team: 'frontline' },
  { id: 'a_admin', name: 'Desk Admin', role: 'admin', team: 'ops' },
];
const LEAD_OF = { frontline: 'a_mara' };
const agentById = (id) => AGENTS.find((x) => x.id === id) || null;

// --- today's tickets (fixed seed; times are ISO on a fixed clock) ---------
const NOW = Date.parse('2026-04-14T12:00:00Z'); // the desk's "now" for SLA math
let seq = 100;

function seed() {
  return [
    // open, urgent, breaching (created 3h ago, SLA 2h)
    { id: 't_501', subject: 'Checkout is down for everyone', category: 'outage', requester: 'r_dana',
      assignee: null, status: 'open', createdAt: '2026-04-14T09:00:00Z', resolution: null,
      priority: 'urgent', comments: [], mergedInto: null, escalated: false },
    // in_progress, high, assigned to Rez
    { id: 't_502', subject: 'Invoice double-charged', category: 'billing', requester: 'r_elias',
      assignee: 'a_rez', status: 'in_progress', createdAt: '2026-04-14T07:30:00Z', resolution: null,
      priority: 'high', comments: [{ id: 'c1', author: 'a_rez', body: 'Looking into it', public: true, at: '2026-04-14T08:00:00Z' }],
      mergedInto: null, escalated: false },
    // resolved, normal, assigned to Lin (reopenable by requester)
    { id: 't_503', subject: 'Cannot change my email', category: 'account', requester: 'r_fen',
      assignee: 'a_lin', status: 'resolved', createdAt: '2026-04-13T15:00:00Z',
      resolution: 'Sent reset link; confirmed working', priority: 'normal', comments: [], mergedInto: null, escalated: false },
    // low, open, unassigned, not breaching
    { id: 't_504', subject: 'How do I export my data?', category: 'howto', requester: 'r_gwen',
      assignee: null, status: 'open', createdAt: '2026-04-14T11:30:00Z', resolution: null,
      priority: 'low', comments: [], mergedInto: null, escalated: false },
    // closed (should be hidden from the default queue)
    { id: 't_505', subject: 'Feature idea: dark mode', category: 'feedback', requester: 'r_hoda',
      assignee: 'a_lin', status: 'closed', createdAt: '2026-04-10T10:00:00Z',
      resolution: 'Logged to roadmap', priority: 'low', comments: [], mergedInto: null, escalated: false },
    // high, in_progress, breaching (created 30h ago, SLA 8h), assigned to Lin
    { id: 't_506', subject: 'API returns 500 on bulk import', category: 'bug', requester: 'r_ivo',
      assignee: 'a_lin', status: 'in_progress', createdAt: '2026-04-13T06:00:00Z', resolution: null,
      priority: 'high', comments: [], mergedInto: null, escalated: false },
  ];
}

let TICKETS = seed();
const reset = () => { TICKETS = seed(); seq = 100; };
const ticketById = (id) => TICKETS.find((t) => t.id === id) || null;

// --- derived reads --------------------------------------------------------

// A ticket is breaching if its SLA has elapsed and it is not yet resolved or
// closed. SLA runs from the ORIGINAL createdAt and a reopen does not reset it.
function isBreaching(t) {
  if (t.status === 'resolved' || t.status === 'closed') return false;
  const due = Date.parse(t.createdAt) + SLA_HOURS[t.priority] * 3600 * 1000;
  return NOW > due;
}

function view(t) {
  return {
    id: t.id, subject: t.subject, category: t.category, requester: t.requester,
    assignee: t.assignee, status: t.status, priority: t.priority,
    createdAt: t.createdAt, resolution: t.resolution, escalated: t.escalated,
    mergedInto: t.mergedInto, breaching: isBreaching(t),
    publicComments: t.comments.filter((c) => c.public).length,
    slaHours: SLA_HOURS[t.priority],
  };
}

// --- the queue (GET /api/tickets) ----------------------------------------
// Closed tickets are hidden unless the caller asks for them. The queue is
// ordered most-pressing-first, then oldest-first. An unknown status filter is a
// bad request, not an empty queue.
function listTickets({ status, includeClosed }) {
  if (status !== undefined && !['open', 'in_progress', 'resolved', 'closed'].includes(status)) {
    return { error: 'unknown status', code: 400 };
  }
  let out = TICKETS.filter((t) => t.mergedInto === null);
  if (status !== undefined) out = out.filter((t) => t.status === status);
  else if (!includeClosed) out = out.filter((t) => t.status !== 'closed');
  out = out.slice().sort((a, b) =>
    PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority] ||
    Date.parse(a.createdAt) - Date.parse(b.createdAt));
  return { code: 200, tickets: out.map(view) };
}

// --- notifications (recorded, so tests can read who was told what) --------
let NOTES = [];
const notify = (to, event, ticket) => { if (to) NOTES.push({ to, event, ticket }); };
const notesReset = () => { NOTES = []; };

// --- create (POST /api/tickets) ------------------------------------------
// A new ticket opens with the priority its category fixes, unassigned. Created
// resources answer 201.
function createTicket(body) {
  const b = body || {};
  if (!b.subject || !b.requester || !b.category) return { code: 400, error: 'subject, requester and category are required' };
  if (!(b.category in CATEGORY_PRIORITY)) return { code: 400, error: 'unknown category' };
  const t = {
    id: 't_' + (++seq), subject: String(b.subject), category: b.category, requester: String(b.requester),
    assignee: null, status: 'open', createdAt: '2026-04-14T12:00:00Z', resolution: null,
    priority: CATEGORY_PRIORITY[b.category], comments: [], mergedInto: null, escalated: false,
  };
  TICKETS.push(t);
  return { code: 201, ticket: view(t) };
}

// --- assign (POST /api/tickets/:id/assign) -------------------------------
// Assigning an open ticket moves it to in_progress and notifies the new agent.
// Re-assigning to the same agent changes nothing and notifies nobody.
function assign(id, body) {
  const t = ticketById(id);
  if (!t || t.mergedInto) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  const agent = agentById(b.assignee);
  if (!agent || agent.role === 'admin') return { code: 400, error: 'assignee must be an agent or lead' };
  if (t.status === 'closed') return { code: 409, error: 'a closed ticket cannot be assigned' };
  if (t.assignee === agent.id) return { code: 200, ticket: view(t), changed: false };
  t.assignee = agent.id;
  if (t.status === 'open') t.status = 'in_progress';
  notify(agent.id, 'assigned', t.id);
  return { code: 200, ticket: view(t), changed: true };
}

// --- comment (POST /api/tickets/:id/comments) ----------------------------
// A public comment on a resolved ticket reopens it (to open) and notifies the
// requester; an internal comment never reopens and notifies nobody. The desk
// notifies the requester on a public comment only when one is really added.
function comment(id, body, actor) {
  const t = ticketById(id);
  if (!t || t.mergedInto) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  if (!b.body) return { code: 400, error: 'a comment body is required' };
  const isPublic = b.public !== false; // public unless explicitly false
  // a requester may only comment publicly on their own ticket
  const who = actor || {};
  if (who.role === 'requester' && (who.id !== t.requester || !isPublic)) {
    return { code: 403, error: 'requesters may only add public comments to their own ticket' };
  }
  const c = { id: 'c_' + (++seq), author: who.id || 'system', body: String(b.body), public: isPublic, at: '2026-04-14T12:00:00Z' };
  t.comments.push(c);
  if (isPublic && t.status === 'resolved') { t.status = 'open'; t.resolution = null; }
  if (isPublic) notify(t.requester, 'public_comment', t.id);
  return { code: 201, ticket: view(t), comment: { id: c.id, public: c.public } };
}

// --- resolve (POST /api/tickets/:id/resolve) -----------------------------
// Only the assignee or an admin may resolve, and a resolution note is required.
// Resolving notifies the requester.
function resolve(id, body, actor) {
  const t = ticketById(id);
  if (!t || t.mergedInto) return { code: 404, error: 'no such ticket' };
  const who = actor || {};
  if (!(who.id === t.assignee || who.role === 'admin')) return { code: 403, error: 'only the assignee or an admin may resolve' };
  if (!ALLOWED[t.status].includes('resolved')) return { code: 409, error: `cannot resolve from ${t.status}` };
  const b = body || {};
  if (!b.resolution) return { code: 400, error: 'a resolution note is required' };
  t.status = 'resolved';
  t.resolution = String(b.resolution);
  notify(t.requester, 'resolved', t.id);
  return { code: 200, ticket: view(t) };
}

// --- reopen (POST /api/tickets/:id/reopen) -------------------------------
// A resolved ticket reopens to OPEN (not in_progress) and clears its
// resolution. The requester may reopen their own within 7 days; an admin any
// time. Reopening notifies the agent who last worked it.
function reopen(id, actor) {
  const t = ticketById(id);
  if (!t || t.mergedInto) return { code: 404, error: 'no such ticket' };
  if (t.status !== 'resolved') return { code: 409, error: 'only a resolved ticket can be reopened' };
  const who = actor || {};
  const withinWindow = NOW - Date.parse(t.createdAt) <= 7 * 24 * 3600 * 1000;
  const may = who.role === 'admin' || (who.id === t.requester && withinWindow);
  if (!may) return { code: 403, error: 'only the requester (within 7 days) or an admin may reopen' };
  const lastAgent = t.assignee;
  t.status = 'open';
  t.resolution = null;
  notify(lastAgent, 'reopened', t.id);
  return { code: 200, ticket: view(t) };
}

// --- escalate (POST /api/tickets/:id/escalate) ---------------------------
// Escalating lifts the priority one rung (urgent is already the top and does
// not change), hands the ticket to the team's lead, and notifies the lead.
function escalate(id) {
  const t = ticketById(id);
  if (!t || t.mergedInto) return { code: 404, error: 'no such ticket' };
  if (t.status === 'closed') return { code: 409, error: 'a closed ticket cannot be escalated' };
  const rung = PRIORITY_LADDER.indexOf(t.priority);
  t.priority = PRIORITY_LADDER[Math.min(rung + 1, PRIORITY_LADDER.length - 1)];
  const lead = LEAD_OF['frontline'];
  t.assignee = lead;
  t.escalated = true;
  if (t.status === 'open') t.status = 'in_progress';
  notify(lead, 'escalated', t.id);
  return { code: 200, ticket: view(t) };
}

// --- merge (POST /api/tickets/:id/merge) ---------------------------------
// Merging this ticket into a target moves its public comments to the target,
// closes it, and records the link. A ticket cannot merge into itself or into a
// closed or already-merged ticket.
function merge(id, body) {
  const t = ticketById(id);
  if (!t || t.mergedInto) return { code: 404, error: 'no such ticket' };
  const b = body || {};
  const into = ticketById(b.into);
  if (!into || into.mergedInto) return { code: 400, error: 'no such target ticket' };
  if (into.id === t.id) return { code: 400, error: 'a ticket cannot merge into itself' };
  if (into.status === 'closed') return { code: 409, error: 'cannot merge into a closed ticket' };
  for (const c of t.comments) if (c.public) into.comments.push(c);
  t.status = 'closed';
  t.mergedInto = into.id;
  return { code: 200, ticket: view(t), into: view(into) };
}

module.exports = {
  CATEGORY_PRIORITY, SLA_HOURS, PRIORITY_LADDER, ALLOWED, AGENTS, agentById,
  NOW, reset, notesReset, ticketById, view, isBreaching,
  listTickets, createTicket, assign, comment, resolve, reopen, escalate, merge,
  _notes: () => NOTES, TICKETS: () => TICKETS,
};
