# 3. Input Files — The Evidence Package

[← Task types](02-task-types.md) · [Index](README.md) · Next: [Writing the prompt →](04-prompt.md)

---

Your input workspace is the file package the model receives: the datasets,
documents, and reports a real analyst in your domain could plausibly have been handed.

> **The test:** could a skilled analyst recover the answer without guessing?

> ### documents
> Pull real documents from the wild.
> PDFs, DOCX, and PPTX files should not have: a few words per page, oceans of white space, tables that are too clean.


---

## What a strong package contains

Not just "larger and messier." The messiness must be **realistic fragmentation the
analyst has to work through** — never random dirt — and it must never change the
correct answer once resolved.

### Scale
- **10 or more files** in the package.
- At least one table has **10,000+ rows**, enough that eyeballing fails.
- The recommendation requires **joining at least two tables**.

### Format variety
- At least **three distinct file formats**.
- At least **two files are substantial**, and not all the same type.

### Messiness that earns its place
- Signal is **fragmented across files**, so the model has to piece it together.
- **Timestamps are inconsistent** and must be reconciled.
- Data is **scattered** enough that the model has to seek around the environment to find what it needs.
- **Template files or historical reports** sit in the package as reference material to discover and use.

### Always true
- Files are **real and license-clean**, with source, date, and license recorded.
> ### ⛔ No complexity for its own sake
> A task is not harder because it has more files, rows, or formats. Every piece of
> material has to serve a realistic analytical purpose. Irrelevant files, duplicated
> information, arbitrary noise, and volume that only creates search burden count
> **against** fairness, not for difficulty. Reviewers read padding as clutter.

---

## The four workflow steps

### Step 1 — Choose your data route

| Route | What it means |
|---|---|
| **Starter Data Kit** | Review what a package includes, then claim one in the Stash registry. See below. |
| **I already have source data** | Run a five-condition eligibility check before you build the workspace. |
| **Study an example first** | Opens three examples picked by difficulty, with a way back to your task plan. |

Claiming and downloading happen in the **external Stash registry**. Nothing in the
handbook claims a package for you.

### Step 2 — Record your files

One row per counted file: package name, total files, load-bearing files, formats in
the package. Nothing is uploaded and no file contents are stored — only the text you
type is saved, in your browser.

### Step 3 — Resolve missing evidence

**Does the current package support the answer?**

- **Yes** → Stop. Do not add decorative files. **File count is not difficulty.**
- **No** →
  1. Identify exactly what is missing: a definition, a piece of evidence, or context.
  2. Find **one** authoritative source that supplies it, and add **only** that file.

**Common gaps worth filling:** definitions · historical context · methodology ·
policy constraints · targets · predictors · revisions · crosswalks

### Step 4 — Confirm the package

Work the 7-point checklist below.

---

## The package checklist (7 points)

The one authoritative test for the package. **A file count on its own is not readiness.**

- [ ] **Necessary files** — ten or more counted files, and removing any counted file breaks the answer.
- [ ] **Recoverable joins or relationships** — the files connect through keys or references an analyst can recover.
- [ ] **Sufficient signal** — the data supports the analysis the prompt actually requests.
- [ ] **Definitions and governing rules are supplied inside the package**, not assumed.
- [ ] **Reproducibility** — every figure in the golden output comes back out of the shipped workspace.
- [ ] **No padding** — no decorative or deletable files are counted.
- [ ] **No fabricated or corrupted complexity** — complications are authentic; nothing is padded, or broken on purpose.

**All 7 must be confirmed** before the input package is marked ready.

---

## Starter data kits

Every fellow gets **one** data package from the Stash. The packages are raw, real,
and unfinished on purpose: **they hand you a workspace, not a task.**

### What a package contains

Six to eight raw files: several CSVs, an `overview.xlsx`, and a
`data_dictionary.json` recording the **source URL, license, snapshot date, and every
transform applied**. Use the dictionary as your provenance note.

### What is already documented

- Source, publisher, and license for each file
- Provenance notes so the package is safe to ship
- A short description of what the data covers and does not cover

### What remains unfinished

Nothing is cleaned, joined, or reconciled for you, and **no task exists yet**. You
still choose the decision, write the prompt, design the trap, and usually add files.

### What you may still need to add

- Supplementary definitions, methodology, or policy context
- Additional files so the package clears the input rules above
- Realistic mess, distractors, and the traps your task depends on

### Claiming rules

| Rule | Detail |
|---|---|
| **One claim per fellow** | You hold one active claim at a time. A second request while your first claim is open is refused. |
| **An open claim implies a submission** | A submitted task is expected from you. |
| **Claiming is final** | The package you take leaves the pool until the inventory cycles. The choice **cannot be swapped**. |

> **Most fellows extend their package rather than shipping it as delivered.**
> Add a file when it creates real analytical depth, or when the final recommendation
> cannot be supported without it. Never add files to inflate the file count or to
> manufacture complexity.

**The Stash** is an external site used only to **browse and claim** data packages. It
is not a submission surface; you submit your finished task on Handshake.

---

## Sourcing rules

- **Scenario documents and derived files carry explicit provenance** stating what they are and how they were produced. *(Blocking)*
- A self-written memo is a **scenario document, not source data**, and it is recorded as such.
- All input files have clear provenance and are **permitted for use and redistribution** in the task.

---

## Readiness checks this stage owns

*(Readiness stage 1 "Policy" + stage 3 "Inputs" — 12 of the 51 checks. See [Readiness](09-readiness-and-submission.md).)*

**Policy — the numeric rules want your real count, not an estimate**

- [ ] A task ships with at least **10** input files.
- [ ] At least **4** of the shipped files are independently necessary: remove any one of them and the solution can no longer be reached.
- [ ] At least **2** of the inputs are substantial rather than token: long, dense files that take real work to read and reconcile.
- [ ] Optional **distractor files are allowed and encouraged**, but they never count toward the four independently necessary files.
- [ ] Scenario documents and derived files carry explicit provenance stating what they are and how they were produced.

**Inputs**

- [ ] Multiple files or sources create genuine analytical dependencies needed to reach the recommendation
- [ ] Input data contains realistic complexity or mess that must be handled correctly when relevant to the analysis
- [ ] All load-bearing definitions, rules, and facts are supplied in the workspace or are standard domain knowledge experts apply consistently
- [ ] Reaching the recommendation requires multiple substantive analytical steps, not a single lookup or trivial calculation
- [ ] The workspace is internally coherent: files, versions, identifiers, populations, dates, and supporting documentation can be reconciled
- [ ] The workspace is complex for analytical reasons, not because of irrelevant file volume or artificial clutter
- [ ] All input files have clear provenance and are permitted for use and redistribution in the task

---

> ⚠️ **Not captured in the source export.** The "Sourcing reference" section held four
> collapsed panels whose bodies were empty in the HTML snapshot:
> *Where to find real documents* · *When a supporting file earns its place* ·
> *Input file formats and the tells to avoid* · *Licensing and provenance in detail*.
> See [Reference → Gaps](10-reference.md#gaps-in-the-source-export).
