# `slate-harbor-equinox` — MARK task bundle (v2)

**Objective:** Forecasting & Predictive Modeling · **Domain:** Economics (public finance) ·
**Reasoning phase:** Analyze/Validate → Recommend · **Format families:** Code + Text + Data.

A state revenue office must commit one FY2027 Q1 (Jul–Sep 2026) sales-and-use tax forecast
and say whether it clears the enacted target. An outside memo says receipts are well ahead
of plan. The correct, fully-corrected analysis says the opposite.

**Committed answer (for reviewers):** the forecast is **$910,952,000**, which **does not
clear** the enacted **$945,000,000** target — a shortfall of ~**$34,048,000** (implied YoY
**−6.9%**). The decoy ("clears, ~$960M–$1.05B") is what any single mistake produces.

**v2 note:** v1 (single-layer data hygiene) was solved by the top rollout responses. v2 adds
two decisive layers a full-hygiene solve still misses — a **mid-2024 regime break** in the
taxable base, and a **statutory rate cut to 5.75% effective inside the forecast quarter** —
so the correct verdict now needs four correct choices at once (status, revised, regime,
rate), each of which flips the verdict alone.

## What's here

```
prompt.md                      the stakeholder prompt (humanized; no method/trap leakage)
input.zip                      the 17-file data package the solver receives
inputs/                        the unzipped package (source of input.zip)
golden/
  receipts_forecast.py         golden Code deliverable (numpy+pandas; reproduces everything)
  revenue_note.docx            golden Text deliverable (one-page note)
  monthly_actuals.csv          golden Data deliverable
evidence/
  answer_key.md                committed answer to every ask
  trap_trace.md                T1–T8: purpose, location, antidote, correction, effect
  rubric.md                    27-criterion 30/10/60 grading preview
  validation_report.md         the five gates + the v1→v2 hardening
  gate3_live_trap.txt          remove-one-file + mishandle-one-trap results
  cold_run_output.txt          golden re-run from input.zip alone
  manifest.md / manifest.json  per-file sha256/bytes/role
  AUTHORING_NOTES.md           provenance of the numbers, how to retune, caveats
build/                         deterministic generators (seed 20260904) — not shipped to solvers
DESIGN.md                      scenario and trap design rationale
```

## The file bar

17 input files · 5 formats (csv, xlsx, json, md, pdf) · largest table
`sut_returns_ledger_2016_2026.csv` = **24,526 rows** · 9 independently-necessary files ·
2 bait · 2 distractor · 4 reference.

## Verify it yourself

```bash
mkdir /tmp/pkg && (cd /tmp/pkg && unzip -q /path/to/input.zip)
python3 golden/receipts_forecast.py /tmp/pkg      # prints the five figures; writes monthly_actuals.csv
python3 build/package.py                           # rebuilds zip+manifest and cold-runs the golden (9 checks)
python3 build/validate_gates.py                    # remove-one-file + mishandle-one-trap tables
```

Expect: Q1 **$910,952,000** (PI $895,878,000–$926,025,000), TTM $3,921,814,000, MAPE
2.0/1.6/2.2/2.7 (selected 2.1% vs full-history 5.4%), four exclusions, verdict **does not
clear $945,000,000**, largest residual 2024-03 ($133,717,421).

## Remaining before submission

Re-run the 12-response rollout on the v2 archive (pass gate: top-2 average < 50%); read the
generated rubric (this bundle's `rubric.md` is the intended shape); clear the 51 Readiness
checks and submit on Handshake.
