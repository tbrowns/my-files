# Design — `slate-harbor-equinox` (v2)

## The decision and the stakes

The State of Calmarra's Office of Revenue Estimates must commit one FY2027 first-quarter
(Jul–Sep 2026) sales-and-use tax forecast and state whether it clears the enacted
`$945,000,000` first-quarter figure, ahead of the mid-year budget review. An outside memo
says receipts are ~$1.05B, well ahead of plan. The correct, fully-corrected analysis says
the quarter will **miss**, at **$910,952,000** (a $34M shortfall).

## Why this is a forecasting stump, not a "flip the number"

The vendor's $1.05B is wrong because of **forecasting method**, not a planted defect: it
extends a full-history trend and holds the current rate. Getting the answer right requires
doing the forecast correctly — the difficulty the handbook allows (forecasting, method
selection, a binding constraint). Every reported figure is internally true.

## The trap stack (detail in `evidence/trap_trace.md`)

Eight traps; **four flip the verdict independently**, so the correct miss needs all four
right at once:

- **T7 (rate / supersession)** — a statutory rate **cut to 5.75% from 1 Aug 2026**, inside
  the forecast quarter. Apply the current 6.50% and you over-forecast by $75.6M. Antidote:
  the rate schedule + the calendar's forward rates.
- **T8 (regime break)** — the taxable base grew ~4.8%/yr, then **flattened from mid-2024**.
  A full-history trend over-forecasts by $57.9M. Antidote: the BER `taxable_base_outlook`
  note, confirmed by the required backtest (full-history model 5.4% vs 2.1% MAPE).
- **T6 (plumbing)** — a row-for-row ledger sum double-counts amendments/duplicates/reversals
  (+$51.8M). Antidote: the dictionary's recognized-status rule.
- **T3 (supersession)** — the preliminary series runs ~3% hot (+$40.8M). Antidote: the
  revision policy note + the revised series.
- **T2 (one-offs)**, **T4 (partial period)**, **T1 (rate normalization)**, **T5 (CTRAI
  leakage distractor)** shape the supplementary answers and underpin the base.

Every wrong path pushes up to the decoy ("clears the target"); only the fully-correct path
lands the shortfall, robustly (target above the whole 80% PI).

## Why the two new layers (v1 → v2)

v1 was a single-layer hygiene stump and the rollout solved it: a thorough code-running
solver reads every antidote and applies every step. T7 and T8 are the fix — a documented
enacted rate change inside the forecast horizon, and a documented structural break that a
full-history trend misreads. Both defeat a *careful* solve, not just a lazy one, and both
sit in families (forecast-horizon rate exposure; regime detection) the v1 solvers never
engaged.

## The numbers (seeded)

Generator seed **20260904**. Simulated mid-size state: base $3.30B (2016-01), growing
**4.8%/yr through mid-2024, then 0.5%/yr** (documented structural slowdown), holiday-heavy
seasonality, 2% monthly noise. Statutory rate 5.50% → 6.50% (2023-04) → **5.75% (2026-08,
forecast quarter)**. Anomalies injected and reproduced at the return-line grain: the
recognized-status aggregation of the 24,526-row ledger reconciles to the revised series
within $0.50. Target `$945M` fixed in dollars so that the correct forecast misses and every
single-error half-solve clears.

## Determinism and fairness

- **Deterministic:** the correct answer is robust (entire 80% PI below target; shortfall
  ~2.3× the PI half-width). The regime choice is pinned by a documented cause **and** the
  required backtest; the rate is an enacted fact.
- **Discoverable, separated antidotes:** rate cut in the schedule/calendar (not the
  forecast); slowdown in a BER note + the backtest; status rules in the dictionary; revision
  bias in a policy note.
- **No parsing puzzles; source-authentic; no leakage.** The prompt states the stakeholder
  frame and names the files; it never names a method, a trap, or which file settles anything.
