# input.zip — manifest

`input.zip` sha256 `83e96f33acbf61de6512fc0d947d9ddb9260785197b6efdee8cf403e8f0c95d7` · 17 files · 2,722,072 bytes uncompressed

Formats: csv, json, md, pdf, xlsx (5). Independently-necessary files: 9. Largest table: sut_returns_ledger_2016_2026.csv (24,526 rows).

| file | fmt | bytes | role | trap | purpose | sha256 (first 12) |
|---|---|---:|---|---|---|---|
| `DATA_NOTES.md` | md | 2,690 | reference | - | Package overview and file relationships | `b8cafef92d3e` |
| `PROVENANCE.md` | md | 2,183 | reference | - | Provenance and licensing (synthetic; redistributable) | `4260c84b7d11` |
| `collections_operations_log_2016_2026.md` | md | 3,890 | necessary | T2/T4 | Operational events: Sep-2022 outage, Oct-2022 catch-up, Mar-2024 settlement, open July 2026 | `753d307e4f85` |
| `ctrai_activity_index.csv` | csv | 4,446 | distractor | T5 | Advisory covariate; published with a ~10-11 week lag (leakage bait) | `c391f131bd5e` |
| `ctrai_methodology_note.md` | md | 2,004 | distractor | T5 | States CTRAI publication lag / advisory status (antidote to leakage) | `5c156e7e1740` |
| `enacted_budget_fy2027.pdf` | pdf | 3,527 | necessary | - | Enacted FY2027 Q1 target ($945,000,000); the figure the forecast is judged against | `d1273510d62b` |
| `filer_directory.csv` | csv | 11,932 | reference | - | Filer -> sector/region/status | `919451c2df4c` |
| `filing_calendar.csv` | csv | 5,873 | necessary | T4/T7 | Per-period due/close dates, statutory_rate incl. forecast-quarter cut, period status (COMPLETE/OPEN/FUTURE) | `106bf7c002a5` |
| `monthly_receipts_preliminary.csv` | csv | 931 | bait | T3 | Preliminary accrual series, inflated ~+3% for recent months | `0fba8f4ed615` |
| `monthly_receipts_revised.xlsx` | xlsx | 8,853 | necessary | T3 | Official revised monthly series; reconciliation anchor vs the ledger rebuild | `c988fb8d03f6` |
| `revenue_data_dictionary.md` | md | 6,721 | necessary | T6 | Field defs + recognized-receipts basis (CLEARED/AMENDED_FINAL only) + full rate rule | `e55373cfac7a` |
| `revision_policy_note.pdf` | pdf | 3,951 | necessary | T3 | Preliminary runs ~3% above revised; revised supersedes (antidote to preliminary bait) | `544788d633b1` |
| `sector_reference.json` | json | 1,820 | reference | - | Sector code -> name/category | `220d2e1764bb` |
| `statutory_rate_schedule.pdf` | pdf | 4,015 | necessary | T1/T7 | Rate history incl. the 2026-08 cut 6.50->5.75 (antidote to rate-step contamination AND to using the current rate for the forecast quarter) | `353b4c3829ba` |
| `sut_returns_ledger_2016_2026.csv` | csv | 2,653,325 | necessary | T6 | Return-level ledger; source of truth; 24,526 lines; status/dedup trap lives here | `5b01b2c88af8` |
| `taxable_base_outlook.md` | md | 2,387 | necessary | T8 | BER note: the mid-2024 structural base slowdown (antidote to the full-history-trend over-forecast) | `bf958de78b67` |
| `vendor_forecast_memo.pdf` | pdf | 3,524 | bait | T1/T7/T8 | Outside memo projecting ~$1.05B via a full-history trend at the current 6.50% rate; the decoy 'clears' reading | `11295a4997da` |
