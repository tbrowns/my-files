# Answer key — `slate-harbor-equinox` (v2)

*Committed before any model rollout. Every figure is reproduced cold from `input.zip`
by `golden/receipts_forecast.py` (see `cold_run_output.txt`).*

## Committed recommendation

**The committed FY2027 first-quarter (Jul–Sep 2026) state sales-and-use tax forecast is
`$910,952,000`, which does NOT clear the enacted `$945,000,000` first-quarter target** —
a shortfall of ~`$34,048,000` (implied YoY **−6.9%** vs the prior-year quarter). The
correct call rejects the outside vendor memo's ~`$1.05B` "well ahead of plan" reading,
which extends the full-history trend at the current 6.50% rate and so misses two things
the record shows: the taxable base has been flat since a **structural slowdown in
mid-2024**, and the statutory rate **drops to 5.75% from 1 August 2026** (the enacted
relief reduction), lowering two of the three forecast months.

Critical components (all four must be right, or the verdict flips to "clears"):
1. Receipts on the **recognized basis** only (`CLEARED` + `AMENDED_FINAL`), not a row sum.
2. The **revised** series (not the +3% preliminary) / ledger rebuild for recent months.
3. Trend fit on the **post-break regime** (mid-2024 on), not the full-history trend.
4. The **statutory rate in force each forecast month** (Jul 6.50%, Aug/Sep 5.75%).

## Per-deliverable answers

### `receipts_forecast.py` (Code)
| Ask | Committed answer |
|---|---|
| Q1 FY2027 forecast (nearest $000) + 80% PI | **$910,952,000**; 80% PI **$895,878,000 … $926,025,000** (entirely below target) |
| TTM receipts through last actual month (nearest $000) | **$3,921,814,000** (through 2026-06) |
| Holdout MAPE, last four quarters (1 dp) | 2025Q3 **2.0%**, 2025Q4 **1.6%**, 2026Q1 **2.2%**, 2026Q2 **2.7%** (mean 2.1%) |
| Selected model + backtest MAPE vs next-best (1 dp) | Selected **post-break-regime piecewise trend, 2.1%**; next-best **full-history trend, 5.4%** (it over-predicts the post-break quarters — the evidence the break is real) |
| Count of excluded months + one-word reason each | **4** — 2022-09 `outage`, 2022-10 `catchup`, 2024-03 `settlement`, 2026-07 `partial` |

### `revenue_note.docx` (Text)
| Ask | Committed answer |
|---|---|
| Q1 figure (nearest $000) + clears the target? | **$910,952,000**; **does not clear** the enacted $945,000,000 target |
| Implied YoY Q1 growth (1 dp) | **−6.9%** vs prior-year quarter (Jul–Sep 2025 actual $978,459,000); mostly the rate cut |
| Shortfall/surplus vs target (nearest $000) | **$34,048,000 shortfall** |
| Single assumption that moves the number most, and by how much | The **forecast-quarter statutory rate** (current 6.50% flat vs the enacted 5.75%-from-August schedule): **+$75,563,000** (to $986,515,000), which alone clears. The **trend basis** (full-history vs post-break regime) is a close second at **+$57,903,000**. *(Accept either as the largest-moving assumption.)* |

### `monthly_actuals.csv` (Data)
| Ask | Committed answer |
|---|---|
| One row per month: actual, fitted, residual (whole USD) | 127 monthly rows (2016-01 … 2026-07) |
| Flag excluded months + reason | 2022-09 outage, 2022-10 catchup, 2024-03 settlement, 2026-07 partial |
| Month with largest absolute residual + that residual (whole USD) | **2024-03**, residual **+$133,717,421** (the one-time audit settlement) |

## The decoy (intended wrong answer)

A careful-but-incomplete solve lands on **"clears the target, ~$960M–$1.05B."** Each
single mistake clears on its own: ignore the rate cut → $986.5M; ignore the mid-2024
break → $968.9M; sum every ledger line → $962.7M; anchor to preliminary → $951.7M. The
lazy path (all of these) → $1,117.9M. The vendor memo pre-computes ~$1.05B. Every wrong
path clears; only handling all four correctly lands the shortfall (see `gate3_live_trap.txt`).
