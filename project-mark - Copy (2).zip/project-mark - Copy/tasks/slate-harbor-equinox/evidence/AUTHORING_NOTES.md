# Authoring notes — `slate-harbor-equinox` (v2)

## Provenance of every number

Nothing is hand-typed. The corpus is emitted by one seeded generator; the committed figures
come from the golden run against that corpus; the documents cite those figures.

| Layer | Produced by | Notes |
|---|---|---|
| Data package (`inputs/`) | `build/gen_corpus.py` (seed 20260904) | Piecewise base (regime break), rate history incl. the 2026-08 cut, ledger, summaries, covariate, references, calendar. Writes `build/_truth.json`. |
| Committed figures | `golden/receipts_forecast.py` | Reads the package; writes `monthly_actuals.csv` and (EMIT_SUMMARY=1) `golden/_forecast_summary.json`. |
| Scenario PDFs | `build/gen_docs.py` | Rate schedule (with cut), budget ($945M target), vendor decoy (~$1.05B), revision note. |
| Structural-break note | `inputs/taxable_base_outlook.md` | Hand-authored BER note — the T8 antidote. |
| Golden note | `build/gen_docx.js` | One-page `.docx`; figures match the golden. |
| Package + manifest + cold run | `build/package.py` | Builds `input.zip`, hashes, cold-runs the golden (9 checks). |
| Gate-3 evidence | `build/validate_gates.py` | Remove-one-file + mishandle-one-trap. |
| Parameter probe | `build/probe.py`, `build/design_v2.py` | Locate the tier separation; set the target between the correct forecast and the half-solves. |

## v1 → v2

v1 shipped a single-layer hygiene stump; the rollout showed both top responses solved it
(≈90%). v2 keeps the whole v1 corpus and adds **T8 (mid-2024 regime break)** and **T7
(forecast-quarter rate cut to 5.75%)**, from families the v1 solvers never touched. The
committed answer changed from $852M/miss to **$910,952,000 / miss** against a **$945,000,000**
target, and now requires four correct choices at once.

## Key parameters (this build)

- Base: L0 $3.30B; growth 4.8%/yr pre-break, 0.5%/yr post-break; break 2024-07; noise σ 2%.
- Rate: 5.50% → 6.50% (2023-04); 6.50% → 5.75% (2026-08, forecast quarter).
- Anomalies: settlement +$135M (2024-03); outage keep 0.66 (2022-09); catch-up (2022-10);
  partial 0.38 (2026-07). Preliminary bias +3%.
- Enacted target **$945,000,000** (set from `probe.py` so the correct forecast misses and
  every half-solve clears). Committed $910,952,000; PI $895,878,000–$926,025,000.

## How to retune

1. Edit constants in `build/gen_corpus.py` (`G1_ANNUAL`, `G2_ANNUAL`, `BREAK`,
   `RATE_CUT_EFF`, `RATE_NEW`, `SETTLEMENT`, `PARTIAL_TARGET`, `PRELIM_BIAS`, `N`).
2. Re-run `gen_corpus.py` → `probe.py` (reads the tiers; pick a target between the correct
   forecast and `min(half-solves)`).
3. Set `ENACTED_TARGET` in `receipts_forecast.py` and `REGIME_BREAK` if the break moved.
4. Update cited numbers in `gen_docs.py`, `gen_docx.js`, and the `enacted_budget` /
   `statutory_rate_schedule` / `vendor_forecast_memo` text; regenerate; then `package.py`
   (update its cold-run check strings) and `validate_gates.py`.

## Reviewer caveats

- **Machine-generated scenario documents.** The four PDFs and the Markdown notes are scenario
  documents (declared in `PROVENANCE.md`), written to be dense and realistic. If a reviewer
  requires hand-authored input prose, they can be rewritten by hand without touching any
  figure; the data files and the committed answer are unaffected. `taxable_base_outlook.md`
  is already hand-authored.
- **CTRAI is a declared distractor** carrying the T5 leakage bait; the committed model does
  not use it. Not one of the necessary files.
- **`build/`, `evidence/_forecast_summary.json`, `_truth.json` are author-side** — not part
  of the solver's `input.zip`.
- The largest-assumption ask has two co-large movers (rate ≈ +$75.6M, regime ≈ +$57.9M); the
  rubric accepts either. Kept deliberately.

## Snapshot / identifiers
Scenario snapshot **2026-09-04**. Fictional "State of Calmarra." Generator seed **20260904**.
Golden runs on numpy + pandas only. Reproduces on the user's device as well as in the cloud.
