# Rubric (preview of the generated grading surface) — `slate-harbor-equinox` (v2)

The MARK rubric is generated from the prompt contract and the golden and is fixed. This is
the intended shape: **27 criteria**, weighted **30 / 10 / 60**, no single criterion over
20%, totalling 100%. Numeric criteria accept equivalent representations and a reasonable
tolerance band; unit and rounding fold into the value. Nothing rewards showing work.

## Deterministic recommendation + critical components — ~30% (5 criteria)

| # | Wt | Criterion (satisfied when…) |
|---|--:|---|
| R1 | 12% | Commits FY2027 Q1 as a **shortfall against the enacted $945,000,000 target** and does not adopt a "clears / ahead of plan" reading. Fails on any hedge, a clears verdict, or a figure in the inflated ~$950–1,050M band. |
| R2 | 7% | Q1 point forecast ≈ **$910,952,000** to the nearest thousand (accept $895.0M–$925.0M). |
| R3 | 4% | An **80% prediction interval** is reported and its **upper bound is below $945,000,000** (accept upper bound ≤ ~$930M). |
| R4 | 4% | The forecast uses the **post-break (mid-2024 on) regime**, not the full-history trend — i.e., the base contribution is not inflated into the ~$960–1,050M band. |
| R5 | 3% | The forecast applies the **enacted forecast-quarter statutory rate** (5.75% for Aug/Sep 2026), not a flat 6.50%. |

## Instruction-following — 10% (5 criteria)

| # | Wt | Criterion |
|---|--:|---|
| I1 | 2% | `receipts_forecast.py` present and runs, printing the five required figures. |
| I2 | 2% | `revenue_note.docx` present, one page, recommendation stated first. |
| I3 | 2% | `monthly_actuals.csv` present, one row per month. |
| I4 | 2% | The csv carries actual, fitted, and residual columns in whole USD. |
| I5 | 2% | Excluded months flagged with a one-word reason; the script prints the excluded-month count. |

## Supplementary questions and asks — ~60% (17 criteria)

| # | Wt | Criterion |
|---|--:|---|
| S1 | 6% | TTM through the last actual month ≈ **$3,921,814,000** (accept ±1%), recognized basis, excluding the open month. |
| S2 | 5% | Exactly **4** months excluded from training. |
| S3a | 2% | 2022-09 labeled **outage**. |
| S3b | 2% | 2022-10 labeled **catchup**. |
| S3c | 2% | 2024-03 labeled **settlement**. |
| S3d | 2% | 2026-07 labeled **partial** (open month). |
| S4 | 6% | Month with the **largest absolute residual = 2024-03**. |
| S5 | 3% | That residual ≈ **+$133,717,421** (accept ±3%). |
| S6 | 5% | Implied YoY Q1 growth ≈ **−6.9%** (accept −9% to −5%). |
| S7 | 5% | Shortfall vs target ≈ **$34,048,000** (accept $18M–$50M shortfall). |
| S8 | 5% | Single largest-moving assumption = the **forecast-quarter statutory rate** (≈ +$75.6M) **or**, equivalently, the **trend basis** (post-break vs full-history, ≈ +$57.9M); either accepted, with the note that it flips the verdict. |
| S9a | 2% | 2025Q3 holdout MAPE ≈ **2.0%** (accept 1.0–3.2%). |
| S9b | 2% | 2025Q4 holdout MAPE ≈ **1.6%** (accept 0.7–2.8%). |
| S9c | 2% | 2026Q1 holdout MAPE ≈ **2.2%** (accept 1.1–3.4%). |
| S9d | 2% | 2026Q2 holdout MAPE ≈ **2.7%** (accept 1.5–4.0%). |
| S10 | 6% | Selected model = **post-break-regime trend**; next-best = **full-history trend** reported at a clearly higher MAPE (~5.4%), from a rolling-origin backtest. |
| S11 | 3% | The backtest is leakage-safe: CTRAI (if used at all) is aligned to `published_date`; the committed model does not rely on a covariate for the horizon. |

**Totals:** recommendation 30% (5) · instruction 10% (5) · supplementary 60% (17) = **100%**,
**27 criteria**, max single criterion 12% (< 20%).

## Why the top responses cannot clear 50%

The recommendation block (30%) requires **four** correct choices at once — recognized
basis, revised-not-preliminary, post-break regime, and the enacted forecast-quarter rate —
each of which flips the verdict on its own. A strong solver that nails three of the four
still commits the wrong verdict and loses R1/R2/R4/R5. The supplementary block (60%) is
answerable in pieces (TTM, exclusions, largest residual, MAPE), so responses make real
partial progress there — but that is not enough to reach 50% while the recommendation is
wrong.
