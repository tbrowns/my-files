# Validation report — `slate-harbor-equinox` (v2)

## Why v2 exists (the iteration loop)

The **v1** task (single-layer data hygiene: status filter, rate-normalize, exclude
anomalies, prefer revised) **did not stump**. In the recorded rollout both top responses
solved the recommendation (≈90%+): a strong code-running solver reads the dictionary, rate
schedule, ops log, and revision note and applies every step — which was the whole golden
path. Per the handbook, "pure conformance" difficulty gets implemented and finished.

**v2 fix** adds two decisive layers from families the v1 solvers never engaged, so a full
hygiene solve still commits the wrong verdict:
- **T8 — regime break.** The taxable base decelerates sharply from mid-2024. A full-history
  trend (what a careful solver fits) over-forecasts; the correct forecast uses the
  post-break slope. Pinned by a BER note **and** by the required backtest (the full-history
  model's recent MAPE is 5.4% vs 2.1%).
- **T7 — forecast-quarter rate cut.** A statutory reduction to 5.75% takes effect 1 Aug
  2026, inside the forecast quarter. Solvers apply the "current" 6.50%; the correct forecast
  applies the enacted per-month schedule.

With the old hygiene layers still in place, the correct "miss" now needs **four** choices
right at once (status, revised, regime, rate) — each of which flips the verdict alone.

## Gate 1 — Reproduce
`build/package.py` extracts `input.zip` to a clean directory, runs the golden, and confirms
every committed figure (`cold_run_output.txt`; all 9 checks PASS). The manifest lists every
file with SHA-256, bytes, format, and role. No step needs outside knowledge. **Pass.**

## Gate 2 — Fork (one defensible recommendation)
The committed **$910,952,000 / miss** is robust:
- The target ($945M) sits **above the entire 80% PI** ($895.9M–$926.0M); the shortfall
  ($34M) is ~2.3× the PI half-width.
- The regime choice is not a free fork: the mid-2024 break has a **documented structural
  cause** (`taxable_base_outlook.md`) and the **rolling-origin backtest** decisively favors
  the post-break model (2.1% vs 5.4%). A competent analyst who runs the required backtest
  sees the full-history model failing the recent quarters.
- The rate is a **documented enacted fact** (rate schedule + calendar), not a judgment.
Every regime-aware, forecast-rate-respecting specification lands on the shortfall. **Pass.**

## Gate 3 — Live trap
See `gate3_live_trap.txt`.
- **Remove-one-file (mechanical):** removing `sut_returns_ledger_2016_2026.csv`,
  `filing_calendar.csv`, or `monthly_receipts_revised.xlsx` makes the reference solver
  **UNREACHABLE**. The document antidotes (dictionary, rate schedule, **taxable_base_outlook**,
  operations log, revision note, budget) carry knowledge the reference script encodes; for a
  **cold solver** they are independently necessary — remove any and the matching trap is
  undiscoverable. That is ≥4 independently-necessary files for a correct cold solve
  (ledger, dictionary, rate schedule, budget, taxable-base outlook, calendar, revised,
  operations log).
- **Mishandle-one-trap:** **T7 (+$75.6M), T8 (+$57.9M), T6 (+$51.8M), and T3 (+$40.8M) each
  flip the verdict MISS→CLEAR on their own.** T2 changes the excluded-months / largest-
  residual answers. All push toward the decoy. **Pass.**

## Gate 4 — Robustness
The entire 80% PI is below target; the shortfall is ~2.3× the PI half-width; a pure
post-break-window fit and the piecewise fit both miss; ±1 pt of assumed base growth moves
Q1 far less than the $34M gap. Not a knife-edge winner. **Pass.**

## Gate 5 — Rollout (cold-solvable, clean, honest)
The ledger rebuild reconciles to the revised series within $0.50; identifiers join; the open
period and the forecast-quarter rates are identifiable from the calendar; the regime break
and the rate cut are pinned by documents, not intent. The prompt (`prompt.md`) names no
method and no trap. Corpus is synthetic with explicit provenance and a redistributable
license; no personal data. **Pass.**

## Expected rollout texture (prediction)
A strong solver that does the v1 hygiene but fits the full-history trend and applies the
current rate lands on **"clears, ~$960M–$1.05B"** — the designed decoy. Correct handling of
all four layers reaches the shortfall. The supplementary block (60%) — TTM, the four labeled
exclusions, the 2024-03 largest residual, the MAPE ladder, the model comparison — is where
responses make partial progress while the recommendation stays wrong on average.
**The 12-response rollout is the remaining step; the task passes when the top-2 average is
below 50%.**

## Required rollout reporting (to complete at rollout)
Model + version strings · runs per model and the pass denominator · rubric version · transcript
retention · which thresholds are hard gates · for each failed response, the substantive
analytical mistake (expected: full-history trend / current-rate-for-the-forecast-quarter /
naive ledger sum / preliminary anchor).
