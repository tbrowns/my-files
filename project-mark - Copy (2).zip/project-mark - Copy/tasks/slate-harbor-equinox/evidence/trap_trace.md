# Trap trace — `slate-harbor-equinox` (v2)

Eight traps across five families. **Four of them each flip the verdict on their own**
(T7 rate, T8 regime, T6 status, T3 preliminary), so the correct "miss" requires all four
handled at once; the rest shape scope and the supplementary answers. Every wrong path
pushes toward the same decoy ("receipts clear the target"). Dollar effects are from
`gate3_live_trap.txt`.

| # | Family | Purpose (what it does to a solver) | Location (bait) | Antidote (in-corpus) | Correction the analyst must make | Effect if missed |
|---|---|---|---|---|---|---|
| **T7** | C/F + E — rate / supersession | A statutory rate **cut to 5.75% takes effect 1 Aug 2026**, inside the forecast quarter. Solvers apply the "current" 6.50% to the whole quarter and over-forecast. **The single largest flip.** | the forecast itself (Aug/Sep 2026 are unseen) | `statutory_rate_schedule.pdf`; `filing_calendar.csv` (`statutory_rate` for FUTURE periods); the budget notes the relief act | Apply the rate in force each forecast month: Jul 6.50%, Aug/Sep 5.75%. | Q1 **+$75.6M → $986.5M, CLEARS**. |
| **T8** | C / forecasting — regime break | The taxable base grew ~4.8%/yr, then **decelerated sharply from mid-2024** (structural). A full-history trend over-forecasts the near term. | the long, growing history invites a single trend | `taxable_base_outlook.md` (the documented slowdown); the rolling-origin backtest (full-history model fails recent quarters, 5.4% vs 2.1% MAPE) | Fit the trend on the post-break regime (a piecewise slope). | Q1 **+$57.9M → $968.9M, CLEARS**. |
| **T6** | D — plumbing/joins | The ledger is transactional; a row-for-row sum double-counts amendments/duplicates/reversals (+5–6%). | `sut_returns_ledger_2016_2026.csv` (mixed `line_status`) | `revenue_data_dictionary.md` §2 (only `CLEARED`+`AMENDED_FINAL` recognized) | Filter to recognized statuses before aggregating. | Q1 **+$51.8M → $962.7M, CLEARS**. |
| **T3** | E — documents/supersession | The published **preliminary** series runs ~3% above final; anchoring recent months to it inflates the level. | `monthly_receipts_preliminary.csv` (+3%) | `revision_policy_note.pdf`; `monthly_receipts_revised.xlsx` (reconciles to the ledger rebuild) | Use revised where published; ledger rebuild for un-revised recent months. | Q1 **+$40.8M → $951.7M, CLEARS**. |
| **T2** | C — time / one-offs | A one-time March-2024 audit settlement (+$135M) and the Sep-2022 outage / Oct-2022 catch-up contaminate specific months. | those three months in the series | `collections_operations_log_2016_2026.md` (dated events) | Exclude the three anomalous months from training; keep them visible in the actuals. | Changes the **excluded-months** and **largest-residual** answers. |
| **T4** | C — partial period | July 2026 is open; only ~38% has cleared, so it reads far below seasonal norm. | many `PENDING` July lines in the ledger | `filing_calendar.csv` (`period_status = OPEN`); operations log | Treat 2026-07 as partial; last actual = 2026-06. | Changes **TTM / last-actual month** and the excluded-months answer. |
| **T1** | C/F — comparability | Reported dollars step up at the 2023 rate increase (5.50→6.50%); modeling nominal receipts confuses the rate step with base growth. | the historical series | `statutory_rate_schedule.pdf`; dictionary §3; per-row `tax_rate` | Rate-normalize to a base before trending. | Underpins T7/T8; on its own a small direct effect. |
| **T5** | Forecasting — leakage (distractor) | CTRAI is published ~10–11 weeks late; a solver who builds a covariate model and uses contemporaneous CTRAI leaks the target month's shock. | `ctrai_activity_index.csv` (`reference_month` vs `published_date`) | `ctrai_methodology_note.md` (the publication lag) | Don't use CTRAI for the horizon (the committed model doesn't); or lag it. | A bad backtest / model choice for solvers who take the bait. Distractor — not among the necessary files. |

## Composition

- **Four independent flips** — T7 (rate), T8 (regime), T6 (status), T3 (preliminary) —
  each takes the forecast over the $945M target on its own. The correct "miss" ($910.95M)
  needs all four right at once. This is the difficulty: a solver who nails three of four
  still commits the wrong verdict.
- **Scope / supplementary**: T2 and T4 (anomaly and partial-period handling) drive the
  excluded-months, largest-residual, and TTM answers; T1 is the base-normalization
  underpinning; T5 is a distractor-borne leakage bait on the model/MAPE asks.
- All wrong paths push **up**, to the decoy "clears the target." Only the fully-correct
  path lands the shortfall, and it is robust: the target sits above the entire 80% PI, and
  the shortfall (~$34M) is ~2.3× the PI half-width. Not a knife edge.

## Fairness

Every antidote is in-corpus and separated from its bait: the rate cut is in the rate
schedule and the calendar (not announced in the forecast); the slowdown is in a BER note
and is independently confirmed by the required backtest; the status rules are in the
dictionary, not the ledger; the revision bias is in a policy note. The prompt names no
method and no trap. No outside knowledge is required. Ten competent revenue analysts
working these files converge on the same shortfall.
