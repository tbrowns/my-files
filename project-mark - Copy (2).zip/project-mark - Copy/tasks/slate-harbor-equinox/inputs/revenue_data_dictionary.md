# Calmarra Department of Revenue — Sales & Use Tax Data Dictionary

**Office of Revenue Estimates (ORE) · Data Governance reference · Rev. 2026-08**
**Coverage:** state sales-and-use tax (SUT) collections, Jan 2016 – Jul 2026.
**Snapshot date of this extract:** 2026-09-04.

This dictionary governs how the SUT collection files in this package are read. It is
the authoritative description of fields, codes, and the recognized-receipts basis the
Department reports on. Figures published by ORE are built from the return ledger under
the rules below; where a summary file and the ledger disagree, the ledger under these
rules is authoritative.

---

## 1. The return ledger — `sut_returns_ledger_2016_2026.csv`

One row per filing line. A single filer-period ordinarily produces one line, but
corrections, duplicate submissions, and reversals produce additional lines against the
same filer and period. The ledger is transactional: it is **not** pre-deduplicated and
should not be summed row-for-row without applying the line-status rules in §2.

| Field | Type | Definition |
|---|---|---|
| `filing_id` | string | Unique line identifier (`R#######`). One per physical line, including corrections and duplicates. |
| `filer_id` | string | Registered filer account (`CAL-####`). Joins to `filer_directory.csv`. |
| `tax_period` | `YYYY-MM` | Calendar reference month the receipts are **economically attributable to** (the month of the taxable activity), not the month filed or posted. |
| `filed_date` | date | Date the return line was filed. Blank for lines not yet filed. |
| `cleared_date` | date | Date remittance cleared to the Treasury. Blank until cleared. |
| `line_status` | code | Processing state of the line. See §2. |
| `gross_taxable_sales` | USD | Taxable sales reported on the line (the effective tax base for the line). |
| `tax_rate` | decimal | Statutory rate applied to the line for its `tax_period` (see §3). |
| `tax_due` | USD | `gross_taxable_sales × tax_rate`, to the cent. |
| `amount_remitted` | USD | Amount actually remitted on the line. Equals `tax_due` for cleared lines; carries the originally-remitted figure on superseded, duplicate, and reversed lines; `0` on lines not yet cleared. |
| `remit_channel` | code | Remittance channel (ACH, WIRE, PORTAL, CHECK, LOCKBOX). |
| `sector_code` | code | Filer's reporting sector. Joins to `sector_reference.json`. |

## 2. Line-status codes and what counts as receipts

Each line carries exactly one `line_status`. Only the statuses marked **Recognized**
below are counted toward reported receipts. The others are present in the ledger for
audit completeness and **must be excluded** from any receipts total.

| `line_status` | Recognized? | Meaning |
|---|---|---|
| `CLEARED` | **Yes** | A filed return whose remittance has cleared. The normal case. |
| `AMENDED_FINAL` | **Yes** | The current, effective version of a return that was amended. Supersedes its `AMENDED_ORIGINAL`. Carries the correct amount. |
| `AMENDED_ORIGINAL` | No | The superseded original of an amended return. Retained for audit trail. **Do not count** — it is replaced by the paired `AMENDED_FINAL`. |
| `DUPLICATE` | No | A duplicate submission flagged in processing (e.g., a re-file of an already-cleared line). **Do not count.** |
| `REVERSED` | No | A remittance later reversed (returned/NSF/charge-back). **Do not count.** |
| `PENDING` | No | Filed or expected but not yet cleared. Carries `amount_remitted = 0`. **Do not count** as receipts; its presence marks a period still filling in. |

> **Recognized net receipts** for a month =
> Σ `amount_remitted` over lines whose `line_status` ∈ {`CLEARED`, `AMENDED_FINAL`},
> grouped by `tax_period`.
> A row-for-row sum of the ledger over-states receipts because it double-counts
> superseded amendment originals and duplicate submissions and includes reversed lines.

## 3. Statutory rate application

`tax_due` is computed at the statutory state SUT rate **in force for the line's
`tax_period`**. The state rate changes inside and just past the coverage window:

| Period range | Statutory state SUT rate |
|---|---|
| 2016-01 … 2023-03 | 5.50% |
| 2023-04 … 2026-07 | 6.50% |
| 2026-08 … 2027-06 | 5.75% (temporary relief reduction) |

The 2023 increase was enacted by the Revenue Modernization Act of 2022 (Public Act
2022-114), effective **1 April 2023**; the 2026 reduction by the Sales Tax Relief Act of
2026 (Public Act 2026-58), effective **1 August 2026**. The per-period rate is carried on
every ledger line (`tax_rate`) and in `filing_calendar.csv` (`statutory_rate`) **for
every period including upcoming ones**; the enabling instruments and full history are in
`statutory_rate_schedule.pdf`. Reported receipts are stated **gross of rate** — that is,
dollars collected, reflecting both the taxable base and the rate in force — so the
reported-dollars series steps with each rate change even where the underlying base does
not. Any projection of collection dollars for a future period must apply the statutory
rate in force for that period. The **base** (activity net of rate) has its own trajectory;
see `taxable_base_outlook.md`.

## 4. Monthly summary series

Two monthly summary files accompany the ledger. They are **derived** views, not
independent sources; the ledger under §2 is authoritative.

- **`monthly_receipts_revised.xlsx`** (`basis = REVISED_FINAL`) — the Department's
  final revised recognized net receipts by month, published after the revision cycle
  closes. Reconciles to the ledger rebuild under §2. Available through the last closed
  revision month.
- **`monthly_receipts_preliminary.csv`** (`basis = PRELIMINARY_ACCRUAL`) — the early
  accrual estimate ORE publishes shortly after each month-end, before all returns
  clear. Preliminary figures are provisional and are superseded by the revised series;
  their known bias and revision timing are described in `revision_policy_note.pdf`.

## 5. Effective taxable base

Where an analysis needs the underlying economic quantity rather than dollars collected,
the **effective taxable base** for a month is recognized net receipts divided by the
statutory rate in force that month (equivalently, the sum of `gross_taxable_sales` over
recognized lines). This is the rate-neutral measure of taxable activity.

## 6. Reference files

- `filer_directory.csv` — filer account, name, sector, region, registration, status.
- `sector_reference.json` — sector code → name and goods/services category.
- `filing_calendar.csv` — per-period filing due date, period close date, statutory
  rate, and period status (`COMPLETE` once the period has closed; `OPEN` while returns
  are still due or clearing).
