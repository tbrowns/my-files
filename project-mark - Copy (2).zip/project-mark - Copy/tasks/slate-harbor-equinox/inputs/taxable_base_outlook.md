# Taxable Base Outlook — Structural Note

**Calmarra Bureau of Economic Research (BER) · Quarterly economic note · 2026-08**

This note describes the trajectory of the state's sales-and-use tax **base** (taxable
retail activity, net of the statutory rate). It is background for revenue estimation and
does not itself produce a receipts figure.

## A structural break in mid-2024

Through the first half of the last decade the state's taxable base expanded briskly and
without interruption. That pace **broke in mid-2024**. From about the third quarter of
2024 the base has been close to flat: the strong multi-year growth did not resume, and
the flattening has persisted through the most recent data rather than reverting.

The change is **structural, not a seasonal dip or a one-quarter wobble**:

- The Bay District construction cycle that drove much of the 2019–2023 expansion wound
  down through 2024 as the regional infrastructure program completed. The associated
  building-materials, furnishings, and durable-goods activity stepped down with it.
- A major durable-goods manufacturer in the Bay District began a phased closure in 2024,
  with the last lines ceasing in early 2025; supplier and payroll-linked retail activity
  contracted in step.
- Net out-migration from the two largest metro counties turned mildly negative over
  2024–2025, trimming household formation and big-ticket taxable spending.

None of these is expected to reverse over the forecast horizon; the Bureau treats the
post-2024 pace as the prevailing regime rather than a temporary deviation from the
earlier trend.

## What this means for reading the history

A taxable-base series that spans the break carries **two regimes** — the fast pre-2024
expansion and the flat post-2024 pace. The long-run average across both understates how
sharply activity has slowed and overstates where the base sits today. Analysts working
with the full series should be aware that its early years and its recent years are not
governed by the same trend.

The break is in the **base**. It is separate from, and additional to, the statutory-rate
changes documented in the rate schedule.

*Prepared by BER staff economists. Figures underlying this note are drawn from the same
taxable-activity panel used for the CTRAI index; see the CTRAI methodology note for that
series' construction and its publication lag.*
