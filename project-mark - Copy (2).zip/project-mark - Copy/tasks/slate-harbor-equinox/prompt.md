# Prompt: `slate-harbor-equinox`

I run the revenue-estimating desk at the Calmarra Department of Revenue. The enacted
FY2027 budget put a number on first-quarter (Jul-Sep 2026) sales-and-use tax, and the
mid-year review is close. An outside advisory memo just landed on my desk telling me
we're comfortably ahead of plan for the quarter; a couple of my own analysts aren't so
sure, and I don't want to walk into the review leaning on someone else's memo. Before I
put a figure in front of the Budget Director I need one committed number, built from our
own records, that I can stand behind and that someone can re-run.

Everything we work from is in the attached pack (extract `input.zip`): the return
ledger, the monthly series we publish, the rate and filing references, the operations
log, the enacted budget, and the outside memo.

**Give me a single committed forecast of FY2027 first-quarter (Jul-Sep 2026) state
sales-and-use tax receipts, and tell me plainly whether it clears the enacted
first-quarter target.** Then hand me three files.

1. **`receipts_forecast.py`**: a script I can run that reproduces the number from the
   attached pack.
   - Print the committed FY2027 Q1 (Jul-Sep 2026) receipts figure in USD to the nearest
     thousand, with its 80% prediction interval (lower and upper bound) in the same unit.
   - Print the trailing-twelve-month receipts through the last actual month, in USD to
     the nearest thousand.
   - Print the holdout error for each of the last four quarters as MAPE in percent to one
     decimal place.
   - Print the model you selected and its backtest MAPE against the next-best model you
     considered, in percent to one decimal place.
   - Print the count of months excluded from training and a one-word reason label for
     each excluded month.

2. **`revenue_note.docx`**: a one-page note I can forward to the Budget Director.
   - State the Q1 figure in USD to the nearest thousand and whether it clears the enacted
     first-quarter target.
   - State the implied year-over-year growth rate for the quarter, in percent to one
     decimal place.
   - State the size of the shortfall or surplus against the target, in USD to the nearest
     thousand.
   - Name the single assumption that would move the number most, and by how much, in USD
     to the nearest thousand.

3. **`monthly_actuals.csv`**: the monthly series behind the estimate.
   - One row per month with actual and fitted receipts in whole USD, plus a residual
     column (actual minus fitted) in whole USD.
   - Flag the months excluded from training and give the reason for each.
   - Name the single month with the largest absolute residual and give that residual in
     whole USD.
