#!/usr/bin/env python3
"""
FY2027 Secondary Success at-risk reserve pipeline.

Runs end-to-end from the planning workspace (./inputs by default) using only the Python
standard library. Implements the FY2027 Planning Directive (fy2027_planning_directive.md)
on the definitions of the FY2026 Program Rules (grant_program_rules.md) and the
reorganization crosswalk memorandum (aoe_reorganization_crosswalk_memo.md).

Usage:
    python3 reserve_pipeline.py [workspace_dir] [--write out_dir]

Prints: per-file read/kept/excluded counts; planning population and classification counts;
the committed reserve total and the named at-risk list; per-unit PPE context.
Writes (with --write): fy2027_risk_panel.csv, exceptions_log.json.
"""
import csv, json, os, re, statistics, sys

BASE_YEARS = ["1718", "1819", "1920", "2021"]   # Directive 3.1 projection base
BENCHMARK = 80.0                                 # Directive 3.4, compared at one decimal
RESERVE_PER_UNIT = 250000                        # Directive 1
EFFECTIVE_XWALK_SY = "1920"                      # reorganization effective SY2019-20

# Identity crosswalk under Rules 3.4, derived from the workspace records: per-year CCD
# universe status codes and effective dates, and the dashboard's school-by-school
# organizational assignments across the SY2019-20 reorganization.
# Ended ST identity -> successor ST identities.
XWALK_ENDED_TO_SUCC = {
    "SU008": ["SU067"],
    "SU018": ["SU067", "SU009"],
    "SU029": ["SU068"],
    "SU037": ["SU066"],
    "SU038": ["SU066"],
    "SU041": ["SU009"],
    "SU043": ["SU068", "SU069"],
    "SU045": ["SU069"],
    "SU057": ["SU027"],
}

def st_short(st_leaid):
    """'VT-SU061' -> 'SU061'"""
    return st_leaid.split("-", 1)[1] if "-" in st_leaid else st_leaid

def parse_interval(rate):
    """EDFacts rate string -> closed interval (lo, hi) in percent, or None if not reportable."""
    r = (rate or "").strip()
    if not r or r == "PS":
        return None
    if re.fullmatch(r"\d+(\.\d+)?", r):
        v = float(r); return (v, v)
    m = re.fullmatch(r"(\d+)-(\d+)", r)
    if m: return (float(m.group(1)), float(m.group(2)))
    m = re.fullmatch(r"GE(\d+)", r)
    if m: return (float(m.group(1)), 100.0)
    m = re.fullmatch(r"(?:LE|LT)(\d+)", r)
    if m: return (0.0, float(m.group(1)))
    m = re.fullmatch(r"GT(\d+)", r)
    if m: return (float(m.group(1)), 100.0)
    return None

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    ws = args[0] if args else "inputs"
    out_dir = None
    if "--write" in sys.argv:
        i = sys.argv.index("--write")
        out_dir = sys.argv[i + 1] if i + 1 < len(sys.argv) else "."
    P = lambda name: os.path.join(ws, name)
    counts = {}
    exceptions = {"pending_units": [], "excluded_f33_components": [], "crosswalk_applications": [],
                  "unreportable_acgr_rows": []}

    # ---- applicant pool: most recent FINAL (v 1a) universe = SY2023-24 (Rules 2) ----
    roster_file = "ccd_lea_029_2324_w_1a_073124.csv"
    pool, comps, read = {}, {}, 0
    with open(P(roster_file), newline="", encoding="utf-8", errors="replace") as f:
        for r in csv.DictReader(f):
            read += 1
            if r["STATENAME"].strip().upper() != "VERMONT":
                continue
            if r["LEA_TYPE_TEXT"] == "Supervisory union" and r["SY_STATUS_TEXT"] in ("Open", "New", "Reopened"):
                pool[r["LEAID"]] = {"leaid": r["LEAID"], "st": st_short(r["ST_LEAID"]),
                                    "name": r["LEA_NAME"], "union": r["UNION"].strip()}
            if "component" in r["LEA_TYPE_TEXT"]:
                comps[r["LEAID"]] = {"leaid": r["LEAID"], "name": r["LEA_NAME"],
                                     "union": r["UNION"].strip()}
    counts[roster_file] = {"read": read, "kept_su": len(pool), "kept_components": len(comps)}
    su_by_union = {v["union"]: k for k, v in pool.items()}

    # ---- ACGR files: all six ship; window uses the three most recent (Rules 3.1) ----
    acgr = {}     # sy -> st_short -> {"rate","cohort","leaid","name"}
    history = {}  # st_short -> set of sy with any reportable row (for "ACGR reporting history")
    def note(sy, st, leaid, name, rate, cohort):
        iv = parse_interval(rate)
        ok = iv is not None and str(cohort).strip().isdigit()
        if ok:
            acgr.setdefault(sy, {})[st] = {"rate": rate.strip(), "cohort": int(cohort),
                                           "leaid": leaid, "name": name}
            history.setdefault(st, set()).add(sy)
        else:
            history.setdefault(st, set())
            if (rate or "").strip() or str(cohort).strip():
                exceptions["unreportable_acgr_rows"].append(
                    {"sy": sy, "st_leaid": st, "leaid": leaid, "rate": (rate or "").strip(),
                     "cohort": str(cohort).strip(), "reason": "not reportable (Rules 3.2/3.4)"})
        return ok

    # LEAID -> state identity, from the universe files (the SY2015-16 ACGR file predates
    # the ST_LEAID column - schema drift across vintages).
    leaid_to_st = {}
    for rf in ("ccd_lea_029_1819_w_1a_091019.csv", "ccd_lea_029_1920_w_1a_082120.csv",
               roster_file):
        with open(P(rf), newline="", encoding="utf-8", errors="replace") as f:
            for r in csv.DictReader(f):
                if r["STATENAME"].strip().upper() == "VERMONT":
                    leaid_to_st.setdefault(r["LEAID"], st_short(r["ST_LEAID"]))

    wide_files = [("1516", "acgr-lea-sy2015-16.csv"), ("1617", "acgr-lea-sy2016-17.csv"),
                  ("1718", "acgr-lea-sy2017-18.csv"), ("1819", "acgr-lea-sy2018-19-wide.csv")]
    for sy, fn in wide_files:
        read = kept = 0
        with open(P(fn), newline="", encoding="utf-8", errors="replace") as f:
            for r in csv.DictReader(f):
                read += 1
                if r["STNAM"].strip().upper() != "VERMONT":
                    continue
                st = st_short(r["ST_LEAID"]) if r.get("ST_LEAID") else \
                     leaid_to_st.get(r["LEAID"], "LEAID:" + r["LEAID"])
                kept += note(sy, st, r["LEAID"], r["LEANM"],
                             r.get(f"ALL_RATE_{sy}", ""), r.get(f"ALL_COHORT_{sy}", ""))
        counts[fn] = {"read": read, "vt_reportable_all_rows": kept}
    long_files = [("1920", "acgr-lea-sy2019-20-long.csv"), ("2021", "acgr-lea-sy2020-21-long.csv")]
    for sy, fn in long_files:
        read = kept = 0
        with open(P(fn), newline="", encoding="utf-8", errors="replace") as f:
            for r in csv.DictReader(f):
                read += 1
                if r["STNAM"].strip().upper() != "VERMONT" or r["CATEGORY"].strip().upper() != "ALL":
                    continue
                kept += note(sy, st_short(r["ST_LEAID"]), r["LEAID"], r["LEANM"],
                             r.get("RATE", ""), r.get("COHORT", ""))
        counts[fn] = {"read": read, "vt_reportable_all_rows": kept}

    has_history = {st for st, s in history.items() if s}

    # ---- F-33 FY2021 component aggregation (Rules 4) ----
    f33_file = "sdf21_1a.txt"
    f33, read = {}, 0
    with open(P(f33_file), newline="", encoding="latin-1") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            read += 1
            if r["STNAME"].strip().upper() == "VERMONT":
                f33[r["LEAID"]] = r
    counts[f33_file] = {"read": read, "vt_records": len(f33)}

    fin = {k: {"exp": 0, "mem": 0, "ncomp": 0} for k in pool}
    for ck, cv in comps.items():
        su = su_by_union.get(cv["union"])
        if su is None:
            continue
        fr = f33.get(ck)
        if fr is None:
            exceptions["excluded_f33_components"].append(
                {"component_leaid": ck, "component": cv["name"], "su_leaid": su,
                 "reason": "no FY2021 F-33 record"})
            continue
        exp, mem = int(fr["TCURELSC"]), int(fr["V33"])
        if exp < 0 or mem < 0:
            exceptions["excluded_f33_components"].append(
                {"component_leaid": ck, "component": cv["name"], "su_leaid": su,
                 "TCURELSC": exp, "V33": mem,
                 "reason": "NCES nonreporting code (Rules 4.2; F-33 documentation)"})
            continue
        fin[su]["exp"] += exp; fin[su]["mem"] += mem; fin[su]["ncomp"] += 1

    for k in pool:
        a = fin[k]
        pool[k]["ppe"] = round(a["exp"] / a["mem"]) if a["mem"] > 0 else None
        pool[k]["ncomp"] = a["ncomp"]
    ppes = sorted(v["ppe"] for v in pool.values() if v["ppe"] is not None)
    median_ppe = int(statistics.median(ppes))

    # ---- projection base and FY2027 planning classification (Directive 3) ----
    for k, u in pool.items():
        st = u["st"]
        detail = []
        series = []  # per base year: (lo, hi, n) or None
        status = "OK"
        if st not in has_history:
            status = "NO_ACGR_IDENTITY"
        else:
            for sy in BASE_YEARS:
                consts = [st]
                if sy < EFFECTIVE_XWALK_SY:
                    consts += [e for e, succs in XWALK_ENDED_TO_SUCC.items() if st in succs]
                used, missing = [], []
                for c in consts:
                    if c != st and c not in has_history:
                        continue  # never carried a reportable ACGR (Rules 3.4)
                    e = acgr.get(sy, {}).get(c)
                    if e is None:
                        missing.append(c)
                    else:
                        used.append((c, e))
                if len(consts) > 1:
                    exceptions["crosswalk_applications"].append(
                        {"unit": u["name"], "st": st, "sy": sy,
                         "constituents_used": [c for c, _ in used],
                         "constituents_missing": missing})
                if missing or not used:
                    status = "PENDING_GRAD_DATA"
                    series.append(None)
                    detail.append({"sy": sy, "value": "unreportable",
                                   "constituents_missing": missing})
                    continue
                lo = sum(parse_interval(e["rate"])[0] * e["cohort"] for _, e in used)
                hi = sum(parse_interval(e["rate"])[1] * e["cohort"] for _, e in used)
                n = sum(e["cohort"] for _, e in used)
                series.append((lo / n, hi / n, n))
                detail.append({"sy": sy,
                               "values": [{"identity": c, "rate": e["rate"],
                                           "cohort": e["cohort"]} for c, e in used]})
        u["grad_status"] = status
        u["detail"] = detail
        if status == "OK":
            # Directive 3.2: endpoint-wise OLS over the four base years, one step ahead.
            xs = [0.0, 1.0, 2.0, 3.0]
            mx = sum(xs) / 4.0
            sxx = sum((x - mx) ** 2 for x in xs)
            def project(vals):
                my = sum(vals) / 4.0
                b = sum((x - mx) * (v - my) for x, v in zip(xs, vals)) / sxx
                return (my - b * mx) + b * 4.0
            p_lo = project([s[0] for s in series])
            p_hi = project([s[1] for s in series])
            p_lo, p_hi = sorted((max(0.0, min(100.0, p_lo)), max(0.0, min(100.0, p_hi))))
            u["proj22_lo"], u["proj22_hi"] = round(p_lo, 2), round(p_hi, 2)
            # Directive 3.3: planning value = weighted 1920 actual + 2021 actual + projected 2122
            (l20, h20, c20), (l21, h21, c21) = series[2], series[3]
            n = c20 + 2 * c21
            u["w27_lo"] = round((l20 * c20 + l21 * c21 + p_lo * c21) / n, 2)
            u["w27_hi"] = round((h20 * c20 + h21 * c21 + p_hi * c21) / n, 2)
            u["weight_n"] = n
        else:
            u["proj22_lo"] = u["proj22_hi"] = u["w27_lo"] = u["w27_hi"] = u["weight_n"] = None

    # ---- classification and reserve (Directive 3.4, 4) ----
    for k, u in pool.items():
        if u["grad_status"] == "NO_ACGR_IDENTITY":
            u["class"] = "PENDING_NO_ACGR_IDENTITY"
        elif u["grad_status"] == "PENDING_GRAD_DATA":
            u["class"] = "PENDING_GRAD_DATA"
        elif u["w27_hi"] < BENCHMARK:
            u["class"] = "AT_RISK"
        else:
            u["class"] = "NOT_AT_RISK"
    at_risk = sorted([u for u in pool.values() if u["class"] == "AT_RISK"],
                     key=lambda u: (u["w27_hi"], u["leaid"]))
    reserve_total = RESERVE_PER_UNIT * len(at_risk)
    for u in pool.values():
        if u["class"].startswith("PENDING"):
            exceptions["pending_units"].append(
                {"unit": u["name"], "leaid": u["leaid"], "st": u["st"], "class": u["class"],
                 "rule": "Directive 3.1 / Rules 3.4",
                 "detail": u["detail"] if u["detail"] else None})

    # ---- print report ----
    print("=" * 78)
    print("FY2027 SECONDARY SUCCESS AT-RISK RESERVE - PLANNING CERTIFICATION")
    print("=" * 78)
    print("\n-- Input files (records read / kept) --")
    for fn, c in counts.items():
        print(f"  {fn}: {c}")
    from collections import Counter
    cc = Counter(u["class"] for u in pool.values())
    print(f"\n-- Planning population (Directive 2 / Rules 2): {len(pool)} supervisory unions")
    print(f"-- Statewide median PPE, context only (Rules 4.3 method): ${median_ppe:,} across {len(ppes)} units")
    print(f"-- Classification counts: " + ", ".join(f"{k}={v}" for k, v in sorted(cc.items())))
    print(f"\n-- COMMITTED RESERVE (Directive 1): {len(at_risk)} units x ${RESERVE_PER_UNIT:,} = ${reserve_total:,} --")
    for i, u in enumerate(at_risk, 1):
        print(f"  {i:2d}. {u['name']}  [{u['st']}, LEAID {u['leaid']}]")
        print(f"      FY2027 planning interval upper {u['w27_hi']:.2f} (lower {u['w27_lo']:.2f}), "
              f"projected SY2021-22 [{u['proj22_lo']:.2f}, {u['proj22_hi']:.2f}], "
              f"weight {u['weight_n']}, PPE ${u['ppe']:,}" if u['ppe'] else
              f"      FY2027 planning interval upper {u['w27_hi']:.2f} (lower {u['w27_lo']:.2f}), PPE n/a")
    nearest_out = min((u for u in pool.values() if u["class"] == "NOT_AT_RISK"), key=lambda u: u["w27_hi"])
    nearest_in = max(at_risk, key=lambda u: u["w27_hi"])
    print(f"\n-- Boundary: nearest at-risk {nearest_in['name']} ({nearest_in['w27_hi']:.2f}); "
          f"nearest not-at-risk {nearest_out['name']} ({nearest_out['w27_hi']:.2f}) --")
    print(f"-- Exceptions: {len(exceptions['pending_units'])} pending units, "
          f"{len(exceptions['excluded_f33_components'])} excluded F-33 component records, "
          f"{len(exceptions['crosswalk_applications'])} crosswalk applications --")

    # ---- write goldens ----
    if out_dir:
        panel_path = os.path.join(out_dir, "fy2027_risk_panel.csv")
        with open(panel_path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["leaid", "st_id", "unit_name",
                        "base_sy1718", "base_sy1819", "base_sy1920", "base_sy2021",
                        "constituents_pre_sy1920", "proj_sy2122_lower", "proj_sy2122_upper",
                        "fy2027_lower", "fy2027_upper", "weight_n",
                        "ppe_fy21_usd", "components_used", "classification", "reserve_usd"])
            def rate_of(u, sy):
                for d in u["detail"]:
                    if d["sy"] == sy:
                        if "values" in d:
                            return ";".join(f"{v['identity']}:{v['rate']}/{v['cohort']}" for v in d["values"])
                        return "unreportable"
                return ""
            for k in sorted(pool, key=lambda k: pool[k]["name"]):
                u = pool[k]
                cpre = ""
                for d in u["detail"]:
                    if d["sy"] in ("1718", "1819") and "values" in d and len(d["values"]) > 1:
                        cpre = ";".join(sorted({v["identity"] for dd in u["detail"] if dd["sy"] in ("1718", "1819") and "values" in dd for v in dd["values"]}))
                        break
                w.writerow([u["leaid"], u["st"], u["name"],
                            rate_of(u, "1718"), rate_of(u, "1819"), rate_of(u, "1920"), rate_of(u, "2021"),
                            cpre, u["proj22_lo"], u["proj22_hi"], u["w27_lo"], u["w27_hi"], u["weight_n"],
                            u["ppe"], u["ncomp"], u["class"],
                            RESERVE_PER_UNIT if u["class"] == "AT_RISK" else ""])
            w.writerow([])
            w.writerow(["CONTROL", "", f"reserve_total_usd={reserve_total}",
                        f"at_risk_units={len(at_risk)}", f"pool={len(pool)}",
                        f"median_ppe_usd={median_ppe}", f"determinable_ppe={len(ppes)}",
                        f"pending={sum(1 for u in pool.values() if u['class'].startswith('PENDING'))}"])
        with open(os.path.join(out_dir, "exceptions_log.json"), "w", encoding="utf-8") as f:
            json.dump({"reason_codes": {
                "PENDING_GRAD_DATA": "Directive 3.1 / Rules 3.4 - a constituent identity with ACGR history lacks a reportable base-year value",
                "PENDING_NO_ACGR_IDENTITY": "Directive 3.1 / Rules 3.4 - unit has no ACGR reporting identity",
                "F33_EXCLUDED": "Rules 4.2 - NCES nonreporting code or missing record (PPE is context only)"},
                "reserve_total_usd": reserve_total, "at_risk_units": len(at_risk),
                "median_ppe_usd": median_ppe, **exceptions}, f, indent=1)
        print(f"\nWrote {panel_path} and exceptions_log.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
